// Browser smoke of the cascade lane through /dev/lesson (scratch; real Azure + Neon).
import http from "http"; import { readFileSync, writeFileSync } from "fs"; import { execFileSync } from "child_process";
import { createRequire } from "module";
const ROOT = "/home/user/Taxila/";
const require = createRequire(ROOT + "package.json");
const { chromium } = require("playwright");
for (const line of readFileSync(ROOT + ".env.local", "utf8").split("\n")) { const m = line.match(/^([A-Z0-9_]+)=(.*)$/); if (m && !process.env[m[1]]) process.env[m[1]] = m[2].replace(/^"(.*)"$/, "$1"); }
const results = []; const check = (n, ok, d = "") => { results.push(ok); console.log(`${ok ? "PASS" : "FAIL"} ${n}${d ? " — " + d : ""}`); };
// fake mic: repeated child speech
const E = process.env.AZURE_OPENAI_ENDPOINT.replace(/\/+$/, "");
const r = await fetch(E + "/audio/speech", { method: "POST", headers: { "api-key": process.env.AZURE_OPENAI_API_KEY, "content-type": "application/json" }, body: JSON.stringify({ model: "gpt-4o-mini-tts", voice: "coral", input: "Mujhe lagta hai teen chauthai bada hai.", instructions: "Voice of a shy 9-year-old Indian child.", response_format: "pcm" }) });
const sp = Buffer.from(await r.arrayBuffer()); const gap = Buffer.alloc(24000 * 2 * 0.3);
const pcm = Buffer.concat([sp, gap, sp, gap, sp, gap, sp]);
writeFileSync("mic.pcm", pcm); execFileSync("ffmpeg", ["-y", "-loglevel", "error", "-f", "s16le", "-ar", "24000", "-ac", "1", "-i", "mic.pcm", "mic.wav"]);
const { handle } = await import(ROOT + "server/index.js");
const api = http.createServer(handle); await new Promise((r) => api.listen(0, "127.0.0.1", r));
const { createServer } = await import(require.resolve("vite"));
const vite = await createServer({ root: ROOT, configFile: ROOT + "vite.config.ts", logLevel: "warn", server: { port: 0, proxy: { "/api": `http://127.0.0.1:${api.address().port}` } } });
await vite.listen(); const base = vite.resolvedUrls.local[0].replace(/\/$/, "");
const browser = await chromium.launch({ executablePath: "/opt/pw-browsers/chromium", proxy: { server: process.env.HTTPS_PROXY, bypass: "localhost,127.0.0.1" },
  args: ["--use-fake-ui-for-media-stream", "--use-fake-device-for-media-stream", `--use-file-for-fake-audio-capture=${process.cwd()}/mic.wav`, "--autoplay-policy=no-user-gesture-required", `--ignore-certificate-errors-spki-list=${process.argv[2]}`] });
const page = await (await browser.newContext({ permissions: ["microphone"] })).newPage();
const log = []; page.on("console", (m) => log.push(m.text()));
const turns = [], sdp = [], tx = [], tts = [];
page.on("request", (q) => { if (q.url().endsWith("/api/lesson/turn")) turns.push(q.postDataJSON()); });
page.on("response", async (q) => {
  const u = q.url();
  if (u.includes("/realtime/calls")) sdp.push(q.status());
  if (u.endsWith("/api/voice/transcribe")) tx.push([q.status(), await q.text().catch(() => "")]);
  if (u.endsWith("/api/voice/tts-stream")) tts.push([q.status(), q.headers()["x-tts-first-ms"]]);
});
const st = () => page.evaluate(() => ({ conn: document.querySelector('[data-testid="connection"]')?.dataset.connection, status: document.querySelector('[data-testid="status"]')?.dataset.status,
  transport: document.querySelector('[data-testid="cascade-controls"]')?.dataset.transport, caps: [...document.querySelectorAll('[data-testid="caption"]')].map((c) => `${c.dataset.who}: ${c.textContent}`), err: document.querySelector('[data-testid="error"]')?.textContent }));
const level = () => page.evaluate(() => new Promise((res) => { let m = 0; const bar = document.querySelector('[aria-label="teacher level"] span span'); const t = setInterval(() => (m = Math.max(m, parseFloat(bar?.style.width || "0"))), 50); setTimeout(() => (clearInterval(t), res(m)), 1500); }));
try {
  await page.goto(`${base}/dev/lesson`);
  await page.getByTestId("create-family").click();
  await page.getByTestId("start").waitFor({ timeout: 20000 });
  check("cascade is the default mode", await page.getByTestId("mode-cascade").isChecked());
  await page.getByTestId("start").click();
  await page.waitForFunction(() => document.querySelector('[data-testid="connection"]')?.dataset.connection === "connected", null, { timeout: 40000 });
  let s = await st();
  check("STT token minted and Azure answered the transcription-session SDP", sdp[0] === 201 || sdp[0] === 200, `SDP ${sdp[0] ?? "not sent"}`);
  check("link connected", s.conn === "connected", `transport=${s.transport} err=${s.err}`);
  await page.waitForFunction(() => document.querySelector('[data-testid="status"]')?.dataset.status === "speaking", null, { timeout: 20000 }).catch(() => {});
  s = await st();
  check("teacher opening is spoken (streamed PCM)", s.status === "speaking" && tts[0]?.[0] === 200, `tts ${JSON.stringify(tts)} caps=${JSON.stringify(s.caps)}`);
  const lv = await level();
  check("teacher level meter moves (lip-sync)", lv > 0, `peak ${lv}%`);
  if (s.transport === "recording") {
    const btn = page.getByTestId("hold-to-talk");
    const box = await btn.boundingBox();
    await page.mouse.move(box.x + 10, box.y + 10); await page.mouse.down();
    await page.waitForTimeout(300);
    s = await st();
    check("pressing talk stops the teacher (barge-in)", s.status === "listening", s.status);
    await page.waitForTimeout(3200); await page.mouse.up();
    await page.waitForFunction(() => [...document.querySelectorAll('[data-testid="caption"][data-who="child"]')].length > 0, null, { timeout: 20000 }).catch(() => {});
    check("push-to-talk clip transcribed", tx[0]?.[0] === 200, JSON.stringify(tx[0]));
    await page.waitForTimeout(500);
    const t = turns.find((x) => x.childText);
    check("the spoken turn reached the Director (not typed, with ASR confidence)", !!t && !t.typed && typeof t.asrConfidence === "number", JSON.stringify(t));
    await page.waitForFunction(() => document.querySelector('[data-testid="status"]')?.dataset.status === "speaking", null, { timeout: 25000 }).catch(() => {});
    s = await st();
    check("the Director's reply is spoken", s.status === "speaking" && tts.length >= 2, JSON.stringify(s.caps.slice(-3)));
  }
  await page.getByTestId("end").click().catch(() => {}); await page.waitForTimeout(1000);
} catch (e) { check("flow", false, e.message); console.log((await st().catch(() => ({}))), log.slice(-15).join("\n")); }
finally { await browser.close(); await vite.close(); api.close(); }
console.log(`${results.filter(Boolean).length}/${results.length} passed`); console.log("console:", log.filter((l) => /cascade|error/i.test(l)).slice(-8).join("\n"));
process.exit(0);
