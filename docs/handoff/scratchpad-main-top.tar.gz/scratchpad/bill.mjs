const e = process.env;
const tok = await (await fetch(`https://login.microsoftonline.com/${e.AZURE_TENANT_ID}/oauth2/v2.0/token`, { method: "POST", body: new URLSearchParams({ grant_type: "client_credentials", client_id: e.AZURE_SP_CLIENT_ID, client_secret: e.AZURE_SP_SECRET, scope: "https://management.azure.com/.default" }) })).json();
const H = { Authorization: `Bearer ${tok.access_token}` };
const g = async (p) => { const r = await fetch(`https://management.azure.com${p}`, { headers: H }); const t = await r.text(); return `${r.status} ${t.slice(0, 600)}`; };
const sub = `/subscriptions/${e.AZURE_SUBSCRIPTION_ID}`;
console.log("billingAccounts:", await g("/providers/Microsoft.Billing/billingAccounts?api-version=2024-04-01"));
console.log("sub billingProperty:", await g(`${sub}/providers/Microsoft.Billing/billingProperty/default?api-version=2024-04-01`));
console.log("consumption balances:", await g(`${sub}/providers/Microsoft.Consumption/credits/balanceSummary?api-version=2023-05-01`));
console.log("spending limit/sub:", await g(`${sub}?api-version=2022-12-01`));
