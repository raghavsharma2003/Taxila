import { launch, serve, sleep, waitReady, runBot } from "/home/user/Taxila/src/studio-v2/tools/pw.mjs";
const { server, base } = await serve(); const b = await launch(); const p = await b.newPage({ viewport: { width: 1024, height: 640 } });
await p.goto(base + "?engine=vault-heist%401"); await waitReady(p);
for (let i = 0; i < 12; i++) { await runBot(p, { maxMs: 3000 }); console.log(JSON.stringify(await p.evaluate(() => ({ s: window.__sv2.seam(), bot: window.__sv2.bot() })))); }
await b.close(); server.close();
