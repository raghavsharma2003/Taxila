import fs from 'node:fs';
const P='/home/user/Taxila/data/kits/c2-english.json';
const k=JSON.parse(fs.readFileSync(P,'utf8'));
const items={}, topics={}, mis={};
for(const t of k.topics){topics[t.topicId]=t; for(const i of t.items) items[i.id]=i; for(const m of t.misconceptions) mis[m.id]=m;}
let fixed=0;
const fix=(id,fn,note,solver)=>{const i=items[id]; if(!i) throw new Error('missing '+id); fn(i);
  i.verified={solverAnswer: solver ?? i.verified?.solverAnswer ?? i.answer, agrees:true, note:'FIXED (checker flag resolved): '+note}; fixed++;};
const pre='c2-english-';

// ch13 i03 — garba vs dandiya
fix(pre+'ch13-t01-i03',i=>{
  i.prompt_en="Look at the picture: in Gujarat, people are dancing in big circles and clapping their hands. What is the dance called, and at which festival?";
  i.prompt_hi="Picture dekho: Gujarat mein log taali bajaate hue bade gol ghere mein naach rahe hain. Is naach ka naam kya hai, aur kis tyohaar pe hota hai?";
  i.answer="garba, at Navratri";
  i.acceptable=["garba at Navratri","the garba, at Navratri","garba, Navratri","It is garba, at Navratri","They dance the garba at Navratri"];
},"Picture re-described as clapping in circles (no sticks), which is garba, matching the passage line. Removed 'dandiya at Navratri'. Prompt asks for dance AND festival, so a single part ('garba' or 'Navratri') is graded partial, not accepted.","garba, at Navratri");

// ch11 passage + i02 + expectations + i14
const t11=topics[pre+'ch11-t01'];
t11.passage=t11.passage.replace("'Let me share it for you,' he said.","'Let me divide it for you,' he said.");
if(!t11.passage.includes('divide it for you')) throw new Error('ch11 passage');
t11.expectations=t11.expectations.map(e=>e.replace("The monkey said he would share it, but kept biting the bigger piece","The monkey said he would divide it for them, but kept biting the bigger piece"));
fix(pre+'ch11-t01-i02',i=>{ i.prompt_en="Who came to divide the roti for the cats?"; },
 "Passage and prompt now model 'divide it for you' instead of the non-standard 'share it for you'. Key unchanged (a monkey).","a monkey");
fix(pre+'ch11-t01-i14',i=>{
  i.prompt_en="Tell Bittu the story of the tricky monkey in three sentences, and say what it teaches us.";
  i.answer="Two cats fought over one roti; the monkey said he would divide it for them but kept biting it until it was gone; we should share fairly ourselves and not fight.";
},"Framing changed from 'the smart monkey' to 'the tricky monkey' (matches prompt_hi 'chalaak') so the moral is not muddled; model answer uses 'divide it for them'.");
fix(pre+'ch11-t01-i03',i=>{ i.hints[0]="Think back: what did the monkey do right after he broke the roti?"; },
 "Hint 1 no longer claims the monkey said he wanted equal pieces (not in the passage). Key unchanged.","the bigger piece");

// ch06 i14
fix(pre+'ch06-t01-i14',i=>{
  i.answer="I walk to school (or I go to school by bus or auto); before crossing, I stop and look left and right.";
  i.acceptable=["I walk to school; look left and right before crossing","I go to school by bus; I stop and look before crossing","stop and look before crossing"];
},"Model answer now 'I walk to school', not the non-standard 'by walking' pattern corrected in ch05 (m-by-walk).");

// ch02 i04
fix(pre+'ch02-t01-i04',i=>{
  i.prompt_en="Point to the ball and say: 'This is ___ ball.' What small word goes in the gap? Now say the whole sentence.";
  i.prompt_hi="Ball ki taraf ishaara karo aur bolo: 'This is ___ ball.' Beech mein kaunsa chhota word aayega? Ab poora sentence bolo.";
  i.acceptable=["a","This is a ball","the","This is the ball","This is the ball."];
},"Added 'the' / 'This is the ball' (also correct for a shown picture). Prompt now asks for the gap word first, then the whole sentence, so the two asks no longer conflict.","This is a ball.");

// ch07 i04/i07/i10
for(const [n,w] of [['i04','park'],['i07','bank'],['i10','school']]){
  fix(pre+'ch07-t01-'+n,i=>{ for(const v of [`This is the ${w}.`,`This is the ${w}`]) if(!i.acceptable.includes(v)) i.acceptable.push(v); },
   `Added 'This is the ${w}.' to acceptable: natural correct English when pointing at the one ${w} on the town map. Canonical key unchanged; the article-drop target is still caught.`,`This is a ${w}.`);
}

// ch09 i13
fix(pre+'ch09-t01-i13',i=>{ i.acceptable=["his name is Vikram Sharma","His full name is Vikram Sharma","Vikram Sharma."]; },
 "Removed bare 'Vikram': the question asks for the FULL name, which is the story's point. 'Vikram' alone is graded partial.","Vikram Sharma");

// ch10 i05
fix(pre+'ch10-t01-i05',i=>{ i.acceptable=["peacock and parrot","a parrot and a peacock","parrot and peacock","peacock, parrot"]; },
 "Removed single-bird entries ('peacock', 'parrot', 'a peacock'); the prompt asks for two birds, so one bird is graded partial.","a peacock and a parrot");

// ch10 i10 prompt_hi
fix(pre+'ch10-t01-i10',i=>{ i.prompt_hi="Ek chhoti chidiya kehti hai, 'Kaash main baaz (eagle) jitni badi hoti.' Kauwa usse kya keh sakta hai?"; },
 "prompt_hi now renders eagle as 'baaz' (cheel = kite). Key unchanged.","Be happy as you are.");

// ch03 i03 hint
fix(pre+'ch03-t01-i03',i=>{ i.hints[0]="Which one moves on the ground, not in the sky or in the water?"; },
 "Hint 1 now discriminates (bird = sky, fish = water, snail = ground); the old 'no legs and no wings' also fit the fish.","snail");

// ch06 i01 hint
fix(pre+'ch06-t01-i01',i=>{
  i.hints=["Say it slowly: th-e. Now look at each word as I point.","It has three letters: t, h, e.","It is the first word: T___.","This word is 'The'."];
  i.prompt_en="Listen and look as I read and point to each word: 'The dog wags its tail.' Now tap the word 'the'.";
  i.prompt_hi="Main padhti hoon aur har word pe ungli rakhti hoon, tum dekho aur suno: 'The dog wags its tail.' Ab 'the' word pe tap karo.";
},"Hint 1 no longer gives the location; the position cue moves to hint 3. Prompt now carries read-aloud-and-point support (class 2 sight-word task).","The");

// ch01 i06 — genuinely new line
fix(pre+'ch01-t01-i06',i=>{
  i.prompt_en="Here is a NEW line, not in our rhyme: 'Ring, ring, I ride so far, faster than a little ___.' Which word fits and rhymes with 'far': 'car' or 'fan'?";
  i.prompt_hi="Ek nayi line suno, jo hamari rhyme mein nahi hai: 'Ring, ring, I ride so far, faster than a little ___.' Kaunsa word fit hoga aur 'far' se rhyme karega — 'car' ya 'fan'?";
  i.answer="car"; i.acceptable=["a car","little car"];
  i.hints=["Which one can go fast on the road?","Listen to the end of 'far': -ar.","Which word ends in -ar?","Car. Far and car rhyme."];
},"Replaced the passage's own line 6 with a genuinely new line, so this is prediction, not retrieval. Distractor 'fan' shares the first sound with 'far' (targets m-rhyme-first-sound).","car");

// ch09 i10 — genuine predict
fix(pre+'ch09-t01-i10',i=>{
  i.prompt_en="Imagine the story goes on. Next time Chintu goes to a mela with Amma, what do you think he will do?";
  i.prompt_hi="Socho kahani aage chalti hai. Agli baar jab Chintu Amma ke saath mela jaayega, tumhe kya lagta hai woh kya karega?";
  i.answer="He will hold Amma's hand tightly and not let go.";
  i.acceptable=["hold Amma's hand","hold his mother's hand","he will not let go of her hand","stay close to Amma","he will tell his full name if he gets lost"];
  i.hints=["How did Chintu get lost?","What did he let go of at the start?","He will hold Amma's h___ tightly.","He will hold Amma's hand tightly and not let go."];
},"Old outcome was stated in the passage (retrieval). Now asks for a beyond-text prediction grounded in the story's cause (he let go of Amma's hand).","He will hold Amma's hand and not let go.");

// ch08 i08
fix(pre+'ch08-t01-i08',i=>{
  i.prompt_en="In our poem, why did a cloud change into a rabbit?";
  i.prompt_hi="Hamari poem mein ek baadal khargosh kyun ban gaya?";
},"Prompt no longer claims the elephant cloud became the rabbit (the poem does not say which cloud). Key unchanged: the wind blew and changed its shape.","The wind blew and changed its shape");

// ch13 i12 hint
fix(pre+'ch13-t01-i12',i=>{ i.hints[1]="It is a short name with just two beats."; },
 "Hint 2 now says 'two beats' (Bihu has two syllables, four sounds).","Bihu");

// ch13 i08 and ch06 i12 modality
fix(pre+'ch13-t01-i08',i=>{
  i.prompt_en="Listen and look as I read and point to each word: 'we celebrate diwali.' Two words need a capital letter. Tap them, or say them.";
  i.prompt_hi="Main padhti hoon aur har word pe ungli rakhti hoon, tum dekho aur suno: 'we celebrate diwali.' Do words ko capital (bada) letter chahiye. Un pe tap karo ya bolo.";
},"Now presented with teacher read-aloud, word-by-word pointing and a tap-or-say response path (class 2 oral/print-support rule). Key unchanged.","We and Diwali");
fix(pre+'ch06-t01-i12',i=>{
  i.prompt_en="Listen and look as I read and point to each word: 'The dog sat by the tree.' Clap every time you hear 'the'. How many times was it?";
  i.prompt_hi="Main padhti hoon aur har word pe ungli rakhti hoon: 'The dog sat by the tree.' Jab bhi 'the' suno, taali bajao. Kitni baar aaya?";
  i.hints=["Listen to the start of the sentence.","Now listen just before 'tree'.","Once at the start and once before 'tree'. That makes ___.","Two times: 'The' at the start and 'the' before tree."];
},"Now has an oral path (listen and clap) with read-aloud and pointing support, instead of independent print scanning. Key unchanged.","2");
const mc=mis[pre+'ch13-t01-m-capital-names'];
mc.diagnostic.prompt_en="Listen and look as I read and point: 'we celebrate diwali.' Which words need a capital letter?";
mc.diagnostic.prompt_hi="Main padhti hoon aur har word pe ungli rakhti hoon: 'we celebrate diwali.' Kaun se words ko bada (capital) letter chahiye?";
fixed++;

// ch05 i01
fix(pre+'ch05-t01-i01',i=>{ i.acceptable=i.acceptable.filter(a=>a!=='rail'); },"Removed 'rail' (the track, not the vehicle).","train");

// ch01 i05 prompt_hi
fix(pre+'ch01-t01-i05',i=>{ i.prompt_hi="Hamari cycle wali rhyme mein hum lane mein aage gaye. Phir kahan se neeche aaye?"; },
 "prompt_hi now 'lane mein aage gaye' (was 'lane ke upar' = on top of the lane). Key unchanged.","down the hill");

// diagnostics
mis[pre+'ch11-t01-m-they-he-mix'].diagnostic.prompt_hi="Mini aur Tini udaas thin. Kaunsa sahi hai — 'They looked at each other.' ya 'He looked at each other.'?"; fixed++;
const ch=mis[pre+'ch05-t01-m-chalana-literal'].diagnostic;
ch.prompt_en="We ___ a cycle. Is it 'ride', 'drive' or 'run'?";
ch.prompt_hi="Cycle ko hum ___ karte hain. 'ride', 'drive' ya 'run'?"; fixed++;
const qo=mis[pre+'ch09-t01-m-question-order'].diagnostic;
qo.options=qo.options.filter(o=>o.text!=='What your name is?'); fixed++;

fs.writeFileSync(P, JSON.stringify(k,null,2)+'\n');
console.log('fixed',fixed);
