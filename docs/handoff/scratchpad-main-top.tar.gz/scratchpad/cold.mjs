import { performance } from "node:perf_hooks";
const t0 = performance.now();
const { scanSafetyDetail } = await import("/home/user/Taxila/server/director/safety.js");
const tImp = performance.now() - t0;
const lines = ["7", "aap mummy se achhi ho", "haha", "main buddhu hoon", "kyunki 3 jode hain upar neeche aage peeche", "my dog died yesterday", "maine toh sahi bola tha", "Aaj raat ko baat karein?", "I am so tired", "aapka number do na"];
const ts = lines.map((l) => { const a = performance.now(); scanSafetyDetail(l); return (performance.now() - a).toFixed(2); });
console.log("import ms", tImp.toFixed(1), "first calls ms", ts.join(" "));
