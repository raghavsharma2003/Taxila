// D38: teacher lines in tum-forms in lessons whose address is aap (and the reverse), TEST DB, last 7 days. Read-only.
const { q } = await import("/home/user/taxila-int/server/db.js");
const TUM = /(?<![\p{L}\p{M}])(?:tum|tumne|tumhe|tumhein|tumhara|tumhari|tumhare|tumko|tumse|tujhe|तुम|तुमने|तुम्हें|तुम्हारा|तुम्हारी|तुम्हारे|तुमको|तुमसे)(?![\p{L}\p{M}])|(?<![\p{L}\p{M}])(?:batao|bolo|socho|dekho|karo|likho|suno|samjho)(?![\p{L}\p{M}])/u;
const AAP = /(?<![\p{L}\p{M}])(?:aap|aapne|aapko|aapka|aapki|aapke|aapse|आप|आपने|आपको|आपका|आपकी|आपके)(?![\p{L}\p{M}])|(?<![\p{L}\p{M}])(?:bataiye|boliye|sochiye|dekhiye|kijiye|likhiye|suniye)(?![\p{L}\p{M}])/u;
const rows = await q(`select l.id, l.state->'ctx'->>'address' as addr, l.state->'ctx'->>'lang' as lang, c.class_level, t.text
  from turn t join lesson l on l.id = t.lesson_id join child c on c.id = l.child_id
  where t.speaker = 'teacher' and l.started_at > now() - interval '7 days'`);
const by = {};
for (const r of rows) {
  const k = `${r.addr ?? "?"}/${r.lang ?? "?"}`; const b = (by[k] ??= { lines: 0, tum: 0, aap: 0, lessons: new Set(), slipLessons: new Set(), ex: [] });
  b.lines++; b.lessons.add(r.id);
  const t = TUM.test(r.text), a = AAP.test(r.text);
  if (t) b.tum++; if (a) b.aap++;
  const slip = (r.addr === "aap" && t && !a) || (r.addr === "tum" && a && !t);
  if (slip) { b.slipLessons.add(r.id); if (b.ex.length < 4) b.ex.push(`c${r.class_level} ${String(r.text).slice(0, 110)}`); }
}
for (const [k, b] of Object.entries(by)) console.log(k, `lines ${b.lines} tum-form ${b.tum} aap-form ${b.aap} lessons ${b.lessons.size} lessons-with-slip ${b.slipLessons.size}`, "\n   " + b.ex.join("\n   "));
process.exit(0);
