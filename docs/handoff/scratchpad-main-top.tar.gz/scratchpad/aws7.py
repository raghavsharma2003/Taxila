exec(open('awsenv.py').read())
import time
out='/home/user/Taxila/evals/model-refresh-2026-10-04/scout/results/polly/'; import os; os.makedirs(out,exist_ok=True)
T='Achha, toh socho zara. Teen chauthai aur do tihai, in dono mein se kaunsa tukda bada hoga? Pizza se sochkar batao.'
for reg,eng in [('us-east-1','generative'),('us-east-1','neural'),('ap-south-1','neural')]:
    p=boto3.client('polly',region_name=reg); t0=time.perf_counter()
    try:
        o=p.synthesize_speech(Text=T,VoiceId='Kajal',Engine=eng,LanguageCode='hi-IN',OutputFormat='mp3',SampleRate='24000')
        b=o['AudioStream'].read(); f=out+f'kajal-{eng}-{reg}.mp3'; open(f,'wb').write(b); print(reg,eng,'OK',len(b),'bytes',round((time.perf_counter()-t0)*1000),'ms', o['RequestCharacters'],'chars')
    except Exception as e: print(reg,eng,'ERR',str(e)[:150])
