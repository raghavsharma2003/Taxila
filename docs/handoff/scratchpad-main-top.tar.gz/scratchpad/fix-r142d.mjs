import { readFileSync, writeFileSync } from "node:fs";
const f = "/home/user/Taxila/context/inbox/r142d-main.json";
const j = JSON.parse(readFileSync(f, "utf8"));
j.edges = [
  { src: "ms-r142-live", rel: "supersedes", dst: "ms-r141-live" },
  { src: "open-r142-board-pointing-empty", rel: "measured_by", dst: "ms-r142-live-board-pointing" },
  { src: "open-r142-game-request-no-piece", rel: "measured_by", dst: "ms-r142-live-game-request" },
  { src: "open-r142-board-pointing-empty", rel: "constrains", dst: "dc-r5-board-answers-the-ask" },
  { src: "rj-r142-fixed-wait-harness", rel: "part_of", dst: "ms-r142-live" },
];
j.md = {
  measurements: `## Release 14.2 live (main, 2026-10-15)

- **ms-r142-live**: taxila-web--sa978ae2-hanh (a978ae2) serves 100%; previous s1138550-lauy.
  - Canary 4/4 (start 1696 ms).
  - The overflow env and secret names are on the live revision.
  - Hours check: lesson 2 starts 201 at 15:11 IST. Resume PASS (no disclosure).
  - Recorder proof 3/3 typed (after the harness fix), deleted, 0 trace rows.
  - Packaged: w2i 38/39, journey OK, resume PASS, owner-5 10/14.
- **ms-r142-live-board-pointing**: turn-1 picture request across 5 live proofs. The board failed in 14.1 and in 14.2 run 2.
  - luna drafts drew the kit example (1/2 x 3/4) instead of her numbers (3/5 x 2/3 = 6/15): 3/4 drafts, plus one 3278 ms timeout. The template was refused too.
  - She said "Dekhiye … kitne marked parts dikh rahe hain?" to an empty board.
- **ms-r142-live-game-request**: "mujhe game khelna hai" got no_game_piece on 3/3 runs (14.1, 14.2 x2). claim_game rewrote her line to a spoken activity. Forge's fraction game, built at lesson start, was not admitted.`,
  rejected: `## rj-r142-fixed-wait-harness (2026-10-15)
- Tried: a fixed 14 s wait between typed turns in r12-liveproof.
- Broke: her 12.3 s reteach line, plus about 3 s to first sound, outlasted the wait. Type shows only on the child's turn, so turn 2 timed out (2/3) and read as a product failure.
- Fix: wait (up to 45 s) for Type to be visible before each turn. Result 3/3.`,
};
writeFileSync(f, JSON.stringify(j, null, 1) + "\n");
