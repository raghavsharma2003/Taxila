import { arm, loadEnv, SUB_PATH } from "/home/user/Taxila/infra/azure.mjs";
loadEnv();
const S = SUB_PATH();
for (const loc of ["southindia","centralindia","westindia"]) {
  try {
    const r = await arm("GET", `${S}/providers/Microsoft.DBforPostgreSQL/locations/${loc}/capabilities?api-version=2024-08-01`);
    const v = r.value?.[0] || {};
    console.log(loc, JSON.stringify({restricted: v.restricted, reason: (v.reason||"").slice(0,120), versions:(v.supportedServerVersions||[]).map(x=>x.name), editions:(v.supportedFlexibleServerEditions||[]).map(e=>e.name)}));
  } catch (e) { console.log(loc, "ERR", e.message.slice(0,200)); }
}
const s = await arm("GET", `${S}/resourceGroups/taxila-sin/providers/Microsoft.DBforPostgreSQL/flexibleServers/taxila-sin-pg?api-version=2024-08-01`, undefined, {allow404:true});
console.log("server", s ? s.properties?.state : "absent");
