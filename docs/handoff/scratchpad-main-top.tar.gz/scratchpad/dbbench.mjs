import { neon } from "@neondatabase/serverless";
import pg from "/home/user/Taxila/node_modules/pg/lib/index.js";
const url = process.env.DATABASE_URL;
const sql = neon(url);
const t = async (label, fn, n = 6) => { const xs = []; for (let i = 0; i < n; i++) { const t0 = performance.now(); await fn(); xs.push(Math.round(performance.now() - t0)); } console.log(label, xs.join(" ")); };
await t("neon-http", () => sql.query("select 1"));
const pool = new pg.Pool({ connectionString: url.replace("&channel_binding=require", ""), max: 4, ssl: { rejectUnauthorized: true } });
await t("pg-pool  ", () => pool.query("select 1"));
await pool.end();
