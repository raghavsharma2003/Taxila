import http from "http";
import { chromium } from "/home/user/Taxila/node_modules/playwright/index.mjs";
const CSP = "default-src 'none'; script-src 'self'; style-src 'self' 'unsafe-inline'; img-src 'self' data: blob:; font-src 'self'; media-src 'self' blob:; connect-src 'none'; frame-src 'none'; worker-src 'none'; form-action 'none'; base-uri 'none'; object-src 'none'";
const hits = [];
const b = http.createServer((req, res) => { hits.push("B" + req.url); res.writeHead(200, { "content-type": "image/gif" }); res.end(); });
await new Promise((r) => b.listen(0, "127.0.0.1", r));
const B = `http://127.0.0.1:${b.address().port}`;
const frameHtml = `<!doctype html><meta http-equiv="Content-Security-Policy" content="${CSP}"><script type="module" src="/own.js"></script>`;
const ownJs = `window.parent.postMessage({ ownScriptRan: true }, "*");
  new Image().src = "${B}/img"; const s = document.createElement("script"); s.src = "${B}/script.js"; document.head.appendChild(s);
  const i = new Image(); i.onload = () => window.parent.postMessage({ ownImg: true }, "*"); i.src = "/own.gif";`;
const a = http.createServer((req, res) => {
  hits.push("A" + req.url + (req.headers.origin ? ` origin=${req.headers.origin}` : ""));
  if (req.url === "/frame") { res.writeHead(200, { "content-type": "text/html" }); return res.end(frameHtml); }
  if (req.url === "/own.js") { res.writeHead(200, { "content-type": "text/javascript", "access-control-allow-origin": "*" }); return res.end(ownJs); }
  if (req.url === "/own.gif") { res.writeHead(200, { "content-type": "image/gif" }); return res.end(Buffer.from("R0lGODlhAQABAAAAACw=", "base64")); }
  res.writeHead(200, { "content-type": "text/html" });
  res.end(`<script>window.got=[];addEventListener("message",e=>got.push(e.data))</script><iframe sandbox="allow-scripts" src="/frame"></iframe>`);
});
await new Promise((r) => a.listen(0, "127.0.0.1", r));
const browser = await chromium.launch({ executablePath: "/opt/pw-browsers/chromium" });
const page = await browser.newPage();
await page.goto(`http://127.0.0.1:${a.address().port}/`);
await page.waitForTimeout(1500);
console.log("messages from frame:", JSON.stringify(await page.evaluate(() => window.got)));
console.log("requests:", hits);
await browser.close(); a.close(); b.close();
