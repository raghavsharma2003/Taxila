import { readForm } from "/home/user/Taxila/src/duplex/form.ts";
import { valuesOf } from "/home/user/Taxila/src/duplex/numerals.ts";
const I = { form: "integer", slots: 1 }, F = { form: "fraction", slots: 1 }, Y = { form: "yes_no", slots: 1 }, U = { form: "number_unit", slots: 1, units: ["cm", "सेंटीमीटर"] };
const cases = [["बासठ", I], ["sixty", I], ["sixty-two", I], ["sixty two", I], ["दो सौ", I], ["दो सौ बीस", I], ["उम्म", I], ["तीन", F], ["तीन बटा", F], ["तीन बटाचार", F], ["तीन बटा चार", F],
 ["तीन बटा आठ, नहीं नहीं", F], ["तीन बटा आठ नहीं नहीं तीन बटा चार", F], ["आठ corners होते हैं", I], ["उत्तर है पच्चीस", I], ["सात आठ छप्पन", I], ["हाँ", Y], ["नहीं नहीं, नहीं होता", Y], ["हाँ लेकिन", Y],
 ["बारह", U], ["बारह सेंटीमीटर", U], ["12 cm", U], ["3/4", F], ["दो दशमलव पांच", { form: "decimal", slots: 1 }], ["two point five", { form: "decimal", slots: 1 }], ["आठ corners और बारह edges", { form: "integer", slots: 2 }],
 ["आठ corners और", { form: "integer", slots: 2 }], ["सोचने दो", I], ["एक", I], ["पाँच। नहीं, छह फेसेस।", I], ["पांच नहीं", I], ["दूसरा वाला", { form: "choice", slots: 1, options: ["ice", "water", "steam"] }], ["water", { form: "choice", slots: 1, options: ["ice", "water", "steam"] }],
 ["evaporation", { form: "word", slots: 1 }], ["चौबीस, नहीं, बीस", I], ["सत्तर", I], ["उनहत्तर", I], ["अड़तालीस", I]];
for (const [t, e] of cases) { const r = readForm(t, e); console.log(t.padEnd(36), e.form.padEnd(12), r.state.padEnd(17), r.reason.padEnd(26), JSON.stringify(r.values), r.repairOpen ? "REPAIR_OPEN" : "", r.repaired ? "REPAIRED" : ""); }
