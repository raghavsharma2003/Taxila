// Per-turn SYSTEM metadata (no child words, no teacher text) for census findings, read-only production.
import { readFileSync, writeFileSync } from "node:fs";
const { q } = await import("/home/user/taxila-int/server/db.js");
const rows = (r) => r.rows ?? r;
const S = "/tmp/claude-0/-home-user/ecee9fc1-62f9-5f67-a47d-69ca79d9981a/scratchpad";
const want = new Set(process.argv.slice(2));   // codes
const finds = [];
for (const f of ["out-1", "out-2", "out-3"]) for (const L of JSON.parse(readFileSync(`${S}/census/${f}.json`, "utf8")).lessons)
  for (const x of L.findings) if (want.has(x.code)) finds.push({ lesson: L.id, code: x.code, sev: x.severity, turns: x.turns, verified: !!x.verified });
await q("begin read only");
const out = [];
for (const fd of finds) {
  const L = rows(await q(`select id::text from lesson where id::text like $1`, [`${fd.lesson.slice(0, 8)}%`]))[0]?.id;
  if (!L) continue;
  const ev = rows(await q(`select turn, kind, data from trace_event where sid=$1 and turn = any($2) and kind in ('director.turn','classify.verdict','ui.render.tray','ui.chips','studio.slot.revealed','studio.slot.failed','studio.rung_replaced','board.page') order by turn, t`, [L, fd.turns]));
  const per = {};
  for (const e of ev) {
    const p = (per[e.turn] ??= {});
    const d = e.data ?? {};
    if (e.kind === "director.turn") Object.assign(p, { move: d.move?.kind ?? d.move, itemId: d.itemId ?? null, lane: d.lane, phase: d.phase, beat: d.beat?.type ?? d.beat ?? null, guard: (d.guard ?? []).slice?.(0, 4), reasons: (d.reasons ?? []).slice?.(0, 4), replanned: d.replanned || undefined });
    else if (e.kind === "classify.verdict") Object.assign(p, { outcome: d.outcome, source: d.source, flags: Object.entries(d.flags ?? {}).filter(([, v]) => v === true).map(([k]) => k) });
    else if (e.kind === "ui.render.tray") p.tray = d.kind;
    else if (e.kind === "ui.chips") p.chips = (d.ids ?? d.chips ?? []).map?.((c) => (typeof c === "string" ? c : c.id)).slice(0, 6);
    else if (e.kind.startsWith("studio.slot")) (p.studio ??= []).push(`${e.kind.split(".").pop()}:${d.kind ?? ""}/${d.state ?? ""}${d.why ? `/${d.why}` : ""}`);
    else if (e.kind === "studio.rung_replaced" || e.kind === "board.page") (p.studio ??= []).push(e.kind);
  }
  out.push({ ...fd, lesson: fd.lesson.slice(0, 8), perTurn: per });
}
await q("rollback");
writeFileSync(`${S}/caseturns-${[...want].join("-")}.json`, JSON.stringify(out, null, 0));
console.log(out.length, "findings;", JSON.stringify(out).length, "chars");
process.exit(0);
