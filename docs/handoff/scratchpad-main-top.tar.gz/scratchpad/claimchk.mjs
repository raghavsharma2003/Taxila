const { q } = await import("/home/user/taxila-int/server/db.js");
const r = await q(`select to_char(t,'HH24:MI:SS') at, sid, turn, data->'reasons' reasons, data->'guard' guard from trace_event where kind = 'director.turn' and t > now() - interval '50 minutes'
  and (data::text ilike '%claim_visual%' or data::text ilike '%claim_request%') order by t`);
for (const x of r) console.log(x.at, x.sid.slice(0, 8), x.turn, JSON.stringify((x.reasons ?? []).filter((y) => /claim|request|studio|say\./.test(y))), JSON.stringify(x.guard?.caught ?? []));
process.exit(0);
