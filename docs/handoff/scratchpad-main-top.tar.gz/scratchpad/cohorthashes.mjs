// Prints ONE comma-joined list of sha256(lower(email)) for: guardians whose hash starts with one of --prefix p1,p2 (read from
// production), plus each --email given. For capture into a shell variable only (never echo it). Exits 1 unless every prefix
// matched exactly one guardian.
import { createHash } from "node:crypto";
const { neon } = await import("/home/user/Taxila/node_modules/@neondatabase/serverless/index.mjs");
const a = process.argv.slice(2), opt = (k) => { const i = a.indexOf(k); return i >= 0 ? a[i + 1] : ""; };
const prefixes = opt("--prefix").split(",").filter(Boolean), emails = opt("--email").split(",").filter(Boolean);
const h = (e) => createHash("sha256").update(String(e).trim().toLowerCase()).digest("hex");
const rows = await neon(process.env.DATABASE_URL).query("select email from guardian");
const out = [];
for (const p of prefixes) {
  const m = rows.map((r) => h(r.email)).filter((x) => x.startsWith(p));
  if (m.length !== 1) { console.error(`prefix ${p}: ${m.length} matches`); process.exit(1); }
  out.push(m[0]);
}
for (const e of emails) out.push(h(e));
process.stdout.write([...new Set(out)].join(","));
