import { readFileSync } from "fs";
import { signalsOf } from "/home/user/Taxila/server/relational/signals.js";
const texts = new Set();
const walk = (o) => { if (!o) return; if (Array.isArray(o)) return o.forEach(walk); if (typeof o === "object") for (const [k,v] of Object.entries(o)) { if (typeof v === "string" && /^(childText|child|text|said|reply)$/.test(k) && v.length < 300) texts.add(v); else walk(v); } };
for (const f of ["evals/comprehension-sim/results/comp-sim-2026-10-02.json","evals/comprehension-sim/results/comp-sim-2026-10-02-llm-echo.json"]) { try { walk(JSON.parse(readFileSync("/home/user/Taxila/"+f,"utf8"))); } catch(e){console.log(f,e.message);} }
let n=0; const hits={}; const ex={};
for (const t of texts) { n++; for (const s of signalsOf(t,{harm:false})) { const k=s.kind+(s.thirdParty?"3P":""); hits[k]=(hits[k]||0)+1; (ex[k] ??= []).length<4 && ex[k].push(t.slice(0,90)); } }
console.log("n",n,hits); for (const k of ["goodbye","end_request","contact_ask","contact_ask3P","romance","goodbye_distress","secret_ask"]) if (ex[k]) console.log(k, ex[k]);
