import fs from "node:fs";
import { splitOf } from "/home/user/Taxila/evals/duplex/taxilafdb/split.mjs";
const sc=JSON.parse(fs.readFileSync("/home/user/Taxila/evals/duplex/taxilafdb/data/scenarios.json")).scenarios.filter(s=>s.family==="F9");
for(const s of sc) console.log(splitOf(s), s.sub, s.id, s.overlays.map(o=>o.kind+"@"+o.gainDb+" "+(o.text||"")).join("|"));
