import sys, urllib.request, urllib.parse, re, html
q=sys.argv[1]; n=int(sys.argv[2]) if len(sys.argv)>2 else 5
url="https://export.arxiv.org/api/query?"+urllib.parse.urlencode({"search_query":q,"max_results":n,"sortBy":"relevance"})
x=urllib.request.urlopen(url,timeout=60).read().decode()
for e in x.split("<entry>")[1:]:
    t=re.search(r"<title>(.*?)</title>",e,re.S).group(1); s=re.search(r"<summary>(.*?)</summary>",e,re.S).group(1)
    i=re.search(r"<id>(.*?)</id>",e).group(1); p=re.search(r"<published>(.*?)</published>",e).group(1)[:10]
    a=re.findall(r"<name>(.*?)</name>",e)[:4]
    print("##",' '.join(t.split()),"|",p,"|",i,"|",'; '.join(a)); print(' '.join(s.split())[:1700]); print()
