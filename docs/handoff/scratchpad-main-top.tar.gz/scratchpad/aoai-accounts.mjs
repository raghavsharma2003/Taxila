// Lists the subscription's Cognitive Services accounts (name, kind, region) and their deployment names + capacity. No keys.
import { arm, SUB_PATH } from "/home/user/Taxila/infra/azure.mjs";
const accounts = [];
for (let page = `${SUB_PATH()}/providers/Microsoft.CognitiveServices/accounts?api-version=2024-10-01`; page;) {
  const r = await arm("GET", page); accounts.push(...(r.value || [])); page = r.nextLink ? r.nextLink.replace(/^https:\/\/management\.azure\.com/, "") : null;
}
for (const a of accounts) {
  const deps = [];
  if (/OpenAI|AIServices/.test(a.kind)) for (let page = `${a.id}/deployments?api-version=2024-10-01`; page;) {
    const r = await arm("GET", page); deps.push(...(r.value || [])); page = r.nextLink ? r.nextLink.replace(/^https:\/\/management\.azure\.com/, "") : null;
  }
  console.log(`${a.name}  kind=${a.kind}  region=${a.location}  rg=${a.id.split("/")[4]}`);
  for (const d of deps) console.log(`    ${d.name}  model=${d.properties?.model?.name}@${d.properties?.model?.version ?? ""}  sku=${d.sku?.name}/${d.sku?.capacity}`);
}
