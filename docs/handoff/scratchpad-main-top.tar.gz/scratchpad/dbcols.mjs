// READ-ONLY: column names of the given tables on the production DB (no values).
const { neon } = await import("/home/user/Taxila/node_modules/@neondatabase/serverless/index.mjs");
const sql = neon(process.env.DATABASE_URL);
for (const t of process.argv.slice(2)) {
  const r = await sql.query("select column_name, data_type from information_schema.columns where table_name=$1 order by ordinal_position", [t]);
  console.log(`${t}: ${r.map((c) => c.column_name + ":" + c.data_type.replace("timestamp with time zone", "tstz").replace("character varying", "varchar")).join(", ")}`);
}
