const { q } = await import("/home/user/taxila-int/server/db.js");
const rows = (r) => r.rows ?? r;
const ids = process.argv.slice(2);
await q("begin read only");
console.table(rows(await q(`select left(id::text,8) id, started_at, ended_at from lesson where id::text = any($1) order by started_at`, [ids])));
await q("rollback"); process.exit(0);
