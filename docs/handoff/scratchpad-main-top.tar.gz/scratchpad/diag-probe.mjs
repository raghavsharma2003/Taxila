import { withTestAccount } from "/home/user/Taxila/tests/prod/lib.mjs";
import { turner } from "/home/user/Taxila/tests/prod/_w1a.mjs";
await withTestAccount(async ({ api, child }) => {
  const s = await api("POST", "/api/lesson/start", { childId: child.id, mode: "text" });
  const t = turner(api, s.lessonId);
  let last = s;
  for (let i = 0; i < 16 && !last.end; i++) {
    const ui = last.ui ?? {}; const it = last.debug?.item;
    let r;
    if (ui.chips?.length) {
      const k = it?.answer != null ? ui.chips.find((c) => c.label === String(it.answer)) : null;
      r = await t.tap(k ?? ui.chips[0]); console.log(`TAP ${JSON.stringify(k ?? ui.chips[0])} key=${it?.answer} item=${it?.id}`);
    } else if (ui.ask?.itemId) { r = await t.say(String(it?.answer ?? "10")); console.log(`SAY ${it?.answer}`); }
    else { r = await t.help("know", "I know this"); console.log("KNOW"); }
    console.log(`  -> ${r.move?.kind} item=${r.move?.itemId} verdict=${r.ui?.verdict} chips=${JSON.stringify(r.ui?.chips)} | ${r.teacherReply}`);
    last = r;
  }
}, { tag: "w1a-diag", child: { firstName: "Aarav", classLevel: 2, languagePref: "hinglish", interests: ["cricket"] } });
