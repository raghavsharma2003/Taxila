const { q } = await import("/home/user/taxila-int/server/db.js");
const rows = (r) => r.rows ?? r;
await q("begin read only");
console.table(rows(await q(`
  select date_trunc('hour', e.t) h, count(*) filter (where e.data->>'lane'='CHAT' and e.data->>'deployment'='taxila-fast') reply_calls,
    count(*) filter (where e.data->>'lane'='CHAT' and e.data->>'deployment'='taxila-fast' and e.data->>'status'='timeout') reply_timeouts,
    count(*) filter (where e.data->>'deployment'='grok-4-1-fast-non-reasoning') grok_calls,
    count(*) filter (where e.data->>'deployment'='grok-4-1-fast-non-reasoning' and e.data->>'status'='timeout') grok_timeouts,
    count(distinct e.sid) lessons
  from trace_event e where e.kind='model.call' and e.t > now() - interval '7 days' and exists (select 1 from lesson l where l.id::text = e.sid)
  group by 1 order by 1`)));
console.table(rows(await q(`
  with m as (select e.sid, e.turn, e.t, e.data from trace_event e where e.kind = 'model.call' and e.t > now() - interval '7 days'
             and exists (select 1 from lesson l where l.id::text = e.sid) and e.data ? 'ms' and e.data->>'deployment' = 'grok-4-1-fast-non-reasoning'),
  lab as (select sid, turn, min(t)::date d, max((data->>'ms')::float) ms from m where data->>'promptId' like 'You label one reply%' group by 1,2),
  bes as (select sid, turn, max((data->>'ms')::float) ms, bool_or(data->>'status'='timeout') tout from m where data->>'promptId' like 'A reply from an Indian school child%' group by 1,2)
  select l.d, count(*) pairs, round(percentile_cont(0.5) within group (order by greatest(0, b.ms - l.ms))) add_p50,
    round(percentile_cont(0.9) within group (order by greatest(0, b.ms - l.ms))) add_p90, count(*) filter (where b.ms > l.ms) slowed,
    count(*) filter (where b.tout) beside_timeouts, round(percentile_cont(0.5) within group (order by l.ms)) label_p50, round(percentile_cont(0.5) within group (order by b.ms)) beside_p50
  from lab l join bes b using (sid, turn) group by 1 order by 1`)));
await q("rollback"); process.exit(0);
