import fs from "node:fs"; import path from "node:path";
import { yin } from "/home/user/Taxila/src/voice/dsp.ts";
const SR=16000;
function rng(seed){let s=seed>>>0;return()=>{s|=0;s=(s+0x6d2b79f5)|0;let t=Math.imul(s^(s>>>15),1|s);t=(t+Math.imul(t^(t>>>7),61|t))^t;return((t^(t>>>14))>>>0)/4294967296;};}
// the generator's physics (mix.mjs cooker): a ~3 kHz tone with 6 Hz vibrato and hiss — re-synthesised here with fresh seeds
function cooker(ms, r){ const n=Math.round(ms*SR/1000), out=new Float32Array(n); const f=2800+r()*400; let ph=0; for(let i=0;i<n;i++){const t=i/SR, env=Math.min(1,t/0.15)*Math.min(1,(n-i)/(0.3*SR)); ph+=2*Math.PI*(f+60*Math.sin(2*Math.PI*6*t))/SR; out[i]=env*(Math.sin(ph)+0.25*(r()*2-1));} let s=0; for(const v of out)s+=v*v; const g=0.1/Math.sqrt(s/n); for(let i=0;i<n;i++) out[i]*=g; return out;}
const f0s=[]; for (let seed=1; seed<=20; seed++){ const x=cooker(2000,rng(seed*7919)); for(let i=0;i+640<=x.length;i+=320){ const f=yin(x.subarray(i,i+640),SR,70,600).f0; f0s.push(f);} }
const v=f0s.filter(Boolean).sort((a,b)=>a-b); console.log("cooker frames", f0s.length, "with f0", v.length, "p10/50/90", v[Math.floor(v.length*.1)]?.toFixed(0), v[v.length>>1]?.toFixed(0), v[Math.floor(v.length*.9)]?.toFixed(0));
// child speech f0 on TRAIN streams (child frames only, her silent, no overlay)
const ST=process.env.TAXILA_FDB_STREAMS; const c=[]; let n=0;
for (const f of fs.readdirSync(ST).filter(x=>x.endsWith(".json"))) { const d=JSON.parse(fs.readFileSync(path.join(ST,f))); if (d.meta.split!=="train") continue; if(++n>300) break; const fr=d.frames; for(let i=0;i<fr.t.length;i++) if(fr.childOn[i]&&!fr.ovOn[i]&&fr.f0[i]) c.push(fr.f0[i]); }
c.sort((a,b)=>a-b); console.log("child f0 (TRAIN, 300 streams) n", c.length, "p50", c[c.length>>1], "p90", c[Math.floor(c.length*.9)], "p99", c[Math.floor(c.length*.99)], "frac>=500", (c.filter(x=>x>=500).length/c.length).toFixed(4));
