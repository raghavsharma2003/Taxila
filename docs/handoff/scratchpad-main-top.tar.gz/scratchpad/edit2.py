p='/home/user/Taxila/evals/voicesig/train/train_filler.py'
s=open(p).read()
a="""        if i1 > i0:
            lab[i0:i1] = np.maximum(lab[i0:i1], l) if l == 1 else np.where(lab[i0:i1] == 1, 1, l)"""
assert a in s
s=s.replace(a,"""        if i1 > i0:
            cur = lab[i0:i1]
            if l == 1:
                cur[:] = 1
            elif l == 0:
                cur[cur != 1] = 0""")
a="""                speech_min += d["speech"].sum() * 0.02 / 60
                hs = heur_runs_eval([d])
            fl = sum(1 for d in fs for _ in [0])
"""
assert a in s
s=s.replace(a,"""                speech_min += d["speech"].sum() * 0.02 / 60
""")
open(p,'w').write(s); print('ok')
