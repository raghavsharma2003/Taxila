const { AZURE_TENANT_ID: t, AZURE_SP_CLIENT_ID: c, AZURE_SP_SECRET: s, AZURE_SUBSCRIPTION_ID: sub } = process.env;
const tok = await (await fetch(`https://login.microsoftonline.com/${t}/oauth2/v2.0/token`, { method: "POST", body: new URLSearchParams({ grant_type: "client_credentials", client_id: c, client_secret: s, scope: "https://management.azure.com/.default" }) })).json();
const H = { authorization: `Bearer ${tok.access_token}` };
const get = async (u) => (await fetch(`https://management.azure.com${u}`, { headers: H })).json();
const apps = await get(`/subscriptions/${sub}/providers/Microsoft.App/containerApps?api-version=2024-03-01`);
for (const a of apps.value || []) {
  const env = a.properties?.template?.containers?.[0]?.env || [];
  const keep = env.filter(e => /^(DEPLOY_|TAXILA_STT|TAXILA_SPECULATE|TAXILA_CLASSIFY|AZURE_SPEECH_REGION|TAXILA_LANE|AZURE_OPENAI_ENDPOINT_)/.test(e.name));
  console.log(`# ${a.name} ${a.location} rev=${a.properties?.latestRevisionName}`);
  for (const e of keep) console.log(`  ${e.name}=${e.secretRef ? "<secretRef>" : /ENDPOINT/.test(e.name) ? (e.value||"").replace(/https:\/\/([^.]+)\..*/, "$1") : e.value}`);
}
