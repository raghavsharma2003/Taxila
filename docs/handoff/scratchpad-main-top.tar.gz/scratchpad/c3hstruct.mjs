import fs from "fs";
const k=JSON.parse(fs.readFileSync("/home/user/Taxila/data/kits/c3-hindi.json","utf8"));
const s=fs.readFileSync("/home/user/Taxila/data/kits/c3-hindi.json","utf8");
const pre=[...s.matchAll(/[क़-य़]/g)].length, nuk=[...s.matchAll(/़/g)].length;
console.log("precomposed nukta letters",pre,"combining nukta",nuk);
const ids=new Set();
for(const t of k.topics){
  const mis=new Set(t.misconceptions.map(m=>m.id)); const sk=new Set(t.skills.map(x=>x.id));
  const kinds=new Set(t.items.map(i=>i.kind));
  if(kinds.size<5) console.log(t.topicId,"kinds",kinds.size);
  if(t.items.length<10||t.items.length>16) console.log(t.topicId,"count",t.items.length);
  for(const m of t.misconceptions){ const c=m.diagnostic.options.filter(o=>o.correct).length; if(c!==1) console.log(m.id,"correct count",c);
    for(const o of m.diagnostic.options) if(o.misconceptionId && !mis.has(o.misconceptionId)) console.log("DANGLING opt", m.id, o.text, o.misconceptionId);
    if(m.diagnostic.options[0].correct!==true) console.log("correct not at 0", m.id);}
  for(const i of t.items){ if(ids.has(i.id)) console.log("dup",i.id); ids.add(i.id);
    if(!sk.has(i.skillId)) console.log("bad skill",i.id);
    if(i.targetsMisconception && !mis.has(i.targetsMisconception)) console.log("bad TM",i.id);
    if(i.hints.length!==4) console.log("hints",i.id,i.hints.length);
    if(i.acceptable.length>8) console.log("acc>8",i.id,i.acceptable.length);
    for(const a of i.acceptable) if(a.length>60) console.log("acc>60",i.id,a);
    if(i.verified) console.log("already verified", i.id);
  }
  // misconceptions with no targeting item
  for(const m of t.misconceptions) if(!t.items.some(i=>i.targetsMisconception===m.id)) console.log("no item targets", m.id);
}
