import { readdirSync, readFileSync } from "node:fs";
import { normalizeKit } from "/home/user/Taxila/server/content/kits.js";
import { fadeItem, fadeStepIndex, blankOf, fadedContent, workedLeadContent, fadeBoard, gapGivenAway } from "/home/user/Taxila/server/director/fading.js";
import { revealsAnswer } from "/home/user/Taxila/server/director/items.js";
const dir = "/home/user/Taxila/data/kits/";
let n=0, fade=0, old=0, leak=0, boardNoGap=0, boardTrunc=0, all=0, allFade=0, allNoGap=0;
for (const f of readdirSync(dir).filter((x) => /^c\d+-[a-z]+\.json$/.test(x))) {
  const d = JSON.parse(readFileSync(dir+f,"utf8"));
  for (const t of d.topics) {
    const kit = normalizeKit(t, { topicId: t.topicId, verified: true });
    const launch = d.class>=4 && d.class<=7;
    const we = kit.workedExample;
    all++;
    const it = fadeItem(kit, { band: "B3" });
    if (it) { allFade++; const i=Number(it.id.slice(5)); if (!/_{2,}/.test(fadeBoard(we,i).value)) allNoGap++; }
    if (!launch) continue;
    n++;
    if (we?.steps) { for (let i=we.steps.length-1;i>=0;i--) if (blankOf(we.steps[i], we.fadedVersion?.[i])) { old++; break; } }
    if (!it) continue;
    fade++;
    const i = Number(it.id.slice(5));
    const txt = [...workedLeadContent(we,i), ...fadedContent(we,i).slice(0,2)].join(" ");
    if (revealsAnswer(txt, it)) leak++;
    const b = fadeBoard(we,i).value;
    if (!/_{2,}/.test(b)) boardNoGap++;
    if (b.includes("…")) boardTrunc++;
  }
}
console.log({ launchKits:n, oldRecoverable:old, fadeNow:fade, leakRealItem:leak, boardNoGap, boardTrunc, all, allFade, allNoGap });
let shown=0;
for (const f of readdirSync(dir).filter((x) => /^c[4-7]-[a-z]+\.json$/.test(x))) {
  const d = JSON.parse(readFileSync(dir+f,"utf8"));
  for (const t of d.topics) {
    const kit = normalizeKit(t, { topicId: t.topicId, verified: true });
    const it = fadeItem(kit, { band: "B3" }); if (!it) continue;
    const we = kit.workedExample; const i = Number(it.id.slice(5));
    const parts = [...workedLeadContent(we,i), ...fadedContent(we,i).slice(0,2)];
    if (revealsAnswer(parts.join(" "), it) && shown++ < 6) console.log(t.topicId, "| key:", it.answer, "|", parts.map(p=>[p.slice(0,90), revealsAnswer(p,it)]));
  }
}
