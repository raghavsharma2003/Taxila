process.env.DATABASE_URL = process.env.TEST_DATABASE_URL;
const { q } = await import("/home/user/taxila-1441/server/db.js");
const rows = (r) => r.rows ?? r;
await q("begin read only");
const all = rows(await q(`select l.id::text id, l.ended_at, l.parent_note pn, l.summary sm, l.state->'ctx'->>'teacherName' tname, c.first_name fn from lesson l join child c on c.id=l.child_id where l.parent_note is not null and l.ended_at > now() - interval '30 days' order by l.ended_at`));
const esc = (s) => s.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
const byDay = {};
for (const r of all) {
  if (!r.tname || !r.fn || r.tname === r.fn) continue;
  const tRe = new RegExp(`\\b${esc(r.tname)}\\b`, "i"), cRe = new RegExp(`\\b${esc(r.fn)}\\b`, "i");
  const d = r.ended_at.toISOString().slice(0, 10);
  const b = (byDay[d] ??= { n: 0, teacherInNote: 0, opensTeacher: 0, childMissing: 0, summaryTeacherAsChild: 0, fallback: 0 });
  b.n++;
  if (/^Today .* practised .* with /.test(r.pn)) b.fallback++;
  if (tRe.test(r.pn)) b.teacherInNote++;
  if (new RegExp(`^\\s*${esc(r.tname)}\\b`, "i").test(r.pn)) b.opensTeacher++;
  if (!cRe.test(r.pn)) b.childMissing++;
  if (new RegExp(`\\b${esc(r.tname)}\\s+(practised|practiced|worked|said|asked|used|tried|showed|identified|learned|learnt)`, "i").test(r.pn + " " + r.sm)) b.summaryTeacherAsChild++;
}
console.table(byDay);
const recent = all.filter((r) => r.tname && new RegExp(`\\b${esc(r.tname)}\\s+(practised|practiced|worked|said|asked|used|tried|showed|identified|learned|learnt)`, "i").test(r.pn));
console.log("teacher-as-actor notes:", recent.length);
for (const r of recent.slice(-6)) console.log(r.id.slice(0, 8), r.ended_at.toISOString().slice(0, 16), `child=${r.fn} teacher=${r.tname}`, "|", r.pn.slice(0, 220));
await q("rollback"); process.exit(0);
