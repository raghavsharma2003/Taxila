import os
for line in open('/home/user/Taxila/.env.local'):
    line=line.strip()
    if line.startswith('AWS_') and '=' in line:
        k,v=line.split('=',1); os.environ[k]=v.strip().strip('"').strip("'")
os.environ['AWS_CA_BUNDLE']='/root/.ccr/ca-bundle.crt'
import boto3
