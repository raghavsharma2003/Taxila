import { performance } from "node:perf_hooks";
const { __lexicon } = await import("/home/user/Taxila/server/safety/lexicon.js");
for (const s of ["aap mumi se achi ho", "kuch aur text yahan", "aap mumi se achi ho blakmail"]) {
  const out = [];
  for (const sh of __lexicon.SHAPES) { const a = performance.now(); sh.re.exec(s); out.push([performance.now() - a, sh.id]); }
  out.sort((a, b) => b[0] - a[0]);
  console.log(s, "total", out.reduce((a, b) => a + b[0], 0).toFixed(1), out.slice(0, 3).map((x) => `${x[0].toFixed(1)} ${x[1]}`).join(", "));
}
