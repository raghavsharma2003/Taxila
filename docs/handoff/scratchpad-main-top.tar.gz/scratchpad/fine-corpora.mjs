import * as C from "/home/user/taxila-int/evals/safety-robust/corpora.mjs";
import { fineReading } from "/home/user/taxila-int/server/safety/fine.js";
const sets = { taxilafdb: C.taxilaFdbDistress(), es3: C.es3Distress(), cv2: (await C.conversationV2Distress()).filter((x) => x.text) };
for (const [k, v] of Object.entries(sets)) {
  const texts = v.map((x) => x.text ?? (Array.isArray(x.segs) ? x.segs.flat().join(" ") : "")).filter(Boolean);
  const fp = texts.filter((t) => fineReading(t).fine);
  console.log(k, texts.length, "fine:", fp.length); for (const t of fp.slice(0, 8)) console.log("   ", t.slice(0, 140));
}
