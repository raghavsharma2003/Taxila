q() { curl -sS -m 60 "https://export.arxiv.org/api/query?search_query=$1&max_results=${2:-12}&sortBy=${3:-relevance}" | python3 -c "
import sys,xml.etree.ElementTree as ET
ns={'a':'http://www.w3.org/2005/Atom'}
s=sys.stdin.read()
try: t=ET.fromstring(s)
except Exception as ex: print('ERR',s[:200]); sys.exit()
for e in t.findall('a:entry',ns):
  i=e.find('a:id',ns).text.split('/abs/')[-1]; ti=' '.join(e.find('a:title',ns).text.split()); d=e.find('a:published',ns).text[:10]
  print(d,i,ti)
"; echo; sleep 3; }
