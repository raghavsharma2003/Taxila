// TEST only: how often the after-board claim repair fired in the last N minutes (argv[2]), from the recorder
if (process.env.TAXILA_DB !== "test") throw new Error("TEST only");
const { q } = await import(process.cwd() + "/server/db.js");
const min = Number(process.argv[2] || 30);
const r = await q(`select kind, count(*)::int n from trace_event where t > now() - ($1 || ' minutes')::interval and data::text like '%claim_after_board%' group by kind`, [String(min)]);
const t = await q(`select count(*)::int n from trace_event where t > now() - ($1 || ' minutes')::interval and kind = 'director.turn'`, [String(min)]);
console.log(`last ${min} min: director.turn ${t[0].n}; events mentioning claim_after_board: ${JSON.stringify(r)}`);
const ex = await q(`select data from trace_event where t > now() - ($1 || ' minutes')::interval and data::text like '%claim_after_board%' limit 3`, [String(min)]);
for (const e of ex) console.log(JSON.stringify(e.data).slice(0, 600));
