import fs from "fs";
const k = JSON.parse(fs.readFileSync("/home/user/Taxila/data/kits/c4-hindi.json","utf8"));
const ch = process.argv[2];
const t = k.topics.find(t=>t.topicId===`c4-hindi-ch${ch}-t01`);
console.log("EXP:", t.expectations.join(" || "));
for (const m of t.misconceptions) console.log("MC", m.id.split("-mc-")[1], m.belief);
for (const it of t.items) console.log(`${it.id.slice(-3)} [${it.kind}/${it.skillId.slice(-2)}] ${it.prompt_hi} => ${it.answer}`);
