#!/bin/bash
# Waits for the X37 freeze to end (21:30 IST = 16:00 UTC), then deploys the worker + jobs from a clean worktree.
while [ "$(date -u +%H%M)" -lt 1601 ]; do sleep 30; done
set -x
cd /home/user/Taxila
WT=/home/user/taxila-deploy2
git worktree add --force $WT claude/blissful-mayer-icwe2j || exit 1
cp -al node_modules $WT/node_modules
cp .env.local $WT/.env.local
cd $WT
git log --oneline -1
git diff --stat 9242020 HEAD -- server shared data db package.json package-lock.json Dockerfile.worker | tail -5
git ls-remote origin refs/heads/claude/blissful-mayer-icwe2j
NODE_USE_ENV_PROXY=1 NODE_NO_WARNINGS=1 node scripts/deploy-worker.mjs --jobs
echo "DEPLOY EXIT $?"
cd /home/user/Taxila
git worktree remove --force $WT
git worktree prune
git worktree list
