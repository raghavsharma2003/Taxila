import fs from "fs";
const out = process.env.DUMP_TO;
const orig = globalThis.fetch;
globalThis.fetch = async (url, init) => {
  if (String(url).endsWith("/chat/completions") && init?.body) fs.appendFileSync(out, init.body + "\n");
  return orig(url, init);
};
