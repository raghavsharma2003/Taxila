// paired: HEAD corroborate vs working-tree corroborate on the same model labels (grading-truth dumps)
import { readFileSync, readdirSync } from "node:fs";
const R = "/home/user/Taxila/";
const CL = await import(R + "server/director/classify.js");
const NEW = await import(R + "server/grading/corroborate.js");
const OLD = await import(process.argv[2] + "/oldcorr/corroborate.js");
const { getKit } = await import(R + "server/content/index.js");
const rows = process.argv.slice(3).flatMap((f) => JSON.parse(readFileSync(f, "utf8")));
const need = new Set(rows.map((r) => r.itemId)); const targets = new Map();
for (const f of readdirSync(R + "data/kits").filter((x) => /^c\d-.*\.json$/.test(x))) {
  const j = JSON.parse(readFileSync(R + "data/kits/" + f, "utf8"));
  for (const t of j.topics) { if (!t.items?.some((i) => need.has(i.id))) continue; const kit = await getKit(t.topicId, { generate: false });
    for (const item of kit?.items ?? []) if (need.has(item.id)) targets.set(item.id, CL.targetFor({ phase: "practice", hintLevel: 0 }, kit, { ...item, misconceptions: kit.misconceptions })); }
}
const v = (o) => (o === "correct" ? "correct" : o === "partial" ? "partial" : o === "incorrect" || o === "misconception" ? "incorrect" : "abstain");
const c = { n: 0, changed: 0, fixedWrong: 0, newWrong: 0, newUncredited: 0, freedUncredited: 0, lostMiss: 0 }; const ex = [];
for (const r of rows) { if (r.error) continue; const t = targets.get(r.itemId); if (!t) continue; c.n++;
  const res = { outcome: r.modelOutcome, source: r.source, confidence: 1, flags: {} };
  const a = v(OLD.corroborate({ target: t, text: r.input, result: res }).outcome), g = NEW.corroborate({ target: t, text: r.input, result: res }), b = v(g.outcome);
  if (a === b) continue; c.changed++;
  const wrong = (x) => x !== "abstain" && ((r.truth === "correct" && x !== "correct") || (r.truth !== "correct" && x === "correct") || (r.truth === "partial" && x === "incorrect"));
  if (wrong(a) && !wrong(b)) c.fixedWrong++; if (!wrong(a) && wrong(b)) c.newWrong++;
  if (r.truth === "correct" && b === "abstain") c.newUncredited++; if (r.truth === "correct" && a === "abstain") c.freedUncredited++;
  if (r.truth !== "correct" && a === "incorrect" && b === "abstain") c.lostMiss++;
  ex.push(`${r.truth} ${a}->${b} (${g.corroboration}) | ${String(r.input).slice(0, 60)} | key: ${String(t.key).slice(0, 60)}`);
}
console.log(JSON.stringify(c)); for (const e of ex.slice(0, 30)) console.log("  " + e);
