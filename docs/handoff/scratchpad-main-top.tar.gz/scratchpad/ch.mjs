import fs from "node:fs";
const D = "/home/user/Taxila/evals/face-puppet/out/diya/";
for (const f of fs.readdirSync(D).filter((x) => /^\d\d\.json$/.test(x)).sort()) {
  const m = JSON.parse(fs.readFileSync(D + f, "utf8"));
  for (const w of m.words) {
    if (!/ch|^bada$|^ud$|dhoondh|baantte|^jaise|^se$/i.test(w.text)) continue;
    const ids = m.visemes.filter((v) => v.ms >= w.ms - 10 && v.ms < w.ms + w.durMs + 10).map((v) => `${v.ms - w.ms}:${v.id}`);
    console.log(f.slice(0,2), w.text, w.ms, w.durMs, ids.join(" "));
  }
}
