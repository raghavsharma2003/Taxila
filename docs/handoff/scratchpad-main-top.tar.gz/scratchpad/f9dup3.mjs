const { q } = await import("/home/user/taxila-int/server/db.js");
const { createHash } = await import("node:crypto");
const rows = (r) => r.rows ?? r;
const sig = (x) => (x == null ? "-" : createHash("sha1").update(JSON.stringify(x)).digest("hex").slice(0, 8));
await q("begin read only");
for (const pre of ["3437b744", "310b8c82"]) {
  const L = rows(await q(`select id::text from lesson where id::text like $1`, [`${pre}%`]))[0].id;
  console.log(`== ${pre}`);
  const ev = rows(await q(`select turn, kind, data from trace_event where sid=$1 and kind in ('ui.render.board','board.page','studio.slot.revealed') order by t`, [L]));
  for (const e of ev) {
    const d = e.data ?? {};
    const a = d.artifact ?? {};
    const ops = d.ops ?? d.page?.ops ?? a.ops ?? a.board?.ops ?? null;
    const texts = Array.isArray(ops) ? ops.map((o) => o.text ?? o.label ?? o.t ?? "").filter(Boolean) : null;
    console.log(`  turn=${e.turn} ${e.kind.padEnd(20)} src=${d.source ?? ""} kind=${d.kind ?? ""} mode=${d.mode ?? a.mode ?? d.page?.mode ?? ""} bsrc=${d.boardSource ?? a.boardSource ?? d.page?.boardSource ?? ""} ops=${Array.isArray(ops) ? ops.length : "?"} opsSig=${sig(ops)} txtSig=${sig(texts)} artSig=${sig(d.artifact)} keys=${Object.keys(d).join(",").slice(0, 90)} akeys=${Object.keys(a).join(",").slice(0, 80)}`);
  }
}
await q("rollback"); process.exit(0);
