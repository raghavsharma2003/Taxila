import { distressBackstop } from "/home/user/Taxila/server/signals/backstop.js";
import { buildES1 } from "/home/user/Taxila/evals/signals/es1-traces.mjs";
import { ES3 } from "/home/user/Taxila/evals/signals/es3-adversarial.data.mjs";
import { ES4 } from "/home/user/Taxila/evals/signals/es4-lexicon.data.mjs";
let n=0,h=0; for (const tr of buildES1()) for (const t of tr.turns) { n++; if (distressBackstop(t.input.childText)) { h++; console.log("ES1 FP", t.input.childText); } }
const non3 = ES3.filter(c=>c.cat!=="a"); const fp3 = non3.filter(c=>distressBackstop(c.text));
const e4 = (Array.isArray(ES4)?ES4:Object.values(ES4).flat()); const fp4 = e4.filter(c=>distressBackstop(c.text ?? c));
console.log({ es1Turns:n, es1Hits:h, es3Non:non3.length, es3FP:fp3.map(c=>c.text), es4:e4.length, es4FP:fp4.length });
