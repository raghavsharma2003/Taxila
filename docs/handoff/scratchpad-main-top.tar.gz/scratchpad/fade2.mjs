import { readdirSync, readFileSync } from "node:fs";
import { normalizeKit } from "/home/user/Taxila/server/content/kits.js";
import { fadeItem, workedLeadContent, fadedContent } from "/home/user/Taxila/server/director/fading.js";
const mod = await import(process.argv[2]);
const revealsAnswer = mod.revealsAnswer;
const dir = "/home/user/Taxila/data/kits/";
let withFade=0, lead=0, shown=0, prob=0;
for (const f of readdirSync(dir)) {
  const m = f.match(/^c(\d)-/); if (!m || +m[1] < 4 || +m[1] > 7 || !f.endsWith(".json")) continue;
  for (const t of JSON.parse(readFileSync(dir+f,"utf8")).topics ?? []) {
    const kit = normalizeKit(t, { topicId: t.topicId, verified: true });
    const it = fadeItem(kit, { band: "B3" }); if (!it) continue; withFade++;
    const i = Number(it.id.slice(5)); const we = kit.workedExample;
    if (revealsAnswer(workedLeadContent(we, i).join(". "), it)) lead++;
    if (revealsAnswer(we.steps.slice(0,i).join(". "), it)) shown++;
    if (revealsAnswer(we.problem, it)) prob++;
  }
}
console.log({ withFade, leadRevealsKey: lead, earlierStepsRevealKey: shown, problemRevealsKey: prob });
