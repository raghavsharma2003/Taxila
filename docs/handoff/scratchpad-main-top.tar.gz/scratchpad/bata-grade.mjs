// Model stubbed (label "key" = the model reads the reply as correct): what the code floor does with a Devanagari fraction.
process.env.AZURE_OPENAI_ENDPOINT = "https://example.test/openai/v1"; process.env.AZURE_OPENAI_API_KEY = "test-key";
globalThis.fetch = async () => new Response(JSON.stringify({ choices: [{ message: { content: JSON.stringify({ match: "key", confidence: 0.95, off_topic: false, distress: false, asks_for_answer: false, wants_to_stop: false }) }, finish_reason: "stop" }], usage: {} }), { status: 200 });
const { classify } = await import("/home/user/taxila-int/server/director/classify.js");
const { classifyFast } = await import("/home/user/taxila-int/server/director/classify.js");
const target = { mode: "item", key: "1/2", also: [], misconceptions: [], ideas: [], options: null, item: { id: "x", kind: "practice", prompt_en: "What fraction of the pizza is left?", prompt_hi: "pizza ka kitna hissa bacha?", answer: "1/2" } };
for (const t of ["एक बटा दो", "एक बता दो", "1/2", "ek bata do", "aadha", "मुझे बता दो"]) {
  const r = await classify({ target, childText: t, typed: false, classLevel: 4, asrConfidence: 0.9 }).catch((e) => ({ err: e.message }));
  console.log(JSON.stringify(t).padEnd(22), "→", r.outcome ?? r.err, r.overridden ?? "", r.source ?? "", r.corroboration ?? "");
}
process.exit(0);
