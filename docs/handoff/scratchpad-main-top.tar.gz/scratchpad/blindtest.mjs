import { chromium } from "/home/user/Taxila/node_modules/playwright/index.mjs";
import http from "node:http"; import fs from "node:fs"; import path from "node:path";
const DIR="/home/user/Taxila/docs/research/voice/final/blind";
const srv=http.createServer((q,s)=>{let f=decodeURIComponent(q.url.split("?")[0]);if(f==="/")f="/index.html";
  if(f.includes("blind-key")||f.endsWith(".py")){s.writeHead(404);return s.end()}
  const p=path.join(DIR,f);if(!fs.existsSync(p)){s.writeHead(404);return s.end()}
  const buf=fs.readFileSync(p);const ct=f.endsWith(".mp3")?"audio/mpeg":"text/html; charset=utf-8";
  const r=q.headers.range;if(r){const [a,b]=r.replace("bytes=","").split("-");const st=+a,en=b?+b:buf.length-1;
    s.writeHead(206,{"Content-Type":ct,"Content-Range":`bytes ${st}-${en}/${buf.length}`,"Accept-Ranges":"bytes","Content-Length":en-st+1});return s.end(buf.subarray(st,en+1))}
  s.writeHead(200,{"Content-Type":ct,"Accept-Ranges":"bytes","Content-Length":buf.length});s.end(buf)}).listen(0);
const base=`http://127.0.0.1:${srv.address().port}/`;
const html=fs.readFileSync(DIR+"/index.html","utf8");const M=JSON.parse(html.match(/const M=(\{.*?\});\nconst LS/s)[1]);
const ok=(c,m)=>{console.log((c?"PASS ":"FAIL ")+m);if(!c)process.exitCode=1};
const DB={};let writes=[];
const browser=await chromium.launch({executablePath:"/opt/pw-browsers/chromium-1194/chrome-linux/chrome",args:["--autoplay-policy=no-user-gesture-required"]});
async function open(ctx,{withApi=true,delay=50}={}){const page=await ctx.newPage();const errs=[];page.on("pageerror",e=>errs.push(String(e)));page.on("console",m=>{if(m.type()==="error")errs.push(m.text())});
  await page.exposeFunction("__dbGet",p=>DB[p]??null);await page.exposeFunction("__dbSet",(p,v)=>{DB[p]=v;writes.push(p)});
  await page.addInitScript(([withApi,delay])=>{window.claude={use:async n=>{await new Promise(r=>setTimeout(r,delay));if(!withApi)return null;
    if(n==="user")return{id:async()=>"U1"};if(n==="db")return{doc:p=>({get:async()=>{const v=await window.__dbGet(p);return{exists:v!=null,data:()=>v}},set:async v=>window.__dbSet(p,v)})};return null}}},[withApi,delay]);
  await page.goto(base);return {page,errs}}
const ctx=await browser.newContext({viewport:{width:390,height:844}});
// 1. structure + name gate
let {page,errs}=await open(ctx);
ok(await page.locator("#gate").isVisible()&&!(await page.locator("#cards section").count()),"name gate shown, no sections before a name");
await page.click("#go");ok((await page.textContent("#store")).includes("Type your name"),"empty name refused");
// remote record for 'Asha' already holds one scored clip (merge-before-write test)
const c0=M.clips[0].c;DB["ratings/U1/people/asha"]={v:M.v,who:"Asha",ratings:JSON.stringify({__seed:12345,[c0]:{score:4,cov:"1".repeat(50),heard:1,note:"remote note",fail:["pace"]},"sec:P1-maths":{note:"remote sec"}})};
await page.fill("#who","Asha");await page.click("#go");await page.waitForTimeout(1500);
ok(await page.locator("#cards section").count()===3,"3 passage sections");
ok(await page.locator(".clip").count()===9,"9 clip rows");
const secs=await page.$$eval("#cards section",ss=>ss.map(s=>({t:s.querySelector("h2").textContent,v:[...s.querySelectorAll(".clip h3")].map(h=>h.textContent),txt:s.querySelector("details").innerText})));
ok(secs.every(s=>new Set(s.v).size===3&&s.v.every(v=>M.voices.map(x=>"Voice "+x).includes(v))),"each section has the 3 voice codes once");
ok(secs.every(s=>s.txt.length>300),"full passage text shown");
const p1=Object.values(M.passages).find(p=>p.title.includes("samosa"));
ok(html.includes(p1.beats[4].t),"surprise beat text present verbatim");
ok(!/diya|mai-voice|priya|gpt-4o|marin|dragon|openai/i.test(html),"no engine names in index.html");
const keyCodes=Object.keys(JSON.parse(fs.readFileSync(DIR+"/blind-key.json")).clips);
ok(keyCodes.every(c=>html.includes(c)),"all 9 codes in page");
const prior=new Set([...Object.keys(JSON.parse(fs.readFileSync(DIR+"/../../v3/blind/blind-key.json")).clips),...Object.keys(JSON.parse(fs.readFileSync(DIR+"/../../v4/blind/blind-key.json")).clips)]);
ok(keyCodes.every(c=>!prior.has(c))&&M.voices.every(v=>![...prior].some(p=>p.startsWith(v))),"no code reused from rounds 2-3");
ok(await page.$eval(`.clip:has(h3) >> nth=0`,()=>true),"render ok");
// merge: remote scored clip restored
const st=await page.evaluate(()=>JSON.parse(localStorage.getItem("taxila-voice-final:asha")));
ok(st[c0]&&st[c0].score===4&&st.__seed===12345&&st["sec:P1-maths"].note==="remote sec","remote ratings merged in (score, seed, section note)");
// db write happened under per-name doc and index doc
await page.waitForTimeout(1200);
ok(DB["ratings/U1"]&&DB["ratings/U1"].names.includes("Asha"),"names index written");
ok(JSON.parse(DB["ratings/U1/people/asha"].ratings)[c0].score===4,"merged record written back (remote score kept)");
// locked until listened
const clipIdx=await page.$$eval(".clip",(cs,c0)=>cs.findIndex(c=>!c.querySelector(".score button.on")),c0);
const row=page.locator(".clip").nth(clipIdx);
ok(await row.locator(".score button").first().isDisabled(),"unheard clip score locked");
// seek-skip must not unlock
await row.locator(".play").click();await page.waitForTimeout(800);
await page.evaluate(i=>{const a=[...document.querySelectorAll("audio")];},clipIdx);
const seekHeard=await page.evaluate(async()=>{/* find playing audio via players: not global; use media elements created with new Audio */return null});
await row.locator(".play").click();
// use page-level hook: monkeypatch via evaluating on the Audio objects is not possible (not in DOM); instead test seeking using HTMLMediaElement prototype capture
await page.close();
// reopen with Audio capture
({page,errs}=await open(ctx));
await page.addInitScript(()=>{});
await page.evaluate(()=>{});
await page.close();
const ctx2=await browser.newContext({viewport:{width:1280,height:900}});
await ctx2.addInitScript(()=>{const O=window.Audio;window.__aud=[];window.Audio=function(s){const a=new O(s);window.__aud.push(a);return a}});
({page,errs}=await open(ctx2));
await page.fill("#who","Ravi");await page.click("#go");await page.waitForTimeout(800);
const idx=0;const r0=page.locator(".clip").nth(idx);
await r0.locator(".play").click();await page.waitForTimeout(1500);
await page.evaluate(()=>{const a=window.__aud[0];a.currentTime=a.duration*0.97});await page.waitForTimeout(2500);
const h1=await page.evaluate(()=>{const R=JSON.parse(localStorage.getItem("taxila-voice-final:ravi")||"{}");return Object.values(R).filter(x=>x&&x.cov).map(x=>x.heard)});
ok(await r0.locator(".score button").first().isDisabled(),`seeking to the end does not unlock (heard ${h1})`);
// real play at 4x to the end of the shortest clip
const shortest=await page.evaluate(()=>{let b=0;window.__aud.forEach((a,i)=>{if(a.duration<window.__aud[b].duration)b=i});return b});
await page.evaluate(()=>window.__aud.forEach(a=>a.pause()));
const rowS=page.locator(".clip").nth(shortest);
await page.evaluate(i=>{const a=window.__aud[i];a.currentTime=0;a.playbackRate=4},shortest);
await rowS.locator(".play").click();
await page.waitForFunction(i=>window.__aud[i].ended,shortest,{timeout:60000});await page.waitForTimeout(300);
ok(!(await rowS.locator(".score button").first().isDisabled()),"clip unlocks after real play to the end: "+await rowS.locator(".heard").textContent());
await rowS.locator('.score button[data-s="5"]').click();await rowS.locator('.chk input[data-k="flat"]').check();
await rowS.locator("input.note").fill("test note");await rowS.locator("input.note").blur();
ok(await page.locator("#pick input").first().isDisabled(),"final pick locked until all 9 scored");
ok((await page.textContent("#pickneed")).includes("1 / 9"),"pick-needs message shows progress");
// unlock the rest by seeding coverage, reload (local restore path)
await page.evaluate(m=>{const R=JSON.parse(localStorage.getItem("taxila-voice-final:ravi"));m.clips.forEach(c=>{R[c.c]=R[c.c]||{};R[c.c].cov="1".repeat(50);R[c.c].heard=1});localStorage.setItem("taxila-voice-final:ravi",JSON.stringify(R))},M);
await page.reload();await page.fill("#who","Ravi");await page.click("#go");await page.waitForTimeout(1000);
const order1=await page.$$eval(".clip h3",hs=>hs.map(h=>h.textContent));
const n=await page.locator(".clip").count();
for(let i=0;i<n;i++){const r=page.locator(".clip").nth(i);if(!(await r.locator(".score button.on").count()))await r.locator('.score button[data-s="3"]').click()}
ok(!(await page.locator("#pick input").first().isDisabled()),"final pick unlocks after 9 scored");
ok((await page.textContent("#donemsg")).includes("Required"),"pick marked required");
await page.locator("#pick label").nth(1).click();await page.fill("#reason","because");await page.locator("#reason").blur();
ok((await page.textContent("#donemsg")).startsWith("Done"),"done message after pick: "+await page.textContent("#donemsg"));
await page.waitForTimeout(1200);
const rec=JSON.parse(DB["ratings/U1/people/ravi"].ratings);
ok(rec.final&&M.voices.includes(rec.final.pick)&&rec.final.reason==="because"&&Object.values(rec).filter(x=>x&&x.score>=1).length===9,"db holds 9 scores + pick + reason for Ravi");
ok(Object.values(rec).some(x=>x&&x.note==="test note"&&x.fail&&x.fail.includes("flat")),"note and tick saved");
ok(JSON.stringify(DB["ratings/U1"].names)===JSON.stringify(["Asha","Ravi"]),"names index has both people");
ok(JSON.parse(DB["ratings/U1/people/asha"].ratings)[c0].score===4,"Asha's doc untouched by Ravi");
// stable order per rater after reload
await page.reload();await page.fill("#who","Ravi");await page.click("#go");await page.waitForTimeout(800);
ok(JSON.stringify(await page.$$eval(".clip h3",hs=>hs.map(h=>h.textContent)))===JSON.stringify(order1),"order stable for the same rater");
// different rater gets (likely) a different order; check over 6 names that orders vary
const orders=new Set();for(const nm of ["a1","a2","a3","a4","a5","a6"]){await page.click("#switch");await page.fill("#who",nm);await page.click("#go");await page.waitForTimeout(300);orders.add(JSON.stringify(await page.$$eval("#cards section",ss=>ss.map(s=>s.querySelector("h2").textContent+[...s.querySelectorAll(".clip h3")].map(h=>h.textContent)))))}
ok(orders.size>=4,`orders vary between raters (${orders.size}/6 distinct)`);
// switch person keeps ratings separate
await page.click("#switch");await page.fill("#who","Ravi");await page.click("#go");await page.waitForTimeout(800);
ok((await page.textContent("#prog")).includes("9 / 9"),"switching back restores Ravi");
// merge-before-write: local-only data on a new device must not be lost and remote must not be clobbered
// export fallback
await page.click("#code");const ex=JSON.parse(await page.inputValue("#codebox"));ok(ex.v==="taxila-voice-final/v1"&&ex.who==="Ravi"&&ex.ratings.final.pick,"export text has version, name, pick");
await page.screenshot({path:"/tmp/claude-0/-home-user/ecee9fc1-62f9-5f67-a47d-69ca79d9981a/scratchpad/desk.png",fullPage:false});
ok(errs.length===0,"no page errors: "+errs.join("|"));
// offline (no api) path
const ctx3=await browser.newContext({viewport:{width:390,height:844}});
({page,errs}=await open(ctx3,{withApi:false}));await page.fill("#who","Meena");await page.click("#go");await page.waitForTimeout(500);
ok((await page.textContent("#store")).includes("Not signed in"),"offline message without db");
const sw=await page.evaluate(()=>document.documentElement.scrollWidth<=window.innerWidth);ok(sw,"no horizontal scroll at 390px");
await page.screenshot({path:"/tmp/claude-0/-home-user/ecee9fc1-62f9-5f67-a47d-69ca79d9981a/scratchpad/phone.png",fullPage:false});
// dark mode render
const ctx4=await browser.newContext({colorScheme:"dark"});({page}=await open(ctx4));const bg=await page.evaluate(()=>getComputedStyle(document.body).backgroundColor);ok(bg==="rgb(22, 22, 20)","dark mode background "+bg);
// key not served
const kr=await fetch(base+"blind-key.json");ok(kr.status===404,"test server does not serve the key");
await browser.close();srv.close();
