// READ-ONLY (production): does the trace writer's existence filter see a real guardian / child? No ids printed.
import { createRequire } from "node:module";
const require = createRequire(process.cwd() + "/package.json");
const m = await import(require.resolve("@neondatabase/serverless")); const neon = m.neon ?? m.default?.neon; const sql = neon(process.env.DATABASE_URL);
const g = (await sql.query("select g.id gid, c.id cid from guardian g join child c on c.guardian_id = g.id limit 1"))[0];
const rows = [{ sid: "probe", cid: g.cid, gid: g.gid }];
const r = await sql.query(`select count(*)::int n from jsonb_to_recordset($1::jsonb) as x(sid text, cid uuid, gid uuid)
  where (x.cid is null or exists (select 1 from child c where c.id = x.cid)) and (x.gid is null or exists (select 1 from guardian g where g.id = x.gid))`, [JSON.stringify(rows)]);
console.log("existence filter keeps", r[0].n, "of 1 rows for a real guardian+child");
const recent = await sql.query(`select src, (gid is not null) has_gid, count(*)::int n, max(t) last from trace_event where t > now() - interval '20 minutes' group by 1,2 order by 1,2`);
for (const x of recent) console.log(`${x.src} gid:${x.has_gid} n=${x.n} last=${new Date(x.last).toISOString().slice(11,19)}`);
