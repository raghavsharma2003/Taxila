// TEST branch only (run under testenvrun with TAXILA_DB=test): a flag.owner + its flag.note → trace.mjs --flags shows the note.
import { spawnSync } from "node:child_process";
import { randomUUID } from "node:crypto";
if (process.env.TAXILA_DB !== "test") throw new Error("TEST only");
const { q } = await import(process.cwd() + "/server/db.js");
const pid = `r13-flagcheck-${randomUUID().slice(0, 8)}`, now = Date.now();
await q(`insert into trace_event (sid, pid, src, seq, t, kind, tier, data) values
  ($1, $1, 'client', 1, to_timestamp($2 / 1000.0), 'flag.owner', 2, $3::jsonb),
  ($1, $1, 'client', 2, to_timestamp(($2 + 4000) / 1000.0), 'flag.note', 2, $4::jsonb)`,
  [pid, now, JSON.stringify({ n: 1, path: "/c/x/lesson/new" }), JSON.stringify({ n: 1, note: "r13 flag-note join check" })]);
const r = spawnSync(process.execPath, ["scripts/trace.mjs", "--flags", "--since", new Date(now - 60_000).toISOString().slice(0, 10)], { env: process.env, encoding: "utf8" });
const line = (r.stdout || "").split("\n").find((l) => l.includes(pid)) ?? "(no line for the probe flag)";
console.log(line);
await q("delete from trace_event where pid = $1", [pid]);
console.log("note shown:", line.includes("r13 flag-note join check"), "| rows cleaned");
