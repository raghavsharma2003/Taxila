// Read-only TEST: the end records of lessons run on the 14.4.1 candidate (QA / sim lab scripted children).
process.env.DATABASE_URL = process.env.TEST_DATABASE_URL;
const { q } = await import("/home/user/taxila-1441/server/db.js");
const L = await import("/home/user/taxila-1441/server/routes/lesson.js");
const rows = (r) => r.rows ?? r;
await q("begin read only");
const ls = rows(await q(`select l.id::text id, l.started_at, l.ended_at, l.summary sm, l.parent_note pn, l.state->'ctx'->>'teacherName' tn, c.first_name fn,
  (l.state->>'safeguardedAt') sga, (l.state->>'checkReleased') cr, (l.state->'safeguard') sg, (select count(*)::int from incident i where i.lesson_id = l.id) inc,
  (select string_agg(text, ' || ' order by seq) from turn t where t.lesson_id = l.id and t.speaker = 'child') kids
  from lesson l join child c on c.id = l.child_id where l.started_at > '2026-10-21T22:15:00Z' and l.ended_at is not null order by l.started_at`));
await q("rollback");
const esc = (s) => s.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
for (const l of ls) {
  const held = L.safeguardedRecord({ safeguardedAt: l.sga, safeguard: l.sg, checkReleased: l.cr }, l.inc);
  const tActor = l.tn ? new RegExp(`\\b${esc(l.tn)}\\s+(practi[sc]ed|tried|answered|identified|learn(ed|t)|named|counted|compared|placed)`, "i").test(`${l.pn} ${l.sm}`) : false;
  const gendered = /\b(she|he|her|him|his)\b/i.test(l.pn ?? "");
  const fenceHit = (L.recordFence(l.pn) !== String(l.pn ?? "").trim()) || (L.recordFence(l.sm, { lines: true }) !== String(l.sm ?? "").trim());
  // child words in a held record: any 3-word run from the child's turns
  const kw = String(l.kids ?? "").toLowerCase().split(/[^\p{L}\p{N}]+/u).filter(Boolean);
  const rec = `${l.pn} ${l.sm}`.toLowerCase();
  let run3 = null; for (let i = 0; i + 2 < kw.length; i++) { const p = `${kw[i]} ${kw[i + 1]} ${kw[i + 2]}`; if (kw[i].length > 2 && rec.includes(p)) { run3 = p; break; } }
  console.log(`${l.id.slice(0, 8)} ${l.started_at.toISOString().slice(11, 16)} child=${l.fn} teacher=${l.tn} held=${held} inc=${l.inc} teacherAsLearner=${tActor} gendered=${gendered} fenceWouldDrop=${fenceHit} childRun3=${held ? run3 : "-"}`);
  console.log(`   NOTE: ${String(l.pn).slice(0, 260)}`);
}
console.log("n", ls.length);
process.exit(0);
