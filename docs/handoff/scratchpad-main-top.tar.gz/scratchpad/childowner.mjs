// READ-ONLY: is the guardian of a child (id prefix) the owner (sha256 of the lower-cased email)? Prints match/no-match only.
import { createHash } from "node:crypto";
const { neon } = await import("/home/user/Taxila/node_modules/@neondatabase/serverless/index.mjs");
const sql = neon(process.env.DATABASE_URL);
const [email, prefix] = process.argv.slice(2);
const want = createHash("sha256").update(email.trim().toLowerCase()).digest("hex");
const cols = (await sql.query("select column_name from information_schema.columns where table_name='child'")).map((r) => r.column_name);
const gcol = cols.find((c) => /guardian/.test(c));
const rows = await sql.query(`select g.email from child c join guardian g on g.id = c.${gcol} where c.id::text like $1`, [prefix + "%"]);
console.log(`children matched: ${rows.length}`);
for (const r of rows) console.log(createHash("sha256").update(String(r.email).trim().toLowerCase()).digest("hex") === want ? "guardian IS the owner" : "guardian is NOT the owner");
