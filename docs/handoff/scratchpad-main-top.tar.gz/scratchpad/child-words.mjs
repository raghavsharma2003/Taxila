// TEST trace, read-only: a lesson's child words by turn (TEST accounts only), written to a scratch json.
import { writeFileSync } from "node:fs";
const { q } = await import("/home/user/taxila-int/server/db.js");
const out = {};
for (const pre of process.argv.slice(3)) {
  const [l] = await q(`select id from lesson where id::text like $1 limit 1`, [pre + "%"]);
  const ev = await q(`select turn, data from trace_event where sid = $1 and kind = 'srv.req' order by t`, [l.id]);
  out[pre] = ev.filter((e) => typeof e.data?.body?.childText === "string").map((e) => ({ turn: e.turn, text: e.data.body.childText }));
}
writeFileSync(process.argv[2], JSON.stringify(out, null, 1));
process.exit(0);
