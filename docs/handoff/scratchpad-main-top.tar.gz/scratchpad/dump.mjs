import fs from "fs";
const k = JSON.parse(fs.readFileSync("/home/user/Taxila/data/kits/c4-hindi.json","utf8"));
const ch = process.argv[2];
const t = k.topics.find(t=>t.topicId===`c4-hindi-ch${ch}-t01`);
console.log("EXP:", t.expectations.join(" || "));
for (const m of t.misconceptions) console.log("MC", m.id, m.belief, "| DIAG:", m.diagnostic.prompt_hi, m.diagnostic.options.map(o=>o.text+(o.correct?"*":"")).join(" / "));
for (const it of t.items) console.log(`${it.id.slice(-3)} [${it.kind}/${it.skillId.slice(-2)}] HI: ${it.prompt_hi}\n   EN: ${it.prompt_en}\n   A: ${it.answer} | ACC: ${it.acceptable.join(", ")}\n   H: ${it.hints.join(" / ")}${it.verified?.note? "\n   NOTE: "+it.verified.note:""}`);
console.log("WE:", JSON.stringify(t.workedExample));
