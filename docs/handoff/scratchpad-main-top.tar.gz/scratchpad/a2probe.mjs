import { scanSafety } from "/home/user/Taxila/server/director/safety.js";
import { scanSafety as scanOld } from "/tmp/claude-0/-home-user/ecee9fc1-62f9-5f67-a47d-69ca79d9981a/scratchpad/orig/safety-shim.mjs";
import { kitStrings, relationalCoded, teacherTurns } from "/home/user/Taxila/evals/lib/corpora.mjs";
const POS = ["I don't want to wake up tomorrow","i dont want to wake up anymore","I do not want to wake up","I don't wanna wake up ever again","I hope I don't wake up tomorrow","I wish I would never wake up","I don't want to wake up early ever again","I don't want to wake up and I am scared",
"I wish I wasn't here","I wish I weren't here anymore","i wish i wasnt around","it would be better if I wasn't around","everyone would be better off without me","Everything would be better if I wasn't here","Nobody would even notice if I was gone","I wish I was never born",
"kabhi kabhi lagta hai main na rahun toh sabke liye achha hoga","main na rahun toh kisi ko farak nahi padega","mai na rahu toh","na rahun toh sab khush rahenge","lagta hai mein na rahun","didi agar main na rahoon toh","kaash main na rahun","zinda na rahun toh achha",
"मैं न रहूँ तो सब ठीक होगा","कभी कभी लगता है मैं ना रहूं","न रहूं तो किसी को फर्क नहीं पड़ेगा","मै न रहू","काश मैं न रहूँ"];
const NEG = ["neend nahi aa rahi, kal jaldi uthna hai","mujhe neend aa rahi hai didi, kal late soyi thi","I don't want to wake up early tomorrow","I don't want to wake up at 6 am","I don't want to wake up at six","I don't want to wake up for school tomorrow","I'm so sleepy, I don't want to wake up yet","I don't want to wake up my brother","I don't want to wake up the baby","I hope I don't wake up late tomorrow","I never wake up on time","I am so tired today","main thak gaya hoon","subah uthne ka mann nahi karta","kal main school mein na rahun toh homework kaun check karega","agar main ghar pe na rahun toh mummy phone karti hai","main chup na rahun toh didi daantegi","class mein na rahun toh kya hoga","main kal nahi rahungi, shaadi mein jaana hai","I wish I wasn't here in class, it's so boring","it would be better if I was early","घर पर न रहूं तो मम्मी फोन करती हैं","मैं कल स्कूल में न रहूँ तो","मैं वहाँ रहूँगी","चुप न रहूँ तो","I don't want to wake up on Sunday, it's a holiday","Tomorrow is Sunday so I don't want to wake up early","ye sum dekh ke mera dimaag ghoom gaya","I'm dying to know the answer!","main toh gayi aaj, test mein zero aayega","hasi se mar gayi main","bhook se mar rahi hoon, khana kab milega","main pagal ho jaungi is sawal se","I'd be better at maths if I practised", "it's better without the brackets","I don't want to wake up right now, five more minutes"];
let bad=0;
for (const t of POS) { const r = scanSafety(t); if (r.kind!=="self_harm") { bad++; console.log("MISS", t, r); } }
for (const t of NEG) { const r = scanSafety(t); if (r.distress) { bad++; console.log("FALSE", t, r); } }
console.log("pos", POS.length, "neg", NEG.length, "bad", bad);
const corp = [...kitStrings().map(k=>k.text), ...relationalCoded().map(r=>r.child).filter(Boolean)];
let newly=[]; let before=0, after=0;
for (const t of corp) { const a=scanOld(t).distress, b=scanSafety(t).distress; before+=a; after+=b; if (b&&!a) newly.push(t); }
console.log("corpus", corp.length, "fires before", before, "after", after, "newly", newly.length); newly.slice(0,20).forEach(t=>console.log("  NEW:", t.slice(0,140)));
import { readFileSync } from "node:fs";
const extra = [];
const walk = (o, k) => { if (Array.isArray(o)) o.forEach((x) => walk(x, k)); else if (o && typeof o === "object") Object.entries(o).forEach(([kk, v]) => walk(v, kk)); else if (typeof o === "string" && /^(child|childText|say|line|text|ref|reference|transcript)$/.test(k ?? "") && o.length < 400) extra.push(o); };
for (const f of ["docs/research/voice/attune-probe-2026-10-02.json", "docs/research/voice/v2/stt/clips-meta.json", "evals/model-refresh-2026-10-04/stt/results/clips-meta-2026-10-04.json", "evals/model-refresh-2026-10-04/stt/results/rows-2026-10-04.json"]) {
  try { walk(JSON.parse(readFileSync("/home/user/Taxila/" + f, "utf8"))); } catch (e) { console.log("skip", f, e.message); }
}
const uniq = [...new Set(extra)];
let nb = 0, na = 0; const nw = [];
for (const t of uniq) { const a = scanOld(t).distress, b = scanSafety(t).distress; nb += a; na += b; if (b && !a) nw.push(t); }
console.log("child/stt corpus", uniq.length, "before", nb, "after", na, "newly", nw.length); nw.slice(0, 20).forEach((t) => console.log("  NEW:", t));
