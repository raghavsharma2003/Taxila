import json
P='/home/user/Taxila/data/kits/c8-sst.json'
d=json.load(open(P))
T={t['topicId']:t for t in d['topics']}
def item(iid):
    for t in d['topics']:
        for it in t['items']:
            if it['id']==iid: return it
    raise KeyError(iid)
n=0
# --- 1. ch07 capital terminology (NCERT: physical capital = fixed + working) ---
t=T['c8-sst-ch07-t01']
t['skills'][1]['title']="Distinguish fixed capital (tools, machines, buildings) from working capital (raw materials, money in hand), know that both together are physical capital, and recognise human capital (skills and knowledge)"
t['expectations'][3]="Physical capital has two parts: fixed capital (tools, machines, buildings that are used again and again for years) and working capital (raw materials and money in hand that get used up in production); human capital is the skill and knowledge of people, built through education, training and good health."
we=t['workedExample']
we['steps'][2]="Capital: stove, kettle and glasses are fixed capital; milk, tea leaves, sugar and gas are working capital (both are physical capital); the lender or owner of these funds earns interest"
we['fadedVersion'][2]="Capital: stove and kettle are ___ capital; milk and tea are ___ capital"
i=item('c8-sst-ch07-t01-i02')
i['answer']="Land: the space where the stall stands (and the water). Labour: the effort of the chaiwala and helper. Capital: stove, kettle and cups (fixed capital); milk, tea leaves, sugar and gas (working capital); both are physical capital. Entrepreneur: the person who started the stall and bears the risk."
i['verified']['note']="Matches key; facts checked. Key reworded to NCERT terms (fixed + working = physical capital) after checker terminology flag."
i=item('c8-sst-ch07-t01-i03')
i['prompt_en']="Contrast a tractor and the seeds a farmer uses: which is fixed capital and which is working capital, and why?"
i['prompt_hi']="Tractor aur kisaan ke beej ka contrast karo: kaunsa fixed capital hai aur kaunsa working capital, aur kyon?"
i['answer']="The tractor is fixed capital because it is used again and again over many seasons; seeds are working capital because they are used up in one season's production. Both are physical capital."
i['acceptable']=["tractor fixed, seeds working","tractor baar-baar, beej ek baar","tractor fixed capital, beej working capital"]
i['hints'][2]="Prompt: used again = ___ capital; used up = ___ capital"
i['hints'][3]="Assert: tractor fixed, seeds working; both physical capital"
i['verified']={"solverAnswer":"Tractor: fixed (physical) capital used over many seasons; seeds: working capital used up in one production cycle.","agrees":True,"note":"Settled: reworded from 'physical vs working' to NCERT's 'fixed vs working' (both are physical capital), per checker terminology flag. Classification unchanged; solver agrees."}
i=item('c8-sst-ch07-t01-i04')
i['answer']="Fixed capital: oven, shop building. Working capital: flour, sugar (fixed and working together make up physical capital). Human capital: the baker's decorating skill."
i['acceptable']=["oven and building fixed; flour and sugar working; skill human capital","oven aur building fixed, maida aur cheeni working, hunar human capital"]
i['hints'][2]="Prompt: fixed ___; working ___; human ___"
i['verified']['note']="Settled: key reworded to 'fixed capital' for oven/building (NCERT: fixed + working = physical capital). Solver agrees."
i=item('c8-sst-ch07-t01-i10')
i['answer']="Land: the factory plot and water. Labour: tailors, machine operators, supervisors. Capital: sewing machines and the building (fixed); cotton fabric, thread and buttons (working). Entrepreneur: the owner who set up the unit and bears the risk."
i['verified']['note']="Matches key; facts checked. Key reworded to NCERT terms (fixed/working) after checker terminology flag."
i=item('c8-sst-ch07-t01-i12')
i['answer']="Capital is everything made by people that is used to produce more. Physical capital has two parts: fixed capital like machines, tools and buildings, and working capital like raw materials and money in hand. Human capital is people's skills. Examples: a tailor's sewing machine (fixed) and the cloth (working); a farmer's tractor (fixed) and seeds (working)."
i['hints'][2]="Prompt: fixed capital ___; working capital ___"
i['verified']['note']="Settled: key reworded so physical capital = fixed + working (NCERT Class 9 Palampur framing). Solver agrees."
n+=1
# --- 2. textile trade 1700 vs 1850 ---
i=item('c8-sst-ch04-t01-i05')
assert i['kind']=='contrast'
i['answer']="Around 1700 India was a leading exporter of fine cotton and silk textiles to the world; by 1850 it exported more and more raw cotton (along with goods like indigo and opium) and imported British mill-made cloth."
i['acceptable']=["exporter of cloth then, exporter of raw materials like raw cotton and importer of cloth later","pehle kapda bechta tha, baad mein kachcha kapaas bechta aur British kapda khareedta tha"]
i['hints'][1]="Point: by 1850 cheap machine-made cloth from British mills was flooding Indian markets"
i['hints'][2]="Prompt: 1700 = exported ___; 1850 = exported more raw ___, imported ___"
i['hints'][3]="Assert: from leading cloth exporter to raw-material exporter and cloth importer"
i['verified']['note']="Settled: hint 2 no longer claims Lancashire spun Indian cotton (it relied mainly on American cotton until the 1860s); key now says 'more and more raw cotton' alongside indigo and opium rather than 'mostly raw cotton'. Solver agrees."
n+=1
# --- 3. charter year hint leak ---
i=item('c8-sst-ch04-t01-i01')
i['hints'][1]="Point: it was around the time Akbar ruled the Mughal empire"
i['verified']['note']="Settled: hint 2 weakened (was 'the very last year of the 16th century', which gave away 1600 at rung 2); now anchors to Akbar's reign (1556-1605). Solver agrees."
n+=1
# --- 4. Timur / Jaunpur ---
i=item('c8-sst-ch02-t01-i06')
i['answer']="The Sultanate was badly weakened, and provinces far from Delhi broke away; regional kingdoms such as Malwa (1401) and Gujarat (1407) became independent, and others like Jaunpur (independent since 1394) grew stronger."
i['verified']['note']="Settled: key no longer lists Jaunpur as breaking away after Timur's raid (it declared independence in 1394); Malwa (1401) and Gujarat (1407) used as post-1398 examples. Solver agrees."
n+=1
# --- 5. RTI appeals ---
i=item('c8-sst-ch11-t01-i13')
i['answer']="Under the Right to Information Act, 2005, a citizen asks a public authority for information, which usually must be given within 30 days; it is a request, not a court case. If the reply is refused or unsatisfactory, the first appeal goes to a senior officer (the First Appellate Authority) in the same office, and the second appeal goes to the Information Commission; a court can still be approached separately."
i['verified']['note']="Settled: key now gives the full appeal path (First Appellate Authority inside the public authority, then Information Commission) and no longer implies courts are excluded (writs to High Courts remain possible). Solver agrees."
n+=1
s=json.dumps(d,ensure_ascii=False,indent=2)
json.loads(s)
open(P,'w').write(s)
print('fixed',n)
