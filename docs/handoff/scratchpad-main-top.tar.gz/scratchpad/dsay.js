// Code predicates over what the teacher SAYS, against what the Director decided and what the screen shows
// (PRODUCT-DESIGN-V2 §4.6, §4.10; audit #6, #13). Inherited law: safety and truth by predicate, not instruction.
//
//   G-PRAISE-1  a confirmation never contradicts the verdict: no praise or agreement for an answer the verified-key
//               classifier did not mark correct (audit: "Bilkul" after "25" for "what comes after 25?"), and no
//               "wrong / not quite" opening after one it did.
//   G-SAY-1     a line that sends the child to the screen (tap, touch, click, the choices below…) needs something on
//               the screen to act on in the SAME response: Director chips (UiDirectives.chips) or a mounted module
//               (audit: "60 mein se choice tap karo" with no choices shown).
//   ask         the written question for the Question card (UiDirectives.ask), taken from what was actually said
//               when the turn has no kit item.

import { sentences as splitSentences } from "../conversation/guards.js";

const S = "[^\\p{L}\\p{N}]";
const lead = (alts) => new RegExp(`(?:^|[.!?।]\\s*|—\\s*|,\\s*(?=(?:bilkul|sahi|correct|exactly|perfect|shabaa?sh)))(?:${alts})(?=${S}|$)`, "iu");

/** Words that open a turn as agreement or praise. "Haan"/"yes" count only after an answer that was not right. */
const PRAISE_OPEN = lead([
  "bilkul(?:\\s+sahi|\\s+theek)?", "sahi(?!\\s+(?:answer|jawab|uttar|tareeka|tarika|kya|kaun|kaunsa|wala|wali)\\s*(?:kya|kaun|kaunsa|hoga|hai\\s+kya|\\?))(?:\\s+hai|\\s+jawab|\\s+answer|\\s+kaha|\\s+bataya|\\s+pakda)?",
  "correct", "that'?s\\s+(?:right|correct|it)", "you'?re\\s+right", "right(?=\\s*[!.])", "exactly", "perfect", "great(?:\\s+job|\\s+work)?",
  "well\\s+done", "very\\s+good", "good\\s+job", "nice(?!\\s+try)", "shabaa?sh(?:i)?", "waa?h", "badhiya", "bahut\\s+(?:accha|achha|acha|badhiya|khoob|sahi)",
  "zabardast", "awesome", "excellent", "brilliant", "super", "ekdam\\s+(?:sahi|theek)", "theek\\s+(?:kaha|bataya)", "haan\\s+ji,?\\s+(?:sahi|bilkul)",
  "सही", "बिल्कुल", "शाबाश", "बहुत\\s+(?:अच्छा|बढ़िया)",
].join("|"));
/** A tick or praise emoji anywhere in the turn reads as "right" (F3, evals/owner-truth: "✅ …" on a not_yet answer). */
const PRAISE_EMOJI = /[\u2705\u2714\u2611\u{1F44D}\u{1F44F}\u{1F389}\u{1F31F}\u2B50\u{1F4AF}\u{1F3C6}\u{1F947}]/u;
const AGREE_OPEN = lead(["haan(?:\\s+ji)?", "ha+n", "yes", "yep", "hmm\\s+haan", "हाँ", "हां"].join("|"));
/** Praise of the answer anywhere in the turn. */
const PRAISE_ANY = new RegExp([
  `(?:aapka|tumhara|tera|your|yeh|ye|that|this|it)\\s+(?:answer|jawab|uttar)?\\s*(?:bilkul\\s+|ekdam\\s+)?(?:sahi|correct|right|theek)(?:\\s+(?:hai|tha|is|was))?(?![\\p{L}]|\\s+(?:nahi|nahin|not|hai\\s+kya|kya))`,
  `(?:aapne|tumne|you)\\s+(?:bilkul\\s+|ekdam\\s+)?(?:sahi|correct(?:ly)?|right)\\s+(?:kaha|bataya|socha|pakda|nikala|got|said|found)`,
  `you\\s+got\\s+it`, `that(?:'?s|\\s+is)\\s+(?:right|correct)`, `sahi\\s+jawab(?!\\s+(?:kya|kaun|kaunsa|hoga))`,
  // F5 (evals/owner-truth s17 t17: "sahi likhi" on a pasted, irrelevant reply): the written / picked / joined forms
  `(?:aapne|tumne|you)\\s+(?:\\p{L}+\\s+){0,3}?(?:bilkul\\s+|ekdam\\s+)?(?:sahi|correct(?:ly)?|right)\\s+(?:likha|likhi|likhe|chuna|chuni|joda|jodi|pehchana|pehchaana|wrote|picked|chose|matched)`,
].join("|"), "iu");
/**
 * round3 truth (owner-1 on taxila.dev 2026-10-09, c5-maths-ch07-t02-i06, an UNGRADED re-ask: "Aapne Pattern A ka niyam sahi
 * pehchaana: …"): the F5 form allowed at most 3 words between "aapne" and "sahi", so a 4-word object slipped through and
 * the turn praised an answer nothing had graded. PRAISE_ANY_WIDE allows up to 8 words (and a few more verb forms) and is
 * used for every verdict except a GRADED partial, where naming the part that is right is the honest, specific feedback
 * (the narrow PRAISE_ANY still applies there, as before).
 */
const PRAISE_ANY_WIDE = new RegExp([PRAISE_ANY.source,
  `(?:aapne|tumne|you)\\s+(?:[\\p{L}\\p{N}'’]+[\\s,:]+){0,8}?(?:bilkul\\s+|ekdam\\s+)?(?:sahi|correct(?:ly)?|right)\\s+(?:kaha|bataya|socha|pakda|nikala|got|said|found|likha|likhi|likhe|chuna|chuni|joda|jodi|pehchana|pehchaana|pehchani|pehchaani|pehchane|pehchaane|identified|spotted|wrote|picked|chose|matched)(?![\\p{L}])`,
].join("|"), "iu");
/**
 * A "you made a mistake" statement anywhere in a turn after a RIGHT answer (F2, evals/owner-truth: "yahan galti hui",
 * "step toot gaya" after a correct pick). Negations ("galti nahi", "no mistake") are not denials.
 */
const DENY_ANY = /\b(?:(?:yahan|yaha|isme|ismein|is\s+mein|thodi|chhoti|ek)\s+galti\s+(?:hui|ho\s+gayi|ho\s+gai|hai|kar\s+di)|galti\s+(?:ho\s+gayi|ho\s+gai|kar\s+di|kar\s+di\s+hai)|step\s+(?:toot|tut|chhoot|chhut|reh)\s+gaya|you\s+made\s+a\s+mistake|that'?s\s+(?:wrong|not\s+right|incorrect)|(?:aapka|tumhara|your)\s+(?:answer|jawab)\s+(?:galat|wrong|sahi\s+nahi))\b(?!\s+(?:nahi|nahin|not))/iu;
/**
 * QA 14.4.1 (P2: "nahi nahi, 160" got "Aapne jodne ki jagah kuch aur operation kiya", a reteach naming a wrong operation
 * the child never did): a sentence that says THEY made a mistake (a second-person subject with a fault word, or what they
 * did instead). A question, a negation ("koi galti nahi") and a general rule ("agar galti ho…") are not claims.
 */
const CLAIM_WHO = /(?<![\p{L}])(?:aapne|tumne|aapse|tumse|aapka|tumhara|aapki|tumhari|you|your)(?![\p{L}])/iu;
const CLAIM_FAULT = /(?<![\p{L}])(?:galat|galti|mistake|wrong|incorrect)(?![\p{L}])|\p{L}+ne\s+ki\s+jagah(?![\p{L}])|(?<![\p{L}])ki\s+jagah\s+(?:badal|ulat|palat)|instead\s+of|(?<![\p{L}])(?:kuch\s+aur|koi\s+aur|doosr[aie]|dusr[aie]|alag|different|another)\s+operation/iu;
// main safety review (14.4.2): the reassurance after a disclosure ("you did nothing wrong by telling me", "tumne kuch galat nahi
// kiya", "it's not your fault") is a negation, never a claim
const CLAIM_NOT = /(?<![\p{L}])(?:nothing\s+(?:wrong|incorrect)|(?:kuch|koi)\s+(?:bhi\s+)?(?:galat|galti)\s+(?:nahi|nahin|na)|(?:not|n['’]t)\s+(?:your|tumhari|aapki)\s+(?:fault|galti)|(?:did|do)\s*(?:not|n['’]t)\s+do\s+anything\s+wrong|(?:galat|galti|mistake|wrong|incorrect)\s+(?:nahi|nahin|not|na)|(?:no|koi|not\s+a|kabhi)\s+(?:galti|mistake)|not\s+(?:wrong|incorrect)|isn'?t\s+wrong|(?:agar|if|whenever|even\s+if|chahe|kabhi\s+kabhi|sometimes|log|students|bachch?e|many|common))(?![\p{L}])/iu;
const claimSentence = (x) => !/[?？]/.test(x) && CLAIM_WHO.test(x) && CLAIM_FAULT.test(x) && !CLAIM_NOT.test(x);
/** Does the turn tell the child they made a mistake (G-PRAISE-1's other side: a fault nothing graded)? */
export const claimsMistake = (text) => DENY_ANY.test(String(text ?? "")) || sentencesOf(text).some(claimSentence);
/** The turn without its sentences that claim a mistake of theirs. */
export const stripClaim = (text) => sentencesOf(text).filter((x) => !claimSentence(x) && !DENY_ANY.test(x)).map((x) => x.trim()).join(" ").replace(/\u2024/g, ".").trim();

/** A "not right" opening, after an answer the classifier marked correct. */
const DENY_OPEN = lead(["galat", "wrong", "not\\s+quite", "not\\s+right", "incorrect", "nope", "oops", "almost", "lagbhag", "thoda\\s+(?:sa\\s+)?galat",
  "nahi,?\\s+(?:ye|yeh)\\s+(?:sahi|theek)", "गलत"].join("|"));

/**
 * The verdict the teacher's words must agree with, from the classification of the child's turn on a graded target.
 * "ungraded": there was nothing to grade (no item, a teaching turn) — no constraint. "correct" | "not_yet" |
 * "partial" | "unverified" (an attempt the classifier could not label: praise would be praise on an unverified answer).
 * @param {{ outcome?: string } | null | undefined} cls  @param {{ mode: string }} target
 */
export function verdictFor(cls, target, { moduleOnly = false, childText = "" } = {}) {
  if (!cls || !target || moduleOnly) return "ungraded";
  // no keyed item, but the child wrote an answer-shaped reply (F5): "attempt" — no "you got it right" for it
  if (target.mode === "none") return childText && !childAsks(childText) && !cls.request && String(childText).trim().split(/\s+/).length >= 3 ? "attempt" : "ungraded";
  if (cls.outcome === "correct") return "correct";
  if (cls.outcome === "partial") return "partial";
  if (cls.outcome === "incorrect" || cls.outcome === "misconception") return "not_yet";
  // The child asked something rather than answered: there is no answer to praise or not ("Great question!" is fine).
  if (childAsks(childText)) return "ungraded";
  return "unverified";
}

/** Is the child's turn a question of their own (not an answer with a rising "?")? */
export const childAsks = (text) => {
  const t = String(text ?? "").trim();
  if (!t || /^[-−]?[\d,./\s]+\??$/.test(t)) return false;
  return /[?？]\s*$/.test(t) || /^(?:kya|kyun|kyon|kaise|kaun|kaunsa|kab|kahan|kitna|kitne|why|how|what|which|who|when|where|can|could|is|are|do|does|क्या|क्यों|कैसे)(?![\p{L}\p{M}])/iu.test(t);
};

/** The child-facing verdict (UiDirectives.verdict) — only for a graded kit item, never for a covert why / teach-back. */
export function uiVerdict(cls, target) {
  if (!cls || target?.mode !== "item") return undefined;
  return ({ correct: "correct", partial: "partial", incorrect: "not_yet", misconception: "not_yet" })[cls.outcome];
}

/**
 * G-PRAISE-1. → null when the words agree with the verdict, else "praise" (agreement/praise for an answer not marked
 * correct) or "contradicts" (a "wrong" opening after a correct one).
 */
/**
 * Warmth about the child's question, effort or thinking — not about the answer — is never a verdict ("Great
 * question!", "Nice try", "Good thinking", "Achhi koshish"). Removed before the praise predicates run.
 */
const EFFORT = /(?:^|(?<=[^\p{L}]))(?:(?:very|really|such\s+a|what\s+a)\s+)?(?:great|good|nice|lovely|interesting|smart|accha|achha|acha|achhi|acchi|badhiya|bahut\s+(?:accha|achha|achhi|badhiya))\s+(?:question|questions|try|effort|thinking|thought|idea|guess|attempt|socha|sawaal|sawal|koshish|prashn)(?![\p{L}])/giu;
export const withoutEffortPraise = (text) => String(text ?? "").replace(EFFORT, " ");

export function praiseProblem(text, verdict) {
  const t = withoutEffortPraise(text).trim();
  if (!t) return null;
  // QA 14.4.1: nothing graded wrong, so no mistake of theirs is named (an ungraded turn has no other constraint)
  if (verdict === "ungraded") return claimsMistake(t) ? "claims" : null;
  if (verdict === "correct") return DENY_OPEN.test(t) || claimsMistake(t) ? "contradicts" : null;
  // F5: a turn with nothing graded may still not tell an attempt it is right ("aapne sahi likha" on an ungraded reply)
  if (verdict === "attempt") return PRAISE_ANY_WIDE.test(t) ? "praise" : claimsMistake(t) ? "claims" : null;
  // partial: "nearly" is honest; "bilkul / sahi" is not.
  if (PRAISE_OPEN.test(t) || (verdict === "partial" ? PRAISE_ANY : PRAISE_ANY_WIDE).test(t) || PRAISE_EMOJI.test(t)) return "praise";
  if (verdict === "not_yet" && AGREE_OPEN.test(t)) return "praise";
  if (verdict === "unverified" && claimsMistake(t)) return "claims";
  return null;
}

const OPENER = /^\s*(?:[\p{L}]+\s*[,—-]\s*)?(?:bilkul(?:\s+sahi)?|sahi(?:\s+hai)?|correct|exactly|perfect|great|well\s+done|very\s+good|good\s+job|nice|shabaa?shi?|waa?h|badhiya|bahut\s+(?:accha|achha|acha|badhiya)|zabardast|awesome|excellent|super|haan(?:\s+ji)?|yes|सही|बिल्कुल|शाबाश|हाँ|हां)\s*[,!.—-]+\s*/iu;

/** The turn with its praise / agreement removed: sentences that praise the answer, and a praising opener on a question. */
export function stripPraise(text) {
  const sentences = String(text ?? "").match(/[^.!?।]+[.!?।]*\s*/g) ?? [];
  const praising = (x) => { const y = withoutEffortPraise(x).trim(); return PRAISE_ANY_WIDE.test(y) || PRAISE_OPEN.test(y) || AGREE_OPEN.test(y); };
  let out = sentences.filter((x) => /[?？]/.test(x) || !praising(x)).join("").replace(new RegExp(PRAISE_EMOJI.source, "gu"), "").trim();
  for (let i = 0; i < 3 && OPENER.test(out); i++) out = out.replace(OPENER, "");
  return out ? out[0].toUpperCase() + out.slice(1) : "";
}

// ── G-SAY-1 ──
const UI_WORDS = new RegExp([
  "\\b(?:tap|taps|tapping|touch|click|press|drag|swipe)\\b",
  "\\b(?:chhoo|chhuo|chhuiye|chhoona|chuo|dabao|dabaiye|dabana|daba\\s+do)\\b",
  "\\bscreen\\b", "\\bbuttons?\\b", "\\btiles?\\b", "\\bchips?\\b",
  "\\b(?:neeche|niche|below|upar|above)\\s+(?:diye|di|diya|wale|wali|ke|ki|the|these|those)?\\s*(?:gaye\\s+)?(?:options?|choices?|cards?|pictures?|boxes?|buttons?)\\b",
  "\\b(?:options?|choices?)\\s+(?:mein\\s+se\\s+)?(?:ek\\s+)?(?:tap|chuno|chuniye|select|on\\s+the\\s+screen)\\b",
  "टैप", "छूओ", "छुओ", "दबाओ", "स्क्रीन", "बटन",
].join("|"), "iu");

/** Does this line send the child to something on the screen? */
export const refersToScreen = (text) => UI_WORDS.test(String(text ?? ""));

/**
 * What the child can act on in this response: Director chips, or a module mounted in the tray.
 * @param {{ chips?: unknown[] } | null | undefined} ui  @param {{ id?: string } | null | undefined} module  state.module after step()
 */
export const screenHasTargets = (ui, module) => !!(ui?.chips?.length || module?.id || (ui?.studioSlot?.artifact && ui.studioSlot.artifact.kind !== "whiteboard"));

/** The words that ask the child to ACT on the screen (tap, press, pick a tile …), not merely to look at it. */
const ACT_WORDS = new RegExp([
  "\\b(?:tap|taps|tapping|touch|click|press|drag|swipe)\\b",
  "\\b(?:chhoo|chhuo|chhuiye|chhoona|chuo|dabao|dabaiye|dabana|daba\\s+do)\\b",
  "\\bbuttons?\\b", "\\btiles?\\b", "\\bchips?\\b",
  "\\b(?:options?|choices?)\\s+(?:mein\\s+se\\s+)?(?:ek\\s+)?(?:tap|chuno|chuniye|select|on\\s+the\\s+screen)\\b",
  "टैप", "छूओ", "छुओ", "दबाओ", "बटन",
].join("|"), "iu");
/** A module drawn to be watched (W2-B fixer, minor 8): the explainer@1 board takes no tap; "look at the board" is fine. */
const watchOnly = (module) => module?.engine === "explainer@1";

// census 2026-10-21 F3 (b08fe8a7 t7: "is diagram mein …" with no diagram ever on screen): a sentence that points at a
// diagram / picture / chart. Only the pointing forms (a deictic before the word, the word + mein/par + a look verb, "look
// at the …"): the bare words are mostly not pointing ("tumhe drawing pasand hai?", "picture the next row", the ways offer
// itself), measured on sim-lab 14.2-14.4 (4384 lines): the bare words 31 lines on an empty stage, all false; this form
// 6 lines, all with something on stage, 0 on an empty one.
const DIAG = "(?:diagrams?|charts?|chitra|tasveer|pictures?|figures?|drawings?|sketch|डायग्राम|चित्र|तस्वीर|चार्ट)";
export const POINT_DIAG = new RegExp([
  `(?:\\b(?:is|iss|us|uss|yeh|ye|yah|this|that)\\s+${DIAG}(?![\\p{L}]))`,
  `(?:\\b${DIAG}\\s+(?:mein|me|par|pe|in|on)\\s+(?:\\S+\\s+){0,3}(?:dekh\\w*|look\\w*|see|notice|dikh\\w*))`,
  `(?:\\b(?:look|dekh\\w*)\\s+(?:at\\s+)?(?:the\\s+|is\\s+|iss\\s+)?${DIAG}(?![\\p{L}]))`,
  `(?:(?:इस|यह|ये|उस)\\s+${DIAG})`,
].join("|"), "iu");
/** Nothing on the stage at all: no Studio piece, no module in the tray. */
export const emptyStage = (ui, module) => !ui?.studioSlot?.artifact && !module?.id;

/**
 * G-SAY-1 → true when the line refers to the screen and nothing on it can be acted on, or when it asks the child to tap
 * / pick something while the only thing on screen is a board drawn to be watched.
 */
export function screenProblem(text, ui, module, { coming = false } = {}) {
  const t = String(text ?? "");
  if (refersToScreen(t)) {
    const act = ACT_WORDS.test(t);
    // acting on the screen needs something to act on (and never a board drawn to be watched)
    if (act && (!screenHasTargets(ui, module) || (watchOnly(module) && !ui?.chips?.length))) return true;
    // r12 RCA failure 5: LOOKING needs only something to look at — a whiteboard counts; what it shows is checked below
    if (!act && !screenHasTargets(ui, module) && !ui?.studioSlot?.artifact) return true;
  }
  // census F3: she points at a diagram / picture and nothing is on the stage (and nothing is coming this turn)
  if (!coming && emptyStage(ui, module) && POINT_DIAG.test(t)) return true;
  // release 13 integration (ms-r13-claims-in-flight): a piece this very turn brings (the child asked for a picture / game /
  // animation and the move answers with one) is drawn in sync with her line or lands a moment later, so it is not on the
  // stage yet when her words are checked; pointing at it is the point. A piece that then fails is the slot-failure path's.
  return coming ? false : screenClaimProblem(t, ui, module);
}

// ── r12 RCA failure 2: a claim about the screen is checked against what is mounted ──
// Owner lesson a95d2ff1: "Screen par game: left Recursive, right Explicit" (turn 3, no game mounted) and "screen par aloo
// dekho" / "board par aloo dekho" (turns 23, 25, a maths table on screen) passed, because G-SAY-1 asked only whether
// there was something to TAP. A sentence that points at the screen or the board must name what is there.
// any sentence that names the screen or the board points at it ("screen par", "screen ke four parts", "on the board"); the
// owner replay of release 13 (2026-10-11, turn 3: "Game: screen ke four parts dekhiye") slipped the narrower par/pe form
const POINT_AT = /\b(?:screen|whiteboard)\b|(?<!\b(?:cbse|icse|state|school|cricket|rbse|bihar|up)\s)\bboard\b(?!\s+(?:exams?|pariksha|games?|ke\s+exam))|स्क्रीन|(?<!(?:सीबीएसई|स्कूल)\s)बोर्ड(?!\s+(?:परीक्षा|एग्जाम))/iu;
const PLAY_CLAIM = /\b(?:games?|khel\w*|activity|play\w*)\b|गेम|खेल/iu;
const CLAIM_STOP = new Set("screen board whiteboard dekho dekhiye dekhte dekh look there here yahan wahan abhi tumhe tumhara aapko aapka dikh raha rahi kaunsa kaunsi kitne kitna batao bataiye socho phir pehle aage left right upar neeche game khel".split(" "));
const stem = (w) => w.toLowerCase().normalize("NFKC").slice(0, 5);
/** The words a mounted piece shows: a whiteboard's texts, the rung's texts and facts, the chips' labels. */
export function stageWords(ui, module) {
  const out = new Set();
  const add = (x) => { for (const w of String(x ?? "").split(/[^\p{L}\p{N}]+/u)) if (w.length >= 2) out.add(stem(w)); };
  for (const o of ui?.studioSlot?.artifact?.script?.ops ?? []) if (o?.text) add(o.text);
  for (const v of Object.values(ui?.studioSlot?.artifact?.script?.facts?.onScreen ?? {})) add(v);
  for (const o of module?.params?.script?.ops ?? []) if (o?.text) add(o.text);
  for (const v of Object.values(module?.params?.script?.facts?.onScreen ?? {})) add(v);
  for (const c of ui?.chips ?? []) add(c?.label);
  return out;
}
const playMounted = (ui, module) => ["play", "stagecraft"].includes(ui?.studioSlot?.artifact?.kind) || (!!module?.id && module.engine !== "explainer@1" && !!module.engine);
/** true when a sentence points at the screen / board and claims what is not there: a game with no play piece up, or
 * content none of whose words the mounted piece shows. PURE. */
export function screenClaimProblem(text, ui, module) {
  const sentences = String(text ?? "").match(/[^.!?।]+[.!?।]*/g) ?? [];
  const pointing = sentences.filter((x) => POINT_AT.test(x));
  if (!pointing.length) return false;
  const words = stageWords(ui, module);
  for (const x of pointing) {
    if (PLAY_CLAIM.test(x) && !playMounted(ui, module)) return true;
    const content = (x.match(/[\p{L}\p{N}]+/gu) ?? []).filter((w) => w.length >= 3 && !CLAIM_STOP.has(w.toLowerCase()) && !/^[A-Z][a-z]+$/.test(w) || /^\d+$/.test(w));
    if (!content.length) continue;
    // only a stage that SHOWS words can prove a claim false by them (ms-r13-claims-in-flight, ms-r13-claims-after-board): a
    // board of shapes only (15 dots in 3 groups), an interactive engine and a play piece carry no readable words here, so a
    // content claim about them passes, as before release 13; a board WITH words that has none of hers (the owner's
    // 'screen par aloo dekho' over the rules table) is a false claim
    if (words.size && !content.some((w) => words.has(stem(w)))) return true;
  }
  return false;
}

// ── release 13 integration (ms-r13-claims-after-board): the claim check run on the board that ACTUALLY arrived ──
// Narrower than screenClaimProblem on purpose: word overlap with the board is a poor judge of a line drawn for it (the
// board says "Solid / Liquid / Gas" while she says "ice, paani, water vapour": the packaged round2 run unpointed 3 such
// lines and their re-timed boards then failed W6). Only the owner's two false-claim shapes are judged here.
const PICTURE_OF = /([\p{L}]{2,20})\s+(?:ka|ki|ke|की|का|के)\s+(?:picture|photo|image|tasveer|chitra|तस्वीर|फोटो|चित्र)|\b(?:picture|photo|image)\s+of\s+(?:an?\s+|the\s+)?([\p{L}]{2,20})/iu;
/** The stems a kit teaches with (title, skills, expectations, its items' prompts): what a lesson's own picture can name. */
export function kitWordsOf(kit) {
  const out = new Set();
  const add = (x) => { for (const w of String(x ?? "").split(/[^\p{L}\p{N}]+/u)) if (w.length >= 2) out.add(stem(w)); };
  add(kit?.title);
  for (const k of kit?.skills ?? []) add(k?.title);
  for (const e of kit?.expectations ?? []) add(e);
  for (const i of (kit?.items ?? []).slice(0, 80)) { add(i?.prompt_en); add(i?.prompt_hi); }
  return out;
}
/**
 * true when a sentence pointing at the screen claims (1) a game while a board, not a play piece, is up, or (2) a picture
 * of a thing named outside both the board and the lesson ("Screen par aloo ka picture dekhiye" over the rules table in a
 * maths lesson: owner lesson a95d2ff1 turn 23). PURE.
 */
export function boardClaimProblem(text, ui, module, { kitWords = new Set() } = {}) {
  const sentences = String(text ?? "").match(/[^.!?।]+[.!?।]*/g) ?? [];
  const words = stageWords(ui, module);
  for (const x of sentences.filter((y) => POINT_AT.test(y))) {
    if (PLAY_CLAIM.test(x) && !playMounted(ui, module)) return true;
    const m = x.match(PICTURE_OF);
    const sub = m?.[1] ?? m?.[2];
    if (sub && !CLAIM_STOP.has(sub.toLowerCase()) && !words.has(stem(sub)) && !kitWords.has(stem(sub))) return true;
  }
  return false;
}

/** "screen par … dekho:", "board pe dekhiye", "look at the screen:": the pointing phrase of a sentence that only LOOKS. */
const POINTING = /\b(?:(?:screen|board)\s+(?:par|pe|mein|me)\s+|on\s+the\s+(?:screen|board)\s*,?\s*|स्क्रीन\s+पर\s+)((?:[\p{L}\p{N}]+\s+){0,3}?)(?:dekho|dekhiye|dekh\s+lo|dekhte\s+hain|look(?:\s+at\s+(?:it|this))?|देखो)\b\s*/iu;
const LOOK_AT_SCREEN = /\b(?:look\s+at\s+the\s+(?:screen|board)|(?:screen|board)\s+(?:par|pe)\s+(?:dekho|dekhiye))\b\s*[:,—-]?\s*/iu;
/**
 * A sentence that only POINTS at the screen, with the pointing taken out and its content kept ("Screen par seedhi dekho:
 * 4, 7, 10." → "Seedhi: 4, 7, 10."), or null when it asks the child to act (tap, drag …) or nothing worth saying is left.
 * r12 RCA failure 5 (owner lesson a95d2ff1 turn 11): deleting the whole sentence took the sequence with it and the child got
 * "Ab 10 ke baad number bolo." with no 10 before it.
 */
export function unpointScreen(sentence) {
  const s0 = String(sentence ?? "");
  if (ACT_WORDS.test(s0)) return null;
  const s = s0.replace(POINTING, (_m, what) => (what ? `${what.trim()}: ` : "")).replace(LOOK_AT_SCREEN, "")
    // any other pointing phrase ("screen ke four parts dekhiye", "on the board") and its look verb
    .replace(/\b(?:on|at)\s+the\s+(?:screen|board)\b/giu, "").replace(/(?:\b(?:screen|whiteboard|board)\b|स्क्रीन|बोर्ड)\s+(?:ke|ki|ka|par|pe|mein|me|के|की|का|पर|में)\s+/giu, "")
    .replace(/\b(?:dekhiye|dekho|dekh\s+lo|dekhte\s+hain|look)\b|देखो|देखिए/giu, "")
    .replace(/\s+([,.;!?।:—-])/g, "$1").replace(/[;:]\s*([.!?।])/g, "$1").replace(/:\s*:/, ":").replace(/\s{2,}/g, " ").replace(/^\s*[:,—-]\s*/, "").trim();
  if (refersToScreen(s) || POINT_AT.test(s) || s.split(/\s+/).filter((w) => /[\p{L}\p{N}]/u.test(w)).length < 2) return null;
  return s[0].toUpperCase() + s.slice(1);
}

/** The line without the sentences that refer to the screen (null if nothing that hands the floor back is left): a sentence
 * that only points keeps its content in words (unpointScreen); one that asks the child to act on the screen goes. */
/** Does the line point at the screen / board at all (agent lane: nothing is up, so any pointing is a false claim)? */
export const pointsAtScreen = (text) => POINT_AT.test(String(text ?? ""));
export function stripScreenRefs(text, { stageEmpty = false } = {}) {
  const sentences = String(text ?? "").match(/[^.!?।]+[.!?।]*\s*/g) ?? [];
  // census F3: on a stage the caller knows is empty, a sentence pointing at a diagram / picture goes too (nothing to
  // unpoint it to); a caller that does not pass the stage strips exactly as before
  const diag = (s) => stageEmpty && POINT_DIAG.test(s);
  return sentences.map((s) => (diag(s) ? "" : refersToScreen(s) || POINT_AT.test(s) ? (unpointScreen(s) ? `${unpointScreen(s)} ` : "") : s)).join("").trim();
}

// ── the Question card ──
export const ASK_MAX = 120;
/** A question that cannot be shortened (no sentence or clause to drop) is shown whole up to this, never cut. */
export const ASK_HARD = 180;
const QMARK = /[?？]/;
const words = (x) => x.split(/\s+/).filter(Boolean).length;
/** The trailing parts of `parts` (joined with `sep`) that fit in ASK_MAX, or "". */
const tailThatFits = (parts, sep) => {
  let out = "";
  for (let i = parts.length - 1; i >= 0; i--) {
    const next = out ? `${parts[i]}${sep}${out}` : parts[i];
    if (next.length > ASK_MAX) break;
    out = next;
  }
  return out;
};

/**
 * A question for the card: the whole text when it fits ASK_MAX; else its last sentences that fit and contain the
 * question; else the question sentence itself when it fits; else that sentence's last clauses that fit (after a ";",
 * ":", dash or ", "); else the whole question sentence up to ASK_HARD. Never invented: always the text's own words,
 * whole words, and a decimal point is never a sentence end ("0.5" stays "0.5"). round 4 (K's audit B04-04 and stream 5's
 * journey audit #10: cards ending "…kis chhote fraction mein…" and "0.5 mein 5" shown as "5 mein 5"): the old last
 * resort cut the FRONT of a long sentence at ASK_MAX and dropped the question at its end. Only a single clause longer
 * than ASK_HARD is still shortened, from the front, so the question words stay.
 */
export function askText(text) {
  const t = String(text ?? "").replace(/\s+/g, " ").trim();
  if (t.length <= ASK_MAX) return t;
  const parts = splitSentences(t).map((x) => x.trim()).filter(Boolean);
  const out = tailThatFits(parts, " ");
  if (out && QMARK.test(out)) return out;
  const q = [...parts].reverse().find((x) => QMARK.test(x)) ?? parts.at(-1) ?? t;
  if (q.length <= ASK_MAX) return q;
  // a clause ends after a word's ";", ":" or "," or at a dash; never inside a number list ("1, 2, 3") or a ratio ("2 : 3")
  const clauses = q.split(/(?<=[;—–])\s+|(?<=\p{L}[:,])\s+|\s+(?=[—–]\s)/u).map((x) => x.trim()).filter(Boolean);
  const tail = clauses.length > 1 ? tailThatFits(clauses, " ") : "";
  if (tail && words(tail) >= 3) return tail;
  if (q.length <= ASK_HARD) return q;
  const end = q.slice(-(ASK_MAX - 1));
  return `…${end.slice(end.indexOf(" ") + 1)}`;
}

/** The question a teacher turn hands back (its last sentence with a "?", else its last sentence), for the card. */
export function askFromReply(reply) {
  const sentences = splitSentences(String(reply ?? "").replace(/\s+/g, " ")).map((s) => s.trim()).filter(Boolean);
  const q = [...sentences].reverse().find((s) => /[?？]/.test(s)) ?? sentences.at(-1);
  return q ? askText(q) : null;
}

// ── G-LEAK-1 (audit §4.4: "Whiteboard: 45,000 ko…") ──
const STAGE = /(?:^|[\s(—-])(?:whiteboard|board|ask|shape|move|note|key|ladder|rung|lesson now|one more check|turn shape|your move)\s*:|[\[\]*#_]{1,}|\bTURN SHAPE\b|\bLESSON NOW\b/i;
// ship5 review (experience B2, owner-5 V3.ascii): a text "diagram" — a run of shape glyphs ("●●●●● ●●●●●"), box drawing or
// ASCII rules — is markup too: on the spoken lane it is read aloud, and a picture belongs on the board, never in her words.
const ART_GLYPH = "●○◯◉■□▪▫▲△▼▽◆◇★☆•◦✓✔✗✘⬤⚫⚪🔴🔵🟢🟡🟠🟣🟤⬛⬜🟥🟦🟩🟨";
// round 5 (14.2; owner-5 visual battery: "0 —|—|—|—|— 1" was read out as a number line): the em / en dash art too, as runs of a
// dash and a pipe, two or more dashes in a row, spaced dash runs, and dash arrows. One dash in a sentence ("Great — ab
// batao?", "bajenge—alag sur") is prose and stays.
const DASH = "\\u2012-\\u2015";
export const TEXT_ART = new RegExp(`(?:[${ART_GLYPH}][\\s,]*){3,}|[\\u2500-\\u257F\\u2580-\\u259F]{2,}|[-=~*+|]{4,}|-{2,}>|<-{2,}`
  + `|(?:[-${DASH}]\\s*\\|\\s*){2,}[-${DASH}]?|(?:\\|\\s*[-${DASH}]+\\s*){2,}\\|?|[${DASH}]{2,}|(?:[${DASH}]\\s+){2,}[${DASH}]|[-${DASH}]+>|<[-${DASH}]+`, "gu");
// ship5 fixer (experience B1 / owner-5 V3.cant_draw): "main nayi picture nahi dikha sakta" — she never says she cannot
// show or draw (the board draws; F16, the owner's session). The sentence is removed; the rest of the turn stands.
const CANT_SHOW = /\b(i can'?t|i cannot|i am not able to|i'm not able to|main|mai|mein)\s+(?:\w+\s+){0,4}(?:draw|show|bana|dikha)\w*\s+(?:nahi|nahin)\s+(?:sakta|sakti|sakte|paunga|paungi|paati|paata)\b|\b(i can'?t|i cannot|i'm not able to|i am not able to)\s+(?:\w+\s+){0,3}(?:draw|show|make)\b|\b(?:dikha|bana|draw\s+kar|show\s+kar)\s+nahi\s+(?:sakta|sakti|sakte|paunga|paungi|payenge|paati|paata)\b|\b(?:main|mai)\s+(?:\w+\s+){0,4}nahi\s+(?:\w+\s+){0,2}(?:dikha|bana)\s+(?:sakta|sakti)\b/i;
export const saysCantShow = (text) => CANT_SHOW.test(String(text ?? ""));
/** The line without the sentence (or clause before a comma + "par/but") that says she cannot show or draw. */
export function stripCantShow(text) {
  const parts = String(text ?? "").match(/[^.!?।]+[.!?।]*\s*/g) ?? [];
  return parts.map((x) => {
    if (!CANT_SHOW.test(x)) return x;
    const m = x.match(/,\s*(?:par|but|lekin|magar)\s+(.*)$/i);
    return m ? m[1].charAt(0).toUpperCase() + m[1].slice(1) : "";
  }).join("").replace(/\s{2,}/g, " ").trim();
}
/** Does a spoken line carry a stage direction, a prompt field name or markup? */
export const leaksStage = (text) => STAGE.test(String(text ?? "").replace(/_{2,}/g, " ")) || new RegExp(TEXT_ART.source, "u").test(String(text ?? ""));
/** The line without field labels and markup (the words after a label stay: they were meant to be said). */
export const stripStage = (text) => String(text ?? "")
  .replace(TEXT_ART, " ")
  .replace(/(^|[\s(—-])(?:whiteboard|board|ask|shape|move|note|key|ladder|rung|lesson now|one more check|turn shape|your move)\s*:\s*/gi, "$1")
  .replace(/\[[^\]]*\]/g, " ").replace(/[\[\]*#]+/g, "").replace(/\s{2,}/g, " ").replace(/\s+([,.!?])/g, "$1").trim();

// ── G-ASK parity (audit flows G4: the card said "13 ka square kitna hai?" while she asked "10 ka square kitna hoga?"; two
// questions in one turn) ──
const normQ = (t) => String(t ?? "").toLowerCase().replace(/…/g, " ").replace(/[^\p{L}\p{N}/]+/gu, " ").trim();
// p5-interaction (owner-2 s1 t5: "2/5 ko 0. 4 samajhiye"): a decimal point is never a sentence end (U+2024 stands in while
// the text is split, then is put back)
const sentencesOf = (t) => (String(t ?? "").replace(/\s+/g, " ").replace(/(\d)\.(\d)/g, "$1\u2024$2").match(/[^.!?।？]+[.!?।？]*/g) ?? [])
  .map((x) => x.replaceAll("\u2024", ".").trim()).filter(Boolean);
const isQuestion = (x) => /[?？]/.test(x);

/**
 * How a reply stands against the pinned question (UiDirectives.ask.text): does it END on that question (its last words
 * are the ask's words), and how many questions does it put to the child — the ask itself counts once however many
 * question marks it carries, every other question sentence counts one. Pure; the battery and the reply guard share it.
 * `ask` null: only the question count (a turn with no pinned item).
 * @returns {{ endsOnAsk: boolean, questions: number, finalQuestion: string | null }}
 */
export function askParity(reply, ask) {
  const r = normQ(reply);
  const a = normQ(ask);
  // A card ask cut with "…" (askText: no sentence fits 120 characters) is a prefix of the question: contained is enough.
  const endsOnAsk = !a || (!!r && (/…\s*$/.test(String(ask)) ? r.includes(a) : r.endsWith(a)));
  const rest = a && r.includes(a) ? String(reply).split(new RegExp(escapeRe(String(ask).replace(/…$/, "").trim()), "i")).join(" ") : String(reply ?? "");
  const others = sentencesOf(rest).filter(isQuestion).length;
  const askIn = a && r.includes(a) ? 1 : 0;
  const finalQuestion = [...sentencesOf(reply)].reverse().find(isQuestion) ?? null;
  return { endsOnAsk, questions: others + askIn, finalQuestion };
}
const escapeRe = (s) => s.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");

/**
 * The reply rewritten in code to end on the pinned question and hold no other: every question sentence that is not
 * the ask is dropped, and the ask closes the turn. What was said before (the acknowledgement, the nudge) stays. The
 * hint itself is on the card (UiDirectives.hint), so a scaffold question that is dropped is not lost to the child.
 */
export function endOnAsk(reply, askFull) {
  const a = normQ(askFull);
  const kept = sentencesOf(reply).filter((x) => !isQuestion(x) && !(a && normQ(x) && (a.includes(normQ(x)) || sharedRun(x, askFull) >= SHARED_RUN_MIN)));
  return `${kept.join(" ").trim()} ${askFull}`.replace(/\s{2,}/g, " ").trim();
}

/**
 * F20 (evals/owner-truth s15 t8): a draft sentence that QUOTES part of the question ("…; ab socho: Tarbooz A ke 3 tukde
 * kiye: ek bada aur do chhote.") was kept because the ask does not contain the WHOLE sentence, then the full question was
 * appended, and the child read the same words twice. A run of this many words in common is the question again.
 */
export const SHARED_RUN_MIN = 5;
/** The longest run of consecutive words two texts share (normalised). Pure; exported for tests. */
export function sharedRun(x, y) {
  const a = normQ(x).split(" ").filter(Boolean), b = normQ(y).split(" ").filter(Boolean);
  let best = 0;
  for (let i = 0; i < a.length; i++) for (let j = 0; j < b.length; j++) {
    let k = 0;
    while (i + k < a.length && j + k < b.length && a[i + k] === b[j + k]) k++;
    if (k > best) best = k;
  }
  return best;
}
/** `lead` then the question, with every lead sentence that repeats (part of) the question dropped (F20). Pure. */
export function joinAsk(lead, askFull) {
  const a = normQ(askFull);
  const kept = sentencesOf(lead).filter((x) => !(a && normQ(x) && (a.includes(normQ(x)) || sharedRun(x, askFull) >= SHARED_RUN_MIN)));
  return `${kept.join(" ").trim()} ${askFull}`.replace(/\s{2,}/g, " ").trim();
}

/** Keep only the LAST question of a turn with no pinned item (one question per turn). */
export function lastQuestionOnly(reply, { keepContent = false } = {}) {
  const ss = sentencesOf(reply);
  const qs = ss.map(isQuestion);
  let keep = qs.lastIndexOf(true);
  // round 3 (conversation; battery boredom-02, boredom-05: "…chalo tareeka badlein: game, picture, ya quick challenge? Kaunsa
  // chunogi?" was cut to "Kaunsa chunogi?", the offer gone): when the last question is a short tag after a question that
  // carries the turn, the tag goes and the carrying question stays
  if (keepContent && keep > 0) {
    const prev = qs.lastIndexOf(true, keep - 1);
    const n = (x) => x.split(/\s+/).filter(Boolean).length;
    if (prev >= 0 && n(ss[keep]) <= 4 && n(ss[prev]) >= 2 * n(ss[keep])) keep = prev;
  }
  return ss.filter((x, i) => !qs[i] || i === keep).join(" ").trim();
}

// ── wrap language only on a wrap move (personalisation 13: "Aaj ke liye bas itna." in a probe turn, mid-lesson) ──
const WRAP_WORDS = /\b(?:aaj\s+ke\s+liye\s+(?:bas\s+)?(?:itna|itni|yahin|ye(?:h)?\s+hi)|aaj\s+(?:ka\s+)?(?:lesson|class|session)\s+(?:khatam|khatm|poora|pura|yahin)|that'?s\s+(?:all|it)\s+for\s+today|see\s+you\s+(?:next\s+time|tomorrow|soon|later)|(?:phir|kal|jaldi)\s+milte\s+hain|good\s*bye|bye[\s-]*bye|alvida|we(?:'re|\s+are)\s+done\s+for\s+today|let'?s\s+stop\s+(?:here|for\s+today)|(?:we'?ll|we\s+will|let'?s)\s+stop\s+(?:here|now)|(?:we['’]?ll|we\s+will|let['’]?s)\s+(?:stop|end)\s+(?:here|now|(?:the\s+|our\s+|today['’]?s\s+)?(?:lesson|class)(?:\s+(?:here|now|for\s+today))?)|lesson\s+ended|yahin\s+(?:rok|ruk|stop|khatam|band)\s*(?:te|dete|kar\s*te|karte|lete|jaate)?\s*(?:hain|hai)|lesson\s+(?:yahin\s+)?(?:khatam|khatm)\s+(?:karte|kar\s+dete)\s+hain|yahin\s+(?:rok|rokte|roke|stop|khatam|khatm|band)\b(?:\s+(?:dete|karte|kar\s+dete|kar\s+lete)\s+hain)?|(?:lesson|class|padhai)\s+(?:yahin\s+)?(?:rok|band|stop)\s+(?:dete|karte|kar\s+dete)\s+(?:hain|hai)|apna\s+(?:khayal|khyal|dhyan)\s+rakh(?:iye|na|o))\b|आज\s+के\s+लिए\s+(?:बस\s+)?इतना|फिर\s+मिलते\s+हैं/iu;
/** Does a line close the lesson (a goodbye, "that's all for today")? Only a wrap move may say that. */
export const wrapsUp = (text) => WRAP_WORDS.test(String(text ?? ""));
/** The line without its closing sentences. */
export const stripWrap = (text) => sentencesOf(text).filter((x) => !wrapsUp(x)).join(" ").trim();

// ── G-PRAISE-2: the words never correct a right answer (W1-A local battery, 2026-10-04: a class-2 diagnostic "2, 4, 6,
// 8… and one more: how many?" key 9; the child tapped 9, graded correct, and she said "yahan 8 ke baad 2 jodna tha,
// isliye 10" — no "wrong" word for G-PRAISE-1 to catch, only a wrong option stated as the result) ──
/**
 * The wrong answers a graded target put in front of the child: a diagnostic's other options and the offered
 * "Show me choices" tiles that are not the key. Short labels only (a long option is a sentence, not an answer token).
 * @param {{ mode?: string, key?: string, also?: string[], options?: { text: string }[], offered?: string[] } | null} target
 */
export function wrongAnswersOf(target) {
  if (!target || target.mode !== "item") return [];
  const keys = new Set([target.key, ...(target.also ?? [])].filter((k) => k != null).map((k) => normQ(k)));
  const all = [...(target.options ?? []).map((o) => o?.text), ...(target.offered ?? [])];
  return [...new Set(all.filter((x) => typeof x === "string" && x.trim() && x.length <= 20 && !keys.has(normQ(x))))];
}
// Number words a reply may use for a small number: romanised Hindi, English and Devanagari (a key said as "nau" is
// still the key; a wrong option said as "das" is still that option).
const NUM_WORDS = {
  0: ["zero", "shunya", "शून्य"], 1: ["ek", "one", "एक"], 2: ["do", "two", "दो"], 3: ["teen", "three", "तीन"],
  4: ["chaar", "char", "four", "चार"], 5: ["paanch", "panch", "five", "पाँच", "पांच"], 6: ["chhe", "chhah", "che", "six", "छह", "छः"],
  7: ["saat", "seven", "सात"], 8: ["aath", "eight", "आठ"], 9: ["nau", "nine", "नौ"], 10: ["das", "dus", "ten", "दस"],
  11: ["gyarah", "gyaarah", "eleven"], 12: ["barah", "baarah", "twelve"], 13: ["terah", "thirteen"], 14: ["chaudah", "fourteen"],
  15: ["pandrah", "fifteen"], 16: ["solah", "sixteen"], 17: ["satrah", "seventeen"], 18: ["atharah", "athaarah", "eighteen"],
  19: ["unnees", "unees", "nineteen"], 20: ["bees", "twenty"],
};
const escRe = (a) => String(a).trim().replace(/[.*+?^${}()|[\]\\]/g, "\\$&").replace(/\s+/g, "\\s+");
/** Regex source for an answer token: its own spelling, plus the number words when it is a small whole number. */
const answerSrc = (a) => {
  const t = String(a).trim();
  const forms = [escRe(t), ...(/^\d+$/.test(t) && NUM_WORDS[Number(t)] ? NUM_WORDS[Number(t)].map(escRe) : [])];
  return `(?<![\\p{L}\\p{N}/.])(?:${forms.join("|")})(?![\\p{L}\\p{N}/]|\\.\\d)`;
};
// A wrong option "as the result": after a result word and closing its clause ("isliye 10", "answer 10", "= 10",
// "toh 10 hai"), or followed by a copula that states it ("10 hota hai", "10 tha", "10 is the answer"). A number that is
// part of the explanation ("8 ke baad 1 aur chappal", "1 chappal ko bhi gina", "10 se ek kam") is not a result.
const RESULT_LEAD = String.raw`(?:isliye|isliy|islie|toh|tou|so|therefore|answer(?:\s+(?:is|was|hai|tha))?|jawab|jawaab|javab|uttar|result|total|matlab|yaani|yani|=|equals|makes|is|was|banega|banta|hoga|hogi|hota\s+hai|aayega|aata\s+hai)`;
const RESULT_CLOSE = String.raw`(?=\s*(?:$|[,.!;:।—–]|(?:hai|hain|tha|thi|hoga|hogi|hota|hoti|hi|banta|banega|aayega|aata)(?![\p{L}])))`;
const RESULT_COPULA = String.raw`\s+(?:hai|tha|thi|hoga|hogi|hota\s+hai|hoti\s+hai|banta|bante|banega|aayega|aata\s+hai|is\s+the\s+answer|is\s+right|is\s+correct|sahi\s+(?:hai|tha))(?![\p{L}])`;
const statesAsResult = (x, w) => {
  const src = answerSrc(w);
  return new RegExp(`(?<![\\p{L}])${RESULT_LEAD}\\s*:?\\s*${src}${RESULT_CLOSE}`, "iu").test(x)
    || new RegExp(`${src}${RESULT_COPULA}`, "iu").test(x);
};
/**
 * Does a reply to a RIGHT answer state one of the wrong answers as the result, in its acknowledgement? The
 * acknowledgement is every non-question sentence that is not mostly the next question (`nextPrompt`, which may
 * itself hold the same numbers; a sentence under 4 words is never "mostly" it, since "Jawab 10 hai." shares 2 of 3
 * words with any prompt holding 10 and "hai"). Only a wrong option presented AS the result counts: praise that uses a wrong option's
 * number while explaining ("8 ke baad 1 aur chappal") is not a correction. A sentence that also says the key, in
 * digits or words, is a contrast ("9, not 10"; "haan nau, 10 nahi"), never a correction.
 * @returns {boolean}
 */
export function correctsRight(reply, { key, wrong = [], nextPrompt = "" } = {}) {
  if (!wrong.length || key == null || String(key).trim() === "") return false;
  const p = new Set(normQ(nextPrompt).split(" ").filter(Boolean));
  const mostlyNext = (x) => { const w = normQ(x).split(" ").filter(Boolean); return p.size > 0 && w.length >= 4 && w.filter((v) => p.has(v)).length / w.length >= 0.6; };
  const keyRe = new RegExp(answerSrc(key), "iu");
  return sentencesOf(reply).filter((x) => !isQuestion(x) && !mostlyNext(x))
    .some((x) => !keyRe.test(x) && wrong.some((w) => statesAsResult(x, w)));
}
/** The reply without the acknowledgement sentences that state a wrong answer (what is left, possibly empty). */
export function stripCorrection(reply, { key, wrong = [], nextPrompt = "" } = {}) {
  return sentencesOf(reply).filter((x) => !correctsRight(x, { key, wrong, nextPrompt })).join(" ").trim();
}
