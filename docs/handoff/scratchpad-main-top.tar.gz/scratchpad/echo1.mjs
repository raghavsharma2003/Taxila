import { loadStream } from "/home/user/Taxila/evals/duplex/taxilafdb/world.mjs";
import { EchoSubtractor } from "/home/user/Taxila/server/duplex/echo.js";
const d = loadStream("f1-fluent_dec_unit-0026~Kavya~noisy");
const e = new EchoSubtractor();
e.heard("u1", d.gold.herWords.map(w=>({w:w.w,startMs:Math.round(w.start),endMs:Math.round(w.end)})));
console.log(d.gold.herWords.map(w=>w.w).join(" "));
for (const toMs of [3000, 5500, 6000]) console.log(toMs, e.subtract("triangle के तीनों angles का sum कितना होता है? तीन सौ साठ डिग्री।", 6060, 900, {fromMs:200,toMs}));
