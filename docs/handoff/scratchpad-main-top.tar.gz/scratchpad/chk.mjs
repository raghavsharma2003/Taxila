import { initLessonState, step } from "/home/user/Taxila/server/director/state.js";
import { kit, CTX, cls } from "/home/user/Taxila/tests/fixtures/kit.mjs";
const K = kit(); const NE = cls("no_evidence");
const s0 = initLessonState({ topicId: K.topicId, kit: K, ctx: { ...CTX }, seed: 7, now: 0 });
let r = step(s0, { event: "start", kit: K, now: 0 });
const turn = (r, c, x={}) => step(r.state, { event: "turn", kit: K, cls: c, now: (r.state.turn + 1) * 20_000, ...x });
for (let i = 0; i < 20 && !(r.state.phase === "practice" && r.move.itemId); i++) r = turn(r, NE);
for (let i = 0; i < 6 && !String(r.move.itemId).startsWith("diag:"); i++) { r = turn(r, cls("correct")); console.log(r.move.kind, r.move.itemId); }
const h = turn(r, cls("incorrect")); console.log(h.move.kind, h.ui.hint, h.move.shape.slice(0,120));
let q=r; for (let i=0;i<5;i++){ q=turn(q,NE); console.log("unclear", q.move.kind, q.move.itemId, !!q.ui.chips);}
