import fs from "node:fs";
import { textCompleteness, endThreshold } from "/home/user/Taxila/src/lesson/turnModel.ts";
import { policyDecide } from "/home/user/Taxila/src/duplex/turnPolicy.ts";
import { STIMULI } from "/home/user/Taxila/docs/research/voice/v2/stt/stimuli.mjs";
const ids=new Set(STIMULI.map(s=>s.id));
const rows=JSON.parse(fs.readFileSync("/home/user/Taxila/evals/model-refresh-2026-10-04/stt/results/rows-2026-10-04.json","utf8")).filter(r=>r.text&&ids.has(r.id));
const ctx={beat:"teachback"}; const cp={beat:"probe"};
const worse={}, late={};
for(const r of rows){const t=r.text.replace(/\s+/g," ").trim(); const re=/[।.,?!](?=\s*\S)/gu; let m;
 while((m=re.exec(t))){const p=t.slice(0,m.index+1).trim(); const sh=textCompleteness(p,ctx)>=0.8; const c=policyDecide(p,ctx);
  if(c.send&&!sh){const k=c.cue+" :: "+p.slice(-25); worse[k]=(worse[k]||0)+1;}}
 const c=policyDecide(t,cp); if(!c.send){const k=c.cue+" :: "+t.slice(-30); late[k]=(late[k]||0)+1;}}
const top=o=>Object.entries(o).sort((a,b)=>b[1]-a[1]).slice(0,25);
console.log("explain: candidate sends, shipped held"); for(const [k,v] of top(worse))console.log(v,k);
console.log("\nprobe: candidate holds full utterance"); for(const [k,v] of top(late))console.log(v,k);
