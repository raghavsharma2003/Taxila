import { listStreams, loadStream, runStream } from "/home/user/Taxila/evals/duplex/taxilafdb/world.mjs";
import { armSpec } from "/home/user/Taxila/evals/duplex/taxilafdb/arms.mjs";
import { facts } from "/home/user/Taxila/evals/duplex/taxilafdb/metrics.mjs";
import { applyConds } from "/home/user/Taxila/evals/duplex/critic/perturb.mjs";
const conds = process.argv[2].split("+"), lane = process.argv[3] || "FAST", split = process.argv[4] || "test", every = Number(process.argv[5] || 1);
const agg = {}; let i = 0;
for (const id of listStreams()) {
  const d0 = loadStream(id); if (d0.meta.split !== split) continue; if (i++ % every) continue;
  const { d } = applyConds(d0, conds);
  const f = facts(await runStream(d, { ...armSpec("stage-a"), lane }));
  for (const p of f.pauses.filter(p => p.thinking)) { const k = p.cls; agg[k] ??= { n: 0, cut: 0, why: {} }; agg[k].n++; if (p.takeover) { agg[k].cut++; for (const r of p.reasons) agg[k].why[r] = (agg[k].why[r] || 0) + 1; } }
}
for (const [k, v] of Object.entries(agg)) console.log(k.padEnd(16), v.n, (v.cut / v.n).toFixed(3), JSON.stringify(v.why));
