import { loadEnv } from "/home/user/Taxila/infra/azure.mjs"; loadEnv();
import { neon } from "@neondatabase/serverless";
const u = process.env.DATABASE_URL;
if (!u.includes("ep-jolly-resonance-b7cecxnr")) { console.log("prod host pattern not found"); process.exit(1); }
const b = u.replace("ep-jolly-resonance-b7cecxnr", "ep-wandering-sky-b745o2ro");
const sql = neon(b);
const r = await sql`select current_database() db, (select count(*) from schema_migrations) mig, (select count(*) from guardian) g`;
console.log(JSON.stringify(r));
