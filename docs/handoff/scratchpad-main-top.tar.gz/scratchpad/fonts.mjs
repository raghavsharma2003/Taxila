import { chromium } from '/home/user/Taxila/node_modules/playwright/index.mjs';
const b = await chromium.launch(); const ctx = await b.newContext();
await ctx.route(/^https?:/, async (route) => { try { const r = await fetch(route.request().url()); const body = Buffer.from(await r.arrayBuffer()); const headers={}; r.headers.forEach((v,k)=>{ if(!['content-encoding','content-length','transfer-encoding'].includes(k)) headers[k]=v; }); await route.fulfill({status:r.status, headers, body}); } catch { await route.abort(); } });
for (const f of ['03-lesson-whiteboard.html','05-diversion.html']) for (const [w,h] of [[360,640],[1440,900]]) {
  const p = await ctx.newPage(); await p.setViewportSize({width:w,height:h});
  await p.goto('file:///home/user/Taxila/prototypes/reset/design-v3/'+f,{waitUntil:'networkidle'}); await p.waitForTimeout(6000);
  const z = await p.evaluate(()=>[...document.querySelectorAll('.stage-slot svg text')].map(t=>Math.round(t.getBoundingClientRect().height*10)/10).filter(x=>x>0));
  console.log(f, `${w}x${h}`, 'text glyph-box heights px:', JSON.stringify(z)); await p.close();
}
await b.close();
