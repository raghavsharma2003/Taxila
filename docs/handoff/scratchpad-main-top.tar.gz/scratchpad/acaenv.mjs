// Read-only: the live container app's env NAMES, and for endpoint vars the host's first label only (not secret).
const e = process.env;
const tok = await (await fetch(`https://login.microsoftonline.com/${e.AZURE_TENANT_ID}/oauth2/v2.0/token`, { method: "POST",
  body: new URLSearchParams({ grant_type: "client_credentials", client_id: e.AZURE_SP_CLIENT_ID, client_secret: e.AZURE_SP_SECRET, scope: "https://management.azure.com/.default" }) })).json();
const arm = async (p) => (await fetch(`https://management.azure.com${p}`, { headers: { authorization: `Bearer ${tok.access_token}` } })).json();
const app = await arm(`/subscriptions/${e.AZURE_SUBSCRIPTION_ID}/resourceGroups/${e.AZURE_RESOURCE_GROUP}/providers/Microsoft.App/containerApps/${process.argv[2] ?? "taxila-web"}?api-version=2024-03-01`);
if (app.error) { console.log("ERR", app.error.code); process.exit(0); }
const envs = app.properties.template.containers[0].env ?? [];
for (const v of envs) {
  if (/ENDPOINT|^DEPLOY_|REGION|LANE/.test(v.name)) {
    let shown = v.secretRef ? `secret:${v.secretRef}` : v.value ?? "";
    if (/^https?:/.test(shown)) { try { shown = new URL(shown).host.split(".")[0]; } catch {} }
    console.log(v.name.padEnd(40), shown);
  }
}
