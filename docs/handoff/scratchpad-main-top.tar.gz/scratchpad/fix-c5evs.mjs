import fs from 'node:fs';
const P = '/home/user/Taxila/data/kits/c5-evs.json';
const k = JSON.parse(fs.readFileSync(P, 'utf8'));
const items = new Map();
const miscs = new Map();
for (const t of k.topics) {
  for (const it of t.items) items.set(it.id, it);
  for (const m of t.misconceptions) miscs.set(m.id, m);
}
const done = { fixed: 0, rewritten: 0, keptAuthor: 0 };
function settle(id, note, kind) {
  const it = items.get(id);
  if (!it) throw new Error('missing ' + id);
  it.verified = { ...(it.verified || {}), agrees: true, note: 'RESOLVED: ' + note };
  done[kind]++;
}
function hints(id, idx, text) { items.get(id).hints[idx] = text; }

// ---- answer-key fixes ----
{
  const it = items.get('c5-evs-ch04-t01-i04');
  it.prompt_en = 'Put a small cup under a dripping school tap for ten minutes. Before you start, predict: will it collect just a few drops, a few spoonfuls, or a full cup? Then think: how much in a whole day, and in a whole week?';
  it.prompt_hi = 'School ke tapakte nal ke neeche das minute ke liye ek chhota cup rakho. Shuru karne se pehle guess karo: sirf kuch boondein jama hongi, kuch chammach bhar paani, ya poora cup? Phir socho: poore din mein kitna, aur poore hafte mein kitna?';
  it.answer = 'It depends on how fast the tap drips. At about one drop a second, ten minutes gives roughly 30 mL, a few spoonfuls, which is more than a few drops but less than a cup. Over a day that adds up to about 4 litres, and over a week to around 30 litres, a few buckets, so leaks must be reported and fixed.';
  it.acceptable = ['a few spoonfuls', 'more than a few drops', 'kuch chammach', 'litres in a day', 'a few buckets in a week', 'depends on how fast it drips'];
  settle(it.id, 'answer reworded to ~30 mL (a few spoonfuls) at 1 drop/s, rate-dependent, ~4 L/day, ~30 L/week; prompt options changed to drops / spoonfuls / full cup.', 'fixed');
}
{
  const it = items.get('c5-evs-ch09-t01-i09');
  it.prompt_en = 'Your cousin in Dubai video-calls you at 8 pm in India. About what time is it there, and is it day or evening? What about your uncle in the USA: morning or night?';
  it.prompt_hi = 'Dubai mein rehne wala tumhara cousin India ke raat 8 baje video call karta hai. Wahaan lagbhag kitne baje honge, din hai ya shaam? Aur USA wale chacha ke yahaan: subah hai ya raat?';
  it.answer = 'Dubai is a little to the west of India and about one and a half hours behind, so it is about 6:30 pm there: early evening. Whether the Sun has already set depends on the season: still light in summer, already dark in winter. The USA is on the far side of the Earth, so it is morning there.';
  it.acceptable = ['about 6:30 pm, evening in Dubai; morning in the USA', 'Dubai mein shaam, USA mein subah', 'evening in Dubai, light or dark depends on the season'];
  hints(it.id, 2, 'Prompt: Dubai is ___ to India so it is early evening there too; the USA is on the ___ side');
  hints(it.id, 3, 'Assert: Dubai is early evening (light or dark depends on the season); the USA has morning');
  settle(it.id, 'answer now says ~6:30 pm early evening, light or dark depends on season; prompt asks time of day rather than a binary day/night for Dubai.', 'fixed');
}

// ---- safety rewrites ----
{
  const it = items.get('c5-evs-ch04-t02-i03');
  it.prompt_en = 'With an adult watching, in an empty open ground (never on a road), your friend wears a helmet, rides a cycle at an easy, steady speed and presses the brakes. Predict first: does the cycle stop on the spot, or roll forward a little before it stops? What does this mean for a car on a road? (No cycle? Roll a ball across the floor and try to stop it with a gentle tap of your hand.)';
  it.prompt_hi = 'Kisi bade ki nigraani mein, khaali khule maidaan mein (sadak pe kabhi nahi), tumhara dost helmet pehenke aaram se dheere cycle chalata hai aur brake dabata hai. Pehle guess karo: cycle wahin ruk jaati hai, ya rukne se pehle thoda aage jaati hai? Iska sadak pe chalti car ke liye kya matlab hai? (Cycle nahi hai? Farsh pe ball ludhkao aur haath se halke se rok ke dekho.)';
  hints(it.id, 1, 'Point to the mark where the brakes were pressed and where the cycle (or ball) stopped');
  settle(it.id, 'rewritten for safety: slow speed, helmet, adult supervision, empty ground, never a road; rolling-ball alternative. Answer unchanged.', 'rewritten');
}
{
  const it = items.get('c5-evs-ch08-t02-i04');
  it.prompt_en = 'With an adult, wet two old handkerchiefs. Fold one and keep it inside a closed box; hang the other open in a breezy place. Predict: after two days, which one will show spots or a musty smell? To check, the adult opens the box while you look from a little distance: do not sniff close or touch any spots. Then the adult seals that cloth in a bag for the bin, and everyone washes hands.';
  it.prompt_hi = 'Kisi bade ke saath do purane rumaal geele karo. Ek ko tah karke band dibbe mein rakho; doosre ko hawa wali jagah khula taang do. Guess karo: do din baad kaunse pe dhabbe dikhenge ya seelan ki smell aayegi? Check karte waqt dibba bada khole aur tum thodi door se dekho: paas se soongho mat, dhabbe chhoona mat. Phir bada us rumaal ko band thaili mein karke kachre mein daale, aur sab haath dho lein.';
  settle(it.id, 'rewritten for safety: adult opens the box, look from a distance, no close sniffing or touching (spores, asthma, allergy), sealed disposal, hand-washing. Answer unchanged.', 'rewritten');
}
{
  const it = items.get('c5-evs-ch06-t01-i03');
  it.prompt_en = 'Ask an adult to put a brick, or a stone about the size of your fist, into a bucket with a little water so its top sticks out above the water: a model island. Predict: if you push the top gently, will it float away like a boat? What is holding it up?';
  it.prompt_hi = 'Kisi bade se kaho ki ek eent, ya mutthi jitna patthar, thode paani wali baalti mein aise rakhein ki uska upar wala hissa paani ke bahar dikhe: ye hua model dweep. Guess karo: upar se halka dhakka doge toh kya ye naav ki tarah tair ke chala jayega? Ise kaun sambhaal raha hai?';
  hints(it.id, 1, 'Point to where the stone or brick touches the bucket');
  settle(it.id, 'rewritten for safety: brick or fist-sized stone, placed by an adult, shallow water. Answer unchanged.', 'rewritten');
}

// ---- hint leaks / stale hints ----
const H = [
  ['c5-evs-ch05-t01-i02', [[0, 'Ask which of these dances they have seen, on TV or at a function'], [1, 'Point to the one pair they are surest of, and work outward from it on the map']], 'h1/h2 no longer describe Bhangra or Garba.'],
  ['c5-evs-ch05-t01-i10', [[1, 'Point to the states on the map one by one and ask which dance they have heard of from each']], 'h2 no longer gives Odissi via the state name.'],
  ['c5-evs-ch05-t01-i13', [[0, 'Ask them to recall the dance map from last time'], [1, 'Offer three choices: Punjab, Gujarat or Assam']], 'removed dandiya cue (and the garba/dandiya raas conflation) and the west-of-India cue; h2 is now a three-way choice.'],
  ['c5-evs-ch05-t01-i11', [[0, 'Ask what language a friend, neighbour or relative from another state speaks at home']], 'stale Chennai reference replaced.'],
  ['c5-evs-ch10-t01-i07', [[1, 'Point to the food, water and shelter links between the forest and its animals']], 'stale shared-river hint replaced with forest links.'],
  ['c5-evs-ch05-t02-i01', [[0, 'Ask them to picture the symbols on stamps, coins or a national-symbols chart'], [1, 'Point to the three parts one at a time: an animal, a bird, a flower']], 'h1/h2 no longer describe the tiger and peacock.'],
  ['c5-evs-ch05-t02-i03', [[0, 'Ask what they remember being told about the anthem at school'], [1, 'Point to the two songs separately: the one sung at assembly, and the national song']], 'removed Nobel/Bengal cue for Tagore.'],
  ['c5-evs-ch05-t02-i13', [[0, 'Ask them to recall the national-symbols chart from last time'], [1, 'Point to the two parts one at a time: first the tree, then the water animal']], 'removed hanging-roots cue for banyan and Ganga cue.'],
  ['c5-evs-ch01-t01-i11', [[1, 'Point to the sea: ask whether it takes a few boxes or nearly all of them']], 'h2 no longer states 97.'],
  ['c5-evs-ch02-t01-i13', [[0, 'Ask where rivers usually begin: up in the hills or at the sea'], [1, 'Point to the seas on both sides of India and ask which one this river reaches']], 'h1/h2 no longer give Nashik, the Bay of Bengal or east.'],
  ['c5-evs-ch04-t02-i08', [[1, 'Point to the two sets of lights at a signal: one for cars, one for people']], 'h2 no longer points at the deciding cue directly.'],
  ['c5-evs-ch04-t01-i12', [[1, 'Point to each thing on the poster in turn and ask whether it rots']], 'h2 no longer names the plastic spoon.'],
  ['c5-evs-ch08-t01-i01', [[1, 'Point to each fibre in turn and ask: did it grow in a field, or come from an animal?']], 'h2 no longer names the silkworm and sheep.'],
  ['c5-evs-ch08-t02-i14', [[0, 'Ask them to recall the lacing cards from last time'], [1, 'Offer two names to choose from: running stitch or back stitch']], 'h1 no longer describes the dashed row; h2 is a two-way choice instead of a description.'],
  ['c5-evs-ch03-t01-i04', [[0, 'Ask whether curd at home takes the same time to set all year round']], 'h1 no longer gives the warmth reasoning.'],
];
for (const [id, hs, note] of H) { for (const [i, t] of hs) hints(id, i, t); settle(id, note, 'fixed'); }

// ---- diagnostics: equalise lengths, add third option, rotate correct position ----
// each entry: [correctText, [distractorText, misconceptionId], [distractorText, misconceptionId]]
const D = {
  'ch01-t01-m1': ['Less than one bucket; the rest is salty or frozen', ['About 90 buckets, since most water on Earth is clean', 'ch01-t01-m1'], ['All 100 buckets, as long as we boil it first', 'ch01-t01-m2']],
  'ch01-t01-m2': ['No; boiling kills germs, but the salt stays in', ['Yes; long boiling takes the salt out of the water', 'ch01-t01-m2'], ['Yes; sea water has hardly any salt in it anyway', 'ch01-t01-m1']],
  'ch01-t01-m3': ['It went into the air as invisible water vapour', ["The sun's heat destroyed it, so it is gone forever", 'ch01-t01-m3'], ['It is still hiding deep inside the threads', 'ch01-t01-m3']],
  'ch01-t01-m4': ['Water vapour from the air turned into drops on it', ['The cold water inside leaked out through the glass', 'ch01-t01-m4'], ['The cold glass itself made new water on its surface', 'ch01-t01-m4']],
  'ch01-t02-m1': ['Pour water into the soil around its roots', ['Spray water only on its leaves, where it drinks', 'ch01-t02-m1'], ['Mix sugar into the soil so it gets some food', 'ch01-t02-m2']],
  'ch01-t02-m2': ['It makes it in its leaves with sunlight, water and air', ['It takes ready-made food out of the soil with its roots', 'ch01-t02-m2'], ['It soaks up ready-made food from rain through its leaves', 'ch01-t02-m1']],
  'ch01-t02-m3': ['Fat, which its body can use when food is scarce', ['Extra water to drink later, like a water bottle', 'ch01-t02-m3'], ['Nothing at all, because camels never need water', 'ch01-t02-m4']],
  'ch01-t02-m4': ['Yes; it drinks a lot at once and loses water slowly', ['No; camels are desert animals and never need water', 'ch01-t02-m4'], ['Yes, and it sips from the water stored in its hump', 'ch01-t02-m3']],
  'ch02-t01-m1': ['In the hills near Nashik, then it flows down to the sea', ['In the Bay of Bengal, then it flows inland to the hills', 'ch02-t01-m1'], ['At the top of the map, then it flows down the map', 'ch02-t01-m2']],
  'ch02-t01-m2': ['From east to west, from higher land to the sea', ['From north to south, as all rivers flow down the map', 'ch02-t01-m2'], ['From the Arabian Sea inland, towards the east', 'ch02-t01-m1']],
  'ch02-t01-m3': ['Rain and melting snow keep adding water to it', ['It will run dry soon; it has only a fixed amount', 'ch02-t01-m3'], ['The sea pushes the water back up the river each day', 'ch02-t01-m1']],
  'ch02-t02-m1': ['They float on, harm animals and stay for hundreds of years', ['The flowing river washes them away and they are gone', 'ch02-t02-m1'], ['They slowly melt in the water, just like sugar does', 'ch02-t02-m2']],
  'ch02-t02-m2': ['A banana peel', ['A plastic wrapper', 'ch02-t02-m2'], ['Both, equally fast', 'ch02-t02-m2']],
  'ch02-t02-m3': ['Not always; it can hold germs we cannot see', ['Yes; clear water is always clean and safe', 'ch02-t02-m3'], ['Yes, as long as it is cold and flowing fast', 'ch02-t02-m3']],
  'ch02-t02-m4': ['Blocked drains with plastic and built on low land', ['Nothing; people cannot make floods better or worse', 'ch02-t02-m4'], ['Nothing; floods just happen because of bad luck', 'ch02-t02-m4']],
  'ch03-t01-m1': ['Microbes grew faster on the warm, damp roti', ['The damp one just got older faster than the dry one', 'ch03-t01-m1'], ['The fuzzy spots grew out of the roti flour itself', 'ch03-t01-m3']],
  'ch03-t01-m2': ['Curd, which is set from milk overnight', ['Nothing good; microbes only make us sick', 'ch03-t01-m2'], ['Only rotten food that nobody wants to eat', 'ch03-t01-m2']],
  'ch03-t01-m3': ['Tiny spores from the air land on it and grow', ['The bread itself slowly changes into mould', 'ch03-t01-m3'], ['It is just dust that settled on the bread', 'ch03-t01-m3']],
  'ch03-t01-m4': ['Throw the slice away; mould spreads unseen threads', ['Pull off the green spot and eat the rest of it', 'ch03-t01-m4'], ['Toast it so the mould goes away, then eat it', 'ch03-t01-m4']],
  'ch03-t02-m1': ['No; the cold only slows microbes, so it will spoil', ['Yes; food kept inside a fridge never goes bad at all', 'ch03-t02-m1'], ['Yes, because the cold kills every germ in it', 'ch03-t02-m2']],
  'ch03-t02-m2': ['Slows them down so they grow very slowly', ['Kills all of them, so the food is germ-free', 'ch03-t02-m2'], ['Makes the food free of microbes forever', 'ch03-t02-m2']],
  'ch03-t02-m3': ['Salt and oil stop microbes, so it lasts for months', ['Only to make it taste good; it has no other use', 'ch03-t02-m3'], ['Only to give it a nice colour and a shiny look', 'ch03-t02-m3']],
  'ch04-t01-m1': ["Everyone's; we should pick up our own litter", ["Only the sweeper's, because that is their work", 'ch04-t01-m1'], ["Only the class monitor's, who is in charge", 'ch04-t01-m1']],
  'ch04-t01-m2': ['Into the green wet-waste bin, to become compost', ['Into any bin at all, because waste is just waste', 'ch04-t01-m2'], ['Into the blue bin, together with the plastic', 'ch04-t01-m2']],
  'ch04-t01-m3': ['Vegetable peels and dry leaves', ['Plastic spoons and wrappers', 'ch04-t01-m3'], ['Everything; the pit rots all of it', 'ch04-t01-m3']],
  'ch04-t01-m4': ['Many litres, enough to fill a few buckets', ['Only a few drops, nothing to worry about', 'ch04-t01-m4'], ['None, because the drops dry up on their own', 'ch04-t01-m4']],
  'ch04-t02-m1': ['Let the bus go, then look both ways and cross', ['Quickly cross right behind the parked bus', 'ch04-t02-m1'], ['Cross in front of the bus as it starts moving', 'ch04-t02-m1']],
  'ch04-t02-m2': ['It needs some distance to stop, so it may not stop', ['It stops at once, the moment the driver brakes', 'ch04-t02-m2'], ['The driver always sees anyone who can see the car', 'ch04-t02-m2']],
  'ch04-t02-m3': ['Walk briskly in a straight line, looking both ways', ['Run as fast as you can to get across quickly', 'ch04-t02-m3'], ['Zig-zag between the vehicles to dodge them', 'ch04-t02-m3']],
  'ch04-t02-m4': ['No; wait for the green walking figure for people', ['Yes; green means go for everyone at the crossing', 'ch04-t02-m4'], ['Yes, as long as you run across really fast', 'ch04-t02-m3']],
  'ch05-t01-m1': ['She may speak Tamil and he may speak Bengali', ['Both speak Hindi, because everyone in India does', 'ch05-t01-m1'], ['A foreign language each, since it is not Hindi', 'ch05-t01-m3']],
  'ch05-t01-m2': ['It changes by region: fish in Bengal, dosa in the south', ['Everyone in India eats roti and dal every single day', 'ch05-t01-m2'], ['Only food from my own state is real Indian food', 'ch05-t01-m2']],
  'ch05-t01-m3': ['From India; Malayalam is spoken in Kerala', ['From abroad, since it is not my language', 'ch05-t01-m3'], ['Nowhere; Malayalam is not a real language', 'ch05-t01-m3']],
  'ch05-t02-m1': ['The tiger, found in forests across India', ['The lion, because lions are on the emblem', 'ch05-t02-m1'], ['The lion, because it is king of the jungle', 'ch05-t02-m1']],
  'ch05-t02-m2': ['Our Constitution began and India became a republic', ['India became free from British rule that day', 'ch05-t02-m2'], ['A king was crowned that day to rule all of India', 'ch05-t02-m3']],
  'ch05-t02-m3': ['The people, by voting in elections', ['A king born into the royal family', 'ch05-t02-m3'], ['The British government, from London', 'ch05-t02-m2']],
  'ch06-t01-m1': ['Rainforests, mangroves, coral reefs, turtles and birds', ['Only sand and sea, with no forests or any animals', 'ch06-t01-m1'], ['Only coconut trees on sand, and nothing else at all', 'ch06-t01-m1']],
  'ch06-t01-m2': ['It is land rising from the sea floor, joined below', ['It floats on top of the sea, just like a boat', 'ch06-t01-m2'], ['Strong waves keep pushing it up from underneath', 'ch06-t01-m2']],
  'ch06-t01-m3': ['Hard skeletons built by tiny animals called polyps', ['A colourful stone that forms under the sea', 'ch06-t01-m3'], ['A kind of plant that grows on the sea floor', 'ch06-t01-m3']],
  'ch06-t01-m4': ['On the west side, facing the sea', ['Equally on both sides of the hills', 'ch06-t01-m4'], ['Mostly on the far, eastern side', 'ch06-t01-m4']],
  'ch06-t02-m1': ['The living coral breaks and dies; fish lose homes', ['Nothing; walking on coral does not hurt it at all', 'ch06-t02-m1'], ['The coral grows faster because it gets touched', 'ch06-t02-m1']],
  'ch06-t02-m2': ['Thousands of wrappers pile up and harm animals', ['Still clean, because one wrapper each is nothing', 'ch06-t02-m2'], ['Clean; the wind will blow all of them away', 'ch06-t02-m2']],
  'ch06-t02-m3': ["Don't feed them; human food makes them sick", ["Feed them chips and biscuits, since they're hungry", 'ch06-t02-m3'], ['Feed them only bread, because bread is healthy', 'ch06-t02-m3']],
  'ch07-t01-m1': ['Something unseen that makes things move, glow or heat', ['A liquid or powder you can see inside batteries', 'ch07-t01-m1'], ['Only something that comes out of a wall plug', 'ch07-t01-m2']],
  'ch07-t01-m2': ['Yes; moving air has energy that can lift a kite', ['No; only things plugged into electricity have it', 'ch07-t01-m2'], ['No; only living things like us have energy', 'ch07-t01-m2']],
  'ch07-t01-m3': ['From sunlight that the wheat plant used for food', ['From the wheat flour itself, not from the Sun', 'ch07-t01-m3'], ['From the gas stove flame that cooked it', 'ch07-t01-m3']],
  'ch07-t01-m4': ['It flows round the loop and back to the battery', ['It gets used up in the bulb and stops there', 'ch07-t01-m4'], ['It leaks out of the hot bulb into the air', 'ch07-t01-m4']],
  'ch07-t02-m1': ['Yes; those hours add up to a lot of electricity', ['No; one fan uses almost nothing, so it is fine', 'ch07-t02-m1'], ['Only if the fan is broken or making a noise', 'ch07-t02-m1']],
  'ch07-t02-m2': ['Yes, a little; switching off at the wall stops it', ['No; it was switched off, so it uses nothing', 'ch07-t02-m2'], ['Only during the daytime, when the sun is out', 'ch07-t02-m2']],
  'ch07-t02-m3': ['From far-off power stations, many burning coal', ['From the socket, which makes it and never runs out', 'ch07-t02-m3'], ['From the electricity meter, which makes it', 'ch07-t02-m3']],
  'ch07-t02-m4': ['Sunlight', ['Coal from mines', 'ch07-t02-m4'], ['Petrol from oil', 'ch07-t02-m4']],
  'ch08-t01-m1': ['By skilled weavers on handlooms, often at home', ['Only by big machines in large factories', 'ch08-t01-m1'], ['It grows as cloth on the silk cotton tree', 'ch08-t01-m2']],
  'ch08-t01-m2': ['From the cocoon spun by the silkworm', ['From the silk cotton (semal) tree', 'ch08-t01-m2'], ['From the soft hair of a sheep', 'ch08-t01-m2']],
  'ch08-t01-m3': ['By twisting many short fibres together', ['By pulling one long hair out of the ball', 'ch08-t01-m3'], ['By gluing the short fibres together in a line', 'ch08-t01-m3']],
  'ch08-t01-m4': ['The sheet is woven; the sweater is knitted in loops', ['Both are woven on a loom in exactly the same way', 'ch08-t01-m4'], ['Both are knitted from one long yarn in loops', 'ch08-t01-m4']],
  'ch08-t02-m1': ["Stitch the seam back with an adult's help", ['Throw it away; torn clothes are of no use', 'ch08-t02-m1'], ['Hide it in the cupboard and never wear it again', 'ch08-t02-m1']],
  'ch08-t02-m2': ['Back stitch, as each stitch overlaps with no gaps', ['Running stitch; any stitch holds just the same', 'ch08-t02-m2'], ['No stitch at all, just one big knot at the end', 'ch08-t02-m2']],
  'ch08-t02-m3': ['In the shade, inside out, so the colour stays', ['In the hottest sun for the whole day, to dry fast', 'ch08-t02-m3'], ['Fold it while wet and put it in the cupboard', 'ch08-t02-m4']],
  'ch08-t02-m4': ['No; dry them fully first, or they grow mould', ['Yes; they will finish drying inside the cupboard', 'ch08-t02-m4'], ['Yes, if you spray some perfume on them first', 'ch08-t02-m4']],
  'ch09-t01-m1': ['Shining on the other side of the Earth', ['Hiding behind the mountains for the night', 'ch09-t01-m1'], ['Switched off until it is morning again', 'ch09-t01-m1']],
  'ch09-t01-m2': ['The Earth spins, turning us towards and away from it', ['The Sun travels all the way around the Earth daily', 'ch09-t01-m2'], ['The Moon pushes the Sun along the sky each day', 'ch09-t01-m3']],
  'ch09-t01-m3': ['Our part of the Earth turns away from the Sun', ['The Moon comes in front of the Sun each evening', 'ch09-t01-m3'], ['Thick clouds cover the Sun and block its light', 'ch09-t01-m3']],
  'ch09-t01-m4': ["Late morning, as the USA is on Earth's far side", ['Also 9 pm at night, the same time as everywhere', 'ch09-t01-m4'], ['Night too, since the Sun has gone under the ground', 'ch09-t01-m1']],
  'ch09-t02-m1': ['Our half of the Earth leans towards the Sun then', ['The Earth comes closest to the Sun in those months', 'ch09-t02-m1'], ['The Sun itself burns hotter in the summer months', 'ch09-t02-m3']],
  'ch09-t02-m2': ["Summer, as Earth's southern half leans to the Sun", ['Winter too, since seasons are the same everywhere', 'ch09-t02-m2'], ['Winter, because Australia is farther from the Sun', 'ch09-t02-m1']],
  'ch09-t02-m3': ['No; what changes is how directly its light falls', ['Yes; it burns much stronger in the summer months', 'ch09-t02-m3'], ['Yes; the Sun itself cools down in the winter', 'ch09-t02-m3']],
  'ch09-t02-m4': ['No; it drops leaves in the dry season and is alive', ['Yes; a tree with no leaves at all must be dead', 'ch09-t02-m4'], ['Yes; the flowers are the last thing before it dies', 'ch09-t02-m4']],
  'ch10-t01-m1': ['Yes; winds carry the smoke to Delhi and other cities', ['No; the smoke stays over the fields where it is made', 'ch10-t01-m1'], ['Only if the farmers themselves live in Delhi', 'ch10-t01-m1']],
  'ch10-t01-m2': ['Every living thing that needs it, not just people', ['Only to the people who live close to the river', 'ch10-t01-m2'], ['To whoever is first to build a dam across it', 'ch10-t01-m2']],
  'ch10-t01-m3': ['Everyone downstream, including in Bangladesh', ['Only India, because the dumping is in India', 'ch10-t01-m3'], ['Only Tibet, because that is where it starts', 'ch10-t01-m3']],
  'ch10-t02-m1': ['Yes; that is 365 fewer plastic bags each year', ["No; one person on her own can't change anything", 'ch10-t02-m1'], ['Only if the government tells her to do it', 'ch10-t02-m1']],
  'ch10-t02-m2': ['Carry a steel bottle and keep refilling it', ['Use a new plastic bottle daily and recycle it', 'ch10-t02-m2'], ['Throw the bottle anywhere; someone will recycle it', 'ch10-t02-m2']],
  'ch10-t02-m3': ['Water them and guard them until they grow strong', ['Nothing more; once planted, the job is done', 'ch10-t02-m3'], ['Plant 20 more each week and forget about them', 'ch10-t02-m3']],
  'ch10-t02-m4': ['Sort it and give it to the kabadiwala to recycle', ['Burn it so that it disappears from the lane', 'ch10-t02-m4'], ['Bury it in the garden so it turns into soil', 'ch10-t02-m4']],
};
const keys = Object.keys(D);
if (keys.length !== miscs.size) throw new Error(`D has ${keys.length}, kit has ${miscs.size}`);
let n = 0;
for (const [mid, m] of miscs) {
  const key = mid.replace('c5-evs-', '');
  const e = D[key];
  if (!e) throw new Error('no rewrite for ' + mid);
  const correct = { text: e[0], misconceptionId: null, correct: true };
  const ds = [e[1], e[2]].map(([text, id]) => {
    const full = 'c5-evs-' + id;
    if (!miscs.has(full)) throw new Error('bad misconception ref ' + full);
    return { text, misconceptionId: full, correct: false };
  });
  // deterministic rotation: correct lands at 0,1,2 in turn; distractor order alternates
  const pos = n % 3;
  if (Math.floor(n / 3) % 2) ds.reverse();
  const opts = [...ds];
  opts.splice(pos, 0, correct);
  m.diagnostic.options = opts;
  n++;
}

fs.writeFileSync(P, JSON.stringify(k, null, 2) + '\n');
console.log(JSON.stringify(done), 'diagnostics', n);
