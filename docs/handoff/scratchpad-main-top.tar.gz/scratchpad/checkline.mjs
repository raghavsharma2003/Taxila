// The check-in line the reply model writes, old wording vs new (14.4 U2b): how often it asks if the child is "safe".
const B = "/home/user/taxila-int";
const { initLessonState, step } = await import(`${B}/server/director/state.js`);
const { findItem } = await import(`${B}/server/director/items.js`);
const { __test } = await import(`${B}/server/routes/lesson.js`);
const { textReply } = await import(`${B}/server/brain/say.js`);
const { kit, CTX, BRIEF, cls } = await import(`${B}/tests/fixtures/kit.mjs`);
const K = kit();
const fresh = () => step(initLessonState({ topicId: K.topicId, kit: K, ctx: { ...CTX, firstName: "Kabir", address: "aap" }, seed: 7, now: 0 }), { event: "start", kit: K, now: 0 }).state;
const dcls = (about) => { const b = cls("no_evidence"); return { ...b, source: "model", flags: { ...b.flags, distress: true, distressKind: "model", distressAbout: about } }; };
const ctxFor = (s, text) => ({ kit: K, child: { id: "child-1", legal_mode: "M1" }, lesson: { id: "lesson-1", started_at: new Date(0) },
  activeItem: findItem(s, K, s.activeItemId), moduleOnly: false, moduleEvents: [], answer: text, childText: text, leaked: false, loadSkills: async () => ({}), now: 200_000 });
const NEW = [["ask gently if they are okay (okay, never safe)", "ask one gentle open question"], ["(are they okay right now: okay, never safe)", "(are they okay right now)"]];
const N = Number(process.env.N ?? 8);
const SAFE = /\bsafe\b|surakshit|सुरक्षित/i;
for (const [line, about] of [["sab bekaar lagta hai, koi mujhse baat nahi karta", "sad_or_lonely"], ["kal ek bandar mere peeche bhaga, main bahut dar gayi thi", "other_fright"]]) {
  const s0 = { ...fresh(), brief: BRIEF, mode: "cascade" };
  const p = await __test.planTurn(s0, dcls(about), ctxFor(s0, line));
  if (p.r.move.tier !== "check") { console.log("not a check-in", p.r.move); process.exit(1); }
  for (const arm of ["old", "new"]) {
    let instr = p.instructions; let hits = 0; const outs = [];
    if (arm === "old") for (const [n, o] of NEW) { if (!instr.includes(n)) { console.log("MISSING", n); process.exit(1); } instr = instr.replace(n, o); }
    for (let i = 0; i < N; i++) {
      try { const r = await textReply({ instructions: instr, state: { ...p.r.state ?? s0, ...(p.r.state ? {} : {}) }, kit: K, childText: line, trace: [], history: [], ui: p.r.ui, module: null, overflow: false });
        const t = typeof r === "string" ? r : (r?.text ?? r?.reply ?? JSON.stringify(r)); if (SAFE.test(t)) hits++; outs.push(t); } catch (e) { outs.push("ERR " + e.message); }
    }
    console.log(`${about.padEnd(14)} ${arm}: "safe" in ${hits}/${N}`);
    for (const o of outs.slice(0, 3)) console.log("    " + String(o).slice(0, 200));
  }
}
process.exit(0);
