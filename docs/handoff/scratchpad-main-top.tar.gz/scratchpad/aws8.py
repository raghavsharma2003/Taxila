exec(open('awsenv.py').read())
import json,re
pr=boto3.client('pricing',region_name='us-east-1')
seen={}
for svc in ['AmazonBedrock','AmazonBedrockFoundationModels','AmazonBedrockService']:
    tok=None; n=0
    try:
        while True:
            kw={'ServiceCode':svc,'Filters':[{'Type':'TERM_MATCH','Field':'regionCode','Value':'ap-south-1'}],'MaxResults':100}
            if tok: kw['NextToken']=tok
            x=pr.get_products(**kw)
            for s in x['PriceList']:
                j=json.loads(s); a=j['product']['attributes']; d=list(list(j['terms']['OnDemand'].values())[0]['priceDimensions'].values())[0]
                desc=d['description']; usd=d['pricePerUnit'].get('USD')
                if re.search(r'kimi|grok|nova 2|nova2|nova-2|sonic|glm|minimax|safeguard|voxtral|qwen3.?next|mistral large 3',desc+json.dumps(a),re.I):
                    seen[desc[:110]]=(usd,d['unit'])
                n+=1
            tok=x.get('NextToken')
            if not tok: break
        print(svc,n)
    except Exception as e: print(svc,'ERR',str(e)[:120])
json.dump(seen,open("bedrock-prices-aps1.json","w"))
for k,v in sorted(seen.items()):
    if re.search(r"(input|output)[- ]tokens?(-standard| for| in)",k) and not re.search(r"batch|flex|priority|cache",k,re.I) and re.search(r"kimi|grok|nova ?2|Nova2|safeguard 120|glm 5|glm-5|minimax m2.5|minimax-m2.5|voxtral small|mistral large 3|mistral-large-3",k,re.I): print(v,k)
