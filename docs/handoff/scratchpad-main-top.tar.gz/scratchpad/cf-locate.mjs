// Model-only (TEST routing): which words of p11 #12 trip the reply deployment's filter under the probe brief (2 tries each).
const { childWordsTrip } = await import("/home/user/taxila-int/server/brain/say.js");
const variants = {
  full: "kyunki... uske teen sides hote hain... tircha ho ya seedha, sides ginne se teen hi aate hain... maine sahi bola?",
  digits: "kyunki... uske 3 sides hote hain... tircha ho ya seedha, sides ginne se 3 hi aate hain... maine sahi bola?",
  noTircha: "kyunki... uske teen sides hote hain... sides ginne se teen hi aate hain... maine sahi bola?",
  tirchaOnly: "tircha ho ya seedha",
  teenSides: "uske teen sides hote hain",
  teenHi: "sides ginne se teen hi aate hain",
  teenAur: "teen aur teen chhe hote hain",
  teenTriangle: "triangle ke teen kone hote hain",
};
for (const [k, v] of Object.entries(variants)) { const r = [await childWordsTrip(v), await childWordsTrip(v)]; console.log(k.padEnd(13), r.join(","), "|", v); }
process.exit(0);
