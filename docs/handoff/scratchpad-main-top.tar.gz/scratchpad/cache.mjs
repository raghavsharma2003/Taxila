import fs from "node:fs";
const env = Object.fromEntries(fs.readFileSync("/home/user/Taxila/.env.local","utf8").split("\n").filter(l=>l.includes("=")).map(l=>{const i=l.indexOf("=");return [l.slice(0,i),l.slice(i+1).trim()]}));
const base = env.AZURE_OPENAI_ENDPOINT.replace(/\/+$/,"");
const doc = fs.readFileSync("/home/user/Taxila/docs/research/factory/llm-game-generation.md","utf8").slice(0,40000);
const sys = `You are the Forge coder.\n# KIT API\n${doc}`;
const res=[];
for (let i=0;i<6;i++){
  const t0=Date.now();
  const r=await fetch(`${base}/responses`,{method:"POST",headers:{"content-type":"application/json","api-key":env.AZURE_OPENAI_API_KEY},
   body:JSON.stringify({model:env.DEPLOY_CODEX,instructions:sys,input:`Reply with the single word ok${i}.`,reasoning:{effort:"low"},max_output_tokens:2000, prompt_cache_key:"forge-kit-v1"})});
  const j=await r.json(); const rem=r.headers.get("x-ratelimit-remaining-tokens");
  res.push({i,status:r.status,ms:Date.now()-t0,in:j.usage?.input_tokens,cached:j.usage?.input_tokens_details?.cached_tokens,out:j.usage?.output_tokens,remTok:rem,err:j.error?.message?.slice(0,150)});
}
console.log(JSON.stringify(res,null,1));
const prev=JSON.parse(fs.readFileSync("/home/user/Taxila/docs/research/factory/llm-game-generation-review-probe-2026-10-02.json","utf8"));
prev.cacheRepeat={method:"6 sequential identical-prefix (10.9k tok) Responses calls, effort low, prompt_cache_key set",res};
fs.writeFileSync("/home/user/Taxila/docs/research/factory/llm-game-generation-review-probe-2026-10-02.json",JSON.stringify(prev,null,2));
