// Per-location Cognitive Services quota usage for the hot chat models (GlobalStandard), no keys.
import { arm, SUB_PATH } from "/home/user/Taxila/infra/azure.mjs";
const want = /gpt-5\.6-luna|gpt-5\.6-sol|gpt-6-sol|gpt-6-luna|grok-4-1-fast-non|DeepSeek-V4-Pro|gpt-5\.6-terra/i;
for (const loc of ["eastus2", "southindia", "swedencentral", "westus3", "polandcentral", "uaenorth", "centralindia"]) {
  try {
    const r = await arm("GET", `${SUB_PATH()}/providers/Microsoft.CognitiveServices/locations/${loc}/usages?api-version=2024-10-01`);
    const rows = (r.value || []).filter((u) => want.test(u.name?.value ?? "") && /GlobalStandard/i.test(u.name?.value ?? ""));
    console.log(loc); for (const u of rows) console.log(`   ${u.name.value}  ${u.currentValue}/${u.limit} ${u.unit}`);
  } catch (e) { console.log(loc, "ERR", String(e.message).slice(0, 160)); }
}
