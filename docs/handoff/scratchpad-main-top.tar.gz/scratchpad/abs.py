import sys,re
for f in sys.argv[1:]:
    t=open(f,errors='ignore').read()
    m=re.search(r'(?is)abstract(.{200,2600}?)(\n\s*(1\s*\n?\s*)?introduction|\n1\s+I|\nI\.\s)',t)
    s=m.group(1) if m else t[:2200]
    s=' '.join(s.split())
    title=' '.join(t[:160].split())[:100]
    print('##',f,'|',title); print(s[:1700]); print()
