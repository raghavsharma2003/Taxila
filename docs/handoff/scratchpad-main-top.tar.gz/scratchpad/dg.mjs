import fs from "fs";
const k=JSON.parse(fs.readFileSync("/home/user/Taxila/data/kits/c8-science.json","utf8"));
const [a,b]=[+process.argv[2],+process.argv[3]];
for(const t of k.topics.slice(a,b))for(const m of t.misconceptions){const d=m.diagnostic;console.log(m.id.replace("c8-science-","")+" Q: "+d.prompt_en);d.options.forEach((o,i)=>console.log("  "+"ABCD"[i]+") "+o.text))}
