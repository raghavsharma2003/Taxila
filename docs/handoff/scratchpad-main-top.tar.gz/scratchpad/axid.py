import sys, urllib.request, urllib.parse, xml.etree.ElementTree as ET
ns={'a':'http://www.w3.org/2005/Atom'}
ids=','.join(sys.argv[1:])
url='https://export.arxiv.org/api/query?'+urllib.parse.urlencode({'id_list':ids,'max_results':50})
root=ET.fromstring(urllib.request.urlopen(url,timeout=60).read())
for e in root.findall('a:entry',ns):
    i=e.find('a:id',ns).text.split('/abs/')[-1]
    t=' '.join(e.find('a:title',ns).text.split())
    p=e.find('a:published',ns).text[:10]
    au=', '.join(a.find('a:name',ns).text for a in e.findall('a:author',ns)[:4])
    s=' '.join(e.find('a:summary',ns).text.split())
    c=e.find('{http://arxiv.org/schemas/atom}comment',ns)
    print(f'=== {i} [{p}] {t}\n  AU: {au}\n  {s}\n  COMMENT: {c.text if c is not None else ""}\n')
