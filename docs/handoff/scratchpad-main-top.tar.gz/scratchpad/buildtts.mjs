import { SCENARIOS } from "/home/user/Taxila/evals/duplex/scenarios.mjs";
import { assemble } from "/home/user/Taxila/evals/duplex/tts-features.mjs";
let n=0; for (const [i, sc] of SCENARIOS.entries()) { const a = await assemble(sc, i, { lead: sc.teacher ? sc.teacher.childStartMs : 600, tail: 100 }); n += a.ttsNew; }
console.log("new clips", n); process.exit(0);
