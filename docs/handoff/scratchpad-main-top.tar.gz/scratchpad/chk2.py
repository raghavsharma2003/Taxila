import bpy,sys,numpy as np
sys.path.insert(0,'/home/user/Taxila/scripts/character/stylised/armB')
import lib as L
bpy.ops.wm.open_mainfile(filepath='/tmp/claude-0/char/stylised-armB/stage.blend')
for o in bpy.data.objects:
    if o.type=='MESH': o.hide_render = o.name not in ('brows','face')
f=bpy.data.objects['face']
f.data.materials[0]=L.new_material('w',base=(0.9,0.9,0.9))
L.setup_render(res=512,samples=8)
for o in list(bpy.data.objects):
    if o.type in ('LIGHT','CAMERA'): bpy.data.objects.remove(o)
c=np.array([0,-0.05,0.27])
L.area_light('k',c+np.array([0,-1,0.3]),c,30,1)
cam=L.camera('c',c+np.array([0,-0.4,0]),c,lens=85)
L.render_to('/tmp/claude-0/char/stylised-armB/dbg/brows.png',cam)
import os; os._exit(0)
