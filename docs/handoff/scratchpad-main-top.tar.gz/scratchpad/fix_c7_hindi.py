import json

P = "/home/user/Taxila/data/kits/c7-hindi.json"
d = json.load(open(P, encoding="utf-8"))
items, mcs = {}, {}
for t in d["topics"]:
    for it in t["items"]:
        items[it["id"]] = it
    for m in t["misconceptions"]:
        mcs[m["id"]] = m

STAMP = "Fix pass 2026-10-02 (c7-hindi checker flags): "


def settle(it, note, solver=None):
    v = it.setdefault("verified", {})
    if solver:
        v["solverAnswer"] = solver
    v["agrees"] = True
    v["note"] = STAMP + note


# 1. ch07-i06: false रेफ rule; rung 2 leak
it = items["c7-hindi-ch07-t01-i06"]
it["answer"] = "सही ‘वर्षा’ है — इस शब्द में ‘ष’ आता है, जैसे वर्ष, हर्ष"
it["hints"] = [
    "Which श/ष/स does this word take?",
    "Think of the word for 'year' — it is spelled the same way.",
    "व + र् + ___ा.",
    "वर्षा, with ष — like वर्ष and हर्ष.",
]
settle(it, "replaced the false rule 'र् (रेफ) के बाद ष आता है' (दर्शन, आदर्श, स्पर्श have रेफ + श) with a word-family note 'इस शब्द में ष आता है, जैसे वर्ष, हर्ष'; rung 2 no longer names ष-words (pointer to 'year' instead). Key वर्षा correct.", "वर्शा → वर्षा (ष)")
m = mcs["c7-hindi-ch07-t01-mc-varsha-spelling"]
m["remediation"]["moveShape"] = ("Point to the little hook on top, ask which letter it is, then let the child write two more words "
                                 "from the same ष family (वर्ष, हर्ष) — as a word family, not a rule, since दर्शन and स्पर्श take श")

# 2. ch06-i06: drop the rhythm claim
it = items["c7-hindi-ch06-t01-i06"]
it["answer"] = ("ये ग़लतियाँ नहीं थीं, कवि के जान-बूझकर लिखे लोकभाषा (अवधी/ब्रज) के रूप थे; "
                "इन्हें बदलने से कविता की मूल भाषा और कवि के अपने शब्द बदल गए")
it["acceptable"] = [
    "ये ग़लती नहीं थी",
    "लोकभाषा के रूप थे",
    "पुरानी भाषा है",
    "मूल भाषा बदल गई",
    "galti nahi thi",
    "purani bhasha",
    "mool bhasha badal gayi",
    "they were dialect words",
]
it["hints"] = [
    "Were they really mistakes?",
    "Did old poets write in today's school Hindi?",
    "They were dialect forms; changing them alters the poet's ___.",
    "They were deliberate old dialect forms; changing them alters the original language of the poem.",
]
settle(it, "dropped the false rhythm claim (गुन→गुण and पाछे→पीछे keep the same mātrā count, 1+1 and 2+2, so the meter is unchanged) from answer, hint 3 and acceptable; key now says they are the poet's deliberate dialect forms and 'correcting' them changes the original language.",
       "ये ग़लतियाँ नहीं, कवि के जान-बूझकर लिखे लोकभाषा रूप थे; बदलने से मूल भाषा बदली")
m = mcs["c7-hindi-ch06-t01-mc-dialect-wrong"]
m["signs"] = [
    "Says 'yahan galat likha hai, peechhe hona chahiye'",
    "Reads पाछे as पीछे while reciting, swapping the poet's words for today's forms",
]
m["remediation"]["moveShape"] = ("Point out that nani's way of speaking also differs and is not 'wrong'; let the child match four pairs, "
                                 "then recite keeping the old forms exactly as the poet wrote them")

# 3. ch07-i05 + diagnostic: तुक is अंत्यानुप्रास; separate वर्ण-आवृत्ति from तुक
it = items["c7-hindi-ch07-t01-i05"]
it["prompt_en"] = ("I say: 'आए–सुनाए की तुक मिलती है, इसलिए यहाँ वैसा ही अनुप्रास है जैसा ‘चम-चम चमकी चंचल चपला’ में — "
                   "एक ही वर्ण का बार-बार आना।' Is that right?")
it["prompt_hi"] = ("मैं कहती हूँ — ‘आए–सुनाए की तुक मिलती है, इसलिए यहाँ वैसा ही अनुप्रास है जैसा ‘चम-चम चमकी चंचल चपला’ में — "
                   "एक ही वर्ण का बार-बार आना।’ क्या यह सही है?")
it["answer"] = ("नहीं; आए–सुनाए में शब्दों के अंत की ध्वनि मिलती है — यह तुक है (इसे अंत्यानुप्रास भी कहते हैं); "
                "‘चम-चम चमकी चंचल चपला’ में एक ही वर्ण ‘च’ बार-बार आता है — वह वर्ण-आवृत्ति वाला अनुप्रास है")
it["acceptable"] = [
    "नहीं",
    "यह तुक है",
    "यह अंत्यानुप्रास है",
    "वहाँ वर्ण नहीं दोहराया",
    "nahi",
    "yeh tuk hai",
    "antyanupras",
    "that is rhyme",
]
it["hints"] = [
    "Do आए and सुनाए match at their ends or at their first sounds?",
    "In ‘चम-चम चमकी…’, which letter keeps coming back?",
    "Ending match = ___; same letter again and again = वर्ण-आवृत्ति.",
    "No — आए–सुनाए is तुक (अंत्यानुप्रास); the ‘च’ line repeats one letter: वर्ण-आवृत्ति अनुप्रास.",
]
settle(it, "reworded so the error is a real one: the claim now says आए–सुनाए is the SAME kind of अनुप्रास as the च-repeat line; key separates तुक (= अंत्यानुप्रास, a type of अनुप्रास) from वर्ण-आवृत्ति, so a school teacher cannot mark it wrong; dropped 'पंक्तियों के अंत में' (आए–सुनाए sit inside one line).",
       "नहीं — आए-सुनाए तुक (अंत्यानुप्रास) है; च-वाली पंक्ति में वर्ण-आवृत्ति है")
m = mcs["c7-hindi-ch07-t01-mc-anupras-rhyme"]
m["belief"] = ("Believes अनुप्रास is only matching word-ends (तुक / अंत्यानुप्रास), and misses वर्ण-आवृत्ति — "
               "the same letter-sound coming again and again within a line")
m["diagnostic"]["prompt_en"] = "In which line does the same letter-sound come again and again (वर्ण-आवृत्ति अनुप्रास)?"
m["diagnostic"]["prompt_hi"] = "किस पंक्ति में एक ही वर्ण की ध्वनि बार-बार आती है — यानी वर्ण-आवृत्ति वाला अनुप्रास?"
m["diagnostic"]["options"] = [
    {"text": "चम-चम चमकी चंचल चपला", "misconceptionId": None, "correct": True},
    {"text": "बादल आए, गीत सुनाए (यहाँ सिर्फ़ आए-सुनाए की तुक मिलती है)",
     "misconceptionId": "c7-hindi-ch07-t01-mc-anupras-rhyme", "correct": False},
    {"text": "आज दिन में धूप खिली", "misconceptionId": None, "correct": False},
]
m["remediation"]["representation"] = ("Sound-highlighter: every च in the line coloured the same (वर्ण-आवृत्ति); a separate panel shows "
                                      "तुक as matching word-ENDS in a different colour, labelled अंत्यानुप्रास")

# 4. ch04 baadh diagnostic: stem leaked बाढ़
m = mcs["c7-hindi-ch04-t01-mc-baadh-spelling"]
m["diagnostic"]["prompt_en"] = "Which word is correct for 'flood' — when a river's water fills the village?"
m["diagnostic"]["prompt_hi"] = "flood के लिए सही शब्द कौन-सा है — जब नदी का पानी गाँव में भर जाए?"

# 5. ch07-i02: rung 2 named all three answers
it = items["c7-hindi-ch07-t01-i02"]
it["hints"] = [
    "Poems often use Sanskrit words for nature.",
    "First sounds: बादल → म…, बिजली → द…, मोर → म…",
    "बादल–मे__, बिजली–दा___, मोर–म___.",
    "मेघ, दामिनी, मयूर.",
]
settle(it, "rung 2 no longer names मेघ/दामिनी/मयूर; it gives first sounds only, rung 3 gives partial words.", "मेघ/घन; दामिनी/चपला; मयूर")

# 6. ch08-i02: rung 1 named 'interview'
it = items["c7-hindi-ch08-t01-i02"]
it["hints"] = [
    "Break it: साक्षात् (face to face) + कार.",
    "One person asks, one answers.",
    "Asker = साक्षात्कार___; answerer = उत्तर___.",
    "An interview; the interviewer and the interviewee.",
]
settle(it, "rung 1 no longer names 'interview' (moved to rung 4); rung 1 now breaks the word साक्षात् + कार.",
       "प्रश्न-उत्तर के रूप में बातचीत; साक्षात्कारकर्ता और साक्षात्कार देने वाला")

# 7. ch08-i03: rung 2 named 'practice'
it = items["c7-hindi-ch08-t01-i03"]
it["hints"][1] = "What does a dancer do every single morning?"
settle(it, "rung 2 no longer names 'practice'.", "नृत्य से प्रेम, परिवार की कथक परंपरा, बरसों का रियाज़")

# 8. ch08-i10: rung 2 leak + one-word acceptable for an open composition
it = items["c7-hindi-ch08-t01-i10"]
it["answer"] = ("तीन खुले प्रश्न (जिनका जवाब हाँ/ना में न हो, बल्कि किसान अपने अनुभव से विस्तार से बताए), जैसे — "
                "‘बारिश देर से आए तो आप क्या करते हैं?’, ‘आपने खेती कैसे सीखी?’, ‘अच्छी फ़सल के लिए क्या-क्या ज़रूरी है?’")
it["acceptable"] = [
    "बारिश देर से आए तो आप क्या करते हैं?",
    "आपने खेती कैसे सीखी?",
    "अच्छी फ़सल के लिए क्या-क्या ज़रूरी है?",
    "मानसून आने पर खेत में क्या-क्या काम होते हैं?",
    "baarish der se aaye to aap kya karte hain?",
    "aapne kheti kaise seekhi?",
]
it["hints"] = [
    "Avoid questions answered by yes/no.",
    "Use question words that make the farmer explain in detail.",
    "e.g. 'आपने खेती ___ सीखी?'",
    "Three open questions on how, why and what the farmer does.",
]
settle(it, "rung 2 no longer names कैसे/क्यों/क्या-क्या; acceptable now holds whole example open questions instead of single question words, and the key states the criterion (three questions, none answerable by yes/no), so a one-word reply cannot match. Open composition: judge on structure.",
       "खुला उत्तर: तीन प्रश्न जो हाँ/ना से न निपटें")

# 9. ch06-i07: rung 3 named 'poet'
it = items["c7-hindi-ch06-t01-i07"]
it["hints"][2] = "He wrote ___ (practical lessons) in kundaliya form."
settle(it, "rung 3 no longer names 'poet'.", "नीति की कुंडलियों के लिए प्रसिद्ध कवि")

# 10. ch06-i10: rung 3 named 'support'
it = items["c7-hindi-ch06-t01-i10"]
it["hints"][2] = "Lean on it when ___; wave it at ___."
settle(it, "rung 3 no longer names 'support'.", "नदी-नाले की गहराई नापना; कुत्ते-जानवर से बचाव (सहारा भी)")

# 11. ch09-i06 + i11: 'घर बनाया छोटा-सा अपने' ungrammatical
LINES = "फुर्र-फुर्र उड़ी चिड़िया रानी, चोंच में लाई बूँद-भर पानी; तिनका-तिनका चुन-चुन लाई, छोटी-सी फिर कुटिया बनाई।"
it = items["c7-hindi-ch09-t01-i06"]
it["prompt_en"] = f"Listen: '{LINES}' What two things did the bird do?"
it["prompt_hi"] = f"ये पंक्तियाँ सुनो — ‘{LINES}’ चिड़िया ने कौन-से दो काम किए?"
it["answer"] = "चोंच में पानी लाई और तिनके चुन-चुनकर अपना छोटा-सा घर (घोंसला) बनाया"
it["acceptable"] = [
    "पानी लाई",
    "घोंसला बनाया",
    "घर बनाया",
    "तिनके लाई",
    "paani laayi",
    "ghonsla banaya",
    "ghar banaya",
    "tinke laayi",
]
it["hints"] = [
    "What was in its beak?",
    "What did it make from straws?",
    "It brought ___ and built a little ___.",
    "Brought water and built its little home straw by straw.",
]
settle(it, "rewrote the original lines: 'घर बनाया छोटा-सा अपने' (ungrammatical; needed अपना) → 'तिनका-तिनका चुन-चुन लाई, छोटी-सी फिर कुटिया बनाई' (कुटिया f. → बनाई agrees; rhymes लाई/बनाई). i11's rhyme words updated to match.",
       "चोंच में पानी लाई; तिनके चुनकर घर (कुटिया) बनाया")
it = items["c7-hindi-ch09-t01-i11"]
it["answer"] = "हर पंक्ति के अंत में (रानी, पानी, लाई, बनाई) छोटा विराम; आवाज़ हल्की और फुर्तीली, जैसे चिड़िया फुदकती है"
it["verified"]["note"] = (it["verified"].get("note", "") + " " + STAMP +
                          "rhyme words updated to रानी, पानी, लाई, बनाई after i06's lines were corrected.").strip()

# 12. ch08-i08: unidiomatic prompt_hi
it = items["c7-hindi-ch08-t01-i08"]
it["prompt_hi"] = "पढ़ने से पहले अनुमान लगाओ — एक महान नर्तक बचपन में रोज़ कितने घंटे अभ्यास करने की बात करेगा, और क्यों?"
settle(it, "prompt_hi now 'रोज़ कितने घंटे अभ्यास करने की बात करेगा' — idiomatic, and faithful to prompt_en's 'how many hours'.",
       "रोज़ कई घंटे रियाज़ की, क्योंकि शास्त्रीय कला लगातार अभ्यास माँगती है")

# 13. ch05-i11: 'झाड़ू का बंडल हाथ पर'
COUP = "सोचा था छुट्टी है, सोऊँगा जी भर, पर माँ ने हाथ में थमा दी झाड़ू — ‘चलो, साफ़ करो घर!’"
it = items["c7-hindi-ch05-t01-i11"]
it["prompt_en"] = f"Listen: '{COUP}' What feeling do these lines carry, and what idea do they share with the story?"
it["prompt_hi"] = f"ये पंक्तियाँ सुनो — ‘{COUP}’ इनमें कैसा भाव है, और कहानी से कौन-सी बात मिलती है?"
settle(it, "couplet rewritten idiomatically: 'माँ ने हाथ में थमा दी झाड़ू — चलो, साफ़ करो घर!' (रोज़मर्रा: हाथ में थमाना; झाड़ू f. → थमा दी; rhyme भर/घर kept). Key unchanged.",
       "हास्य भरी निराशा; सोचा कुछ, हुआ कुछ — कहानी जैसा")

# 14. ch03-i06: prompt_en fidelity
it = items["c7-hindi-ch03-t01-i06"]
it["prompt_en"] = "Complete the sentence using ‘जबकि’: 'फूल सबको सुगंध देता है, जबकि काँटा…'"
settle(it, "prompt_en now matches prompt_hi: जबकि is supplied and the child completes the clause.",
       "…जबकि काँटा सबको चुभता है/दुख देता है।")

# 15. ch06-i11: 'स्क्रीन पर' ambiguity + weak acceptable
it = items["c7-hindi-ch06-t01-i11"]
it["prompt_hi"] = "फ़ोन या स्क्रीन के बारे में अपनी ओर से दो पंक्तियों की एक नीति-बात सरल हिंदी में बनाओ, जो एक ही शब्द से शुरू और उसी पर ख़त्म हो।"
it["answer"] = ("कोई भी दो पंक्तियाँ जो फ़ोन/स्क्रीन के बारे में एक साफ़ सीख दें और एक ही शब्द से शुरू होकर उसी पर ख़त्म हों; जैसे — "
                "‘फ़ोन चलाओ सोच के, समय न जाए खोय; आँख, नींद सब ठीक रहें, जब कम चलाओ फ़ोन।’")
it["acceptable"] = [
    "फ़ोन चलाओ सोच के, समय न जाए खोय; कम चलाओ फ़ोन",
    "स्क्रीन देखो कम, आँखें रहें ठीक; बाहर खेलो, कम स्क्रीन",
    "phone chalao soch ke, kam chalao phone",
    "screen dekho kam, bahar khelo, kam screen",
]
settle(it, "prompt_hi now 'फ़ोन या स्क्रीन के बारे में' (was readable as 'make it on a phone'); acceptable now holds whole example couplets that meet both criteria (a lesson; same first and last word) instead of fragments, and the key states the criteria. Open composition: judge on structure.",
       "खुला उत्तर: दो पंक्तियाँ, फ़ोन/स्क्रीन पर एक सीख, एक ही शब्द से शुरू-ख़त्म")

# 16. ch02-i07: text-dependence — make it an explicitly original parallel tale
it = items["c7-hindi-ch02-t01-i07"]
SEQ = ("(क) तीनों ने राजा को बताया कि घोड़ा किस ओर गया (ख) एक दिन राजा का घोड़ा खो गया "
       "(ग) तीनों ने खुरों के निशान ध्यान से देखे (घ) राजा ने तीन चतुर दोस्तों को बुलाया")
it["prompt_en"] = "This is a short tale of my own, like the one in the book. Put its events in order: " + SEQ
it["prompt_hi"] = "यह किताब वाली कहानी नहीं, उसी जैसी मेरी एक छोटी कथा है। इसकी घटनाओं को सही क्रम में लगाओ — " + SEQ
settle(it, "text-dependence resolved by framing, not by guessing the chapter: the item now says it is an original parallel tale ('किताब वाली कहानी नहीं, उसी जैसी मेरी एक छोटी कथा'), so its lost horse and cast cannot contradict तीन बुद्धिमान whatever the book's details are. (क) reworded to 'तीनों ने राजा को बताया कि घोड़ा किस ओर गया'. Sequence self-contained; key unchanged.",
       "ख, घ, ग, क")

# 17. ch05: real vs feigned illness — make i02/i08/i13 neutral to it
it = items["c7-hindi-ch05-t01-i02"]
it["prompt_en"] = "Once everyone at home treated the narrator as ill, what was it actually like for him?"
it["prompt_hi"] = "जब घर में सब कथावाचक को बीमार मानकर उसकी देखभाल करने लगे, तब उसे असल में कैसा अनुभव हुआ?"
settle(it, "text-dependence resolved by wording: i02, i08 and i13 no longer assert whether the narrator really fell ill or only had to be believed ill ('सब उसे बीमार मानकर देखभाल करने लगे' holds either way), which also makes them consistent with i07 hint 1. Key unchanged.",
       "बुरा: कड़वी दवा, परहेज़ का फीका खाना, बिस्तर पर पड़े रहना, खेल-दोस्त छूटे")
SEQ5 = ("(क) उसने तय किया कि अब कभी बीमार नहीं होना (ख) उसे लगा, बीमार होकर मज़े होंगे "
        "(ग) उसे कड़वी दवा और फीका खाना मिला (घ) घर में सब उसे बीमार मानकर उसकी देखभाल करने लगे")
it = items["c7-hindi-ch05-t01-i08"]
it["prompt_en"] = "Put in order: " + SEQ5
it["prompt_hi"] = "सही क्रम लगाओ — " + SEQ5
it["hints"][2] = "Wish → treated as ill → ___ → decision."
settle(it, "(घ) 'वह सच में बीमार पड़ गया' → 'घर में सब उसे बीमार मानकर उसकी देखभाल करने लगे', true whether the illness was real or feigned. Order ख, घ, ग, क unchanged.", "ख, घ, ग, क")
it = items["c7-hindi-ch05-t01-i13"]
it["answer"] = ("एक बच्चा मज़े और छुट्टी के लिए बीमार होना चाहता था; जब सब उसे बीमार मानकर देखभाल करने लगे, तो उसे कड़वी दवा, "
                "फीका खाना और बिस्तर मिला, खेल छूट गए; तब उसने तय किया — नहीं होना बीमार; सीख: सेहत सबसे बड़ा सुख है")
it["verified"]["note"] = (it["verified"].get("note", "") + " " + STAMP +
                          "key no longer asserts 'वह बीमार पड़ा' (real vs feigned illness unconfirmed against the chapter).").strip()

with open(P, "w", encoding="utf-8") as f:
    json.dump(d, f, ensure_ascii=False, indent=2)
    f.write("\n")
print("ok")
