import fs from 'fs';
const p='/home/user/Taxila/data/kits/c1-hindi.json';
const k=JSON.parse(fs.readFileSync(p,'utf8'));
const items=Object.fromEntries(k.topics.flatMap(t=>t.items).map(i=>[i.id,i]));
let n=0;
const a=items['c1-hindi-ch06-t01-i12'];
Object.assign(a,{
 prompt_en:"(Picture: exactly 3 mangoes in a row.) Look — one mango, one more mango, and one more mango. Count them with your finger — one, two… Now say it fully: '___ mangoes'.",
 prompt_hi:"तस्वीर देखो — एक आम, फिर एक और आम, फिर एक और आम। उँगली रखकर गिनो — एक, दो, …। अब पूरा बोलो: '___ आम'।",
 acceptable:["तीन आम","तीन","teen aam","tin aam","teen","3 aam","3 आम"],
 hints:["उँगली रखकर एक-एक आम गिनो।","एक, दो, और…?","___ आम","तीन आम।"],
 verified:{solverAnswer:"तीन आम",agrees:true,note:"r4 fix: count now stated in the prompt itself (picture spec: exactly 3 mangoes; spoken prompt names each of the three mangoes), so the key is derivable from the item alone. Re-solved: एक आम + एक और + एक और = तीन आम; matches key."}
}); n++;
const b=items['c1-hindi-ch13-t01-i02'];
Object.assign(b,{
 prompt_en:"Our fair poem: 'Chalo chalein mele mein bhai, gubbaare, choodi, aur …' What comes next? It is a sweet thing from the fair that rhymes with 'bhai'.",
 prompt_hi:"हमारी मेले वाली कविता सुनो: 'चलो चलें मेले में भाई, गुब्बारे, चूड़ी, और…' आगे क्या आता है? मेले की एक मीठी चीज़, जो 'भाई' से तुक मिलाती है।",
 acceptable:["मिठाई","mithai","mithaai","meethai"],
 hints:["पहली पंक्ति 'भाई' पर ख़त्म होती है — भा-ई। आख़िर में '-आई' चाहिए।","मेले में खाने वाली मीठी चीज़…","और मि___","गुब्बारे, चूड़ी, और मिठाई।"],
 verified:{solverAnswer:"मिठाई",agrees:true,note:"r4 fix: the poem's two lines (original text, same as workedExample.fadedVersion) are now inside the prompt, plus the rhyme anchor 'भाई' and the cue 'मीठी चीज़'. Re-solved blind from the item alone: -आई rhyme + sweet fair food = मिठाई; matches key."}
}); n++;
const c=items['c1-hindi-ch15-t01-i02'];
Object.assign(c,{
 prompt_en:"Our Holi poem: 'Aayi Holi, aayi Holi, rang udaati aayi toli, \"Holi hai!\" saari toli …' (Holi has come, the colour-throwing gang has come, 'It's Holi!' the whole gang …) What word comes next? It rhymes with Holi and toli.",
 prompt_hi:"हमारी होली वाली कविता सुनो: 'आई होली, आई होली, रंग उड़ाती आई टोली, \"होली है!\" सारी टोली…' आगे कौन-सा शब्द आता है? होली और टोली से तुक मिलाओ।",
 answer:"बोली",
 acceptable:["बोली","boli","boli.","बोली है"],
 hints:["होली, टोली — तीसरा तुक वाला शब्द '-ओली' पर ख़त्म होगा।","टोली ने 'होली है!' कहा — 'कहा' को दूसरे शब्द में…? ब से शुरू होता है।","सारी टोली ___","\"होली है!\" सारी टोली बोली।"],
 verified:{solverAnswer:"बोली",agrees:true,note:"r4 fix: replaced the thin line 'रंगों वाली टोली बोली' with an original three-line verse given in full inside the prompt ('आई होली, आई होली, / रंग उड़ाती आई टोली, / \"होली है!\" सारी टोली बोली।' — the gang shouts 'It's Holi!'; टोली feminine → बोली agrees). Re-solved from the item alone: -ओली rhyme + speech verb for टोली = बोली; matches key and skill s2 rhyme family होली–टोली–बोली."}
}); n++;
fs.writeFileSync(p, JSON.stringify(k,null,1)+'\n');
console.log('fixed',n);
