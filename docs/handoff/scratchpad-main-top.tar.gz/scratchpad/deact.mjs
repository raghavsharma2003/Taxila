import {arm,loadEnv,SUB_PATH} from "/home/user/Taxila/infra/azure.mjs"; loadEnv();
const A=`${SUB_PATH()}/resourceGroups/taxila-sin/providers/Microsoft.App/containerApps/taxila-sin-staging`;
const app=await arm("GET",`${A}?api-version=2024-03-01`); const latest=app.properties.latestRevisionName;
for (const r of (await arm("GET",`${A}/revisions?api-version=2024-03-01`)).value) {
  if (r.name!==latest && r.properties.active) { await arm("POST",`${A}/revisions/${r.name}/deactivate?api-version=2024-03-01`); console.log("deactivated",r.name); }
  else console.log(r.name, r.properties.active, r.properties.trafficWeight);
}
