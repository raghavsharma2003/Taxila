#!/bin/bash
for id in "$@"; do
curl -sS -m 30 "https://export.arxiv.org/api/query?id_list=$id" | python3 -c "
import sys,re
t=sys.stdin.read()
e=t.split('<entry>')[1] if '<entry>' in t else ''
g=lambda k: re.sub(r'\s+',' ',(re.search('<'+k+'>(.*?)</'+k+'>',e,re.S) or [None,''])[1])
print('##',g('published')[:10],'|',g('title'))
print(', '.join(re.findall('<name>(.*?)</name>',e)[:6]))
print(g('summary'));print()
"
sleep 3
done
