// 14.3.1 live proof of the ack trace on PRODUCTION, a dedicated @taxila.test account (never a child's data):
//   NODE_USE_ENV_PROXY=1 node --env-file=/home/user/Taxila/.env.local ackproof.mjs [base-url]
// text lesson → turn-ack (expects none "lane") and cascade lesson → turn-ack (any decision); waits for the trace flush;
// reads ONLY those two lessons' ack.decision rows, read-only (codes only by construction); deletes the account; re-reads
// (expects 0 rows). Prints codes and counts only: never an email, a key or a URL with credentials.
const BASE = process.argv[2] || "https://taxila-web.nicebay-a0d3a12f.eastus2.azurecontainerapps.io";
const { q } = await import("/home/user/taxila-int/server/db.js");
let cookie = "";
async function A(method, path, body, expect = [200, 201]) {
  const res = await fetch(BASE + path, { method, headers: { "content-type": "application/json", ...(cookie ? { cookie } : {}) }, body: body ? JSON.stringify(body) : undefined });
  const set = res.headers.get("set-cookie"); if (set) cookie = set.split(";")[0];
  const j = await res.json().catch(() => ({}));
  if (!expect.includes(res.status)) throw new Error(`${method} ${path} → ${res.status} ${JSON.stringify(j).slice(0, 200)}`);
  // turn-ack's refusal is a 204 with the reason in x-prefetch
  return { status: res.status, ...(res.status === 204 ? { none: res.headers.get("x-prefetch") } : {}), ...j };
}
const ok = (c, m) => { console.log(`${c ? "PASS" : "FAIL"} ${m}`); if (!c) process.exitCode = 1; };
const rows = async (ids) => { const r = await q("select sid, turn, data from trace_event where kind = 'ack.decision' and sid = any($1::text[]) order by id", [ids]); return r.rows ?? r; };
const st = Date.now(), PW = `ackproof-pw-${st}`;
await A("POST", "/api/auth/signup", { email: `ackproof+${st}@taxila.test`, password: PW, name: "Ack Proof", isGuardianAdult: true });
const ids = [];
try {
  const { child } = await A("POST", "/api/children", { firstName: "Riya", classLevel: 5, languagePref: "hinglish", interests: ["cricket"] });
  await A("POST", "/api/consent", { childId: child.id, grants: { core_tutoring: true, learning_profile: true, memory: true } });
  await A("POST", "/api/parent/controls", { childId: child.id, hoursStart: "00:00", hoursEnd: "23:59", dailyMinutes: 120 });
  const t = await A("POST", "/api/lesson/start", { childId: child.id, mode: "text" });
  ids.push(t.lessonId);
  const a1 = await A("POST", "/api/lesson/turn-ack", { lessonId: t.lessonId, text: "paanch", continuer: true }, [200, 204]);
  ok(a1.none === "lane", `text lesson ack → ${a1.none ?? a1.ack?.kind}`);
  await A("POST", "/api/lesson/end", { lessonId: t.lessonId });
  const c = await A("POST", "/api/lesson/start", { childId: child.id, mode: "cascade" });
  ids.push(c.lessonId);
  const a2 = await A("POST", "/api/lesson/turn-ack", { lessonId: c.lessonId, text: "haan didi main ready hoon", continuer: true }, [200, 204]);
  console.log(`  cascade lesson ack → ${a2.none ? `none:${a2.none}` : a2.ack?.kind}`);
  await A("POST", "/api/lesson/end", { lessonId: c.lessonId });
  let got = [];
  for (let i = 0; i < 10 && got.length < 2; i++) { await new Promise((r) => setTimeout(r, 2000)); got = await rows(ids); }
  ok(got.length === 2, `ack.decision rows landed: ${got.length} of 2`);
  for (const r of got) {
    const keys = Object.keys(r.data).sort().join(",");
    console.log(`  row turn ${r.turn} · ${r.sid === ids[0] ? "text" : "cascade"} · ${r.data.kind ?? `none:${r.data.none}`} · cohort ${r.data.cohort} · keys ${keys}`);
    ok(!/text|phrase|token|words/.test(keys), "codes only (no text / phrase / token key)");
  }
  const t0 = got.find((r) => r.sid === ids[0]);
  ok(t0?.data?.none === "lane" && t0?.data?.cohort === false, "text row: none lane, not cohort");
} catch (err) {
  ok(false, err.message);
} finally {
  await A("DELETE", "/api/account", { password: PW, confirm: true }).then(() => console.log("cleanup: account deleted"), (e) => console.log(`could not delete the account: ${e.message}`));
  if (ids.length) {
    await new Promise((r) => setTimeout(r, 1500));
    const left = await rows(ids);
    // erase.js deletes trace_event by the guardian's lesson sids as well as by cid: nothing may be left
    ok(left.length === 0, `ack.decision rows left after deletion: ${left.length}`);
  }
  process.exit(process.exitCode ?? 0);
}
