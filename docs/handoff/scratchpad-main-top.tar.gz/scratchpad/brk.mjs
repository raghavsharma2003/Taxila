import { synth, childSsml, segmentGroup } from "/home/user/Taxila/evals/duplex/taxilafdb/render.mjs";
import { VOICES } from "/home/user/Taxila/evals/duplex/taxilafdb/split.mjs";
const v = VOICES.train[0], m = VOICES.train[1];
for (const voice of [v, m]) for (const [texts, b] of [[["तीन बटा आठ", "नहीं नहीं तीन बटा चार"], 0], [["तीन बटा आठ", "नहीं नहीं तीन बटा चार"], 100], [["तीन बटा आठ", "नहीं नहीं तीन बटा चार"], 300], [["तीन बटा आठ", "नहीं नहीं तीन बटा चार"], 1000],
  [["क्या मैं उंगलियों पे गिन सकता हूँ?", "मुझे वो समझ नहीं आया"], 0], [["क्या मैं उंगलियों पे गिन सकता हूँ?", "मुझे वो समझ नहीं आया"], 500], [["क्या मैं उंगलियों पे गिन सकता हूँ", "मुझे वो समझ नहीं आया"], 0], [["उम्म", "बासठ"], 0], [["उम्म", "बासठ"], 600]]) {
  const r = await synth(childSsml(voice, texts, [b]));
  const s = segmentGroup(r.pcm, [Math.max(b, 300)]);
  console.log(voice.name, b, JSON.stringify(texts).slice(0, 40), "gap", s.gaps, s.ok);
}
