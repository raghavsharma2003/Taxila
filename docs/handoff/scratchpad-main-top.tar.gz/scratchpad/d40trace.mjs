const { q } = await import("/home/user/taxila-int/server/db.js");
const sid = process.argv[2];
const r = await q(`select turn, kind, src, data from trace_event where sid = $1 and kind in ('safety.scan','safety.hold','classify.verdict','turn.move','brain.move','director.plan') order by id`, [sid]);
const rows = r.rows ?? r; for (const x of rows) console.log(x.turn, x.kind, JSON.stringify(x.data).slice(0, 600));
const k = await q(`select kind, count(*)::int n from trace_event where sid = $1 group by 1 order by 2 desc`, [sid]);
console.log((k.rows ?? k).map((x) => `${x.kind}:${x.n}`).join(" "));
process.exit(0);
