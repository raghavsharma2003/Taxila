// Read-only PRODUCTION: content-filter blocks by category on real lessons (sid is a lesson id), and how many ended in a
// safeguard move on the same turn. Codes and counts only.
process.env.DATABASE_URL = process.env.TEST_DATABASE_URL;
const { q } = await import("/home/user/taxila-int/server/db.js");
const rows = (r) => r.rows ?? r;
await q("begin read only");
const ev = rows(await q(`select te.sid, te.turn, te.data->'filterCats' cats, te.data->>'promptId' pid from trace_event te join lesson l on l.id::text = te.sid
  where te.kind='model.call' and te.data ? 'filterCats' and te.t > now() - interval '30 days'`));
const byCat = {}; const turns = new Map();
for (const e of ev) { const k = (e.cats ?? []).slice().sort().join("+") || "?"; byCat[k] = (byCat[k] ?? 0) + 1; turns.set(`${e.sid}:${e.turn}`, k); }
console.log("filtered model calls on real lessons, 30d, by categories:", JSON.stringify(byCat));
let sg = {};
for (const [key, k] of turns) {
  const [sid, turn] = key.split(":");
  const d = rows(await q(`select data->>'move' move from trace_event where sid=$1 and turn=$2 and kind='director.turn' limit 1`, [sid, Number(turn)]))[0];
  const kk = `${k} → ${d?.move ?? "?"}`; sg[kk] = (sg[kk] ?? 0) + 1;
}
console.log("turns with a filtered call → the turn's move:", JSON.stringify(sg));
await q("rollback"); process.exit(0);
