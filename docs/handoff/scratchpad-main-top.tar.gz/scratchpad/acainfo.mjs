// READ-ONLY: taxila-web ingress, scale, and env NAMES (values only for non-secret TAXILA_DUPLEX*/VOICELIVE names)
const { arm, loadEnv, SUB_PATH } = await import("/home/user/Taxila/infra/azure.mjs");
loadEnv?.();
const base = `${SUB_PATH()}/resourceGroups/${process.env.AZURE_RESOURCE_GROUP}/providers/Microsoft.App/containerApps/taxila-web`;
const a = await arm("GET", `${base}?api-version=2024-03-01`);
const p = a.properties;
console.log("rev", p.latestRevisionName, "ready", p.latestReadyRevisionName);
console.log("ingress", JSON.stringify({ transport: p.configuration.ingress?.transport, allowInsecure: p.configuration.ingress?.allowInsecure, stickySessions: p.configuration.ingress?.stickySessions, traffic: p.configuration.ingress?.traffic, clientCertificateMode: p.configuration.ingress?.clientCertificateMode }));
console.log("scale", JSON.stringify(p.template.scale));
const env = p.template.containers[0].env || [];
console.log("env names:", env.length);
for (const e of env) if (/DUPLEX|VOICELIVE|CENTRALINDIA|TRACE_FULL|LANE/.test(e.name)) console.log("  ", e.name, e.secretRef ? "<secretRef>" : (/KEY|SECRET/.test(e.name) ? "<value hidden>" : e.value));
console.log("secrets:", (p.configuration.secrets || []).map((s) => s.name).filter((n) => /voice|centralindia|ai-/i.test(n)).join(", "));
