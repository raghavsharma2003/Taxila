FX=88
M=1e-6
P=dict(luna56_in=0.20,luna56_out=1.20, luna6_in=0.10,luna6_out=0.50, sol6_in=2,sol6_out=10, grok41_in=0.20,grok41_out=0.50,
       v4pro_in=1.74,v4pro_out=3.48, hd_tts=22, live_tx_h=1.02, s1_h=1.0, lid_h=0.30, flare_img=0.0066, img2_med=0.053)
def per_call(i,o,pin,pout): return i*pin*M+o*pout*M
reply_fast=lambda tin: per_call(tin,35,P['luna56_in'],P['luna56_out'])
classify=per_call(900,45,P['grok41_in'],P['grok41_out'])
grade=per_call(400,30,P['v4pro_in'],P['v4pro_out'])
print('reply fast @961', reply_fast(961), '@1500', reply_fast(1500), '@2500', reply_fast(2500))
print('reply luna6 @1500', per_call(1500,35,P['luna6_in'],P['luna6_out']))
print('classify', classify, 'grade', grade)
S={
 'low':     dict(turns=60, model_share=0.5, fan=2, miss=0.05, rewrite=0.05, tin=961,  why=5,  targets=1, stt_h=P['live_tx_h']*0.25, chars=8900, lessons=3, pieces=1.0, hit=0.95, race=0.125, imgs=0, imgp=P['flare_img'], end=0.008, other=0.005),
 'expected':dict(turns=80, model_share=0.75,fan=3, miss=0.08, rewrite=0.10, tin=1500, why=10, targets=2, stt_h=P['live_tx_h']*1.0,  chars=17300,lessons=3, pieces=1.5, hit=0.90, race=0.125, imgs=3, imgp=P['flare_img'], end=0.008, other=0.01),
 'high':    dict(turns=150,model_share=1.0, fan=4, miss=0.15, rewrite=0.44, tin=2500, why=20, targets=4, stt_h=(P['s1_h']+P['lid_h'])*1.0, chars=17300*1.5, lessons=3, pieces=1.5, hit=0.0, race=0.213, imgs=9, imgp=P['img2_med'], end=0.017, other=0.02),
}
out={}
for k,s in S.items():
    rc = s['turns']*( s['model_share']*(s['fan']+s['miss']) + (1-s['model_share'])*1 + s['rewrite'] )
    reply = rc*reply_fast(s['tin'])
    cls = s['turns']*s['model_share']*classify
    grd = s['why']*s['targets']*grade*1.13
    tts = s['chars']*P['hd_tts']*M
    stt = s['stt_h']
    studio = s['lessons']*s['pieces']*(1-s['hit'])*s['race']
    img = s['imgs']*s['imgp']
    end = s['lessons']*s['end']
    other = s['other']
    tot = reply+cls+grd+tts+stt+studio+img+end+other
    out[k]=dict(reply_calls=rc, reply=reply, classify=cls, grade=grd, tts=tts, stt=stt, studio=studio, images=img, end=end, other=other, total=tot)
for k,v in out.items():
    print(k, {a:round(b,4) for a,b in v.items()})
    t=v['total']; print('   $/h',round(t,3),' Rs/h',round(t*FX,1),' $/min',round(t/60,5),' Rs/min',round(t*FX/60,2))
    for h in (20,26): print(f'   {h}h/mo: ${t*h:.2f} Rs{t*h*FX:.0f}')
for price in (299,399):
    net=price/1.18*(1-0.0236)
    print(price,'net ex-GST ex-pay',round(net,1))
    for k,v in out.items():
        rsh=v['total']*FX
        print('   ',k,'hours at 45% COGS',round(net*0.45/rsh,2),'hours at 100%',round(net/rsh,2))
# India STT placeholder variants
print('MAI placeholder at FastTx 0.36/h:', 0.36)
