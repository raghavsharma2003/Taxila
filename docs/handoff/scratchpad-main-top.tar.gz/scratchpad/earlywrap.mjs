process.env.DATABASE_URL = process.env.TEST_DATABASE_URL;
const { q } = await import("/home/user/taxila-1441/server/db.js");
const rows = (r) => r.rows ?? r;
await q("begin read only");
const w = rows(await q(`select sid, turn, t, data->>'teacherReply' reply, data->'reasons' reasons from trace_event where kind='director.turn' and t > now() - interval '3 hours' and data->>'move'='wrap' and turn <= 8 order by t`));
for (const r of w) {
  const n = rows(await q(`select count(*)::int n from trace_event where sid=$1 and kind='director.turn'`, [r.sid]))[0].n;
  const reqs = rows(await q(`select data->'body'->>'childText' t, data->'body'->>'chipId' chip from trace_event where sid=$1 and kind='srv.req' and data->>'route'='POST /api/lesson/turn' order by t`, [r.sid]));
  console.log(`${r.sid.slice(0, 8)} wrap@t${r.turn} of ${n} turns ${r.t.toISOString()} reasons=${JSON.stringify(r.reasons).slice(0, 200)}`);
  for (const x of reqs) console.log(`    child: ${JSON.stringify(x.t)?.slice(0, 120)}${x.chip ? " chip=" + x.chip : ""}`);
  console.log(`    her: ${String(r.reply).slice(0, 120)}`);
}
await q("rollback"); process.exit(0);
