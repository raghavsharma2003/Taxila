// The turn's WORD and GUARD stages (TEACHER-BRAIN §5.1 stages 5-6): the teacher's reply written from the ONE compiled
// instructions string (one compile() for every lane) and guarded on the bytes by code: answer leaks, drift, floor
// breaks, praise/verdict agreement, the screen, register, script, length and the turn's shape. Moved out of
// server/routes/lesson.js unchanged by W2-E BR1 (BUILD-PLAN W2-E #2); the lesson start and the turn both call it.
import { safetyOpeningFor, safetyModeOf } from "../relational/openings.js";
import { chat, DEPLOY, isContentFilter, nonHarmFilter, notChildSafety } from "../azure.js";
import { floorViolations, scrubPii, filterSafe } from "../director/safety.js";
import { upcomingItem, hintShapeWords } from "../director/state.js";
import { findItem, promptFor, revealsAnswer, posesItem, handsBack, asksWhy, stripRungLabel } from "../director/items.js";
import { TURN_WORDS, FLOOR_FIX } from "../compiler/compile.js";
import { HELPLINES } from "../compiler/floor.js";
import { registerBroken, toAap } from "../director/register.js";
// round 3 fix (experience B6): arithmetic she states, and her own closed sums, checked in code
import { arithmeticSlip, selfPosedVerdict } from "./arith.js";
import { praiseProblem, claimsMistake, stripPraise, stripClaim, screenProblem, stripScreenRefs, emptyStage, leaksStage, stripStage, saysCantShow, stripCantShow, askParity, endOnAsk, joinAsk, lastQuestionOnly, wrapsUp, stripWrap, correctsRight, stripCorrection } from "../director/say.js";
import { mixedUnitComparison, withoutMixedUnits } from "../director/units.js";
import { screenContradiction, stripStrayParts } from "../director/modules.js";
import { isBare, repeatsEarlier, tidy, leadWithoutQuestion, sentences } from "../conversation/guards.js";
import { p5Flag } from "../conversation/flags.js";
import { leadSlotWanted, leadSlotNote, cleanLead, leadOk, composeTurn, requestNote, turnNote, LEAD_MAX_WORDS, LEAD_MIN_FIRST, LEAD_MAX_FIRST } from "../conversation/compose.js";
import { fallbackLead } from "../conversation/fallback-lead.js";
// r4-latency: the TTS part split (part 0 = the first sentence the child hears)
import { splitSentences } from "../voice/sentences.js";
import { lessonHyperbole, lessonIdiom } from "../safety/idioms.js";

/** p5-interaction: problems a gutted teaching turn's one retry may still carry, because code repairs them (never truth). */
const HELP_ASKS = new Set(["another", "clarify", "slower", "example", "story", "frustration", "easier"]);
const SOFT_FIX = new Set(["long", "twoq", "wrap", "script", "register", "stage", "cantshow", "uiword"]);
// round 3 fix (experience B10 / B2): her words never name a screen part by its internal name. The review heard "Chips mein
// chuno: keep going, short break, ya stop for today" (c4-10) and "bar1 ke 4 parts", "bar2 ko … kijiye" over strips labelled
// A and B (3 times): the child sees buttons and strips A / B, never "chips" or "bar1". PURE.
// Precision (2026-10-10 scan): only a CHOOSING verb makes "chips" the buttons ("chips mein chuno", "chips par tap karo", "tap one
// of the chips"); food chips in a lesson ("chips mein namak aur tel", "a potato chip on a piece of paper") are not. A strip's
// internal name is "bar1" / "bar2" (or "bar 1 / 2" with a case marker after it); a bar graph's "bar 4 squares" is not.
const CHOOSE = String.raw`(?:chuno|chuniye|chun\s+lo|choose|pick|tap|dabao|dabaiye|daba\s+do|select|click)`;
const CHIPS_UI = String.raw`chips?\s+(?:mein|me|par|pe|se|on|in|from)\s+(?:se\s+|ek\s+|one\s+)?(?:\S+\s+){0,2}?${CHOOSE}|chips\s+${CHOOSE}|${CHOOSE}\s+(?:on\s+)?(?:one\s+of\s+)?(?:a\s+|the\s+|ek\s+)?chips?`;
const BAR_UI = String.raw`bar[1-9](?![\p{L}\p{N}])|bar\s[12]\s+(?:ke|ko|mein|me|ka|ki|par|aur|and|is|has)(?![\p{L}])`;
/** A sentence that points at what is on the screen ("Screen par…", "dekho", "look at", "this roti", "yeh board"). */
const SCREEN_SENTENCE = /(?<![\p{L}])(?:screen|board|tray|dekho|dekhiye|dekhein|dekh\s+rahe|look|see\s+(?:the|this|how)|here|yahan|yahaan|is\s+(?:roti|picture|tasveer|board|shape|strip|bar)|yeh\s+(?:roti|picture|tasveer|board|shape|strip|bar)|this\s+(?:roti|picture|board|shape|strip|bar))(?![\p{L}])/iu;
const UI_WORD = new RegExp(String.raw`(?<![\p{L}\p{N}])(?:${CHIPS_UI}|${BAR_UI})`, "iu");
export const namesUiPart = (t) => UI_WORD.test(String(t ?? ""));
/** The code repair: "chips mein chuno / tap the chips" → the screen; "bar1 / bar2" → A / B (the strips' own labels). */
export function plainUiWords(t, lang = "hinglish") {
  const scr = lang === "english" ? "on the screen" : "screen par";
  return String(t ?? "")
    .replace(new RegExp(String.raw`(?<![\p{L}\p{N}])bar\s?([12])(?=\s+(?:ke|ko|mein|me|ka|ki|par|aur|and|is|has)(?![\p{L}]))|(?<![\p{L}\p{N}])bar([1-9])(?![\p{L}\p{N}])`, "giu"), (_, a, b) => "ABCDEFGHI"[Number(a ?? b) - 1] ?? (a ?? b))
    .replace(new RegExp(String.raw`(?<![\p{L}\p{N}])chips?\s+(?:mein|me|par|pe|se|on|in|from)(?=\s+(?:se\s+|ek\s+|one\s+)?(?:\S+\s+){0,2}?${CHOOSE})`, "giu"), scr)
    .replace(new RegExp(String.raw`(?<![\p{L}\p{N}])chips(?=\s+${CHOOSE})`, "giu"), scr)
    .replace(new RegExp(String.raw`(?<=${CHOOSE}\s+)(?:on\s+)?(?:one\s+of\s+)?(?:a\s+|the\s+|ek\s+)?chips?(?![\p{L}])`, "giu"), lang === "english" ? "a button on the screen" : "screen par ek button")
    .replace(/\s{2,}/g, " ").trim();
}
/** Text-mode hard ceiling for the reply guard (the compiled rule asks for TURN_WORDS). */
export const REPLY_MAX_WORDS = { "6-9": 30, "10-15": 40 };

export const words = (t) => String(t || "").trim().split(/\s+/).filter(Boolean).length;

/**
 * The call-site recipe for floorViolations (context/inbox/merged/harvest-ports.json; decision never-rules-floor-violations
 * revised): the posed item's verified content — its prompt in each language, the answer, the acceptable answers, the
 * hints and the diagnostic options — is passed as `content`, which safety.js removes only as whole long segments that
 * carry a hit of their own (0/26,576 posed kit questions flagged with it). Exported for the eval.
 */
export function floorContentOf(item) {
  if (!item) return [];
  const s = (x) => (typeof x === "string" && x.trim() ? [x] : []);
  return [...s(item.prompt_en), ...s(item.prompt_hi), ...s(item.answer), ...(item.acceptable ?? []).flatMap(s), ...(item.hints ?? []).flatMap(s),
    ...(item.options ?? []).flatMap((o) => s(o?.text))];
}

/** A child's words on their way to a model: direct identifiers masked (scrubPii; decision scrub-pii-cued). */
export const scrubbed = (t) => scrubPii(t).text;
/** The copy a reply-side model call reads: scrubbed, and the Hindi number "teen" as 3 (safety.js filterSafe). */
export const forModel = (t) => filterSafe(scrubbed(t));

/** The reply model call, injectable for tests of the guards (tests/lesson-truth.test.mjs); production uses azure.js. */
export const replyDeps = { chat };

/**
 * round 5 (sim lab p43, main safety review): do the CHILD'S OWN WORDS trip the content filter? The reply prompt carries the
 * system brief, her earlier lines and the history as well, and a harm category can fire on that mix: the reply prompt for
 * "6 aur 5... 30... 3,00,000?" came back `sexual` (TEST lesson 2af743d2, turn 4) while the classifier and the labeller
 * passed the same words, and the child got the helpline script. The probe sends the child's recent words alone (masked as
 * the reply saw them, joined so a disclosure spread over several turns is judged whole) through the reply deployment, so
 * the same filter policy judges them. "harm": a harm or unreadable block; "clear": passed (or only an injection / copyright
 * detector fired); "unknown": the probe itself failed, which the caller treats as harm (it could not be cleared).
 * @returns {Promise<"harm"|"clear"|"unknown">}
 */
export async function childWordsTrip(words, { trace } = {}) {
  if (!words) return "clear";
  try {
    await replyDeps.chat(DEPLOY.reply, [{ role: "system", content: "Answer with one word: ok" }, { role: "user", content: words }],
      { maxTokens: 16, effort: "none", timeoutMs: 4000, retries: 1, trace, purpose: "filter_probe" });
    return "clear";
  } catch (e) {
    // 14.4: a block by the hate detectors alone is no child-safety signal (azure.js notChildSafety)
    if (isContentFilter(e)) return notChildSafety(e) ? "clear" : "harm";
    return "unknown";
  }
}

/** The child's words a filter probe judges: their last few turns and this one, masked, newest last. */
export const probeWords = (history, childText) =>
  [...history.filter((t) => t.who !== "teacher").slice(-4).map((t) => t.text), childText].filter((t) => typeof t === "string" && t.trim()).map(forModel).join("\n");

/** Keep whole sentences up to `max` words (last-resort guard after one rewrite failed). */
export function trimToWords(text, max) {
  const parts = p5Flag("GUARDS") ? sentences(text) : String(text).match(/[^.!?।]+[.!?।]*\s*/g) ?? [text];
  let out = "";
  for (const s of parts.length ? parts : [text]) {
    if (words(out + s) > max) break;
    out += s;
  }
  return (out || String(text).split(/\s+/).slice(0, max).join(" ") + "…").trim();
}

/** Moves whose turn must put the active item's question to the child (at rung 0, before any nudge). */
export const POSING_MOVES = new Set(["practice", "probe", "retrieval", "greet"]);
/** Moves that end the exchange or hold it; every other turn must hand the floor back. */
export const CLOSING_MOVES = new Set(["wrap", "safeguard"]);
/**
 * Teaching turns with no item on the table: what they say must not answer the question that comes next
 * (measured in evals/director-sim.mjs: an explain turn said "use one-fourth kehte hain", and the next item,
 * "Ek tukde ko kya kehte hain?", was scored as an unaided correct answer).
 */
export const TEACHING_MOVES = new Set(["hook", "explain", "worked_example", "reteach"]);
/**
 * Scripts a written reply may use: Roman for Hinglish/English (the compiled rule asks for it), Roman or
 * Devanagari for Hindi. Measured in evals/director-sim.mjs: a stray Gujarati word and Devanagari fragments
 * inside Roman Hinglish both reached the child before this check.
 */
// F18 (evals/owner-truth s09 t17): `\p{M}` accepted ANY script's combining marks, so Gujarati vowel signs (U+0A82,
// U+0AC7) passed as "Latin". Script=Inherited is the shared combining set (accents on Latin); a script's own marks belong
// to that script (Devanagari's to Devanagari, allowed only for Hindi).
const LATIN = /^[\p{Script=Latin}\p{Script=Common}\p{Script=Inherited}]*$/u;
const SCRIPT_OK = { hinglish: LATIN, english: LATIN, hindi: /^[\p{Script=Latin}\p{Script=Devanagari}\p{Script=Common}\p{Script=Inherited}]*$/u };
const OFF_SCRIPT = { hinglish: /[^\p{Script=Latin}\p{Script=Common}\p{Script=Inherited}]/gu, english: /[^\p{Script=Latin}\p{Script=Common}\p{Script=Inherited}]/gu,
  hindi: /[^\p{Script=Latin}\p{Script=Devanagari}\p{Script=Common}\p{Script=Inherited}]/gu };
/** Is a written reply in the scripts its language allows? Exported for tests. */
export const scriptOk = (t, lang) => (SCRIPT_OK[lang] ?? LATIN).test(String(t ?? ""));

/**
 * What the child reads when no reply could be written (the model failed twice): content where there is
 * some — the question on the table — else a fixed line for the move. Never a throw after the turn's
 * evidence is decided: the lesson goes on. The safeguard line carries the helpline (the floor's contract).
 */
/** Both crisis lines, from the one source (compiler/floor.js HELPLINES; the floor and V2 §16 name them together). */
const HELPLINE_LINE = HELPLINES.map((h) => `${h.name} ${h.number}`).join(" or ");
const HELPLINE_LINE_HI = HELPLINES.map((h) => `${h.name} ${h.number}`).join(" ya ");
export const FALLBACK = {
  english: { wrap: "That's all for today. See you next time!", safeguard: `What you said matters. Please tell a grown-up you trust, or call ${HELPLINE_LINE}. Are you okay right now?`,
    safeguardCheck: `Are you okay right now? If anything is worrying you, tell a grown-up you trust, or call ${HELPLINE_LINE}.`,
    other: "Sorry, I lost my words for a second. Can you say that again?",
    heard: "Thanks for telling me! Let's keep going.",
    checkinStop: "That's okay. We can keep going, take a short break, or stop for today. You choose.",
    checkinRel: "That's okay, stopping is completely fine. Are you okay right now, and is a grown-up nearby?",
    forgetSafety: "That is not something to forget, because your safety matters. You did the right thing by telling. Please tell a grown-up you trust, so they can help." },
  hinglish: { wrap: "Aaj ke liye itna hi. Phir milte hain!", safeguard: `Tumne jo bataya, woh zaroori hai. Kisi bade ko batao jis par bharosa ho, ya ${HELPLINE_LINE_HI} pe call karo. Kya tum abhi theek ho?`,
    safeguardCheck: `Kya tum abhi theek ho? Agar koi baat pareshan kar rahi hai, toh kisi bade ko batao jis par bharosa ho, ya ${HELPLINE_LINE_HI} pe call karo.`,
    other: "Ek second, meri baat atak gayi. Kya tum phir se bata sakte ho?",
    heard: "Accha, batane ke liye thanks! Chalo, aage badhte hain.",
    checkinStop: "Theek hai, koi baat nahi. Hum aage chal sakte hain, thoda break le sakte hain, ya aaj ke liye stop kar sakte hain. Tum batao.",
    checkinRel: "Theek hai, rukna bilkul theek hai. Kya tum abhi theek ho, aur koi bada paas hai?",
    forgetSafety: "Isse bhoolna theek nahi hoga, kyunki tumhari safety zaroori hai. Tumne batakar bilkul sahi kiya. Kisi bade ko zaroor batao jis par tumhe bharosa ho, taaki woh tumhari madad kar sakein." },
};
// round 2 safety floor (adversarial B2, 2026-10-07): a stop check-in is an OFFER to stop, never a teaching turn. Before
// this it was guarded as one: her honest "aaj ke liye yahin rok dete hain" tripped the goodbye check ("wrap"), the rewrite
// note said "the lesson goes on … end with one question about the same thing", stripWrap cut the stop option, and the child
// who said "bas, aaj ke liye itna hi" heard "ab isi jagah se continue karte hain — 1 kg mein kitne grams…?" (w2flow-walk
// pass 2; reproduced without a model). A check-in now must name the stop option and must not ask a lesson question or
// hold them for "one more"; what cannot be rewritten clean is the fixed check-in line below, never the lesson's question.
// round 3 fix (adversarial B5): on a forget request after a disclosure (relational overlay forget_after_safety) her line never
// promises to forget it or keep it secret (the incident row and the hand-off stand, so the promise would be false). PURE.
const FORGET_PROMISE = /(?<![\p{L}])(?:i(?:'ll| will| can| am going to)? (?:forget|not remember|keep (?:it|this|that|your secret)(?: a)? secret)|i won'?t (?:remember|keep|tell|say)|(?:it'?s|it is|this is|that'?s|that is) (?:our|a|just our) secret|(?:our|a) little secret|forgotten|between (?:us|you and me)|nobody will know|no one will know|bhool (?:jaung[ia]|jaunga|jaungi|jaati|jaata|gayi|gaya|chuk[ia]|chuke|di|diya|dungi|dunga)|bhula (?:dungi|dunga|diya|di|deti|deta)|yaad nahi\s+rakh(?:ungi|unga|ti|ta|enge|oongi)|nahi\s+rakh(?:ungi|unga|oongi|enge)|kisi ko (?:nahi|nahin|na) bata(?:ungi|unga|oongi|yenge|enge|aungi|aunga)|(?:raaz|raz|secret) (?:rakh(?:ungi|unga|enge|te|ti)?|rahega|rahegi|hai)|hamara (?:raaz|secret)|mita (?:diya|di|dungi|dunga|deti|deta)|भूल (?:जाऊँगी|जाऊंगी|जाऊँगा|जाऊंगा|गई|गया)|याद नहीं रखूँगी|याद नहीं रखूंगी|किसी को नहीं बताऊँगी|किसी को नहीं बताऊंगी|राज़|राज)(?![\p{L}])/iu;
export const promisesForget = (t) => FORGET_PROMISE.test(String(t ?? ""));

/** The child's options include stopping (Roman Hinglish / English / Devanagari). */
const STOP_OFFER = /(?<![\p{L}])(?:rok|rukna|ruk|ruke|rukte|rukenge|stop|stopping|bas|band|khatam|khatm|chhutti|for today|aaj ke liye|end (?:here|now|for today))|रोक|रुक|बस|बंद|ख़?त्म|आज के लिए/iu;
/** "One more / a last / first a small check" — holding a child who asked to stop (NEVER MANIPULATE). */
const HOLD_WORDS = /(?<![\p{L}])(?:(?:pehle|first|before (?:you go|we stop|stopping))\b[^.?!।]{0,30}\b(?:check|question|sawal|sawaal|sum|try)|(?:last|aakhri|akhri|one more|ek aur|bas ek)\s+(?:chhota\s+sa\s+|small\s+|quick\s+|little\s+)?(?:check|question|sawal|sawaal|sum|try|problem))/iu;
/** A check-in's words: what is wrong with them (none: an honest offer of the three choices). Exported for tests. */
export function checkInProblems(t, { kind = "stop", active = null, lang = "hinglish" } = {}) {
  const text = String(t ?? "");
  const out = [];
  const asksLesson = (active && (text.includes(promptFor(active, lang)) || posesItem(text, active, lang)))
    || (String(text).match(/[^.!?।]*[?？]/g) ?? []).some((q) => /\d/.test(q)) || HOLD_WORDS.test(text);
  if (asksLesson) out.push("hold");
  if (!STOP_OFFER.test(text)) out.push("nostop");
  // round 3 (conversation; local battery base-head-1, "end the lesson"): "Okay, Meher. We'll stop the lesson here." named
  // the stop and offered nothing else, and the child's "yes" then got "Lesson ended … <a question>". A stop check-in is a
  // CHOICE: going on (or a break) is offered as well. (The relational check-in "rel" only has to say stopping is fine.)
  if (kind === "stop" && p5Flag("R3CONV") && !GO_ON_OFFER.test(text)) out.push("nochoice");
  // round 3 integration (owner-3 on the integrated local tree, 2026-10-09, 2 of 10 stop phrases): the R3 say-back "in their
  // words" turned "lesson khatam" into "Theek hai Aarav, aap lesson khatam karna chahte hain—keep going, …": goodbye words
  // on a turn that goes on (F9 mixed signal; owner-3 RX.wrapWords). A stop check-in carries none of the owner's goodbye
  // words; the check-in's own rewrite ("offer stopping as one of the choices, not as a goodbye"), then the fixed line, apply.
  if (kind === "stop" && p5Flag("R3CONV") && CHECKIN_GOODBYE.test(text)) out.push("wrap");
  return out;
}
/** The owner-3 acceptance's goodbye words (tests/prod/_owner.mjs RX.wrapWords), read on a stop check-in only. */
const CHECKIN_GOODBYE = /\b(?:aaj ke liye (?:bas )?(?:itna|yahin)|lesson (?:yahin )?(?:khatam|khatm)|phir milenge|phir milte hain|goodbye|bye[\s-]*bye|see you|that'?s all for today|let'?s stop (?:here|for today)|yahin rok(?:te| dete) hain)\b/i;
/** The child's options include going on or a short break (Roman Hinglish / English / Devanagari). */
const GO_ON_OFFER = /(?<![\p{L}])(?:continue|keep\s+going|carry\s+on|go\s+on|aage|chalte\s+rah|jaari|padhte\s+rah|karte\s+rah|break|pause|aaram|thoda\s+ruk)|आगे|जारी|ब्रेक/iu;
/**
 * The fixed safeguarding line (both helplines) in the child's language mode and address form: W2-I's vetted opening
 * (server/relational/openings.js, identical to the client's src/lesson/safetyStrings.ts) and then one check-in question.
 */
const CHECK_Q = { en: "Are you safe right now?", hinglish: { tum: "Kya tum abhi safe ho?", aap: "Kya aap abhi safe hain?" }, hi: { tum: "क्या तुम अभी सुरक्षित हो?", aap: "क्या आप अभी सुरक्षित हैं?" } };
/**
 * F10 (evals/owner-truth patch 05, reconciled with W2-I's openings): a fallback safeguard line whose trigger was ONLY the
 * classifier model or the content filter ("I'm done" read as distress) gets the neutral check-in wording, never "what you
 * said matters". Every other trigger (the predicate's families, the relational floor, an unknown/legacy state) keeps the
 * vetted disclosure opening. W2-I's CHECK opening (openings.js) names Childline only, and a fallback line must name both
 * helplines (tests/lesson-truth "safeguard fallback names ... Tele-MANAS 14416"), so the check form is patch 05's
 * two-helpline line; Devanagari has no vetted two-helpline check line yet, so it keeps the disclosure opening.
 * Wording only: the predicate, the hold and the helplines are unchanged.
 */
const CHECK_ONLY_KINDS = new Set(["model", "content_filter"]);
/**
 * 14.4 (main safety review; QA TEST bfb56c4f t1 "ye sawaal mujhe maar dalega": no detector read distress, yet the reteach
 * line asked "kya aap khud ko nuksan pahunchane ki baat kar rahe hain?" and gave 1098 / 14416; f3ebe9b0 and e35b9ea0 the
 * same shape, the second inside a check-in): the REPLY MODEL never makes the safeguarding call. The tier is the Director's
 * (state.js checkTier on the predicate, the reads and the floor); a reply that names a helpline or asks about hurting
 * themself on a turn that is not the full script, in a lesson with no full script yet, is a problem ("harmtalk"):
 * rewritten, else the move's fixed line.
 */
const HARM_TALK = /(?<![\p{L}\p{M}\p{N}])(?:child ?line|tele[\s-]?manas|1098|14416|help ?line|चाइल्डलाइन|टेली[\s-]?मानस|हेल्पलाइन|suicid\w*|aatm ?hatya|atmhatya|आत्महत्या)(?![\p{L}\p{M}\p{N}])|(?<![\p{L}\p{M}])(?:khud|apne ?(?:aap|ap)|apne|खुद|अपने ?आप)\s*(?:ko|को)\s+(?:\S+\s+){0,1}(?:nuksan|nuksaan|nukasan|nuqsan|nuqsaan|harm|maar|maarne|kill|नुकसान|नुक़सान|मारने)|(?<![\p{L}\p{M}])(?:khud|apne ?(?:aap|ap)|खुद|अपने ?आप)\s*(?:ko|को)\s+(?:hurt|chot|चोट|हर्ट)\s+(?:pahunchane|pahuchane|pohnchane|karne|dene|पहुंचाने|पहुँचाने|करने)|(?<![\p{L}\p{M}])(?:apni|अपनी)\s+(?:jaan|जान)\s+(?:lene|dene|लेने|देने)|self[\s-]?harm|(?<![\p{L}\p{M}])(?:aap|tum|tu|आप|तुम)\s+(?:abhi\s+|ghar\s+(?:par|pe|mein|me)\s+|अभी\s+)?(?:safe|surakshit|सेफ|सुरक्षित)\s+(?:hain|ho|hai|hoon|mehsoos|feel|हैं|हो)|(?:are|do)\s+you\s+(?:feel(?:ing)?\s+)?safe\b|(?:want|wanting|wanted|thinking|thought|think|feel like|feeling like|plan\w*|try\w*)\s+(?:of\s+|about\s+|to\s+)?(?:hurt|harm|kill)(?:ing)?\s+yourself|(?:harm|kill)(?:ing)?\s+yourself|(?:marne|mar jaane|khatam karne|jaan dene)\s+(?:ka|ke|ki)\s+(?:khayal|khyal|vichar|soch|mann|man|baat|baatein|baaten)|(?<![\p{L}\p{M}])(?:nuksan|nuksaan|nukasan|nuqsan|nuqsaan|hurt|harm|chot|नुकसान|नुक़सान|चोट)\s+(?:pahunchane|pahuchane|pohnchane|karne|dene|पहुंचाने|पहुँचाने|करने)\s+(?:ka|ke|ki|का|के|की)\s+(?:khayal|khyal|vichar|soch|irada|ख़याल|खयाल|ख्याल|विचार)|(?:ghar|घर)\s+(?:mein|me|pe|par|में|पर)\s+(?:kisi|koi|किसी|कोई)\s+(?:se\s+|से\s+)?(?:dar|darr|hurt|maar|डर)/iu;
export const harmTalk = (text) => HARM_TALK.test(String(text ?? ""));
/** 14.4.1: the child's turn when their words could not be shown to the reply model (a context filter block): a note, never a line */
const MASKED_TURN = "(their reply is not shown here: no guessing at it and no quoting it; a warm thanks in a few words, then carry on with the move)";
/** A child line the predicate's idiom checks read as the lesson's own pressure, said as what it means (the reply's history only). */
export const idiomMeaning = (text) => (lessonHyperbole(String(text ?? "")) ? "(they said the studying feels like too much for them)"
  : lessonIdiom(String(text ?? "")) ? "(they said this question is too hard for them)" : null);
/** May a reply on this (next) state carry safety talk of its own? Only the full script's turns, or once one has happened. */
export const safetyTalkAllowed = (state) => state?.safeguardedAt != null
  || (state?.lastMove?.kind === "safeguard" && state?.lastMove?.tier !== "check") || !!state?.safeguard?.carried;
export function safeguardLine(ctx = {}, { kind = null } = {}) {
  const mode = safetyModeOf(ctx.lang);
  if (CHECK_ONLY_KINDS.has(kind) && mode !== "hi") {
    const line = FALLBACK[mode === "en" ? "english" : "hinglish"].safeguardCheck;
    return ctx.address === "aap" && mode !== "en" ? toAap(line) : line;
  }
  const open = safetyOpeningFor(ctx.lang, { address: ctx.address });
  const q = open.mode === "en" ? CHECK_Q.en : CHECK_Q[open.mode][ctx.address === "aap" ? "aap" : "tum"];
  return `${open.text} ${q}`;
}
// round 5 (sim lab voice lane; persona p19): the safeguard's STAY turn (the episode's second turn: "stay with them and keep
// listening") whose model line broke a guard fell back to the FIRST turn's fixed line, word for word ("Aapne mujhe batakar
// bilkul sahi kiya..." twice in a row, after the child had answered). The stay turn has its own fixed line: she is here,
// no hurry, both helplines named (the floor's requirement), and a door left open instead of the same question again.
const STAY = {
  en: { tum: "I'm right here, and there's no hurry. If anything is worrying you, a grown-up you trust can help, and you can call Childline 1098 or Tele-MANAS 14416 any time. You can tell me whatever you want to.",
    aap: "I'm right here, and there's no hurry. If anything is worrying you, a grown-up you trust can help, and you can call Childline 1098 or Tele-MANAS 14416 any time. You can tell me whatever you want to." },
  hinglish: { tum: "Main yahin hoon, koi jaldi nahi hai. Agar koi baat pareshan kar rahi ho, toh jis bade par bharosa ho woh madad kar sakte hain, aur Childline 1098 ya Tele-MANAS 14416 pe kabhi bhi call kar sakte ho. Jo mann ho, mujhe bata sakte ho.",
    aap: "Main yahin hoon, koi jaldi nahi hai. Agar koi baat pareshan kar rahi ho, toh jis bade par bharosa ho woh madad kar sakte hain, aur Childline 1098 ya Tele-MANAS 14416 pe kabhi bhi call kar sakte hain. Jo mann ho, mujhe bata sakte hain." },
  hi: { tum: "मैं यहीं हूँ, कोई जल्दी नहीं है। अगर कोई बात परेशान कर रही हो, तो जिस बड़े पर भरोसा हो वे मदद कर सकते हैं, और चाइल्डलाइन 1098 या टेली-मानस 14416 पर कभी भी फ़ोन कर सकते हो। जो मन हो, मुझे बता सकते हो।",
    aap: "मैं यहीं हूँ, कोई जल्दी नहीं है। अगर कोई बात परेशान कर रही हो, तो जिस बड़े पर भरोसा हो वे मदद कर सकते हैं, और चाइल्डलाइन 1098 या टेली-मानस 14416 पर कभी भी फ़ोन कर सकते हैं। जो मन हो, मुझे बता सकते हैं।" },
};
// round 5 (14.2): the check-in a lesson opens on when it starts within hours of a safeguarding incident (state.js decide,
// `carried`). Fixed, like every safeguarding line. Discreet: no word of what was said or that anything was; both
// helplines; the choice to start slowly or stop. {name} is the child's first name.
const CARRIED = {
  en: { tum: "Hi {name}! Before we start: how are you feeling today? If anything ever worries you, a grown-up you trust can help, and you can call Childline 1098 or Tele-MANAS 14416 any time. Shall we start slowly, or stop for today? Either is fine.",
    aap: "Hi {name}! Before we start: how are you feeling today? If anything ever worries you, a grown-up you trust can help, and you can call Childline 1098 or Tele-MANAS 14416 any time. Shall we start slowly, or stop for today? Either is fine." },
  hinglish: { tum: "Namaste {name}! Shuru karne se pehle ek baat: aaj mann kaisa hai? Agar kabhi koi baat pareshan kare, toh jis bade par bharosa ho woh madad kar sakte hain, aur Childline 1098 ya Tele-MANAS 14416 pe kabhi bhi call kar sakte ho. Dheere se shuru karein, ya aaj ke liye bas? Dono theek hain.",
    aap: "Namaste {name}! Shuru karne se pehle ek baat: aaj mann kaisa hai? Agar kabhi koi baat pareshan kare, toh jis bade par bharosa ho woh madad kar sakte hain, aur Childline 1098 ya Tele-MANAS 14416 pe kabhi bhi call kar sakte hain. Dheere se shuru karein, ya aaj ke liye bas? Dono theek hain." },
  hi: { tum: "नमस्ते {name}! शुरू करने से पहले एक बात: आज मन कैसा है? अगर कभी कोई बात परेशान करे, तो जिस बड़े पर भरोसा हो वे मदद कर सकते हैं, और चाइल्डलाइन 1098 या टेली-मानस 14416 पर कभी भी फ़ोन कर सकते हो। धीरे से शुरू करें, या आज के लिए बस? दोनों ठीक हैं।",
    aap: "नमस्ते {name}! शुरू करने से पहले एक बात: आज मन कैसा है? अगर कभी कोई बात परेशान करे, तो जिस बड़े पर भरोसा हो वे मदद कर सकते हैं, और चाइल्डलाइन 1098 या टेली-मानस 14416 पर कभी भी फ़ोन कर सकते हैं। धीरे से शुरू करें, या आज के लिए बस? दोनों ठीक हैं।" },
};
/** The fixed check-in a lesson opens on after a recent safeguarding incident. Exported for tests. */
export function carriedCheckInLine(ctx = {}) {
  const mode = safetyModeOf(ctx.lang);
  const line = CARRIED[mode === "en" ? "en" : mode === "hi" ? "hi" : "hinglish"][ctx.address === "aap" ? "aap" : "tum"];
  const name = String(ctx.firstName ?? "").trim().split(/\s+/)[0] ?? "";
  return name ? line.replace("{name}", name) : line.replace(" {name}!", "!").replace(" {name}", "");
}
/** The fixed line for the safeguard's stay turn (never the first turn's line again). Exported for tests. */
export function safeguardStayLine(ctx = {}) {
  const mode = safetyModeOf(ctx.lang);
  return STAY[mode === "en" ? "en" : mode === "hi" ? "hi" : "hinglish"][ctx.address === "aap" ? "aap" : "tum"];
}
// 14.4: the fixed line for the check-in tier when no model line could be written: noticing and one open question, no numbers
const CHECK_IN = {
  en: { tum: "That sounds hard. Are you okay right now? You can tell me what happened.", aap: "That sounds hard. Are you okay right now? You can tell me what happened." },
  hinglish: { tum: "Yeh sunke lag raha hai kuch mushkil hai. Kya tum abhi theek ho? Jo hua, mujhe bata sakte ho.", aap: "Yeh sunke lag raha hai kuch mushkil hai. Kya aap abhi theek hain? Jo hua, mujhe bata sakte hain." },
  hi: { tum: "यह सुनकर लग रहा है कुछ मुश्किल है। क्या तुम अभी ठीक हो? जो हुआ, मुझे बता सकते हो।", aap: "यह सुनकर लग रहा है कुछ मुश्किल है। क्या आप अभी ठीक हैं? जो हुआ, मुझे बता सकते हैं।" },
};
/** The fixed check-in line (the check-in tier's fallback). Exported for tests. */
export function distressCheckLine(ctx = {}) {
  const mode = safetyModeOf(ctx.lang);
  return CHECK_IN[mode === "en" ? "en" : mode === "hi" ? "hi" : "hinglish"][ctx.address === "aap" ? "aap" : "tum"];
}
export function fallbackReply(state, item) {
  if (state.lastMove?.kind === "safeguard" && state.lastMove?.tier === "check") return distressCheckLine(state.ctx);
  if (state.lastMove?.kind === "safeguard") {
    return (state.safeguard?.calm ?? 0) >= 1 ? safeguardStayLine(state.ctx) : safeguardLine(state.ctx, { kind: state.safeguard?.kind ?? null });
  }
  const lang = state.ctx.lang;
  const kind = state.lastMove?.kind;
  // round 2 safety floor: a check-in the model could not write is the fixed offer of the choices (stop named), never
  // "say that again" (that asks a child who said stop to say it twice)
  if (state.lastMove?.checkin) {
    const line = FALLBACK[lang === "english" ? "english" : "hinglish"][state.lastMove.checkin === "rel" ? "checkinRel" : "checkinStop"];
    return state.ctx.address === "aap" && lang !== "english" ? toAap(line) : line;
  }
  if (item && !CLOSING_MOVES.has(kind)) {
    const q = promptFor(item, lang);
    // round 2 (conversation): a model outage (429 / timeout / every repair failed) on a turn that answers a request or puts
    // the question again is no longer a bare re-ask: a fixed code lead for what the move is doing, then the question
    // (conversation/fallback-lead.js; owner-2 prod R3 x4 + R2). Same kill switch as the lead slot.
    if (!p5Flag("LEADSLOT")) return q;
    const lead = fallbackLead({ request: state.lastMove?.request ?? null, hint: hintStatements(item, state.lastMove?.hintLevel),
      rePose: state.pinItem === item.id && (state.pinRun ?? 0) > 1, lang });
    if (!lead) return q;
    return composeTurn(state.ctx.address === "aap" && lang !== "english" ? toAap(lead) : lead, q);
  }
  const lines = FALLBACK[lang === "english" ? "english" : "hinglish"];
  const line = lines[kind] ?? lines.other;
  // The fixed lines are written in tum forms; an "aap" child hears them in aap forms (G-REG-1).
  return state.ctx.address === "aap" && lang !== "english" ? toAap(line) : line;
}
/**
 * 14.4 (live on the real filter: "humne race lagayi", two class 8 answers about British rule): a block of the CONTEXT whose
 * child's words pass (or trip only a detector that is no child-safety signal) never gets "say that again": the same words
 * would trip it again. The move's own fixed line when it has one (an item's question, a check-in, a wrap), else a warm
 * carry-on. Exported for tests.
 */
export function filterNeutralReply(state, item) {
  const line = fallbackReply(state, item);
  const lang = state.ctx.lang;
  const lines = FALLBACK[lang === "english" ? "english" : "hinglish"];
  const aap = state.ctx.address === "aap" && lang !== "english";
  if (line !== (aap ? toAap(lines.other) : lines.other)) return line;
  return aap ? toAap(lines.heard) : lines.heard;
}

/**
 * The draft up to (not including) its first question, then the item's own question; a lead sentence that repeats part of
 * the question is dropped (F20) and, with `noLeak`, so is one that states the item's key (F17: a leak that survived the
 * rewrite used to replace the WHOLE turn with the bare question — 38/394 replies in the owner's session). Exported for tests.
 */
export function repairDrift(draft, item, lang, { noLeak = false } = {}) {
  const parts = p5Flag("GUARDS") ? sentences(draft) : String(draft).match(/[^.!?।]+[.!?।]*\s*/g) ?? [];
  const lead = [];
  for (const x of parts) {
    if (/[?？]/.test(x)) break;
    if (noLeak && revealsAnswer(x, item)) continue;
    lead.push(x);
  }
  return joinAsk(lead.join("").replace(/^[\s”"'’)\]]+/, "").trim(), promptFor(item, lang));
}

/** Sentences of `text` that do not state `item`'s key (what is left of a teaching turn after a leak survived). */
export const withoutLeaks = (text, item) => (p5Flag("GUARDS") ? sentences(text) : String(text).match(/[^.!?।]+[.!?।]*\s*/g) ?? []).filter((x) => !revealsAnswer(x, item)).join("").trim();
/**
 * Is what is left of a gutted teaching turn still a turn? F18 (evals/owner-truth s06 t2): every sentence of an explanation
 * "revealed" the next item, and the remainder was "” Aapka question?". A remainder must open on a word, carry some
 * content, and hand the floor back. Exported for tests.
 */
// p5-interaction (owner-2 s2 t11, R6.gutted: "What unit fraction represents one pot?" shipped as a whole explain turn): a
// remainder must also be a turn's worth of words (GUTTED_MIN, the battery's own bar); else the rewrite stands and the next
// item is marked spoiled.
export const GUTTED_MIN = 9;
export const coherentRemainder = (t) => !!t && !/^[\s”"'’)\]]/.test(t) && words(t) >= (p5Flag("GUARDS") ? GUTTED_MIN : 6) && handsBack(t);
/**
 * An upcoming item whose key is a STATEMENT of the idea being taught (a why / teach-back item, or a key of 6+ words such
 * as "Any question that can be checked by trying something") cannot be kept out of the explanation that teaches it: the
 * ahead-leak check would gut the turn (F18). Its answer is still discounted if said (brain/turn.js spoiledBy → spoiled →
 * hintsUsed 4), so evidence stays honest. Exported for tests.
 */
export const statementKey = (item) => !!item && (["why", "teachback"].includes(item.kind) || words(item.answer) >= 6);

/**
 * Text-mode teacher reply from the SAME compiled instructions, guarded on the bytes: an answer leak before
 * rung 4 (on the active item, or — on a teaching turn — on the item that comes next), a posing turn that
 * does not pose the item (drift), or an over-long turn gets one rewrite; a leak or drift that survives is
 * replaced by the question itself (content), or the leaking sentences are dropped, never shipped. A model
 * failure falls back (fallbackReply) instead of throwing.
 */
/** r5-latency: the reply lane's hedge point (~p95 of taxila-fast replies, n = 86, 2026-10-14); 0 turns it off. */
export const REPLY_HEDGE_MS = () => { const v = Number(process.env.TAXILA_REPLY_HEDGE_MS ?? 2200); return Number.isFinite(v) && v > 0 ? v : 0; };
export async function textReply({ instructions, state, kit, childText, trace, history = state.recent.slice(0, -1), verdict = state.lastVerdict ?? "ungraded", ui = null, module = null, overflow = true }) {
  const item = state.lastMove?.itemId ? findItem(state, kit, state.lastMove.itemId) : null;
  const next = !item && TEACHING_MOVES.has(state.lastMove?.kind) ? upcomingItem(state, kit) : null;
  const ahead = next && !statementKey(next) ? next : null;
  const lang = state.ctx.lang;
  // A diagnostic's options are content read aloud, so they do not count against the turn length.
  const max = REPLY_MAX_WORDS[state.ctx.ageBand] + (item?.diagnostic ? words(item.options.map((o) => o.text).join(" ")) : 0);
  const guardable = item && state.hintLevel < 4 && state.pendingWhy !== item.id;
  const posingTurn = guardable && state.hintLevel === 0 && POSING_MOVES.has(state.lastMove.kind);
  // p5-interaction: a thinking-aloud wait hands back by letting them go on, never by a question (the "thinkq" guard below)
  const thinkingWait = p5Flag("GUARDS") && state.lastMove?.request === "thinking";
  // round 2 safety floor: a check-in hands back by the choices it offers (the chips wait), never by a lesson question
  const checkin = state.lastMove?.checkin ?? null;
  const activeItem = checkin && state.activeItemId ? findItem(state, kit, state.activeItemId) : null;
  // round 3: a granted break hands back nothing (breakYes: "no question now"); before this the hand-back check made the
  // rewrite add a lesson question to "brb" / "can we pause for a bit?" (local battery base-head-1: 3 of 3 breaks rewritten)
  const restBreak = p5Flag("R3CONV") && state.lastMove?.kind === "break" && state.lastMove?.request === "break";
  // round 3 fix (adversarial B5): this turn answers a forget request after a disclosure (state.rel: the accepted overlay)
  const forgetSafety = state.rel?.overlay?.shapeId === "forget_after_safety";
  const mustHandBack = !CLOSING_MOVES.has(state.lastMove.kind) && !thinkingWait && !checkin && !restBreak;
  const whyProbe = !!item && state.pendingWhy === item.id;
  // A comparison across kinds of quantity (45,000 fans vs 4,500 km) in the teacher's OWN words; the kit's posed
  // question is verified content and is not judged here.
  const own = (t) => (item ? String(t).split(promptFor(item, lang)).join(" ") : String(t));
  // r5 QA D38 (14.3): an English lesson (no address) holds a code-switched Hinglish line to the parent's / class address
  // (aap only: a code-switched "aap" to a younger child is not wrong, and is never worth a rewrite's second)
  const address = state.ctx.address ?? (state.ctx.mixAddress === "aap" ? "aap" : null);
  const kindNow = state.lastMove?.kind;
  // The floor's NEVER rules on the teacher's own words (director/safety.js; verified kit content is not judged).
  const floorContent = floorContentOf(item);
  // 14.4: the check-in tier names no helpline yet (state.js checkTier); every other safeguard turn must
  const floorOf = (t) => floorViolations(t, { content: floorContent, requireHelpline: kindNow === "safeguard" && state.lastMove?.tier !== "check", goodbye: kindNow === "wrap" });
  // 14.4: a turn that is not the full script, in a lesson with none yet, carries no safety talk of its own (harmTalk)
  const talkOk = safetyTalkAllowed(state) || forgetSafety;
  // G-ASK parity: a turn with a pinned question (UiDirectives.ask for THIS item) ends on that question and asks no
  // other — a corrective move (hint, re-teach, repair) re-poses the same item, it never moves to a side question.
  // Any other handing-back turn asks one question at most (audit flows G4: "…14 times 14 karke batayiye. 9² kitna hota hai?").
  const pinned = item && ui?.ask?.itemId === item.id ? ui.ask.text : null;
  const parityOf = (t) => askParity(t, pinned);
  // a check-in that SAYS goodbye ("aaj ke liye yahin rok dete hain") while the child has not chosen yet is a mixed signal
  // (owner-3: the lesson goes on after it); it is still caught, but its repair is the check-in's own (below), never
  // stripWrap — which cut the stop option out and left "the lesson goes on" (adversarial B2)
  const wrapping = !CLOSING_MOVES.has(kindNow);
  // round 3: a turn whose move answers a request that is not an answer ("thoda break chahiye", "can we play a game") has no
  // answer to praise: "Bilkul, aap break lijiye" agrees to the request (base-head-1: caught as praise, rewritten, then
  // shipped flat). Only an UNVERIFIED reading is relaxed; a graded wrong answer keeps every praise check.
  const NOT_ANSWERS = new Set(["break", "stop", "identity", "uptake", "decline", "park", "detour", "adult", "language", "change_topic", "boredom", "back",
    "visual", "story", "example", "another", "slower", "repeat", "clarify", "answer_q", "adapt", "adopt", "harder", "easier", "skip", "know", "frustration"]);
  const wordsVerdict = p5Flag("R3CONV") && verdict === "unverified" && NOT_ANSWERS.has(String(state.lastMove?.request ?? "")) ? "ungraded" : verdict;
  // round 3 fix (experience B6): her OWN closed sum ("2000 + 50 = ___?") answered with a bare number is checked in code for
  // her words ("Haan, 2000 g…" to a wrong 2000): never evidence, only what her line may agree with
  // QA 14.4.1 ("nahi nahi, 160" to her own "2 × 80?" got a wrong operation named): also when the move after it poses the
  // next card, as long as no kit item was on the table when they answered (state.js priorItemId)
  const lastAsked = !item || state.priorItemId === null ? history.filter((x) => x.who === "teacher").at(-1)?.text ?? null : null;
  const selfV = lastAsked ? selfPosedVerdict(lastAsked, childText) : null;
  const praiseOf = (t) => praiseProblem(t, selfV === "incorrect" ? "not_yet" : selfV === "correct" ? "correct" : wordsVerdict);
  // p5-interaction guards (conversation/guards.js): her earlier lines of this lesson (the repeat guard reads the last six)
  const G = p5Flag("GUARDS");
  const earlier = G ? history.filter((t) => t.who === "teacher").slice(-6).map((t) => t.text) : [];
  // p5-interaction (owner-2 R4: a 40-word question re-read in full on every hint turn): once the question has been posed,
  // a re-pose ends on the card's form of it (UiDirectives.ask.text, ≤ 120 characters: the question sentence itself)
  const rePose = !!item && state.pinItem === item.id && (state.pinRun ?? 0) > 1;
  const askEnd = item ? (G && pinned && rePose ? pinned : promptFor(item, lang)) : null;
  // Round 3 (conversation stream; kill switch TAXILA_P5_R3CONV=off): the question was posed on the last turn (a re-pose),
  // so a turn that ends on the card's form of it has posed it; the "drift" check (half the full prompt's content words)
  // asks only for a FIRST pose. Before this, a re-pose at rung 0 (a request answered, a question of theirs, small talk)
  // that ended on the card form tripped drift on every turn (the lead slot itself ends on the card form): base-head-1 had
  // drift on 26 of 90 turns, and the rewrite or the drift repair dropped what the draft had said to the child
  // ("pehle mera sawaal": the rainbow answer cut, insistence "engages_brief" no).
  const R3 = G && p5Flag("R3CONV");
  // round 3: the help requests whose turn must carry a line of her own before the card question (never only the question)
  const helpAsk = R3 && HELP_ASKS.has(String(state.lastMove?.request ?? ""));
  const mustPose = posingTurn && !(R3 && pinned && rePose);
  const firstPose = R3 && !!pinned && !rePose && posingTurn;
  // round 3 (conversation; smoke on the round-3 tree): confirming a RIGHT answer names the parts of the question they just
  // answered ("Haan — Flag A mein 4 equal sections hain") while the screen already shows the next idea (thirds): the parts
  // check read that as naming parts the screen does not show, and the repair cut the confirmation (8 of 94 turns, then
  // "noconfirm" on what shipped). The answered item's own question and key are verified content: their parts may be named.
  const answered = R3 && verdict === "correct" && state.itemsDone?.length ? findItem(state, kit, state.itemsDone.at(-1)) : null;
  const partsLines = answered ? [promptFor(answered, lang), String(answered.answer ?? "")] : undefined;
  // round 3 fix (owner-4 "example do", 2 of 2 local runs): a REQUESTED example / story / other way brings its own numbers
  // ("12 mangoes ka 1/3 hissa") beside the board; only her sentences ABOUT the screen are held to what it shows. Every such
  // sentence was stripped as "parts the screen does not show" and the turn shipped the model-failure line.
  const ownWay = ["example", "story", "another"].includes(state.lastMove?.request);
  const aboutScreen = (t) => (ownWay ? (String(t ?? "").match(/[^.!?।]+[.!?।]*\s*/g) ?? []).filter((x) => SCREEN_SENTENCE.test(x)).join("") : t);
  // round 2 (conversation): a lead-slot turn's length is its OWN words (the card question after them is verified content,
  // like a diagnostic's options): within the lead budget it is not "long"
  const slotState = { on: false };
  const slotLength = (t) => slotState.on && !!askEnd && String(t).trim().endsWith(String(askEnd).trim())
    && words(String(t).trim().slice(0, String(t).trim().length - String(askEnd).trim().length)) <= (LEAD_MAX_WORDS[state.ctx.ageBand] ?? 30);
  // G-PRAISE-2: after a right answer the acknowledgement never states a wrong option as the result (say.js correctsRight).
  const right = verdict === "correct" && state.lastRight?.wrong?.length ? { ...state.lastRight, nextPrompt: item ? promptFor(item, lang) : ahead ? promptFor(ahead, lang) : "" } : null;
  const problems = (t) => [
    floorOf(t).length && "floor",
    !talkOk && harmTalk(t) && "harmtalk",
    forgetSafety && promisesForget(t) && "forget",
    praiseOf(t) === "praise" && "praise",
    praiseOf(t) === "contradicts" && "deny",
    // QA 14.4.1: a mistake of theirs named when nothing graded their answer wrong (director/say.js claimsMistake)
    // (never on a safeguard turn: its reassurance is no feedback on an answer, and no pedagogy guard rewrites safety copy)
    kindNow !== "safeguard" && praiseOf(t) === "claims" && "claim",
    right && correctsRight(t, right) && "corrects",
    screenProblem(t, ui, module, { coming: !!state.lastMove?.visual && state.lastMove?.request === "visual" }) && "screen",
    // W2-B #1: the line names parts the mounted module does not show (she said quarters over fifths). Her OWN words only:
    // the kit's posed question is verified content (W2-E: the replay showed the predicate flagging a verified question
    // that names halves/quarters/eighths beside a 1/2-only predict screen, which cost a rewrite and her lead-in).
    screenContradiction(aboutScreen(own(t)), module, partsLines) && "parts",
    registerBroken(t, address) && "register",
    leaksStage(t) && "stage",
    namesUiPart(own(t)) && "uiword",
    saysCantShow(t) && "cantshow",
    (guardable && revealsAnswer(t, item) || ahead && revealsAnswer(t, ahead)) && "leak",
    mixedUnitComparison(own(t)) && "units",
    // round 3 fix (experience B6): an arithmetic result she states that is false ("1 by 4 ko 3 se multiply karne par 3 by 12")
    !!arithmeticSlip(own(t)) && "math",
    mustPose && !posesItem(t, item, lang) && "drift",
    whyProbe && !asksWhy(t) && "nowhy",
    // round 3: a turn that ends on the pinned kit question has handed the floor back, whatever its verb ("…sabse bade
    // tukde se sabse chhote tak lagao." has no "?" and no listed verb: every pose of it was "flat" and rewritten)
    mustHandBack && !handsBack(t) && !(R3 && pinned && parityOf(t).endsOnAsk) && "flat",
    !scriptOk(t, lang) && "script",
    words(t) > max && !slotLength(t) && "long",
    pinned && !parityOf(t).endsOnAsk && "ask",
    mustHandBack && parityOf(t).questions > 1 && "twoq",
    wrapping && wrapsUp(t) && "wrap",
    // p5-interaction: the reply is only the question again (owner-2 R3, 9 / 90), or a line she already said (R4, 8 / 90)
    // round 3: a welcome back is short by nature ("Wapas aa gaye, Riya!"): two own words are a response there
    // round 3 (owner-2 on both trees: "samajh nahi aaya" on a faded step got only the step's question, R3 + R7.same_again): a
    // turn answering a request for help carries a real line of its own even on a first pose
    G && pinned && isBare(t, promptFor(item, lang), pinned, helpAsk ? undefined : !rePose ? 1 : R3 && state.lastMove?.request === "back" ? 2 : undefined) && "bare",
    G && repeatsEarlier(t, earlier) && "same",
    // a mid-thought gets no question (conversation-v2 thinking_aloud 1/8: "new_question"); a right answer is confirmed
    // before anything else (answer_correct 4/8: a covert probe with no uptake)
    thinkingWait && /[?？]/.test(t) && "thinkq",
    G && verdict === "correct" && !CLOSING_MOVES.has(kindNow) && !checkin && !confirmsFirst(t) && "noconfirm",
    ...(checkin ? checkInProblems(t, { kind: checkin, active: activeItem, lang }) : []),
  ].filter(Boolean);
  // The code repairs for the turn's shape (no model call): goodbye sentences out of a non-wrap turn, then the turn
  // ends on the pinned question (or keeps only its last question).
  const shapeFix = (t, f) => {
    let out = f.includes("wrap") ? stripWrap(t) : t;
    if (pinned) out = endOnAsk(out, askEnd);
    else if (f.includes("drift")) out = repairDrift(out, item, lang);
    else if (f.includes("twoq")) out = lastQuestionOnly(out, { keepContent: R3 });
    return out;
  };
  const SHAPE = new Set(["drift", "flat", "ask", "twoq", "wrap"]);
  const messages = [
    { role: "system", content: instructions },
    // The turn being answered is the last message (childText); by default it is the newest recent row.
    // Every turn reaches the reply model with direct identifiers masked (scrubPii), history and this turn alike.
    // Teacher turns too: on the voice lane her transcript came from a model that heard the child's audio unmasked,
    // so it can repeat a phone number, school or address back.
    // 14.4 (QA TEST d359423b / a9c3136d, 9ad86661; model-only replay 4 of 6 runs): a past child line the predicate's idiom checks
    // read as the lesson's own pressure ("main mar jaunga itna padh ke", "ye sawaal mujhe maar dalega") reached every later
    // draft word for word, and the reply made the safeguarding call on it turns after the Director had made its own ("turant
    // batayiye… akele mat rahiye"; once "aap marne ki baat keh rahi hain", which the next turn's read took for the child's).
    // Until a full script has happened it reaches the reply model as what it means. The turn being answered is never changed.
    ...history.map((t) => ({ role: t.who === "teacher" ? "assistant" : "user", content: t.who !== "teacher" && !talkOk && idiomMeaning(t.text) || forModel(t.text) })),
    { role: "user", content: childText ? forModel(childText) : "(the child has joined the lesson and is listening)" },
  ];
  const replyT0 = performance.now();
  // Replies take ~1-2 s (measured in evals/director-sim.mjs); a stuck call is cut at 6 s and retried once.
  // r5-latency: hedged (azure.js hedged): a call still out at REPLY_HEDGE_MS gets an identical twin, the first answer wins
  // overflow: false for a speculative bet (brain/turn.js speculate): a throttled bet just loses, the real reply still moves;
  // the real reply's hedge twin goes to the overflow account (azure.js chat twin, 14.4), a bet's never does
  const ask = (msgs) => replyDeps.chat(DEPLOY.reply, msgs, { maxTokens: 220, effort: "none", timeoutMs: 6000, trace, hedgeMs: REPLY_HEDGE_MS(), ...(overflow ? { twin: "overflow" } : { overflow: false }) }).then((r) => r.text.trim());
  let reply;
  const guardSlot = {};
  // The content filter blocking the reply call (the child's words are in it) is a safety signal, not an
  // outage: the caller fails CLOSED to the safeguarding protocol (turn(): `filtered`).
  // 14.4: `probe` is what the child's own words alone did (childWordsTrip); a probe that could not run is UNSURE: the caller
  // opens a check-in (one gentle question, no helplines yet; the next turn escalates unless the child is clearly fine)
  const blocked = (probe = "harm") => ({ reply: fallbackReply(state, item), filtered: true, ...(probe === "unknown" ? { unsure: true } : {}),
    guard: { caught: ["content_filter"], rewritten: false, replaced: true } });
  // 14.4 (main safety review; owner census dad0c9db t22: "pata nahi" got the helpline script with no disclosure anywhere in
  // the lesson): a block on a REWRITE or REPAIR call (the brief, her draft and the child's words) is judged as every other
  // reply-side block. A non-harm detector: a neutral line. Otherwise the child's own words alone decide: clear, a neutral
  // line; a harm block, the safeguard; a probe that could not run, the check-in.
  const blockedAfterDraft = async (e, code) => {
    if (nonHarmFilter(e)) return { reply: filterNeutralReply(state, item), guard: { caught: ["content_filter_nonharm"], rewritten: false, replaced: true } };
    const probe = await childWordsTrip(probeWords(history, childText), { trace });
    if (probe === "clear") {
      console.warn(`[lesson] ${code} blocked but the child's own words pass: a neutral line`);
      return { reply: filterNeutralReply(state, item), guard: { caught: [code], rewritten: false, replaced: true } };
    }
    console.warn(`[lesson] ${code} blocked; the child's own words ${probe === "harm" ? "trip the filter" : "could not be cleared"}`);
    return blocked(probe);
  };
  // round 2 (conversation): the LEAD SLOT. A turn that answers a request before the card question, or puts the same
  // question again, is written as two parts: the model writes only what comes before the question, code adds the question
  // byte for byte (conversation/compose.js). A lead that comes back unusable falls through to the one-call path.
  const slot = G && p5Flag("LEADSLOT") && !!item && leadSlotWanted({ request: state.lastMove?.request ?? null, rePose, pinned, diagnostic: !!item?.diagnostic,
    whyProbe, closing: CLOSING_MOVES.has(kindNow), firstPose: firstPose && !checkin });
  // round 3: a first pose with no request is a bridge into a new question (shorter lead, a right answer confirmed first)
  const bridge = firstPose && !state.lastMove?.request;
  const shortLead = bridge || (R3 && state.lastMove?.request === "back");
  const leadMax = (bridge ? LEAD_MAX_FIRST : LEAD_MAX_WORDS)[state.ctx.ageBand] ?? 30;
  const leadCall = async (why = null, draft = null) => {
    const extra = [...(draft ? [{ role: "assistant", content: draft }] : []), { role: "system", content: leadSlotNote({ lead: state.lastMove?.lead ?? null, why, ageBand: state.ctx.ageBand,
      first: bridge, confirm: R3 && verdict === "correct" && !checkin, noAnswer: R3 && bridge && (wordsVerdict === "unverified" || wordsVerdict === "attempt") }) }];
    const raw = await ask([...messages, ...extra]);
    const lead = cleanLead(raw, askEnd, leadMax);
    return leadOk(lead, [item?.answer, ...(item?.acceptable ?? [])], shortLead ? { min: LEAD_MIN_FIRST } : undefined) ? composeTurn(lead, askEnd) : null;
  };
  // round 3: a one-call turn gets its own shape LAST (compose.js turnNote): a request's note first when the move answers one
  // with no card question, then the turn shape (end on the card question; or hand the floor back, no goodbye). Not on a
  // check-in, a granted break, a thinking-aloud wait, a why-probe or a closing move (each has its own shape).
  const reqNote = R3 && !pinned && !CLOSING_MOVES.has(kindNow) && !checkin && state.lastMove?.lead ? requestNote(state.lastMove.lead) : null;
  const shapeNote = R3 && !CLOSING_MOVES.has(kindNow) && !checkin && !restBreak && !thinkingWait && !whyProbe && !item?.diagnostic && mustHandBack
    ? turnNote({ ask: pinned ? askEnd : null, maxWords: TURN_WORDS[state.ctx.ageBand] ?? 25 }) : null;
  const lastNotes = [reqNote, shapeNote].filter(Boolean).join(" ");
  try {
    reply = slot ? (await leadCall()) : null;
    if (reply) { guardSlot.used = true; slotState.on = true; }
    reply ??= await ask(lastNotes ? [...messages, { role: "system", content: lastNotes }] : messages);
  } catch (e) {
    // round 4 (stream 4A, 2026-10-10): a block on the COMPLETION (HTTP 200, finish_reason content_filter: the filter judged
    // the model's own words, not the child's) gets ONE fresh reply before the turn fails closed. In context, "explain it
    // differently" (Zoya, class 5, states of water) drew 1 completion block in 58 lessons and the child got the helplines;
    // the child's words had passed the predicate and the model distress read. A block on the PROMPT (HTTP 400: the child's
    // words are in it) and a second completion block still fail CLOSED, as before.
    let again = null;
    // round 5 (sim lab baseline, main safety review): a block whose categories are KNOWN and are only prompt-injection or
    // copyright detectors ("jailbreak": a child's maths answer, "6 aur 5... 30... 3,00,000?") is not a child-safety signal.
    // One retry on the system prompt and this turn only (the history may carry what tripped it); if that is blocked too, a
    // neutral fallback line, never the helplines. Harm categories (sexual, self_harm, violence, hate) and unreadable blocks
    // still fail CLOSED below, exactly as before.
    const neutral = (code) => ({ reply: filterNeutralReply(state, item), guard: { caught: [code], rewritten: false, replaced: true } });
    const lone = [messages[0], messages[messages.length - 1], ...(lastNotes ? [{ role: "system", content: lastNotes }] : [])];
    // 14.4.1 (sim lab p26h on 5c127d1a, QA 4b3d875c: a class 8 answer about the British, blocked on hate on the prompt and on
    // this turn alone, got only the fixed carry-on, with no question): one more try with their words NOT shown, so her line is
    // the move's own; blocked or failed, the fixed line as before. Their words still reached every read and the probe.
    const masked = () => ask([messages[0], { role: "user", content: MASKED_TURN }, ...(lastNotes ? [{ role: "system", content: lastNotes }] : [])]).catch(() => null);
    let triedLone = false;
    if (isContentFilter(e) && nonHarmFilter(e)) {
      console.warn(`[lesson] reply blocked by a non-harm filter (${e.filterCats.join(",")}): one retry on this turn alone`);
      triedLone = true;
      try { again = await ask(lone); } catch (e2) { if (isContentFilter(e2) && !nonHarmFilter(e2)) e = e2; }
      if (!again && !(isContentFilter(e) && !nonHarmFilter(e))) {
        const m = await masked();
        if (!m) return neutral("content_filter_nonharm");
        again = m; guardSlot.masked = true;
      }
    }
    // round 5 (sim lab p43, main safety review): a HARM (or unreadable) block on the PROMPT is the filter judging the whole
    // mix (the brief, her lines, the history, the child's words), not the child. The safeguard fires only when the CHILD'S
    // OWN WORDS trip it: a probe of their recent words alone (childWordsTrip) runs beside one retry on this turn alone. The
    // probe blocked on a harm category, or failing for any reason, fails CLOSED exactly as before, whatever the retry did.
    // A clear probe: the retry's reply if it came back, else a neutral line, never the helplines. The completion block
    // (HTTP 200, below) is unchanged: there the prompt with the child's words already passed.
    if (!again && isContentFilter(e) && !nonHarmFilter(e) && e.status !== 200) {
      const cats = (e.filterCats ?? []).join(",") || "unreadable";
      const [retry, probe] = await Promise.all([
        triedLone ? null : ask(lone).catch(() => null),
        childWordsTrip(probeWords(history, childText), { trace }),
      ]);
      if (probe !== "clear") {
        console.warn(`[lesson] reply prompt blocked (${cats}); the child's own words ${probe === "harm" ? "trip the filter" : "could not be cleared"}: fail closed`);
        return blocked(probe);
      }
      console.warn(`[lesson] reply prompt blocked (${cats}) but the child's own words pass: ${retry ? "the retry on this turn alone" : "a neutral line"}`);
      const got = retry ?? await masked();
      if (!got) return neutral("content_filter_context");
      again = got;
      guardSlot.filter = "context";
      if (!retry) guardSlot.masked = true;
    }
    if (!again && isContentFilter(e) && e.status === 200 && !nonHarmFilter(e)) {
      console.warn("[lesson] reply completion blocked by the content filter: one fresh reply");
      // main safety review: if the fresh reply fails for any other reason (a timeout, a 5xx), the ORIGINAL block stands
      // and the turn fails closed; only a second filter block replaces it (same outcome)
      try { again = await ask(lastNotes ? [...messages, { role: "system", content: lastNotes }] : messages); } catch (e2) { if (isContentFilter(e2)) e = e2; }
    }
    if (again) reply = again;
    else {
      if (isContentFilter(e) && nonHarmFilter(e)) return neutral("content_filter_nonharm");
      // 14.3.1 (main safety review; sim lab rel143 p16 r2, TEST 955a17b7 t12): HER OWN reply about chips packets and nitrogen
      // was blocked on completion twice. The prompt with the child's words had passed and the classifier read the answer
      // correct, yet the turn failed closed to the helpline script, and the lesson held helplines two more turns. A block on
      // HER completion is a safeguard only when the child's own words trip the filter (the 14.2 prompt-side rule): a clear
      // probe gives a neutral line, never the helplines; a harm or unreadable probe fails CLOSED exactly as before.
      if (isContentFilter(e) && e.status === 200) {
        const probe = await childWordsTrip(probeWords(history, childText), { trace });
        if (probe === "clear") {
          console.warn("[lesson] her reply was blocked on completion but the child's own words pass: a neutral line");
          return neutral("content_filter_output");
        }
        console.warn("[lesson] her reply was blocked on completion and the child's own words could not be cleared");
        return blocked(probe);
      }
      if (isContentFilter(e)) { console.warn("[lesson] reply blocked by the content filter"); return blocked(); }
      console.warn("[lesson] reply unavailable, falling back:", e.message);
      return { reply: fallbackReply(state, item), guard: { caught: ["unavailable"], rewritten: false, replaced: true } };
    }
  }
  let found = problems(reply);
  const guard = { caught: found, rewritten: false, replaced: false, ...(found.length ? { firstDraft: reply } : {}), ...(guardSlot.used ? { leadSlot: true } : {}), ...(guardSlot.filter ? { filter: guardSlot.filter } : {}), ...(guardSlot.masked ? { masked: true } : {}) };
  // r4-latency (TAXILA_TTS_FIRST_SENTENCE, SHADOW): can the draft's first TTS sentence be LOCKED now — could it start speaking
  // while the rest of the turn is still being guarded or rewritten? Locked only when it passes every per-sentence guard on its
  // own, names nothing on the screen (the child would still see the last turn's), asks nothing, and the minimal turn
  // `s1 + the pinned kit question` passes EVERY guard of the whole turn, so a final reply that starts with s1 always exists.
  // Shadow records the lock and whether the final reply (today's path, unchanged) still starts with s1; nothing else moves.
  const early = firstSentenceMode() === "off" ? null
    : lockFirstSentence({ reply, askEnd: pinned ? askEnd : null, problems, closing: CLOSING_MOVES.has(kindNow) || !!checkin || forgetSafety || whyProbe || thinkingWait || restBreak || !!item?.diagnostic,
      spoken: state.mode !== "text", confirmNeeded: G && verdict === "correct", t0: replyT0 });
  // Drift (a posing turn that asked some other question) is repaired without a model call when it is the
  // only problem besides the hand-back the posed question supplies: what the draft said BEFORE its first
  // question (the acknowledgement), then the verified question itself — what the rewrite produced in 9/9
  // measured drift rewrites (5 the question alone, 4 acknowledgement + question; evals/cascade-latency.mjs,
  // 2026-10-02), at ~1 s less. Every guard runs again on the result; anything left goes to the rewrite.
  // The same holds for the G-ASK parity, two-question and goodbye problems (a pure shape fix, measured below).
  if (found.length && !checkin && found.every((p) => SHAPE.has(p))) {
    const repaired = shapeFix(reply, found);
    if (!problems(repaired).length) {
      reply = repaired;
      found = [];
      guard.repaired = true;
    }
  }
  // r5 QA D38: an English lesson's code-switched line in tum forms is held to aap by the closed tum → aap lexicon, without a
  // model call; the rewrite below runs only if the register is still broken or something else is
  if (found.includes("register") && !state.ctx.address && address === "aap") {
    const fixed = toAap(reply);
    if (!registerBroken(fixed, address)) { reply = fixed; guard.repaired = true; found = problems(reply); }
  }
  if (found.length) {
    const asked = G && ["example", "story", "another"].includes(state.lastMove?.request);
    const why = [found.includes("leak") && asked && "it gives away the answer to the question — keep what they asked for, but with different numbers and a different case from the question, so its answer is never stated",
      found.includes("leak") && !asked && (ahead
      ? "it states the answer to the practice question that comes next — explain with different numbers or a different example, and do not answer that question"
      : "it gives away the key answer — the hint ladder has not reached rung 4"),
      found.includes("drift") && `it must ask exactly this question and no other: "${promptFor(item, lang)}"`,
      found.includes("nowhy") && "it must ask how they knew or why — about the question they just answered, not a new problem; the reason is theirs to give",
      found.includes("flat") && !found.includes("nowhy") && "it never hands the floor back — end with one question for the child about the same thing (and do not answer it yourself)",
      found.includes("script") && (lang === "hindi" ? "write it in Roman or Devanagari only" : "write it in Roman script only — no Devanagari or any other script"),
      found.includes("long") && `it is too long — at most ${TURN_WORDS[state.ctx.ageBand]} words`,
      found.includes("units") && "it asks which is bigger between two different kinds of quantity — compare like with like (two counts, or two lengths in one unit)",
      found.includes("math") && (() => { const x = arithmeticSlip(own(reply)); return x ? `it states a result that is not true (${x.claim}: the true value is ${x.value}) — say it correctly, or leave the sum out` : null; })(),
      found.includes("floor") && `it breaks the safety floor — ${floorOf(reply).map((k) => FLOOR_FIX[k]).filter(Boolean).join("; ")}`,
      found.includes("harmtalk") && (state.lastMove?.kind === "safeguard"
        ? "a check-in asks only if they are okay — no helpline yet, and never whether they are safe or want to hurt themself"
        : "it brings up a helpline or asks whether they want to hurt themself, but nothing they said is about being unsafe (the safety check read their words) — no helpline and no question about harm: answer warmly, as their teacher, about what they actually said"),
      found.includes("forget") && "it promises to forget or keep secret what they told you about being unsafe — never promise that; say kindly that telling was right and that a grown-up they trust should know so they can help",
      // round 3: on a turn with no answer to judge (a filler, an unverified reply) "start from what they actually did" made the
      // rewrite echo the filler ("Tumne bas “haan” kaha", 4 of ~500 turns on the paired battery): there it says go straight on
      found.includes("praise") && (R3 && (wordsVerdict === "unverified" || wordsVerdict === "attempt")
        ? "it praises or agrees as if they answered, but there is no answer of theirs to judge this turn — no praise or agreement word; go straight on with the move, without commenting on what they said"
        : `it agrees with or praises their answer, but their answer was not marked right — no agreement or praise word for it; ${R3 ? "start from what they actually did" : "name what is sensible in it"}, then the next step`),
      found.includes("deny") && "it says their answer is wrong, but it was right — confirm it plainly",
      found.includes("claim") && "it says they made a mistake, but nothing checked their answer as wrong — say nothing about right or wrong or what they did; go straight on with the move",
      found.includes("corrects") && `it implies their answer was wrong or that the answer is something else, but their answer ${JSON.stringify(String(right.key))} was right — confirm it plainly and do not name any other answer as the result`,
      found.includes("screen") && "it sends them to the screen (to tap or pick something, or to look at a picture or diagram), but nothing of that is on the screen this turn — say it in words, or ask them to say it",
      found.includes("parts") && `it names parts the screen does not show — ${screenContradiction(aboutScreen(own(reply)), module, partsLines)?.onScreen ?? ""}`,
      found.includes("cantshow") && "it says you cannot show or draw — never say that; talk about the idea itself in words, and point at the screen only at what is on it now",
      found.includes("stage") && "it reads out a field name, markup or a text picture (like 'Whiteboard:', brackets or rows of symbols like ●●●) — plain spoken words only; the board draws pictures, never your words",
      found.includes("uiword") && "it names a screen part by an internal name (chips, bar1) — say what the child sees: the buttons on the screen, strip A or B",
      found.includes("register") && (address === "aap" ? "it uses tum forms — address the child with aap forms only (aap, aapka; verbs ending -iye)" : "it uses aap — address the child with tum forms (tum, tumhara)"),
      found.includes("ask") && !found.includes("drift") && `it must end by asking exactly this question, and ask nothing else: "${askEnd}"`,
      found.includes("twoq") && !found.includes("ask") && "it asks more than one question — keep only one question, at the end",
      found.includes("wrap") && (checkin ? "it already says goodbye, but they have not chosen yet — offer stopping as one of the choices (stop for today), not as a goodbye"
        : "it says goodbye or that the lesson is over, but the lesson goes on — no goodbye words"),
      found.includes("bare") && (rePose || helpAsk ? "it is only the question again — first answer what they just said, or give the nudge or the step, in one short line of your own; then the question"
        : "it is only the question — say a short bridge of your own first (a few words to what they said), then the question"),
      found.includes("same") && "it repeats what you already said earlier, almost word for word — say something new (a different nudge, example or way in); then the question",
      found.includes("thinkq") && "they are in the middle of a thought — ask nothing at all; only a few words that let them go on and finish it",
      found.includes("noconfirm") && "their answer was right — open by confirming it in a few words, naming what they got right, before anything else",
      found.includes("hold") && "they asked to stop: it asks a lesson question or holds them for one more — this turn asks nothing about the lesson; only offer the choices",
      found.includes("nostop") && (checkin === "rel" ? "it must say plainly that stopping now is fine" : "it leaves out stopping — name all three choices: keep going, a short break, or stop for today"),
      found.includes("nochoice") && !found.includes("nostop") && "it only names stopping — they have not chosen yet: name all three choices, keep going, a short break, or stop for today",
    ].filter(Boolean).join("; and ");
    try {
      reply = await ask([...messages, { role: "assistant", content: reply }, { role: "system", content: checkin
        ? `Rewrite that turn: ${why}. Same check-in, same language, one or two short warm sentences, then wait for their choice.`
        : `Rewrite that turn: ${why}. Same move, same language, one idea, end by handing the floor back.` }]);
      guard.rewritten = true;
      found = problems(reply);
    } catch (e) {
      if (isContentFilter(e)) return await blockedAfterDraft(e, "content_filter_rewrite");
      console.warn("[lesson] rewrite unavailable, guarding the draft:", e.message); // the draft's problems stand
    }
    guard.afterRewrite = found;
    if (checkin && (found.includes("floor") || found.includes("hold") || found.includes("nostop") || found.includes("wrap") || found.includes("nochoice"))) {
      // a check-in that still asks a lesson question, holds them, or drops the stop option is never sent: the fixed line
      reply = fallbackReply(state, null);
      guard.replaced = true;
    } else if (found.includes("forget")) {
      // round 3 fix (adversarial B5): a promise to forget a disclosure is never sent: the fixed honest line
      const line = FALLBACK[lang === "english" ? "english" : "hinglish"].forgetSafety;
      reply = address === "aap" && lang !== "english" ? toAap(line) : line;
      guard.replaced = true;
    } else if (found.includes("floor") || found.includes("harmtalk")) {
      // A teacher line that still breaks the floor, or still makes the safeguarding call itself, is never sent: the fixed
      // line for the move (or the question).
      reply = fallbackReply(state, item);
      guard.replaced = true;
    } else if (found.includes("leak") && ahead) {
      // what is left must still be a turn (F18); else the rewrite stands and the next item is marked spoiled (turn.js)
      const left = withoutLeaks(reply, ahead).replace(/^[\s”"'’)\]]+/, "");
      // p5-interaction (owner-4 "story ki tarah batao": the story was cut to "Agar cake 12 pieces ka ho, ek part mein kitne?"):
      // when the child ASKED for this teaching (a story, an example, another way, slower, a picture), their request wins over
      // the next item's evidence value: the rewrite stands and that item is marked spoiled (its answer is discounted)
      if (coherentRemainder(left) && !(G && state.lastMove?.request)) { reply = left; guard.replaced = true; } else guard.spoilsAhead = ahead.id;
    } else if (found.includes("leak") || found.includes("drift")) {
      // the acknowledgement before the drift / leak stays, then the verified question (F17: never the bare question when
      // the child's words got an answer in the draft)
      reply = repairDrift(reply, item, lang, { noLeak: true });
      if (problems(reply).includes("leak")) reply = askEnd;
      guard.replaced = true;
      // p5-interaction (acceptance 2026-10-05, the req:story chip: 2 / 6 requested stories were cut to the bare question
      // because the story's numbers stated the key): a REQUESTED story / example / other way gets one more attempt with
      // other numbers; it is used only when no truth problem is left (a leak still ships the question alone)
      if (G && item && state.lastMove?.request && isBare(reply, askEnd, pinned)) {
        try {
          const again = await ask([...messages, { role: "assistant", content: guard.firstDraft ?? reply }, { role: "system", content: `Rewrite that turn: they asked for it this way, so keep it that way, but use different numbers and things from the question so it never gives away or works out the question's answer; two short sentences, then end by asking exactly this question: "${askEnd}". Same language.` }]);
          let a = again;
          if (problems(a).includes("long")) a = trimToWords(a, max);
          if (!problems(a).filter((p) => !SOFT_FIX.has(p)).length && !problems(a).includes("long") && !isBare(a, askEnd, pinned)) { reply = a; guard.reasked = true; }
        } catch (e) { if (isContentFilter(e)) return await blockedAfterDraft(e, "content_filter_repair"); }
      }
    } else {
      if (found.includes("units")) { reply = withoutMixedUnits(reply) || fallbackReply(state, item); guard.replaced = true; }
      if (found.includes("script")) reply = reply.replace(OFF_SCRIPT[lang] ?? OFF_SCRIPT.english, "").replace(/\s{2,}/g, " ").trim();
      // What is left of a turn whose words contradicted the verdict or the screen: those sentences go; if nothing
      // that hands the floor back is left, the item's question (or the move's fixed line) is the turn.
      const keepOr = (t) => (t && handsBack(t) ? t : item && !CLOSING_MOVES.has(kindNow) && state.pendingWhy !== item.id
        ? joinAsk(t ?? "", askEnd) : t || fallbackReply(state, item));
      // a false sum that survived the rewrite: its sentence goes (the rest of the turn stands, or the question / fixed line)
      if (found.includes("math")) { reply = keepOr(sentences(reply).filter((x) => !arithmeticSlip(own(x))).join(" ").trim()); guard.replaced = true; }
      if (found.includes("praise")) { reply = keepOr(stripPraise(reply)); guard.replaced = true; }
      if (found.includes("claim")) { reply = keepOr(stripClaim(reply)); guard.replaced = true; }
      if (found.includes("corrects")) { reply = keepOr(stripCorrection(reply, right)); guard.replaced = true; }
      if (found.includes("screen")) { reply = keepOr(stripScreenRefs(reply, { stageEmpty: emptyStage(ui, module) })); guard.replaced = true; }
      // W2-B fixer: a rewrite that still names part counts the screen does not show loses those sentences
      if (found.includes("parts")) {
        // a requested example keeps its own sentences: only the ones about the screen are taken out
        const keepOwn = ownWay ? (x) => !SCREEN_SENTENCE.test(x) : null;
        reply = keepOr(keepOwn ? (String(reply).match(/[^.!?।]+[.!?।]*\s*/g) ?? []).filter((x) => keepOwn(x) || !screenContradiction(x, module, partsLines)).join("").trim() || null
          : stripStrayParts(reply, module, partsLines, { keep: item ? promptFor(item, lang) : "" }));
        guard.replaced = true;
      }
      if (found.includes("register") && address === "aap") { reply = toAap(reply); guard.repaired = true; }
      if (found.includes("stage")) { reply = stripStage(reply) || fallbackReply(state, item); guard.replaced = true; }
      if (found.includes("uiword")) { reply = plainUiWords(reply, lang); guard.repaired = true; }
      if (found.includes("cantshow")) { reply = keepOr(stripCantShow(reply)); guard.replaced = true; }
      if (found.includes("long")) reply = trimToWords(reply, max);
      // Last: the turn's shape (goodbye words out, the pinned question at the end, one question), in code.
      const left = problems(reply).filter((p) => SHAPE.has(p));
      if (left.length) {
        const fixed = shapeFix(reply, left);
        // p5-interaction: the shape fix drops every question that is not the pinned one; when that leaves only the question
        // (the model's uptake was itself a question: owner-2 R3), the last lead question stays before it instead (goodbye
        // sentences still go)
        // ship5 integration (p5 x W1 "one question per turn", tests/prod/w1a-battery): on a hint turn the rung's own kit
        // hint, as STATEMENTS only, leads first; a lead question is the last resort (it makes the turn two questions).
        const hintLead = G && pinned && kindNow === "hint" ? hintStatements(item, state.lastMove?.hintLevel) : "";
        const alt = G && pinned && isBare(fixed, askEnd, pinned)
          ? (hintLead ? joinAsk(hintLead, askEnd) : keepLastLeadQuestion(left.includes("wrap") ? stripWrap(reply) : reply, askEnd)) : null;
        reply = alt && !isBare(alt, askEnd, pinned) ? alt : fixed;
        guard.repaired = true;
      }
    }
    // QA 14.4.1: a mistake of theirs nothing graded survives no branch above (the drift repair keeps the acknowledgement
    // before the question, and a claim is usually that acknowledgement): its sentences go
    if (kindNow !== "safeguard" && problems(reply).some((p) => p === "claim" || p === "deny") && claimsMistake(reply)) {
      const left = stripClaim(reply);
      reply = left && handsBack(left) ? left : item && !CLOSING_MOVES.has(kindNow) ? joinAsk(left, askEnd) : left || fallbackReply(state, item);
      guard.replaced = true;
    }
  }
  if (G) {
    // p5-interaction: a teaching turn the repairs above left gutted (owner-2 R6, 3 / 90: "What do you predict?" as a whole
    // hook, after the mixed-units strip) gets one more attempt at a full turn; it is used only when it is clean.
    // (a strip that left nothing put the fixed "lost my words" line on a teaching turn: owner-2 R2 on a local run — the same retry)
    const fixedLine = !item && reply === fallbackReply(state, null);
    if (TEACHING_MOVES.has(kindNow) && (words(reply) < GUTTED_MIN || fixedLine) && !guard.final) {
      try {
        const floorWhy = guard.firstDraft ? floorOf(guard.firstDraft).map((k) => FLOOR_FIX[k]).filter(Boolean).join("; ") : "";
        const again = await ask([...messages, { role: "assistant", content: guard.firstDraft ?? reply }, { role: "system", content: `Rewrite that turn as a full turn: the same idea in two or three short sentences, then one small question about it${ahead ? "; do not answer the practice question that comes next" : ""}; compare only like with like${floorWhy ? `; ${floorWhy}` : ""}; same language.` }]);
        // only the soft problems may remain, and they are repaired in code; any truth problem (floor, leak, praise, deny,
        // units, screen, parts) keeps the turn as it was
        const hard = problems(again).filter((p) => !SOFT_FIX.has(p));
        if (words(again) >= GUTTED_MIN && !hard.length) {
          let a = again;
          const soft = problems(a);
          if (soft.includes("wrap")) a = stripWrap(a) || a;
          if (soft.includes("script")) a = a.replace(OFF_SCRIPT[lang] ?? OFF_SCRIPT.english, "").replace(/\s{2,}/g, " ").trim();
          if (soft.includes("register") && address === "aap") a = toAap(a);
          if (soft.includes("stage")) a = stripStage(a) || a;
          if (soft.includes("uiword")) a = plainUiWords(a, lang);
          if (soft.includes("cantshow")) a = stripCantShow(a) || a;
          if (words(a) > max) a = trimToWords(a, max);
          if (words(a) >= GUTTED_MIN && !problems(a).filter((p) => !SOFT_FIX.has(p)).length) { reply = a; guard.regutted = true; }
        }
      } catch (e) { if (isContentFilter(e)) return await blockedAfterDraft(e, "content_filter_repair"); }
    }
    // a hint turn still only the question after the rewrite: the rung's own kit hint (verified content that never states
    // the key, never a teacher note) leads the question
    if (item && kindNow === "hint" && problems(reply).includes("bare")) {
      // ship5 integration: statements only, so the repaired turn still asks ONE question (a kit hint can itself ask one)
      const h = hintStatements(item, state.lastMove?.hintLevel);
      if (h) { reply = joinAsk(h, askEnd); guard.repaired = true; }
    }
    // round 2 (conversation): a turn still only the question, or a line she already said, after every repair above: one
    // lead-slot call (the model writes only the response to what they said; code adds the question). Used only when the
    // joined turn has no problem the old one did not have; never after a floor or leak catch (a truth repair stands).
    // round 3: a leak caught on the first draft no longer bars this repair: the leak repair left only the question (owner-2
    // R3 "bare question after a wrong answer": a kit hint whose numbers equal the key, cut, then nothing to say), and the new
    // lead is checked against the key (leadOk) and the joined turn may carry no problem the repaired one did not, a leak
    // included. A floor catch still bars it (rj-conv-lead-repair-after-floor).
    if (p5Flag("LEADSLOT") && item && pinned && !whyProbe && !item.diagnostic && !CLOSING_MOVES.has(kindNow) && !guard.caught.some((c) => c === "floor" || (c === "leak" && !R3))) {
      const left = problems(reply);
      if (left.includes("bare") || left.includes("same")) {
        try {
          const why = left.includes("bare") ? "your last try was only the question: first respond to what they just said (or give the nudge or the step) in your own words"
            : "your last try repeated what you said earlier: say something new (a different nudge, example or way in)";
          const again = await leadCall(why, guard.firstDraft ?? reply);
          if (again) {
            const was = new Set(left), prevOn = slotState.on;
            slotState.on = true;
            const now = problems(again);
            if (!now.includes("bare") && !now.includes("same") && !now.includes("leak") && now.every((p) => was.has(p))) { reply = again; guard.leadRepair = true; } else slotState.on = prevOn;
          }
        } catch (e) { if (isContentFilter(e)) return await blockedAfterDraft(e, "content_filter_repair"); }
      }
    }
    // round 3: a re-pose STILL only the question after every model repair gets the fixed code lead (conversation/
    // fallback-lead.js: the kit hint's statements when safe and not said yet, else a generic nudge she has not said this
    // lesson), never the bare question: owner-2 R3 on prod 4 of 90 turns. Code lines, never prompt text (nothing to recite).
    if (R3 && item && pinned && (rePose || helpAsk) && !whyProbe && !item.diagnostic && !CLOSING_MOVES.has(kindNow) && !checkin && !guard.caught.includes("floor")
      && problems(reply).includes("bare")) {
      const fixedLead = fallbackLead({ request: state.lastMove?.request ?? null, hint: hintStatements(item, state.lastMove?.hintLevel), rePose: true, lang, avoid: earlier });
      if (fixedLead) {
        const joined = composeTurn(address === "aap" && lang !== "english" ? toAap(fixedLead) : fixedLead, askEnd);
        const was = new Set(problems(reply)), prevOn = slotState.on;
        slotState.on = true;
        const now = problems(joined);
        if (!now.includes("bare") && now.every((p) => was.has(p))) { reply = joined; guard.codeLead = true; } else slotState.on = prevOn;
      }
    }
    // the cut marks the repairs leave (an orphan quote, an empty fragment) and a lead sentence that re-poses the question
    const tidied = tidyAround(reply, pinned ? askEnd : null);
    if (tidied && tidied !== reply) { reply = tidied; guard.tidied = true; }
  }
  // ship5 fixer (experience B4: "apna maths sawaal likho" to a child talking hands-free): on a spoken lane her OWN words ask
  // the child to say it, never to write or type it (the pinned kit question is verified content and is left byte for byte)
  if (state.mode !== "text") {
    const spoken = speakNotWrite(reply, askEnd);
    if (spoken !== reply) { reply = spoken; guard.spoken = true; }
  }
  // 14.4 (QA TEST a9c3136d t8, 9ad86661): the goodbye strip took her only sentence ("…padhai rok dete hain—…?"), the full-turn
  // retry raised self-harm again and was refused, and the child got "" and a module tray. A turn is never empty: the fixed line.
  if (!String(reply ?? "").trim()) { reply = fallbackReply(state, item); guard.replaced = true; guard.emptied = true; }
  // The final words, checked once more (debug and the evals read it): what reached the child.
  const final = problems(reply).filter((p) => p !== "long" || words(reply) > max);
  if (final.length) guard.final = final;
  if (early) {
    const kept = early.locked ? String(reply).trim().startsWith(early.s1) : false;
    guard.early = { mode: firstSentenceMode(), locked: early.locked, ...(early.why ? { why: early.why } : {}), ...(early.locked ? { kept, lockedMs: early.ms } : {}),
      finalMs: Math.round(performance.now() - replyT0) };
  }
  // The floor families of what will actually be said (the cascade speaks exactly this): [] after the guard, unless
  // even the fixed line broke a rule. The caller turns a non-empty list into the next correction and an incident.
  const floor = final.includes("floor") ? floorOf(reply) : [];
  return { reply, guard, ...(floor.length ? { floor } : {}) };
}

/**
 * p5-interaction: the reply with every question but its LAST lead question and the pinned one dropped, ending on the pinned
 * question (the fallback when the strict one-question fix would leave only the bare question). Exported for tests.
 */
/**
 * p5-interaction: the reply with the cut marks of the repairs tidied (conversation/guards.js tidy) and, when it ends on
 * the pinned question, every lead sentence that is that question again dropped (a copy, a re-wording, a second form of a
 * blanked question: owner-2 s1 t6 "Khaali jagah bhariye: 2/5 is ___ the middle. Khaali jagah bhariye: Check: …"). The
 * question itself is verified content and is kept byte for byte. Exported for tests.
 */
/**
 * ship5 integration: the rung's kit hint (verified content) as a lead with its QUESTION sentences dropped, or "" when
 * nothing is left, it states the key, or it is a teacher's shape note. Exported for tests.
 */
export function hintStatements(item, hintLevel) {
  const h = stripRungLabel(String(item?.hints?.[(hintLevel ?? 1) - 1] ?? "")).replace(/\s+/g, " ").trim();
  if (!h || revealsAnswer(h, item) || hintShapeWords(h)) return "";
  // round 3: a kit hint with no closing stop ran into the question ("…as places they live What are microbes…?", base-head-1)
  const out = sentences(h).map((x) => x.trim()).filter((x) => x && !/[?？]/.test(x)).map((x) => (/[.!।…]$/.test(x) ? x : `${x}.`)).join(" ").trim();
  // it opens her turn: a capital first letter ("look at the step just before…" came out lower-case)
  return out ? out[0].toUpperCase() + out.slice(1) : "";
}

export function keepLastLeadQuestion(reply, ask) {
  const r = String(reply ?? "").split(String(ask ?? "")).join(" ");
  const ss = sentences(r).map((x) => x.trim()).filter(Boolean);
  const qi = ss.map((x) => /[?？]/.test(x)).lastIndexOf(true);
  const lead = ss.filter((x, i) => !/[?？]/.test(x) || i === qi).join(" ");
  return `${leadWithoutQuestion(lead, ask) || lead} ${String(ask ?? "").trim()}`.replace(/\s{2,}/g, " ").trim();
}

export function tidyAround(reply, ask) {
  const r = String(reply ?? "").trim();
  if (ask && r.endsWith(String(ask).trim())) {
    const lead = leadWithoutQuestion(r.slice(0, r.length - String(ask).trim().length), ask);
    return `${tidy(lead)} ${String(ask).trim()}`.replace(/\s{2,}/g, " ").trim();
  }
  return tidy(r);
}

/** p5-interaction: does a reply to a RIGHT answer confirm it in its first two sentences (agreement / praise of the answer)? */
// round 3 (conversation; base-head-1): "Kabir, haan, 1 player bach jaata hai" and "Aarav, aapne … bilkul sahi groups se
// banaya" were caught as NOT confirming (the name before "haan"; "sahi" not right before a listed verb) and rewritten
// (~1-2 s each). A confirmation word in a statement among the first two sentences counts; a negated one never does. This is
// a quality check on a turn after a RIGHT answer (no truth guard is loosened: praise / deny keep their own predicates).
const CONFIRM_WORD = /(?<![\p{L}])(?:bilkul|sahi|correct(?:ly)?|right|haan|haa+n?|yes|yep|exactly|ekdam|sha+ba+sh|well\s+done|perfect|great|badhiya|zabardast|theek\s+(?:kaha|bataya|socha|pakda))(?![\p{L}])(?!\s+(?:nahi|nahin|not|hai\s+kya))|सही|बिल्कुल|हाँ|शाबाश/iu;
function confirmsFirst(t) {
  const head = sentences(t).slice(0, 2).join(" ");
  if (praiseProblem(head, "not_yet") === "praise") return true;
  return p5Flag("R3CONV") && sentences(t).slice(0, 2).some((x) => !/[?？]/.test(x) && CONFIRM_WORD.test(x));
}

/** Imperatives to write / type → the spoken form (her own words only; the pinned question at the end is kept). Exported for tests. */
const WRITE_TO_SAY = [
  [/\blikh\s+(?:kar|ke)\s+(?:bhejo|batao|dikhao)\b/gi, "bolkar batao"], [/\blikh\s+(?:kar|ke)\s+(?:bhejiye|bataiye|dikhaiye)\b/gi, "bolkar bataiye"],
  [/\blikh\s+do\b/gi, "bata do"], [/\blikh\s+dijiye\b/gi, "bata dijiye"], [/\blikhiye\b/gi, "bataiye"], [/\blikho\b/gi, "batao"],
  // round 5 (owner 2026-10-14, phone, voice-first: "homework type karke bhejo" twice): the forms the first list missed
  [/\btype\s+kar\s*ke\s+(?:bhejo|bhej\s+do|batao|send\s+karo|dikhao)\b/gi, "bolkar batao"], [/\btype\s+kar\s*ke\s+(?:bhejiye|bataiye|dikhaiye)\b/gi, "bolkar bataiye"],
  [/\blikh\s*(?:kar|ke)\s*(?:bhejo|batao|dikhao)\b/gi, "bolkar batao"], [/\blikh\s*(?:kar|ke)\s*(?:bhejiye|bataiye|dikhaiye)\b/gi, "bolkar bataiye"],
  [/\b(?:type|message)\s+(?:karna|karein|karenge|karo\s+na)\b/gi, "bolna"], [/\bmessage\s+(?:karo|kar\s+do|bhejo)\b/gi, "bolo"],
  [/टाइप\s*(?:करके|कर\s*के)\s*(?:भेजो|बताओ|भेज\s*दो)/g, "बोलकर बताओ"], [/टाइप\s*(?:करो|कर\s*दो)/g, "बोलो"], [/लिख\s*(?:कर|के)\s*(?:भेजो|बताओ)/g, "बोलकर बताओ"],
  [/\btype\s+(?:it\s+)?(?:and\s+send(?:\s+it)?|it\s+in|in\s+the\s+chat)\b/gi, "say it"],
  [/\btype\s+(?:karo|kar\s+do)\b/gi, "bolo"], [/\btype\s+(?:kijiye|kariye|kar\s+dijiye)\b/gi, "boliye"],
  [/\b(?:write|type)\s+(?:it|that|this|your\s+answer|the\s+answer)(?:\s+down)?\b/gi, "say it"], [/\bwrite\s+down\b/gi, "say"],
  // round 5 (QA D20, session-first intake: "homework ka question bhejo" n=2/2 to a voice-first class 4 child): they say it
  [/\b(question|sawaal|sawal|swaal|prashn|homework)\s+bhej\s*(?:o|do|dijiye)\b/gi, (m) => `${m.split(/\s+/)[0]} bolo`], [/(सवाल|प्रश्न|होमवर्क)\s*भेजो/g, (m) => `${m.split(/\s+/)[0].replace("भेजो", "")} बोलो`],
  // round 5 (main, owner-5-visual V3.child_draws on the voice lane: after "animation dikhao na" she told the CHILD to draw
  // it): no drawing pad exists in the lesson, so on a spoken lane the child pictures it and says it, never draws it
  [/\b(?:draw|drawing|chitra|picture)\s+(?:bana\s*)?(?:kar|ke|bana)\s*(?:ke|kar)?\s+(?:dikhao|batao|bhejo)\b/gi, "bolkar batao"],
  [/\b(?:bana|banaa)\s*(?:kar|ke)\s+(?:dikhao|bhejo)\b/gi, "bolkar batao"],
  [/\b(?:draw|drawing|sketch)\s+(?:karo|kar\s+lo|kar\s+do|banao)\b/gi, "mann mein socho"], [/\b(?:draw|drawing|sketch)\s+(?:kijiye|kariye|banaiye)\b/gi, "mann mein sochiye"],
  [/\b(?:chitra|tasveer|picture)\s+banao\b/gi, "tasveer socho"], [/\b(?:copy|kaagaz|kagaz|notebook)\s+(?:par|pe|mein)\s+bana(?:o|kar)\b/gi, "mann mein socho"],
  [/(?:ड्रॉ|ड्रा|चित्र)\s*(?:करो|बनाओ)/g, "मन में सोचो"], [/बना\s*(?:कर|के)\s*(?:दिखाओ|भेजो)/g, "बोलकर बताओ"],
  [/\bdraw\s+(it|this|that)\s+and\s+show\s+me\b/gi, (m) => m.replace(/draw/i, "picture").replace(/show/i, "tell")],
  [/\b(?:can\s+you\s+|now\s+|please\s+)?draw\s+(?:it|this|that|a|an|the|one)\b/gi, (m) => m.replace(/draw/i, "picture")],
];
export function speakNotWrite(reply, askEnd = null) {
  const r = String(reply ?? "");
  const ask = askEnd ? String(askEnd).trim() : "";
  const cut = ask && r.trim().endsWith(ask) ? r.trim().length - ask.length : r.length;
  let lead = r.slice(0, cut);
  for (const [re, to] of WRITE_TO_SAY) lead = lead.replace(re, (m) => { const t = typeof to === "function" ? to(m) : to; return /^\p{Lu}/u.test(m) ? t[0].toUpperCase() + t.slice(1) : t; });
  return lead + r.slice(cut);
}

// ───────────── r4-latency: the first TTS sentence, locked early (TAXILA_TTS_FIRST_SENTENCE) ─────────────

/** off (default) | shadow (lock decided and logged on guard.early; behaviour unchanged). The live mode is not built yet. */
export const firstSentenceMode = (env = process.env) => (/^shadow$/i.test(String(env.TAXILA_TTS_FIRST_SENTENCE ?? "")) ? "shadow" : "off");

/** The guards a single sentence can fail on its own (truth, safety, register, screen, script). The rest judge the whole
 *  turn's shape (ask, flat, drift, twoq, long, bare, nowhy, noconfirm) and are checked on `s1 + the question` instead. */
export const PER_SENTENCE = new Set(["floor", "harmtalk", "forget", "praise", "deny", "claim", "corrects", "screen", "parts", "register", "stage", "uiword", "cantshow",
  "leak", "units", "math", "script", "thinkq", "wrap", "same"]);

/**
 * PURE (given the turn's own `problems`). Lock the draft's first TTS sentence (server/voice/sentences.js splitSentences,
 * the same split the speech parts use) when ALL hold: a spoken lane; not a closing / check-in / forget-after-safety / why /
 * thinking / break / diagnostic turn; a pinned kit question; the draft has more than one sentence; s1 asks nothing and
 * names nothing on the screen or in the UI; s1 fails no per-sentence guard; on a right answer s1 confirms it; and the
 * minimal turn joinAsk(s1, question) fails no guard at all (so a final reply that starts with s1 always exists).
 * @returns {{ locked: true, s1: string, fallback: string, ms: number } | { locked: false, why: string }}
 */
export function lockFirstSentence({ reply, askEnd, problems, closing, spoken, confirmNeeded, t0 = performance.now() }) {
  const no = (why) => ({ locked: false, why });
  if (!spoken) return no("text_lane");
  if (closing) return no("turn_kind");
  if (!askEnd) return no("no_pinned_question");
  const parts = splitSentences(String(reply ?? "").trim());
  if (parts.length < 2) return no("one_sentence");
  const s1 = parts[0].trim();
  if (/[?？]/.test(s1)) return no("s1_asks");
  if (SCREEN_SENTENCE.test(s1) || namesUiPart(s1)) return no("s1_screen");
  if (words(s1) < 2) return no("s1_short");
  const own = problems(s1).filter((p) => PER_SENTENCE.has(p));
  if (own.length) return no(`s1_${own[0]}`);
  if (confirmNeeded && !confirmsFirst(s1)) return no("s1_noconfirm");
  const fallback = joinAsk(s1, askEnd);
  if (!fallback.startsWith(s1)) return no("join");
  const whole = problems(fallback);
  if (whole.length) return no(`min_${whole[0]}`);
  return { locked: true, s1, fallback, ms: Math.round(performance.now() - t0) };
}

// ───────────── round 5 (14.4, main; open-r143-affirm-on-no-answer): no affirmation that approves what nobody said ─────────────
// Sim lab p30 @f444f064 #6: the child tapped "No — insects have six legs…" (graded right) and her reply opened "Yes, Pihu—
// earthworm has no legs": a bare Yes before a negative fact agrees with the opposite of what the child said. And an
// opener of agreement on a not-yet / partly-right answer, or on no input at all, approves an answer that was not given.
// (a) not_yet / partial verdict, or truly empty input (no words, no tap): the leading affirmation goes, the rest stands.
// (b) a right answer that itself opens with No / nahi / नहीं: a bare Yes / Haan opener becomes "Right" / "Sahi" / "सही"
// (agreeing with the child), never a Yes before their No. Ungraded / unverified / attempt turns are left alone (main: 175
// mostly-fine openers on 14.2 when they were in). PURE.
const AFFIRM = "(?:ji\\s+haan|yes|yeah|yep|haa+n?|han|bilkul(?:\\s+sahi)?|ekdam\\s+sahi|sahi(?:\\s+(?:hai|kaha|jawab|baat))?|right|correct|exactly|sha+ba+sh|very\\s+good|well\\s+done|great|हाँ|हां|बिल्कुल(?:\\s+सही)?|सही|शाबाश)";
const YES_ONLY = /^(?:ji\s+haan|yes|yeah|yep|haa+n?|han|हाँ|हां)$/iu;
const NO_FIRST = /^\s*(?:no|nope|nahi|nahin|nhi|na|नहीं|ना)(?![\p{L}])/iu;
const escapeRe = (s) => String(s).replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
export function affirmOpenerFix(reply, { verdict = null, empty = false, answer = "", name = null, lang = "hinglish" } = {}) {
  const text = String(reply ?? "");
  const lead = name ? `(?:${escapeRe(name)}\\s*[,،—–-]?\\s*)?` : "";
  if (verdict === "not_yet" || verdict === "partial" || empty) {
    const m = text.match(new RegExp(`^\\s*(${lead})((?:${AFFIRM}(?![\\p{L}-])\\s*[,!.।—–-]*\\s*)+)`, "iu"));
    if (!m) return { text, fix: null };
    const rest = text.slice(m[0].length).trim();
    if (!rest) return { text, fix: null };
    const named = m[1] ? `${m[1].trim().replace(/[,،—–-]+$/, "")}, ` : "";
    const body = named ? rest : rest[0].toUpperCase() + rest.slice(1);
    return { text: `${named}${body}`, fix: "strip" };
  }
  if (verdict === "correct" && NO_FIRST.test(String(answer ?? ""))) {
    const m = text.match(new RegExp(`^(\\s*)(${AFFIRM})(?![\\p{L}])`, "iu"));
    if (!m || !YES_ONLY.test(m[2])) return { text, fix: null };
    const word = /[ऀ-ॿ]/.test(m[2]) ? "सही" : lang === "english" ? "Right" : "Sahi";
    return { text: `${m[1]}${word}${text.slice(m[0].length)}`, fix: "polarity" };
  }
  return { text, fix: null };
}
