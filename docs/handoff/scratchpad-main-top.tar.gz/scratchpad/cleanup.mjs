import { apiClient } from "/home/user/Taxila/tests/prod/lib.mjs";
const api = apiClient("http://127.0.0.1:8917");
const email = "prod-w2h+1791171260653kue8ww@taxila.test", password = "prod-pw-1791171260653-kue8ww";
await api("POST", "/api/auth/login", { email, password });
await api("DELETE", "/api/account", { password, confirm: true });
console.log("deleted");
