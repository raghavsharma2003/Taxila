import json,sys,time,urllib.parse,subprocess
def q(s,rows=4):
    for i in range(4):
        u="https://api.crossref.org/works?query.bibliographic="+urllib.parse.quote(s)+f"&rows={rows}&select=DOI,title,author,issued,container-title,abstract&mailto=research@example.org"
        r=subprocess.run(["curl","-sS","--max-time","40",u],capture_output=True,text=True).stdout
        try:
            d=json.loads(r); break
        except Exception:
            time.sleep(3+i*3)
    else:
        print("FAIL",s); return
    print("==",s)
    for w in d['message']['items']:
        au=', '.join((a.get('family') or '') for a in w.get('author',[])[:3])
        print(' ',w.get('issued',{}).get('date-parts',[[None]])[0][0],'|',(w.get('title') or [''])[0][:120],'|',w['DOI'],'|',au,'|',(w.get('container-title') or [''])[0][:50], '| ABS' if w.get('abstract') else '')
for s in sys.argv[1:]:
    q(s); time.sleep(1.5)
