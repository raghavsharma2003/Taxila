import { readFileSync } from "fs";
const j = JSON.parse(readFileSync("/home/user/Taxila/evals/owner-truth/results/acceptance-2026-10-04-prod9242020/owner-4.json", "utf8"));
process.argv.push("--base", "https://taxila.dev");
const { hindiShare, enShare } = await import("/home/user/Taxila/tests/prod/_owner.mjs");
for (const o of j.outcomes.filter((o) => /english|hindi|example|story/.test(o.id))) console.log(o.id, o.spoken, "hi", hindiShare(o.reply).toFixed(2), "en", enShare(o.reply).toFixed(2), "|", o.reply.slice(0, 160));
for (const tag of ["english", "hindi"]) {
  for (const t of j.transcripts.filter((t) => t.tag.startsWith(tag))) { console.log("--", t.tag); for (const r of t.rows) console.log("  ", r.child, "=>", (r.r?.teacherReply || "").slice(0, 140), "| ask:", r.r?.ui?.ask?.text?.slice(0, 60)); }
}
