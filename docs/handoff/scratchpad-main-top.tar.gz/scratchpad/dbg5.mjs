import { readFileSync } from "fs";
const j = JSON.parse(readFileSync("/home/user/Taxila/evals/owner-truth/results/acceptance-2026-10-04-prod9242020/owner-5.json", "utf8"));
for (const o of j.outcomes) console.log("==", o.id, o.spoken, JSON.stringify(o.artifact), "\n", JSON.stringify(o.reply), "\n NEXT:", JSON.stringify(o.next).slice(0, 200));
