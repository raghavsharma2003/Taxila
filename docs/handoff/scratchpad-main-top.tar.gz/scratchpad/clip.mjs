import { chromium } from "/home/user/Taxila/node_modules/playwright/index.mjs";
const FX = ["idle","speaking","showing","yielding","your_turn","listening","heard","thinking","work-speaking","work-your_turn","work-listening","work-heard","work-thinking","work-tiles","T1","T2","T3","T4","T5","T6","RC","PTT","pause","end","hint","help-menu","help","grownup","no-mic","locked","correct","not_yet","partial","hint-line","with-help","board-correct","board-not_yet","summary","summary-tried","keyboard","thinking-4s"];
const b = await chromium.launch();
for (const [w,h,dpr] of [[360,640,2],[1280,800,1]]) for (const band of ["b1","b2","b3","b4"]) {
  const ctx = await b.newContext({ viewport:{width:w,height:h}, deviceScaleFactor:dpr });
  const p = await ctx.newPage();
  for (const f of FX) {
    await p.goto(`http://127.0.0.1:5391/dev/desk?fixture=${f}&band=${band}`, { waitUntil: "networkidle" });
    await p.waitForTimeout(150);
    const r = await p.evaluate(() => {
      const out = [];
      for (const el of document.querySelectorAll(".dk-zone, .dk-card, .dk-dock, .dk-strip, .dk-sheet, .dk-help, button, a")) {
        const cs = getComputedStyle(el);
        if (el.scrollHeight > el.clientHeight + 2 && cs.overflowY !== "auto" && cs.overflowY !== "scroll" && el.clientHeight>0) out.push(`${el.className||el.tagName}:${el.scrollHeight}>${el.clientHeight}`);
        const rr = el.getBoundingClientRect();
        if ((el.tagName==="BUTTON"||el.tagName==="A") && rr.width>0 && (rr.height<48 || rr.width<48)) out.push(`small ${el.textContent.trim().slice(0,20)||el.getAttribute("aria-label")} ${Math.round(rr.width)}x${Math.round(rr.height)}`);
      }
      const sx = document.documentElement.scrollWidth > innerWidth;
      return { out, sx };
    });
    if (r.out.length || r.sx) console.log(w, band, f, r.sx ? "HSCROLL" : "", JSON.stringify([...new Set(r.out)]));
  }
  await ctx.close();
}
await b.close();
