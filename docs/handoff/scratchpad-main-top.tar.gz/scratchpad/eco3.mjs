import * as S from "/home/user/Taxila/shared/studio-spec.ts";
const all = S.SPECIES_IDS;
const lostD = (r) => all.filter(s => r.some(st => st.pop[s] < 0.1 * S.ECO_EQ[s]));
const strat = {
  none: [], cullDeer: [25, 28].map(d => ({ day: d, species: "deer", kind: "cull" })),
  cullDeerAddIns: [{day:25,species:"deer",kind:"cull"},{day:28,species:"deer",kind:"cull"},{day:30,species:"insects",kind:"add"},{day:33,species:"insects",kind:"add"}],
  cullDeerAddInsFrog: [{day:25,species:"deer",kind:"cull"},{day:28,species:"deer",kind:"cull"},{day:30,species:"insects",kind:"add"},{day:33,species:"insects",kind:"add"},{day:35,species:"frog",kind:"add"},{day:38,species:"frog",kind:"add"}],
  cullSnake: [{day:28,species:"snake",kind:"cull"},{day:32,species:"snake",kind:"cull"}],
  smart: [{day:25,species:"deer",kind:"cull"},{day:27,species:"snake",kind:"cull"},{day:30,species:"insects",kind:"add"},{day:33,species:"insects",kind:"add"},{day:36,species:"frog",kind:"add"}],
};
for (const len of [10, 12, 14, 16]) {
  const row = Object.entries(strat).map(([k, a]) => k + ":" + (lostD(S.ecoRun(all, 80, a, { from: 25, to: 25 + len })).join("+") || "OK"));
  console.log(len, row.join("  "));
}
