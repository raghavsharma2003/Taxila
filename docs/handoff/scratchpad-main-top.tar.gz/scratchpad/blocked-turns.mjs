// TEST trace, read-only, 10 days: turns whose reply guard caught content_filter and failed closed (no _context / _nonharm),
// with the child's last five turns, written to a scratch json for a model-only probe.
import { writeFileSync } from "node:fs";
const { q } = await import("/home/user/taxila-int/server/db.js");
const rows = await q(`select sid, turn, data->'reasons' as reasons from trace_event where kind = 'director.turn' and t > now() - interval '10 days'
  and data->'reasons' ? 'guard.content_filter' and not (data->'reasons' ? 'guard.content_filter_context') and not (data->'reasons' ? 'guard.content_filter_nonharm')`);
const out = [];
for (const r of rows) {
  const ev = await q(`select turn, data->'body'->>'childText' as t from trace_event where sid = $1 and kind = 'srv.req' and turn <= $2 and turn > $2 - 6 order by turn`, [r.sid, r.turn]);
  const texts = ev.filter((e) => typeof e.t === "string" && e.t.trim()).map((e) => ({ turn: e.turn, text: e.t }));
  if (texts.length) out.push({ sid: r.sid, turn: r.turn, texts });
}
writeFileSync(process.argv[2], JSON.stringify(out, null, 1));
console.log({ blockedTurns: rows.length, withWords: out.length });
process.exit(0);
