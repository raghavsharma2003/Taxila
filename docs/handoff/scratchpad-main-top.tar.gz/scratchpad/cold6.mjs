import { performance } from "node:perf_hooks";
const L = await import("/home/user/Taxila/server/safety/lexicon.js");
const rs = L.canonicalReadings("aap mummy se achhi ho");
console.log(rs);
const out = [];
for (const r of rs) for (const sh of L.__lexicon.SHAPES) { const a = performance.now(); sh.re.exec(r); out.push([performance.now() - a, sh.id, r]); }
out.sort((a, b) => b[0] - a[0]); console.log(out.slice(0, 5).map((x) => x[0].toFixed(2) + " " + x[1] + " | " + x[2]).join("\n"));
