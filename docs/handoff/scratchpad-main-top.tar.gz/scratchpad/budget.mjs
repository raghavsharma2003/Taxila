const e = process.env;
const tok = await (await fetch(`https://login.microsoftonline.com/${e.AZURE_TENANT_ID}/oauth2/v2.0/token`, { method: "POST", body: new URLSearchParams({ grant_type: "client_credentials", client_id: e.AZURE_SP_CLIENT_ID, client_secret: e.AZURE_SP_SECRET, scope: "https://management.azure.com/.default" }) })).json();
const H = { Authorization: `Bearer ${tok.access_token}`, "Content-Type": "application/json" };
const sub = `/subscriptions/${e.AZURE_SUBSCRIPTION_ID}`;
const n = (op, th, type = "Actual") => ({ enabled: true, operator: "GreaterThanOrEqualTo", threshold: th, contactEmails: [], contactRoles: ["Owner"], thresholdType: type, locale: "en-us" });
const budgets = {
  "credit-guard-total": { category: "Cost", amount: 480000, timeGrain: "Annually", timePeriod: { startDate: "2026-07-01T00:00:00Z", endDate: "2027-06-30T00:00:00Z" },
    notifications: { at70: n("", 70), at85: n("", 85), at95: n("", 95), fc100: n("", 100, "Forecasted") } },
  "credit-guard-monthly": { category: "Cost", amount: 30000, timeGrain: "Monthly", timePeriod: { startDate: "2026-10-01T00:00:00Z", endDate: "2027-09-30T00:00:00Z" },
    notifications: { at50: n("", 50), at80: n("", 80), at100: n("", 100), fc100: n("", 100, "Forecasted") } },
};
for (const [name, properties] of Object.entries(budgets)) {
  const r = await fetch(`https://management.azure.com${sub}/providers/Microsoft.Consumption/budgets/${name}?api-version=2023-05-01`, { method: "PUT", headers: H, body: JSON.stringify({ properties }) });
  const j = await r.json(); console.log(name, r.status, r.ok ? `ok amount=${j.properties.amount} spent=${j.properties.currentSpend?.amount}` : JSON.stringify(j).slice(0, 300));
}
