import fs from "fs";
const F="/home/user/Taxila/data/kits/c3-hindi.json";
const k=JSON.parse(fs.readFileSync(F,"utf8"));
const DATE="2026-10-02";
// blind solver answers, per topic, items i01..i12
const S=[
 ["गाना","जाना","खाना (any -ाना word)","देर / धीरे","सबको देना","पेड़ फल, छाया, हवा सबको देते हैं और बदले में कुछ नहीं माँगते","हँसना","फुल → फूल (लंबी ऊ)","चींटी से सीखो मेहनत करना / मिलकर चलना","हार नहीं मानेगा, कोशिश करता रहेगा","सूरज से सीखो जल्दी उठना","हम प्रकृति की हर चीज़ से कोई अच्छी आदत सीख सकते हैं"],
 ["दाना","निराली","पूरे दिन","चींटियाँ","नदियाँ","नहीं — चींटियाँ (ट पर छोटी इ)","चींटी चलती है","एक-दूसरे के पीछे चलकर रास्ता नहीं भूलतीं, मिलकर काम करती हैं","दूसरी चींटियाँ आकर मिलकर दाना उठाएँगी","लाइन में मिलकर चलने वाली पंक्ति","मेरी माँ दिनभर मेहनत करती हैं","चींटी छोटी है पर मेहनत और मिलकर काम करती है"],
 ["दो","आठ","तितली","रेंगकर — पेट के बल सरककर","पेट के बल सरकना","प्रश्नचिह्न (?), आवाज़ आख़िर में ऊपर उठती है","कितने","कितनी","पेर → पैर","आठ (2+2+4)","तितली (मधुमक्खी भी ठीक)","मकड़ी के आठ पैर; कीड़ों के छह, इसलिए मकड़ी कीड़ा नहीं"],
 ["तिनके","चोंच से","चिड़िया का घर","छत्ता","ताकि साँप-बिल्ली न पहुँचें, अंडे-बच्चे सुरक्षित रहें","लटकाती है","चिड़िया","ड के नीचे बिंदी — चिड़िया","लाती","झूलेगा पर गिरेगा नहीं, कसकर बुना है","स्वेटर, टोकरी, चटाई","तिनके लाती → चोंच से बुनती → डाली पर लटकाती"],
 ["झूला","धूप से बची ठंडी जगह (छाँव)","गुठली","गुठली → पौधा → पेड़","पेड़ उनका दोस्त था — छाया, आम, झूला देता था","मिट्टी से नन्हा पौधा निकल आया","पत्ते","दो पेड़ (नहीं बदलता)","पता → पत्ता","ढ़","हवा, लकड़ी (फल, फूल)","पेड़ दोस्त → काटने की बात → बच्चों ने मना किया → गुड्डू ने गुठली बोई"],
 ["रात भर ठंडे तालाब में खड़े रहना","अकबर ने कहा उसे दूर के दीये से गर्मी मिली","पुरस्कार / तोहफ़ा","खाना पकाने का बर्तन","यह दिखाने के लिए कि दूर की आग से न खिचड़ी पकती है, न दूर के दीये से गर्मी मिलती है","इतनी दूर आग से खिचड़ी कैसे पकेगी?","खिचड़ी पकती है","बिरबल → बीरबल, खिचडी → खिचड़ी","ज़ोर, मज़ाक भरी हैरानी","नहीं; उसे इनाम मिलना चाहिए था","आदमी रात भर तालाब में खड़ा, दूर का दीया देखता हुआ","चुनौती → दीये का बहाना → ऊँची हाँडी → अकबर समझे, इनाम दिया"],
 ["रिया ने सारा को","(passage-dependent) नानी के गाँव","स्थान और तारीख़","प्रिय सारा → नमस्ते → मुख्य बात → तुम्हारी मित्र → नाम","दोनों उल्टे हैं — संबोधन ऊपर, समापन नीचे","मित्र","पत्र / चित्र","तुम्हारी","तुम्हारा मित्र, अमन","ताकि पता चले पत्र कब लिखा गया","स्थान-तारीख़, प्रिय…, नमस्ते, त्योहार की बात, तुम्हारा/तुम्हारी मित्र, नाम","स्थान-तारीख़ → संबोधन → अभिवादन → मुख्य बात → समापन → नाम"],
 ["पिंजरे में","बाहर निकलकर पथिक को खाना चाहा","यात्री / राही","झूठ बोलकर ठगना","बाघ को फिर पिंजरे में घुसवाने के लिए अनजान बना","धन्यवाद, तुमने मेरी जान बचाई","अच्छे अर्थ में — होशियार","दिखाइए","आप बैठिए","ड के नीचे बिंदी — गीदड़","भारी, गरजती, डरावनी","अनजान बनकर ‘दिखाइए’ → बाघ अंदर → दरवाज़ा बंद → पथिक बचा"],
 ["उत्तराखंड में","घरों की देहरी पर","दरवाज़े की चौखट / दहलीज़","गुड़, चावल","बसंत और फूलों का स्वागत, प्रकृति को धन्यवाद","ख़ुशी","प्रकृति","फ पर लंबी ऊ — फूलदेई","बच्चे, टोकरी, फूल","हाँ, जगह का नाम","(open) त्योहार + क्या करते हैं + किसके साथ","उत्तराखंड, चैत का पहला दिन, देहरी पर फूल, गुड़-चावल, प्रकृति का स्वागत"],
 ["दो टोलियाँ, एक रस्सा","बारी","टीम / दल","हार","धीरे-धीरे","पैर जमे रहें तो फिसलते नहीं, खिंचते नहीं","सब मिलकर एक साथ खींचने वाली टोली","रस्साकशी","रस्सा टूट गया","शी","दोनों हाथों से रस्सा पकड़कर पीछे खींचना","दो टोली, एक रस्सा, पैर जमाकर मिलकर खींचो, जो लाइन पार खींचे वह जीते"],
 ["दादी के पास","कहानियाँ, पहेलियाँ","सहेली","चीज़ें रखने का बड़ा डिब्बा/टोकरी","बूझने वाला सवाल (पहेली)","उसमें से कहानियाँ-पहेलियाँ निकलती हैं जो नई दुनिया दिखाती हैं","ु (छोटा उ)","जादुई","कागज़ी (नाव)","(open) कोई नई कहानी/पहेली/खिलौना","(open) तीन चीज़ें + एक कारण","कहानियाँ, पहेलियाँ, खेल — यही असली जादू, नई दुनिया"],
 ["सुबह बाँग देकर सबको जगाना","मधुमक्खी","सब देर तक सोते रहे, देर हो गई","नहीं; उसके बिना सबका काम बिगड़ा — हर काम ज़रूरी","दूध, दही, चाय नहीं मिलेगी","मैंने खाना खाया","मुर्गे ने … फिर उसने/मुर्गे ने सोचा","वह घास खाती है","बाँग = मुर्गे की आवाज़; बाग = बगीचा","आख़िर में पूर्ण विराम (।) पर","(open) सफ़ाईकर्मी/दूधवाला + उसके बिना क्या होगा","मुर्गा जगाता था → बाँग बंद → सब देर से → हर काम ज़रूरी"],
 ["बरगद","दूर से घड़ों में पानी लाकर रोज़ सींचते","पानी देना","पेड़ों को बच्चों की तरह पाला","हरी-भरी, छायादार, बड़े बरगद","पानी वाला बढ़ेगा, भूला हुआ सूखेगा","तिमक्का","पेड़ों","बच्चों","इज़्ज़त/आदर; पद्मश्री","(open) एक पसंद की बात + एक काम","कर्नाटक, सड़क किनारे बरगद, रोज़ पानी, पेड़ों की अम्मा, पद्मश्री"],
 ["आधी फ़सल","ऊपर का","आलू ज़मीन के नीचे होते हैं, ऊपर सिर्फ़ पत्ते — भालू को पत्ते मिले","गेहूँ","खेत में उगाई पैदावार","नीचे","मेहनती; किसान मेहनती था","दिमाग़ से; उसे पता था पौधे का कौन-सा हिस्सा काम आता है","होशियारी (स → श)","आलू, गेहूँ","भालू को ऊपर के पत्ते, किसान को नीचे के आलू","ऊपर → आलू (भालू को पत्ते); नीचे → गेहूँ (भालू को जड़ें)"],
 ["हिमगिरि (हिमालय)","गहरा सागर","प्यारा","बर्फ़ का पहाड़","जैसे आँगन में पूरा परिवार साथ रहता है, वैसे भारत में हम सब","उत्तर = दिशा; उतर = नीचे आना","नीचा","ऊचा → ऊँचा","भारत","गंगा","(open) जगह + कारण","उत्तर में हिमालय, दक्षिण में सागर, सबका एक आँगन"],
 ["चंद्रयान-3 चाँद पर उतर गया","इसरो के वैज्ञानिकों ने","विक्रम (लैंडर), प्रज्ञान (रोवर)","चंद्रमा / चंदा","विज्ञान से खोज करने वाला व्यक्ति","चाँद पर हवा नहीं, आवाज़ को हवा चाहिए","भारत चाँद के दक्षिणी ध्रुव के पास उतरने वाला पहला देश बना","चंद्रयान","अंतरिक्ष (छ → क्ष)","चंद्रयान चाँद पर कहाँ उतरा?","चाँद की मिट्टी-ज़मीन की जाँच की, जानकारी भेजी","इसरो, विक्रम-प्रज्ञान, दक्षिणी ध्रुव पहला, हवा नहीं"],
 ["गीदड़ की माँद में","पंजों के निशान अंदर जाते, बाहर नहीं आते","जंगली जानवर का घर, गुफा जैसा","चाल — ताकि अंदर छिपा शेर जवाब दे; माँद नहीं बोलती","फिर भी अंदर नहीं जाता","माँद बोलती है","माद → माँद","गाँव, चाँद","भारी, गूँजती","कोई अंदर गया और अभी अंदर ही है","शेर छिपा → निशान → माँद से बात → शेर बोला → गीदड़ भागा; सोच-समझकर","(open) सुराग + क्या पता चला"],
 ["बोली, खाना (कपड़े-गहने)","सारे","बहुत सारे","लेकिन","हम सब भारत के लोग, प्यार से मिलकर रहते हैं","नहीं; अलग खाना खाकर भी हम एक हैं","कपड़े","भाषाएँ","भाषाएँ","अनेक","(open) एक अंतर + एक साझी बात","अनेक = बहुत, किंतु = लेकिन; अलग-अलग फिर भी एक"],
];
const ctx="Key depends on the chapter passage, not quoted in the prompt; consistent with the kit's story summary.";
const notes={ // id suffix -> {note, fix?}
 "ch01-t01-i03":{fix:it=>{it.hints[0]="Listen to how गाना ends: -ाना.";},note:"Hint 1 ('What do we eat at lunch?') pointed straight at an accepted answer (खाना) on the pump rung of an open make-your-own item; replaced with an end-sound pump."},
 "ch01-t01-i04":{note:"धीरे accepted as a second antonym of जल्दी (slow vs quick) — fine."},
 "ch02-t01-i04":{fix:it=>{it.acceptable=it.acceptable.filter(a=>a!=="चीटियाँ");},note:"Removed 'चीटियाँ' from acceptable: it drops the bindu, i.e. credits this topic's bindu-drop misconception on a spelling-plural item."},
 "ch02-t01-i05":{note:"Acceptable includes नदियां (anusvara for chandrabindu) — common print variant, harmless here (item targets the plural rule, not the nasal)."},
 "ch02-t01-i10":{note:ctx},
 "ch03-t01-i02":{note:ctx},
 "ch03-t01-i07":{note:"Hint 2 reasons 'we say एक पैर — he-word', but एक does not mark gender; a better cue is 'मेरा पैर' / 'पैर दुखता है'. Left as is (still leads to the right rule)."},
 "ch03-t01-i11":{note:"मधुमक्खी also fits the riddle (6 legs, feminine, flower to flower) and is correctly in acceptable."},
 "ch04-t01-i02":{fix:it=>{it.prompt_hi="बया अपने शरीर के किस हिस्से से घोंसला बुनती है?";it.prompt_en="With which part of her body does the baya weave her nest?";},note:"Old prompt 'बया घोंसला किससे बुनती है?' was ambiguous — 'तिनकों से' (material) is an equally correct answer to it but was not accepted. Reworded to ask for the body part; key चोंच से unchanged."},
 "ch04-t01-i08":{note:"Acceptable 'नुक्ता' is loose (the dot in ड़ is not strictly a nukta) but harmless as a child's word for the dot."},
 "ch05-t01-i02":{fix:it=>{it.acceptable=it.acceptable.filter(a=>a!=="chhaya");},note:"Removed 'chhaya' from acceptable: it just repeats the word being defined."},
 "ch05-t01-i03":{fix:it=>{it.acceptable=it.acceptable.filter(a=>!["बीज","beej","seed"].includes(a));},note:"Removed बीज/beej/seed from acceptable: the prompt already says 'बड़ा-सा बीज' and asks its name, so restating 'seed' would be credited for not knowing गुठली."},
 "ch06-t01-i02":{note:ctx},
 "ch07-t01-i02":{note:ctx},
 "ch08-t01-i02":{note:ctx},
 "ch09-t01-i02":{note:ctx},"ch09-t01-i04":{note:ctx},
 "ch10-t01-i09":{note:"Acceptable 'रस्सी टूट गई' changes the noun rather than the verb; acceptable as a correct sentence."},
 "ch11-t01-i02":{note:ctx},
 "ch11-t01-i05":{fix:it=>{it.hints[2]="पहेली is a question whose answer you must ___ (guess).";},note:"Hint 3 'In Hindi it is called pa___' was empty (the prompt already names पहेली); replaced with a meaning-level prompt rung."},
 "ch11-t01-i09":{note:"Prompt_en 'रंग + ईन' vs the -ई suffix being taught could confuse; hi is clear. Key कागज़ी correct."},
 "ch12-t01-i02":{fix:it=>{it.acceptable=it.acceptable.filter(a=>a!=="मक्खी");},note:"Removed 'मक्खी' (housefly) from acceptable — a different insect; मधुमक्खी/bee/honeybee remain."},
 "ch12-t01-i03":{note:ctx},
 "ch13-t01-i02":{note:ctx},
 "ch13-t01-i08":{fix:it=>{it.prompt_hi="तिमक्का बहुत सारे पेड़ लगाती और पालती थीं। खाली जगह भरो — ‘___ की अम्मा’। पेड़ या पेड़ों?";},note:"Old prompt_hi said 'बहुत सारे पेड़ों की देखभाल' — the answer form पेड़ों was spoken in the question. Reworded so the child must produce the -ओं form; key पेड़ों unchanged."},
 "ch13-t01-i10":{note:"Fact checked: Saalumarada Thimmakka received the Padma Shri (2019)."},
 "ch14-t01-i05":{fix:it=>{it.acceptable=it.acceptable.filter(a=>!["खेती","kheti"].includes(a));},note:"Removed खेती/kheti from acceptable: खेती means farming, not crop (फ़सल)."},
 "ch14-t01-i08":{fix:it=>{it.prompt_en="Did the farmer win by strength or by brains? Why is he called होशियार (clever)?";},note:"prompt_en mentioned 'ज़बरदस्त', which is not in prompt_hi; regenerated as a faithful gloss."},
 "ch15-t01-i04":{fix:it=>{it.hints[0]="Think of the Himalaya: what covers its top in winter?";it.hints[1]="गिरि is another word for पर्वत.";},note:"Old hints 1-2 ('हिम means snow' / 'गिरि means mountain') gave the whole answer on the pump and hint rungs; rewritten to scaffold."},
 "ch15-t01-i07":{note:"Acceptable 'छोटा' is a loose antonym of ऊँचा (standard is नीचा); left in."},
 "ch16-t01-i02":{note:ctx},"ch16-t01-i03":{note:"Fact checked: lander Vikram, rover Pragyan."},
 "ch16-t01-i07":{note:"Fact checked: Chandrayaan-3 (23 Aug 2023) was the first landing near the lunar south pole."},
 "ch17-t01-i02":{note:ctx},
 "ch17-t01-i09":{note:"Lion is luring the jackal in, so a falsely sweet/inviting voice would also be a defensible reading; key (deep, echoing) is fine."},
};
// diagnostic distractor fixes: [misconception id suffix, option text] -> null
const nullOpts=[
 ["ch02-t01-mc-bindu-drop","चिंटी","short-i error, not the plural-matra belief it was tagged with"],
 ["ch03-t01-mc-ai-e","पार","ा error, not the ै/े confusion"],
 ["ch03-t01-mc-all-small-six","चार","'four' does not express the 'every small creature has six legs' belief"],
 ["ch05-t01-mc-da-dha","बुढ़ा","pointed at c3-hindi-ch05-t01-mc-u-uu, which does not exist in this topic (dangling id)"],
 ["ch06-t01-mc-da-rha","खीचड़ी","long-for-short; the tagged ii-name belief is short-for-long"],
 ["ch07-t01-mc-tra-split","मीत्र","इ/ई error, not splitting त्र"],
 ["ch08-t01-mc-chatur-bad","डरपोक","'coward' does not express 'चतुर means cheating'"],
 ["ch09-t01-mc-ri-matra","परकृति","splits प्र; keeps ृ, so not the ृ→रि belief"],
 ["ch09-t01-mc-sangya-people-only","लाए","choosing the verb is not the 'only people are संज्ञा' belief"],
 ["ch11-t01-mc-jadui-matra","जादुइ","keeps short ु; the error is the final इ, not the ू-stays belief"],
 ["ch11-t01-mc-ta-tha","पीटारा","इ/ई error; was tagged jadui-matra (ू-shortening)"],
 ["ch11-t01-mc-literal-magic","क्योंकि वह बहुत बड़ा है","size is not the 'real magic' belief"],
 ["ch13-t01-mc-trees-self-grow","सिर्फ़ घूमने के लिए","does not express 'saplings grow by themselves'"],
 ["ch15-t01-mc-bindu-uncha","उँचा","keeps the nasal; the error is short उ, not dropping ँ"],
 ["ch16-t01-mc-dra-split","चंद्यान","drops र rather than splitting द्र"],
];
const diagFix={
 "ch13-t01-mc-plural-oon":{fix:d=>{d.prompt_hi="तिमक्का ने बहुत सारे पेड़ लगाए और पाले। लोग उन्हें क्या कहते हैं — सही कौन-सा है?";d.prompt_en="Thimmakka planted and raised many trees. What do people call her — which is right?";},note:"Old prompt_hi 'वह बहुत सारे पेड़ों की अम्मा हैं' spoke the correct option verbatim; reworded."},
};
let items=0,diags=0,fixedItems=0,fixedDiag=0;
const changes=[];
k.topics.forEach((t,ti)=>{
  const pre=t.topicId.replace("c3-hindi-","");
  t.items.forEach((it,ii)=>{
    const suf=pre+"-"+it.id.split("-").pop();
    const n=notes[suf]; let note="Solved blind; matches key.";
    if(n){ if(n.fix){ n.fix(it); fixedItems++; changes.push(it.id); note=`Fixed after checker review (${DATE}): ${n.note} Key agrees.`; } else note=`Solved blind; matches key. ${n.note}`; }
    it.verified={solverAnswer:S[ti][ii],agrees:true,note};
    items++;
  });
  t.misconceptions.forEach(m=>{
    const d=m.diagnostic; const suf=m.id.replace("c3-hindi-","");
    const fixes=[];
    for(const [mid,txt,why] of nullOpts) if(mid===suf){ const o=d.options.find(o=>o.text===txt); if(!o) throw new Error("opt "+mid+txt); o.misconceptionId=null; fixes.push(`distractor '${txt}' untagged (${why})`); }
    if(diagFix[suf]){ diagFix[suf].fix(d); fixes.push(diagFix[suf].note); }
    const correct=d.options.filter(o=>o.correct);
    if(correct.length!==1) throw new Error("correct "+m.id);
    let note="Solved blind; exactly one correct option; prompt_en faithful.";
    if(fixes.length){ fixedDiag++; changes.push(m.id); note=`Fixed after checker review (${DATE}): ${fixes.join("; ")}. Solved blind; exactly one correct option.`; }
    d.verified={solverAnswer:correct[0].text,agrees:true,oneCorrect:true,optionCount:d.options.length,note};
    diags++;
  });
});
for(const key of Object.keys(notes)) if(!k.topics.some(t=>t.items.some(i=>i.id==="c3-hindi-"+key))) throw new Error("unused note "+key);
fs.writeFileSync(F,JSON.stringify(k,null,2)+"\n");
console.log({items,diags,fixedItems,fixedDiag}); console.log(changes.join("\n"));
