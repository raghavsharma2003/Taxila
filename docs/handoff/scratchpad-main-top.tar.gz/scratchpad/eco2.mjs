import * as S from "/home/user/Taxila/shared/studio-spec.ts";
const all = S.SPECIES_IDS, r0 = (x) => JSON.stringify(Object.fromEntries(Object.entries(x.pop).map(([k, v]) => [k, Math.round(v)])));
const dr = S.ecoRun(all, 80, [], { from: 25, to: 43 });
console.log("no action lost", all.filter(s => dr.some(st => st.pop[s] <= 0.01)), "min", r0(dr[43]));
for (const [rem, w] of [["snake","insects"],["tiger","grass"],["snake","frog"],["tiger","deer"]]) console.log("trend", rem, w, S.ecoTrend(all, rem, w, 70));
// search simple strategies for keep-alive
const strategies = {
  cullDeer: [25, 28, 31].map(d => ({ day: d, species: "deer", kind: "cull" })),
  cullInsects: [27,30].map(d => ({ day: d, species: "insects", kind: "cull" })),
  addFrogs: [30, 34, 38].map(d => ({ day: d, species: "frog", kind: "add" })),
  combo: [{day:25,species:"deer",kind:"cull"},{day:28,species:"deer",kind:"cull"},{day:32,species:"frog",kind:"add"},{day:36,species:"frog",kind:"add"},{day:40,species:"snake",kind:"add"}],
};
for (const [k, a] of Object.entries(strategies)) { const r = S.ecoRun(all, 80, a, { from: 25, to: 43 }); console.log(k, "lost", all.filter(s => r.some(st => st.pop[s] <= 0.01)), r0(r[43])); }
console.log("--- danger line 10% of EQ");
const lostD = (r) => all.filter(s => r.some(st => st.pop[s] < 0.1 * S.ECO_EQ[s]));
const strat2 = { none: [], ...strategies,
  insectsFirst: [{day:26,species:"deer",kind:"cull"},{day:29,species:"insects",kind:"add"},{day:33,species:"insects",kind:"add"},{day:36,species:"frog",kind:"add"},{day:40,species:"frog",kind:"add"}],
  heavy: [24,27,30].map(d=>({day:d,species:"deer",kind:"cull"})).concat([30,33,36,39,42].map(d=>({day:d,species:"insects",kind:"add"}))).concat([36,40,44].map(d=>({day:d,species:"frog",kind:"add"}))),
};
for (const [k, a] of Object.entries(strat2)) { const r = S.ecoRun(all, 80, a, { from: 25, to: 43 }); console.log(k.padEnd(13), "lost", lostD(r).join(",")); }
