import fs from "node:fs";
const rows=fs.readFileSync("/tmp/taxila-fdb/runs/critic-repro.jsonl","utf8").split("\n").filter(Boolean).map(JSON.parse);
const q=(a,p)=>{if(!a.length)return null;const s=[...a].sort((x,y)=>x-y);return s[Math.floor((s.length-1)*p)];};
// thinking pause length distribution (test, one arm)
const th=rows.filter(r=>r.f.arm==="stage-a"&&r.f.lane==="FAST").flatMap(r=>r.f.pauses.filter(p=>p.thinking));
console.log("thinking pauses n",th.length,"ms p10/50/90",q(th.map(p=>p.ms),.1),q(th.map(p=>p.ms),.5),q(th.map(p=>p.ms),.9), "share<640", (th.filter(p=>p.ms<640).length/th.length).toFixed(3));
const byCls={};for(const p of th){byCls[p.cls]??=[];byCls[p.cls].push(p.ms);} for(const[k,v]of Object.entries(byCls))console.log(" ",k,v.length,"p50",q(v,.5));
for (const lane of ["FAST","D4"]) for (const arm of ["stage-a","silence-640","cascade-900"]) {
 const R=rows.filter(r=>r.f.arm===arm&&r.f.lane===lane&&r.f.endClass==="respond"&&r.f.gap!==null);
 const by={};for(const r of R){by[r.f.endReason]=(by[r.f.endReason]||0)+1;}
 const g=R.map(r=>r.f.gap);
 // per family
 const fam={};for(const r of R){fam[r.f.family]??=[];fam[r.f.family].push(r.f.gap);}
 console.log(lane,arm,"n",R.length,JSON.stringify(by),"gap<300:",(g.filter(x=>x<300).length/g.length).toFixed(3),"p10/50/90",q(g,.1),q(g,.5),q(g,.9), Object.entries(fam).map(([k,v])=>`${k}:${q(v,.5)}`).join(" "));
}
// end reasons by sub for stage-a FAST
const R=rows.filter(r=>r.f.arm==="stage-a"&&r.f.lane==="FAST"&&r.f.endClass==="respond");
const sub={};for(const r of R){const k=r.f.family+"."+r.f.sub;sub[k]??={n:0,bs:0,g:[]};sub[k].n++;if(r.f.endReason==="speak:backstop_silence")sub[k].bs++;if(r.f.gap!==null)sub[k].g.push(r.f.gap);}
for(const[k,v]of Object.entries(sub))console.log("  ",k,v.n,"backstop",v.bs,"gap p50",q(v.g,.5));
