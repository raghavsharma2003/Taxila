const e = process.env;
const tok = await (await fetch(`https://login.microsoftonline.com/${e.AZURE_TENANT_ID}/oauth2/v2.0/token`, { method: "POST", body: new URLSearchParams({ grant_type: "client_credentials", client_id: e.AZURE_SP_CLIENT_ID, client_secret: e.AZURE_SP_SECRET, scope: "https://management.azure.com/.default" }) })).json();
const H = { Authorization: `Bearer ${tok.access_token}` };
const rg = "rg-raghavsharma1729-7190";
for (const acct of ["raghavsharma1729-compan-resource", "taxila-ai-southindia", "taxila-ai-centralindia"]) {
  const id = `/subscriptions/${e.AZURE_SUBSCRIPTION_ID}/resourceGroups/${rg}/providers/Microsoft.CognitiveServices/accounts/${acct}`;
  const u = `https://management.azure.com${id}/providers/microsoft.insights/metrics?api-version=2023-10-01&timespan=2026-10-01T00:00:00Z/2026-10-24T12:00:00Z&interval=P1D&metricnames=ProcessedPromptTokens,GeneratedTokens&aggregation=Total&$filter=ModelDeploymentName eq '*'&top=60`;
  const j = await (await fetch(u, { headers: H })).json();
  if (!j.value) { console.log(acct, "metrics error", JSON.stringify(j).slice(0, 200)); continue; }
  console.log(`\n== ${acct} (Oct 1-24, million tokens)`);
  const agg = {};
  for (const m of j.value) for (const ts of m.timeseries ?? []) {
    const dep = ts.metadatavalues?.[0]?.value ?? "?"; const tot = ts.data.reduce((s, d) => s + (d.total ?? 0), 0);
    const peak = ts.data.reduce((b, d) => ((d.total ?? 0) > (b.total ?? 0) ? d : b), {});
    (agg[dep] ??= {})[m.name.value] = { tot, peak: peak.timeStamp?.slice(5, 10) };
  }
  for (const [d, v] of Object.entries(agg).sort((a, b) => (b[1].GeneratedTokens?.tot ?? 0) + (b[1].ProcessedPromptTokens?.tot ?? 0) - (a[1].GeneratedTokens?.tot ?? 0) - (a[1].ProcessedPromptTokens?.tot ?? 0)).slice(0, 18))
    console.log(d.padEnd(34), "in", ((v.ProcessedPromptTokens?.tot ?? 0) / 1e6).toFixed(1).padStart(7), "out", ((v.GeneratedTokens?.tot ?? 0) / 1e6).toFixed(1).padStart(6), "peak", v.GeneratedTokens?.peak ?? v.ProcessedPromptTokens?.peak);
}
