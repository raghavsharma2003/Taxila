import { readFileSync } from "fs";
for (const line of readFileSync("/home/user/Taxila/.env.local", "utf8").split("\n")) { const m = line.match(/^([A-Z0-9_]+)=(.*)$/); if (m && !process.env[m[1]]) process.env[m[1]] = m[2].replace(/^"(.*)"$/, "$1"); }
const url = process.env.DATABASE_URL;
console.log("host pooled?", /-pooler\./.test(url));
const pg = (await import("pg")).default;
try { const c = new pg.Client({ connectionString: url.replace(/[?&]channel_binding=require/, ""), ssl: { rejectUnauthorized: true }, connectionTimeoutMillis: 8000 }); await c.connect(); console.log("pg tcp ok", (await c.query("select version()")).rows[0].version.slice(0,30)); await c.end(); } catch (e) { console.log("pg tcp fail", e.message); }
try { const { Pool, neonConfig } = await import("@neondatabase/serverless"); const ws = await import("ws").catch(()=>null); if (ws) neonConfig.webSocketConstructor = ws.default; const p = new Pool({ connectionString: url }); const r = await p.query("select 1 as x"); console.log("neon ws ok", r.rows); await p.end(); } catch (e) { console.log("neon ws fail", e.message); }
