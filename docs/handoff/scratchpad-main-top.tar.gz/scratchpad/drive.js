// generic turn driver; s.tag names shots; s.typeAnswers optional array for typed answers
const chrome = /^(Pause|Captions off||Captions off|Captions on|More|Hear|Hear again|Help|Hear it again|Show me how|That wasn't me|Talk|Done|OK|Hint|Wait|Send|Type)$/;
const out = []; const t0 = Date.now(); let lastQ = ""; let n = 0; let idle = 0;
while (Date.now() - t0 < (s.budget || 240000)) {
  await page.waitForTimeout(1500);
  const st = await page.evaluate(() => ({ url: location.pathname, turn: !!document.querySelector('[data-floor="your_turn"], .dk-dock--turn') , txt: document.body.innerText }));
  if (/summary|What you did|Finish/.test(st.txt) && !/Pause/.test(st.txt.slice(0,20))) { out.push("SUMMARY?"); break; }
  const d = await dump();
  const q = (d.text.match(/Hear \| /) ? d.text.split(" | ").slice(0,6).join(" / ") : d.text.slice(0,200));
  const yourTurn = await page.getByText("Your turn", { exact: true }).first().isVisible().catch(()=>false) && !/is thinking|is talking/.test(d.text.split("Your turn.")[0]);
  if (!yourTurn) { idle++; if (idle > 30) { out.push("STUCK " + d.text.slice(0,300)); break; } continue; }
  idle = 0; n++;
  const input = await page.locator("textarea:visible, input[type=text]:visible").first();
  const hasInput = await input.count() > 0 && await input.isVisible().catch(()=>false);
  const cands = d.btns.filter(b => b.startsWith("button[") && !b.includes("(disabled)")).map(b => b.match(/\[(.*?)\]/)[1]).filter(l => !chrome.test(l));
  let action;
  if (hasInput && s.typeAnswers?.length) { const a = s.typeAnswers.shift(); await input.fill(a); await page.keyboard.press("Enter"); action = "typed:" + a; }
  else if (cands.length) { const help = ["Show me choices","Show me how","Hear it again"]; const real = cands.filter(c => !help.includes(c)); const pick = real.length ? real[0] : (s.pref && cands.includes(s.pref) ? s.pref : cands[0]); await page.getByRole("button", { name: pick, exact: true }).first().click({ timeout: 5000 }).catch(e => out.push("clickfail " + pick)); action = "tap:" + pick + " of [" + cands.join("|") + "]"; }
  else if (hasInput) { await input.fill(s.fallback || "I don't know"); await page.keyboard.press("Enter"); action = "typed-fallback"; }
  else { action = "NO-ACTION " + d.btns.join(";"); out.push(action); break; }
  const ta = Date.now();
  await shot(`${s.tag}-turn${String(n).padStart(2,"0")}`);
  out.push(`#${n} @${Math.round((ta-t0)/1000)}s Q=[${q}] -> ${action}`);
  // wait until your turn disappears
  for (let i = 0; i < 20; i++) { await page.waitForTimeout(500); if (!(await page.getByText("Your turn", { exact: true }).first().isVisible().catch(()=>false))) break; }
  if (n >= (s.maxTurns || 25)) break;
}
const d = await dump(); await shot(`${s.tag}-final`);
out.push("FINAL " + d.url + " :: " + d.text.slice(0, 800) + " || " + d.btns.join(" ; "));
return out;
