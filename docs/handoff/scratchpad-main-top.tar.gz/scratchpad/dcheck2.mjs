process.env.DATABASE_URL = process.env.TEST_DATABASE_URL;
const { q } = await import("/home/user/taxila-1441/server/db.js");
const rows = (r) => r.rows ?? r;
await q("begin read only");
const one = rows(await q(`select data from trace_event where t > now() - interval '2 days' and kind = 'model.call' limit 1`));
console.log(Object.keys(one[0].data), JSON.stringify(one[0].data).slice(0, 400));
const f = rows(await q(`select data->>'schema' sch, data->>'name' nm, data->>'outcome' oc, data->>'status' st, count(*)::int n from trace_event where t > now() - interval '14 days' and kind = 'model.call' and data::text ilike '%distress%' group by 1,2,3,4 order by 5 desc limit 15`));
console.log(f);
await q("rollback"); process.exit(0);
