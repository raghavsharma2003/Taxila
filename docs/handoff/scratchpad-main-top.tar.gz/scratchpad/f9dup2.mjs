const { q } = await import("/home/user/taxila-int/server/db.js");
const { createHash } = await import("node:crypto");
const rows = (r) => r.rows ?? r;
const sig = (x) => createHash("sha1").update(JSON.stringify(x ?? null)).digest("hex").slice(0, 8);
await q("begin read only");
for (const [pre, turns] of [["3437b744", [21, 23, 31, 33]], ["310b8c82", [12, 16, 29, 31, 39]]]) {
  const L = rows(await q(`select id::text from lesson where id::text like $1`, [`${pre}%`]))[0].id;
  const srv = rows(await q(`select data from trace_event where sid=$1 and kind='mic.duplex' order by t limit 1`, [L]))[0]?.data?.server;
  console.log(`== ${pre} server=${JSON.stringify(srv).slice(0, 80)}`);
  const ev = rows(await q(`select turn, kind, data from trace_event where sid=$1 and turn = any($2) and kind in ('ui.render.board','board.page','studio.slot.revealed','ui.render.tray','director.turn') order by turn, t`, [L, turns]));
  for (const e of ev) {
    const d = e.data ?? {};
    if (e.kind === "director.turn") { console.log(`  t${e.turn} director move=${d.move?.kind ?? d.move} beat=${d.beat?.type ?? d.beat ?? ""} boardSource=${d.boardSource ?? d.board?.source ?? ""}`); continue; }
    const ops = d.ops ?? d.page?.ops ?? d.board?.ops ?? null;
    const texts = Array.isArray(ops) ? ops.map((o) => o.text ?? o.label ?? "").filter(Boolean) : d.texts ?? null;
    console.log(`  t${e.turn} ${e.kind} keys=${Object.keys(d).slice(0, 12).join(",")} mode=${d.mode ?? d.page?.mode ?? ""} source=${d.boardSource ?? d.source ?? d.page?.source ?? ""} ops=${Array.isArray(ops) ? ops.length : "?"} opsSig=${sig(ops)} textsSig=${sig(texts)} pageSig=${d.pageSig ?? d.sig ?? ""}`);
  }
}
await q("rollback"); process.exit(0);
