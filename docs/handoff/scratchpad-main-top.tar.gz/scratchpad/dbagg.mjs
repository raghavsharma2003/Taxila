import { readFileSync } from "fs";
for (const l of readFileSync("/home/user/Taxila/.env.local","utf8").split("\n")) { const m=/^([A-Z0-9_]+)=(.*)$/.exec(l.trim()); if (m && !process.env[m[1]]) process.env[m[1]]=m[2].replace(/^["']|["']$/g,""); }
const { q } = await import("/home/user/Taxila/server/db.js");
const run = async (label, sql) => { try { console.log(label, JSON.stringify(await q(sql))); } catch (e) { console.log(label, "ERR", e.message); } };
await run("tables", "select count(*) filter (where table_name in ('kt_evidence','comp_facet_state','probe_log','grade_audit','reteach_attempts','weave_queue','evidence')) n from information_schema.tables where table_schema='public'");
await run("kt_evidence by cls/grader (7d)", "select cls, grader, count(*) n from kt_evidence where at > now() - interval '7 days' group by 1,2 order by 3 desc limit 30");
await run("kt shapeId", "select coalesce(shape_id,'-') shape, count(*) n from kt_evidence group by 1 order by 2 desc limit 30");
await run("probe_log", "select shape_id, count(*) n from probe_log group by 1 order by 2 desc limit 30");
await run("grade_audit", "select op, label, span_ok, model, count(*) n from grade_audit group by 1,2,3,4 order by 5 desc limit 30");
await run("reteach_attempts", "select count(*) n, count(*) filter (where resolved_at is not null) resolved from reteach_attempts");
await run("weave_queue", "select count(*) n from weave_queue");
await run("comp_facet_state", "select count(*) n from comp_facet_state");
await run("children", "select count(*) n from child");
process.exit(0);
