import re
src=open('/tmp/claude-0/-home-user/ecee9fc1-62f9-5f67-a47d-69ca79d9981a/scratchpad/lesson.premove.js').read().split('\n')
L=lambda a,b: src[a-1:b]   # inclusive 1-indexed
header=L(1,57)
imports='\n'.join(L(5,57))
say=L(66,67)+['']+L(70,70)+['']+L(164,192)+['']+L(216,277)+['']+L(279,445)
rows=L(59,65)+L(68,68)+['']+L(105,162)+['']+L(197,214)+['']+L(484,517)+['']+L(1353,1365)
turn=L(81,103)+['']+L(520,522)+['']+L(754,1437)+['']+L(1638,1664)+['']+L(1675,1691)
keep=L(1,58)+L(72,79)+['']+L(194,195)+['']+L(447,483)+L(519,519)+L(523,752)+['']+L(1439,1636)+['']+L(1666,1674)+L(1693,1694)
def exp(lines,names):
    out=[]
    for ln in lines:
        m=re.match(r'^(async function|function|const) (\w+)',ln)
        if m and m.group(2) in names: ln='export '+ln
        out.append(ln)
    return out
say=exp(say,{'REPLY_MAX_WORDS','words','scrubbed','trimToWords','POSING_MOVES','CLOSING_MOVES','TEACHING_MOVES','safeguardLine','fallbackReply','textReply','withoutLeaks','FALLBACK'})
rows=exp(rows,{'debugFor','RECENT_TURNS','kitFor','stageTurns','turnInsertStmt','incidentStmt','withSeamUi','withAsk','LANES','laneOf','runTurnTx'})
turn=exp(turn,{'loadTurnContext','HELP_SAID','activitySummary','ACKS_MAX','sendReplay','turn','childRowSeq','uiVerdictOf','noteDid','planTurn','gradeRequestFor','carriedFrom','launchGrades','replyKey','speculate','specFanout','pickSpeculation','spoiledBy','flushHeld','missReason','SPEC_OUTCOMES','DID_MAX','KEY_PARTS'})
S='/tmp/claude-0/-home-user/ecee9fc1-62f9-5f67-a47d-69ca79d9981a/scratchpad/'
open(S+'say.body','w').write('\n'.join(say))
open(S+'rows.body','w').write('\n'.join(rows))
open(S+'turn.body','w').write('\n'.join(turn))
open(S+'keep.body','w').write('\n'.join(keep))
open(S+'imports.txt','w').write(imports)
