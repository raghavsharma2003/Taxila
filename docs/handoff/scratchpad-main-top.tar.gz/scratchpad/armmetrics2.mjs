const { arm, SUB_PATH } = await import("/home/user/taxila-int/infra/azure.mjs");
const host = (u) => { try { return new URL(u).host; } catch { return null; } };
const chatHost = host(process.env.AZURE_OPENAI_ENDPOINT_CHAT || process.env.AZURE_OPENAI_ENDPOINT);
console.log("CHAT endpoint host:", chatHost);
const RG = `${SUB_PATH()}/resourceGroups/${process.env.AZURE_RESOURCE_GROUP}`;
const accts = (await arm("GET", `${RG}/providers/Microsoft.CognitiveServices/accounts?api-version=2024-10-01`)).value ?? [];
const primary = accts.find((a) => chatHost && (a.properties?.endpoint ?? "").includes(chatHost.split(".")[0])) ?? accts.find((a) => /centralindia/.test(a.name));
console.log("primary account:", primary?.name, primary?.location);
const span = "2026-10-16T07:30:00Z/2026-10-16T10:30:00Z";
for (const names of ["AzureOpenAIRequests", "AzureOpenAITimeToResponse", "AzureOpenAITTLTInMS", "ServerErrors", "Latency"]) {
  try {
    const r = await arm("GET", `${primary.id}/providers/microsoft.insights/metrics?api-version=2023-10-01&metricnames=${names}&timespan=${span}&interval=PT15M&aggregation=Average,Maximum,Total`);
    for (const m of r.value ?? []) for (const ts of m.timeseries ?? []) console.log(` ${m.name.value}: ` + (ts.data ?? []).map((d) => `${d.timeStamp.slice(11, 16)} ${Math.round(d.maximum ?? d.total ?? d.average ?? 0)}`).join(" | "));
  } catch (e) { console.log(` ${names}: ${e.message.slice(-120)}`); }
}
