// Which TRUE distress items (every recall set) would the 14.4 demotions turn from the full script into a check-in?
// lessonHyperbole (on a predicate self_harm hit), lessonIdiom / scoldOnly (on a model read). Deterministic, the clean text.
const B = "/home/user/taxila-1441";
const C = await import(`${B}/evals/safety-robust/corpora.mjs`);
const { HELDOUT_DISTRESS } = await import(`${B}/evals/safety-robust/negatives.data.mjs`);
const { REDTEAM_DISTRESS, REDTEAM_ROUND2, REDTEAM_ROUND3 } = await import(`${B}/evals/safety-robust/redteam.data.mjs`);
const { lessonIdiom, scoldOnly, lessonHyperbole } = await import(`${B}/server/safety/idioms.js`);
const { scanSafetyDetail } = await import(`${B}/server/director/safety.js`);
const sets = { fdb: C.taxilaFdbDistress(), es3: C.es3Distress(), es1: (C.es1Turns?.() ?? []).filter((x) => x.distress), cv2: await C.conversationV2Distress(),
  heldout: HELDOUT_DISTRESS, rt1: REDTEAM_DISTRESS, rt2: REDTEAM_ROUND2, rt3: REDTEAM_ROUND3 };
let n = 0; const hits = [];
for (const [name, items] of Object.entries(sets)) for (const it of items ?? []) {
  const text = typeof it === "string" ? it : (it.text ?? (it.segs ? C.cleanText(it) : ""));
  if (!text) continue; n++;
  const d = scanSafetyDetail(text);
  const why = [d.kind === "self_harm" && lessonHyperbole(text) && "hyperbole", lessonIdiom(text) && "idiom", scoldOnly(text) && "scold"].filter(Boolean);
  if (why.length) hits.push(`${name} ${why.join("+")} pred=${d.distress}/${d.kind} | ${text.slice(0, 140)}`);
}
console.log(`true distress items: ${n}; matched by a demotion: ${hits.length}`);
for (const h of hits) console.log("  " + h);
process.exit(0);
