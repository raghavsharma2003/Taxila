import { expressiveSeam } from "/home/user/Taxila/server/voice/expressive/seam.js";
import { renderParts } from "/home/user/Taxila/server/voice/expressive/render.js";
import { createGovernor } from "/home/user/Taxila/server/voice/expressive/governor.js";
const style = { engine: "dhd", dhd: { voice: "v", baseRate: -35 }, voice: "marin", instructions: "", version: "t", spoken: { mode: "hinglish" } };
const gov = createGovernor({ now: () => 0 });
const reply = "Chalo, 27 aur 35 jodte hain. Pehle tens: 20 aur 30, matlab 50. Phir 7 aur 5, 12. Toh total kya hua?";
const m = (i) => ({ move: "worked_example", verdict: "ungraded", engagement: "engaged", teacherAffect: { display: "neutral_warm", intensity: 1, cause: "none", turn: i }, bondStage: "first_sessions", safety: false, childLaughed: false, thinkAloud: true, band: "B3", lang: "hinglish" });
const a = [], b = [];
for (let i = 0; i < 2000; i++) { const t0 = performance.now(); const p = expressiveSeam.planDelivery(m(i), reply); const t1 = performance.now(); renderParts({ lessonId: "B", text: reply, style, delivery: p, gov, log: false }); const t2 = performance.now(); if (i >= 200) { a.push(t1 - t0); b.push(t2 - t1); } }
const q = (x, f) => x.sort((u, v) => u - v)[Math.floor(x.length * f)].toFixed(3);
console.log("plan p50", q(a, .5), "p99", q(a, .99), "| render p50", q(b, .5), "p99", q(b, .99));
