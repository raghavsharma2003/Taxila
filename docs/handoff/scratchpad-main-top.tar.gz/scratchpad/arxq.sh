q() { curl -sS --max-time 30 "https://export.arxiv.org/api/query?max_results=${2:-4}&sortBy=relevance&search_query=$(python3 -c "import urllib.parse,sys;print(urllib.parse.quote(sys.argv[1], safe=':'))" "$1")" | python3 -c "
import sys,re
x=sys.stdin.read()
for e in re.findall(r'<entry>(.*?)</entry>',x,re.S):
  t=re.sub(r'\s+',' ',re.search(r'<title>(.*?)</title>',e,re.S).group(1))
  i=re.search(r'<id>(.*?)</id>',e).group(1)
  p=re.search(r'<published>(.*?)</published>',e).group(1)[:10]
  s=re.sub(r'\s+',' ',re.search(r'<summary>(.*?)</summary>',e,re.S).group(1))
  print('*',i,p,'|',t,'\n  ',s[:900])
"; echo; sleep 3; }
