import { openHarness } from "/home/user/Taxila/scripts/character/harness.mjs";
process.chdir("/home/user/Taxila");
const hx = await openHarness({ w: 600, h: 400 });
const S = process.argv[2];
try {
  await hx.page.evaluate(() => TX.load("plum", "H"));
  for (const [n, vis] of [["cards_on", true], ["cards_off", false]]) {
    await hx.page.evaluate((v) => { TX.rig.meshes.cards.visible = v; TX.frame("face", 0); TX.pose({}); TX.render(); }, vis);
    await hx.shot(`${S}/${n}.png`);
  }
  const r = await hx.page.evaluate(() => { const m = TX.rig.meshes.cards; const t = m.material.uniforms.tAlbedo.value; return { img: t && t.image && [t.image.width, t.image.height], fmt: t && t.format, cs: t && t.colorSpace, uvMax: Math.max(...m.geometry.attributes.uv.array), uvMin: Math.min(...m.geometry.attributes.uv.array) }; });
  console.log(JSON.stringify(r));
} finally { await hx.close(); }
