// Model-only (TEST routing): the reply path's childWordsTrip on the sim lab's two false-safeguard turns, 3 tries each,
// plus each child line alone. No DB use.
import { readFileSync } from "node:fs";
const { childWordsTrip, probeWords } = await import("/home/user/taxila-int/server/brain/say.js");
const d = JSON.parse(readFileSync(process.argv[2], "utf8"));
for (const [pre, turn] of [["1bd3182c", 12], ["0353dc41", 7]]) {
  const rows = d[pre].filter((x) => x.turn <= turn);
  const history = rows.slice(0, -1).map((x) => ({ who: "child", text: x.text }));
  const words = probeWords(history, rows.at(-1).text);
  const tries = []; for (let i = 0; i < 3; i++) tries.push(await childWordsTrip(words));
  console.log(pre, turn, "probe(last 5 child turns):", tries.join(","));
  for (const r of rows.slice(-5)) console.log("   alone", r.turn, await childWordsTrip(probeWords([], r.text)));
}
process.exit(0);
