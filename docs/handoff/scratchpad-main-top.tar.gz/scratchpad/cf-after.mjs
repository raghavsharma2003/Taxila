// Model-only (TEST routing): after the fix, the copy the reply probe reads for the lines that tripped, and p11's probe words.
import { readFileSync } from "node:fs";
const { childWordsTrip, probeWords, forModel } = await import("/home/user/taxila-int/server/brain/say.js");
const d = JSON.parse(readFileSync(process.argv[2], "utf8"));
const lines = ["teen aur teen chhe", "do aur teen paanch", "teen guna teen nau", "teen saal ka bhai", "teen plus teen equals chhe",
  "kyunki... uske teen sides hote hain... tircha ho ya seedha, sides ginne se teen hi aate hain... maine sahi bola?"];
let harm = 0, n = 0;
for (const v of lines) for (let i = 0; i < 3; i++) { const r = await childWordsTrip(probeWords([], v)); n++; if (r !== "clear") harm++; }
console.log("tripping lines after the fix:", `${harm}/${n} probes not clear`);
const rows = d["1bd3182c"].filter((x) => x.turn <= 12);
const w = probeWords(rows.slice(0, -1).map((x) => ({ who: "child", text: x.text })), rows.at(-1).text);
const t = []; for (let i = 0; i < 3; i++) t.push(await childWordsTrip(w));
console.log("p11 t12 probe words after the fix:", t.join(","));
process.exit(0);
