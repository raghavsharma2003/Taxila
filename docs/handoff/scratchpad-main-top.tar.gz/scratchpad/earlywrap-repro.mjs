// The sim lab's ok10 r1 (c5-maths-ch02-t01): does the Director end the lesson after the third turn? Pure Director steps with
// scripted classifications shaped like the record (no model calls).
const B = "/home/user/taxila-1441";
const { initLessonState, step } = await import(`${B}/server/director/state.js`);
const { kitFor } = await import(`${B}/server/brain/rows.js`);
const { CTX, cls } = await import(`${B}/tests/fixtures/kit.mjs`);
const K = await kitFor("c5-maths-ch02-t01", {});
console.log("kit items", K.items.length, K.items.map((i) => `${i.id}:${i.kind}`).join(" "));
let r = step(initLessonState({ topicId: K.topicId, kit: K, ctx: { ...CTX, firstName: "Riya", lang: "hinglish", classLevel: 5 }, seed: 7, now: 0 }), { event: "start", kit: K, now: 0 });
const show = (tag, r) => console.log(tag, "move", r.move.kind, "phase", r.state.phase, "item", r.state.activeItemId ?? null, "queue", (r.state.queue ?? r.state.practiceQueue ?? []).length ?? "?", r.end ? "END" : "");
show("start", r);
const noEv = (f = {}) => { const b = cls("no_evidence"); return { ...b, flags: { ...b.flags, ...f } }; };
for (const [i, [text, c]] of [["Haan ji, drawing bahut pasand hai! ... aap fractions kya hota hai, waise?", noEv({ offTopic: true })],
  ["Pizza! Mmmm... barabar parts? Chaar, chheh, ho sakte hain na?", noEv()],
  ["Accha, number line... 2/5 ke liye, matlab paanch mein se do hisse. To do gaps aage jaana padega, na? Haan, do gaps!", noEv()]].entries()) {
  r = step(r.state, { event: "turn", kit: K, cls: c, text, now: 20_000 * (i + 1) });
  show(`t${i + 1}`, r);
}
process.exit(0);
