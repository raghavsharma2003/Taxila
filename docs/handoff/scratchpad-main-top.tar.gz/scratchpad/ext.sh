#!/bin/bash
# ext.sh file startline -> prints entry
awk -v s=$2 'NR>=s { if (NR>s && /^## /) exit; print NR": "$0 }' $1
