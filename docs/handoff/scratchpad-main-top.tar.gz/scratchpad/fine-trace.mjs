// TEST trace: the child's reply right after an episode OPENED (safety.scan safeguardMove, not episode_open), by kind;
// how many read as clearly fine (fine.js). Codes and child words of TEST accounts only; nothing is written.
const { q } = await import("/home/user/taxila-int/server/db.js");
const { fineReading, asksToCarryOn } = await import("/home/user/taxila-int/server/safety/fine.js");
const MODEL = new Set(["model", "content_filter", "model_note"]);
const opens = await q(`select sid, turn, data from trace_event where kind = 'safety.scan' and (data->>'safeguardMove')::boolean
  and not (data->'sources') ? 'episode_open' and t > now() - interval '10 days' order by t`);
const out = { model: { n: 0, fine: 0, carry: 0, why: {} }, other: { n: 0, fine: 0, carry: 0, why: {} } };
const showFine = [], showNot = [];
for (const o of opens) {
  const nx = await q(`select data from trace_event where sid = $1 and turn = $2 and kind = 'srv.req' and data->>'route' like '%/lesson/turn%' limit 1`, [o.sid, o.turn + 1]);
  const text = nx[0]?.data?.body?.childText;
  if (typeof text !== "string" || !text.trim()) continue;
  const g = MODEL.has(o.data.kind) ? out.model : out.other;
  const r = fineReading(text); g.n++; g.why[r.why] = (g.why[r.why] ?? 0) + 1;
  if (r.fine) { g.fine++; if (asksToCarryOn(text)) g.carry++; (g === out.model ? showFine : showFine).push(`${o.data.kind}: ${text.slice(0, 130)}`); }
  else if (g === out.model) showNot.push(`${r.why}: ${text.slice(0, 130)}`);
}
console.log(JSON.stringify(out, null, 1));
console.log("\nREAD FINE (all kinds):"); for (const s of showFine) console.log("  ", s);
console.log("\nMODEL-KIND NOT FINE:"); for (const s of showNot.slice(0, 40)) console.log("  ", s);
process.exit(0);
