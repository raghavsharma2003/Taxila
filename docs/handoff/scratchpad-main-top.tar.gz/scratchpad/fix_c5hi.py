import json,re
P='/home/user/Taxila/data/kits/c5-hindi.json'
d=json.load(open(P))
items={it['id']:it for t in d['topics'] for it in t['items']}
N='़'

def setnote(it,msg):
    it['verified']['agrees']=True
    it['verified']['note']=msg

# ch01 i03
it=items['c5-hindi-ch01-t01-i03']
it['hints']=["Listen to how उजियारा ends: -आरा.","Keep the ending -आरा and change only the first sound.","Ta___ or sa___.","तारा and सारा rhyme with उजियारा."]
setnote(it,"Agrees. Fixed: hint 1 no longer a riddle for तारा; it now points to the -आरा ending.")
# ch01 i04
it=items['c5-hindi-ch01-t01-i04']
it['hints']=["Opposite means the other side: if उजियारा is light, what is 'no light'?","Think of a room at night with every lamp switched off.","Not light but andh___.","The opposite is अँधेरा."]
setnote(it,"Agrees (अँधियारा also accepted). Fixed: hint 1 now starts from the 'opposite of light' idea instead of naming अँधेरा.")
# ch02 i02
it=items['c5-hindi-ch02-t01-i02']
it['hints']=["Listen again — whose words come first in the passage?","She is old and wise, and gives the order to untie the rope.","It was samajhdaar da___.","The wise दादी sat on the chair."]
setnote(it,"Agrees; easy literal retrieval (answer is in the passage by design, difficulty 1). Fixed: hint 1 no longer refers to smiling, which no passage contains.")
# ch03 i05
it=items['c5-hindi-ch03-t01-i05']
it['hints']=["Listen to how मोटा ends: -ओटा.","Keep -ओटा, change only the first sound.","Chh___ or l___.","छोटा and लोटा rhyme with मोटा."]
if 'सोटा' not in it['acceptable']: it['acceptable']+=['सोटा','sota']
setnote(it,"Agrees. Fixed: hint 1 now leads with the -ओटा ending instead of 'opposite of बड़ा'; added सोटा.")
# ch07: add the line to the i02 passage, and quote it in i06
it=items['c5-hindi-ch07-t01-i02']
old='पाठशाला में पढ़ाई से ज़्यादा मेरा मन खेलों में लगता था।’'
assert old in it['prompt_hi']
it['prompt_hi']=it['prompt_hi'].replace(old,'पाठशाला में पढ़ाई से ज़्यादा मेरा मन खेलों में लगता था। आज सोचता हूँ, वे दिन कितने बेफ़िक्र थे!’')
it=items['c5-hindi-ch07-t01-i06']
it['prompt_en']="Listen: \"आज सोचता हूँ, वे दिन कितने बेफ़िक्र थे!\" Why does the writer say \"आज सोचता हूँ\"? When did he write this?"
it['prompt_hi']="सुनो — ‘आज सोचता हूँ, वे दिन कितने बेफ़िक्र थे!’ लेखक ‘आज सोचता हूँ’ क्यों कहता है? ये बातें उसने कब लिखीं?"
setnote(it,"Agrees. Fixed: the line 'आज सोचता हूँ, वे दिन कितने बेफ़िक्र थे!' is now in the i02 passage and quoted in this prompt, so the child can locate it (it also grounds i05's बेफ़िक्र).")
# ch08 i03
it=items['c5-hindi-ch08-t01-i03']
it['prompt_hi']=it['prompt_hi'].replace('दुनिया के सबसे ज़्यादा','दुनिया में सबसे ज़्यादा')
setnote(it,"Agrees. Fixed grammar: 'दुनिया में सबसे ज़्यादा ऐसे गैंडे यहीं रहते हैं'. Fact checks out (Kaziranga holds about two-thirds of the world's one-horned rhinos).")
# ch10 i03
it=items['c5-hindi-ch10-t01-i03']
it['prompt_hi']=it['prompt_hi'].replace('मरी होने का नाटक करके','मरने का नाटक करके')
it['acceptable']=[a for a in it['acceptable'] if a!='मरी होने का नाटक']+['मरने का नाटक','मरी हुई होने का नाटक','marne ka natak']
setnote(it,"Agrees. Fixed phrasing: passage now says 'मरने का नाटक करके'; acceptable updated.")
# ch11 i01
it=items['c5-hindi-ch11-t01-i01']
it['prompt_hi']=it['prompt_hi'].replace('पास ही एलोरा में कैलाश मंदिर है','उसी इलाक़े में एलोरा की गुफ़ाएँ हैं, जहाँ कैलाश मंदिर है')
assert 'उसी इलाक़े' in it['prompt_hi']
setnote(it,"Agrees. Fixed fact: 'पास ही एलोरा' replaced by 'उसी इलाक़े में एलोरा की गुफ़ाएँ हैं' (they are ~100 km apart in the same region).")
# ch12 i01
it=items['c5-hindi-ch12-t01-i01']
it['hints']=["Listen for a name anywhere in the story.","Who is telling the story about herself? Her name comes in the last sentence.","Aage chalkar mera naam Gan___ padta hai.","'मैं' is the river Ganga."]
setnote(it,"Agrees. Fixed: hint 1 no longer sends the child to the first sentence; hint 2 points to the last sentence, where the name is.")
# ch09 i10
it=items['c5-hindi-ch09-t01-i10']
for a in ["रोहन: (धीरे से) मैडम, शॉट मैंने मारा था।","रोहन: (धीरे से) मैडम, शॉट मैंने मारा था","रोहन धीरे से मैडम शॉट मैंने मारा था","Rohan: (dheere se) madam, shot maine maara tha"]:
    if a not in it['acceptable']: it['acceptable'].append(a)
setnote(it,"Agrees; both versions (with or without 'मैडम,') are valid play lines and both are now accepted.")
# ch04 stray acceptable
it=items['c5-hindi-ch04-t01-i12']
it['acceptable']=[a for a in it['acceptable'] if a!='पहला']

# ---- kit-wide string transforms
SKIP_KEYS={'solverAnswer','note'}
def nuk(s):
    rules=[(r'खुश(?!'+N+')','ख़ुश'),(r'ख(?!'+N+')ुश','ख़ुश'),(r'खराब','ख़राब'),(r'बाग(?!'+N+')','बाग़'),(r'खत्म','ख़त्म'),
           (r'गलत','ग़लत'),(r'बेफिक्र','बेफ़िक्र'),(r'बर्फ(?!'+N+')','बर्फ़'),(r'दरवाज(?!'+N+')','दरवाज़'),(r'गुस्स','ग़ुस्स'),
           (r'खयाल','ख़याल'),(r'मौका','मौक़ा')]
    for a,b in rules: s=re.sub(a,b,s)
    return s
def sang(s):
    s=s.replace('साङकेन','साङ्केन').replace('साङ-केन','साङ्-केन')
    s=re.sub(r'साङ(?![्क])',lambda m:'साङ्',s)
    return s
def walk(o,key=None):
    if isinstance(o,dict): return {k:walk(v,k) for k,v in o.items()}
    if isinstance(o,list):
        if key=='acceptable':
            out=[]
            for a in o:
                for v in (a, sang(a), nuk(sang(a))):
                    if v not in out: out.append(v)
            return out
        return [walk(v,key) for v in o]
    if isinstance(o,str) and key not in SKIP_KEYS: return nuk(sang(o))
    return o
d=walk(d)
items={it['id']:it for t in d['topics'] for it in t['items']}
# ch04 notes + acceptable
it=items['c5-hindi-ch04-t01-i01']; setnote(it,"Agrees. Fixed kit-wide: साङकेन → साङ्केन (halant on ङ) in skills, prompts, diagnostic, remediation and items, so it is the conjunct the skill describes.")
it=items['c5-hindi-ch04-t01-i04']
for a in ['साङ् केन','साङ्केन']:
    if a not in it['acceptable']: it['acceptable'].append(a)
setnote(it,"Agrees (साङ्-केन). Fixed: spelling now carries the halant (साङ्केन) kit-wide.")
it=items['c5-hindi-ch04-t01-i05']; setnote(it,"Blind answer matches the key. Spelling updated to साङ्केन.")
it=[t for t in d['topics'] if t['topicId']=='c5-hindi-ch11-t01'][0]
for x in it['items']:
    if x.get('verified',{}).get('note','').startswith('Agrees. Nukta inconsistency'):
        setnote(x,"Agrees. Fixed: nukta normalised kit-wide (ख़राब, ख़ुश, बाग़, ख़त्म, ग़लत …); plain forms kept in acceptable[] as transcription variants.")

# ---- diagnostic option order: spread correct index
k=0
for t in d['topics']:
    for m in t['misconceptions']:
        opts=m['diagnostic']['options']
        c=[o for o in opts if o['correct']]; w=[o for o in opts if not o['correct']]
        assert len(c)==1
        pos=k%len(opts); k+=1
        m['diagnostic']['options']=w[:pos]+c+w[pos:]
json.dump(d,open(P,'w'),ensure_ascii=False,indent=2)
open(P,'a').write('\n')
print('ok',k)
