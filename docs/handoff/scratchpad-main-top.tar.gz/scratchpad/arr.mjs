import { readFileSync, readdirSync } from "fs";
import { planEngine } from "/home/user/Taxila/shared/engine-catalog.js";
const root="/home/user/Taxila/";
const topicMap = JSON.parse(readFileSync(root+"shared/engine-topic-map.json","utf8"));
let n=0, unboundDefault=0, total=0;
for (const f of readdirSync(root+"data/kits").filter(f=>/^c[4-7]-.*\.json$/.test(f))){ const kf=JSON.parse(readFileSync(root+"data/kits/"+f,"utf8"));
 for (const kit of kf.topics) for (const item of kit.items??[]) { const p=planEngine({kit,item,lang:"english",topicMap}); if(!p) continue; total++;
  if (p.why.startsWith("no item adapter")) unboundDefault++;
  if (p.bindItem && p.engine==="multiply-divide@1" && n++<4) console.log(item.id, "|", item.prompt_en, "|", item.answer, "|", JSON.stringify({mode:p.params.mode,a:p.params.a,b:p.params.b,n:p.params.n,k:p.params.k}));
 }}
console.log({total, unboundDefault});
