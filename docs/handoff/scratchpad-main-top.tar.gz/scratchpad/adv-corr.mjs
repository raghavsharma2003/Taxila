import { corroborate, supports } from "/home/user/Taxila/server/grading/corroborate.js";
import { numberPhrases } from "/home/user/Taxila/server/grading/spoken-number.js";
const i04 = { prompt_en: "2/3 and 3/4 are both one piece short of a whole. Predict: are they equal?", prompt_hi: "2/3 aur 3/4 dono poore se ek tukda kam hain. Guess karo: kya barabar hain?" };
const t04 = { mode: "item", key: "No: 3/4 is bigger, because its missing piece (1/4) is smaller than the missing 1/3", also: ["no", "3/4 is bigger"], item: i04 };
const i06 = { prompt_en: "Ali says 4/9 > 3/4 because 4 > 3 and 9 > 4. Check.", prompt_hi: "Ali kehta hai 4/9 > 3/4 kyunki 4 > 3 aur 9 > 4. Check karo." };
const t06 = { mode: "item", key: "Wrong: 4/9 is less than 1/2 and 3/4 is more; with denominator 36, 16/36 < 27/36", also: ["wrong", "3/4 is bigger"], item: i06 };
const m = (o) => ({ outcome: o, source: "model", flags: {} });
for (const [t, txt] of [[t04, "1/3, 1/4, 3/4"], [t04, "3/4"], [t04, "2/3"], [t04, "3/4 is smaller"], [t04, "yes 3/4"], [t04,"haan"],[t04,"yes they are equal, 3/4"], [t06, "3/4"], [t06, "4/9"], [t06, "4/9 is bigger"], [t06, "right, 4/9 > 3/4"], [t06, "Ali is right 4/9"], [t06, "16/36 and 27/36"],[t06,"4 > 3 and 9 > 4"]])
  console.log(JSON.stringify(txt), corroborate({ target: t, text: txt, result: m("correct") }).outcome, corroborate({ target: t, text: txt, result: m("correct") }).corroboration);
console.log(numberPhrases("3/4"), numberPhrases("1/3, 1/4, 3/4"));
