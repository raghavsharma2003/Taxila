import fs from "fs";
const P="/home/user/Taxila/data/kits/c5-hindi.json";
const k=JSON.parse(fs.readFileSync(P,"utf8"));
const items={};const mcs={};
for(const t of k.topics){for(const i of t.items)items[i.id]=i;for(const m of t.misconceptions||[])mcs[m.id]=m;}
const set=(id,f)=>{const i=items[id]; if(!i) throw new Error(id); f(i);};
set("c5-hindi-ch05-t01-i04",i=>{
 i.prompt_hi="सुनो — ‘सुंदरिया बीमार पड़ी तो तीन दिन तक माँ और बाबा ने उसकी दवा और सेवा की। माँ रात में भी उठकर उसे पानी पिलातीं।’ यहाँ ‘सेवा’ का मतलब क्या है?";
 i.prompt_en="Listen: when Sundariya fell ill, for three days Maa and Baba gave her medicine and सेवा; Maa got up at night to give her water. What does सेवा mean here?";
 i.verified.note="Fixed: prompt now carries its own story context (तीन दिन दवा और सेवा) so the item stands alone. Re-solved blind: देखभाल; agrees.";
});
set("c5-hindi-ch05-t01-i10",i=>{
 i.prompt_hi="सुनो — ‘सुंदरिया का बुखार बढ़ता गया, तो बाबा गाँव से पशु-डॉक्टर को बुला लाए। डॉक्टर ने उसे दवा दी।’ अगर बाबा पशु-डॉक्टर को न बुलाते, तो क्या हो सकता था?";
 i.prompt_en="Listen: Sundariya's fever kept rising, so Baba fetched the vet from the village, who gave her medicine. If Baba had not called the vet, what might have happened?";
 i.verified.note="Fixed: prompt now introduces Baba and the vet itself. Re-solved blind: और बीमार होकर शायद ठीक न होती; agrees.";
});
set("c5-hindi-ch05-t01-i14",i=>{
 i.prompt_hi="सुनो — ‘बीमारी के दिनों में माँ, बाबा और मैं बारी-बारी से उसके पास बैठे। जिस दिन वह फिर उछलने लगी, उस दिन घर में त्योहार जैसा लगा।’ समझाओ — कहानी के अंत में लेखक को सुंदरिया ‘घर की सदस्य’ क्यों लगी?";
 i.prompt_en="Listen: during her illness Maa, Baba and I took turns sitting by her; the day she jumped about again, the house felt like a festival. Explain why, at the end, the narrator felt Sundariya was a family member.";
 i.verified.note="Fixed: prompt now carries the care-and-recovery context. Open item re-solved blind: पूरे घर ने परिवार जैसी सेवा की, गहरा लगाव; key is a valid model answer; agrees.";
});
set("c5-hindi-ch09-t01-i03",i=>{
 i.prompt_hi="सुनो — ‘अध्यापिका: शीशा तो नया लग जाएगा, रोहन, पर झूठ से भरोसा टूटता है, और वह इतनी आसानी से नहीं जुड़ता।’ ‘झूठ से भरोसा टूटता है’ — इसका क्या मतलब है?";
 i.prompt_en="Listen: the teacher says the glass can be replaced, but a lie breaks trust and that does not mend so easily. What does \"झूठ से भरोसा टूटता है\" mean?";
 i.verified.note="Fixed: the quote now sits in the item's own passage (with the glass contrast the key relies on). Re-solved blind; agrees.";
});
set("c5-hindi-ch09-t01-i09",i=>{
 i.prompt_hi="सुनो — ‘अध्यापिका: कल से तुम खेल के बाद मैदान ठीक रखने में हाथ बँटाओगे।’ यहाँ ‘हाथ बँटाना’ मुहावरे का क्या मतलब है?";
 i.prompt_en="Listen: the teacher says that from tomorrow Rohan will हाथ बँटाना in keeping the ground tidy after games. What does the idiom हाथ बँटाना mean?";
 i.verified.note="Fixed: prompt now gives the idiom in context, so hint 2 no longer depends on i12. Re-solved blind: मदद करना; agrees.";
});
set("c5-hindi-ch05-t01-i01",i=>{
 i.acceptable=i.acceptable.filter(a=>a!=="गाय");
 i.verified.note="Fixed: removed 'गाय' from acceptable[] (a बछिया is a calf, not a cow). Solved blind; agrees.";
});
set("c5-hindi-ch01-t01-i05",i=>{
 i.acceptable=i.acceptable.filter(a=>a!=="दर");
 i.verified.note="Fixed: removed ambiguous 'दर' (usually means 'rate') from acceptable[]. Solved blind; agrees.";
});
set("c5-hindi-ch06-t01-i07",i=>{
 i.hints[0]="What do we call the mother lion in the jungle?";
 i.verified.note="Fixed: removed 'sheran' from acceptable[] (not a standard form); hint 1 no longer cues मोर, which pre-empted i08. Solved blind; agrees.";
});
const mc=mcs["c5-hindi-ch01-t01-mc-i-ii"];
mc.diagnostic.prompt_hi="कविता में आया शब्द ‘किरन’ — यानी सूरज की रोशनी की लकीर — इनमें से सही कैसे लिखते हैं?";
mc.diagnostic.prompt_en="The poem's word for 'sunbeam' (किरन, standard written form किरण) — which spelling is correct?";
fs.writeFileSync(P,JSON.stringify(k,null,2)+"\n");
console.log("ok");
