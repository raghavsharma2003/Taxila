// TEST trace, read-only: the reply right after an episode opened, before vs after a fine.js change (codes + TEST words only).
const { q } = await import("/home/user/taxila-int/server/db.js");
const after = await import("/home/user/taxila-int/server/safety/fine.js");
const before = await import(process.argv[2]);
const opens = await q(`select sid, turn, data from trace_event where kind = 'safety.scan' and (data->>'safeguardMove')::boolean
  and t > now() - interval '10 days' order by t`);
let n = 0, changed = 0;
for (const o of opens) {
  const nx = await q(`select data from trace_event where sid = $1 and turn = $2 and kind = 'srv.req' and data->>'route' like '%/lesson/turn%' limit 1`, [o.sid, o.turn + 1]);
  const text = nx[0]?.data?.body?.childText;
  if (typeof text !== "string" || !text.trim()) continue;
  n++;
  const a = after.fineReading(text), b = before.fineReading(text);
  const ca = a.fine && after.asksToCarryOn(text), cb = b.fine && before.asksToCarryOn(text);
  if (ca !== cb) console.log(`CARRY ${cb} -> ${ca} | ${text.slice(0, 160)}`);
  if (a.fine !== b.fine || a.why !== b.why) { changed++; console.log(`${o.data.kind}: ${b.why} -> ${a.why} | ${text.slice(0, 160)}`); }
}
console.log({ n, changed });
process.exit(0);
