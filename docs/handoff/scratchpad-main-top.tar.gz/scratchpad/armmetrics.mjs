const { arm, SUB_PATH } = await import("/home/user/taxila-int/infra/azure.mjs");
const RG = `${SUB_PATH()}/resourceGroups/${process.env.AZURE_RESOURCE_GROUP}`;
const span = "2026-10-16T07:30:00Z/2026-10-16T10:30:00Z";
const show = (title, r) => {
  console.log(`== ${title}`);
  for (const m of r.value ?? []) for (const ts of m.timeseries ?? []) {
    const pts = (ts.data ?? []).filter((d) => d.average != null || d.maximum != null || d.total != null);
    const dims = (ts.metadatavalues ?? []).map((x) => `${x.name.value}=${x.value}`).join(",");
    console.log(` ${m.name.value}${dims ? ` [${dims}]` : ""}: ` + pts.map((d) => `${d.timeStamp.slice(11, 16)} ${Math.round(d.maximum ?? d.average ?? d.total)}`).join(" | "));
  }
};
const app = `${RG}/providers/Microsoft.App/containerApps/taxila-web`;
try {
  show("taxila-web (CPU nanocores max, memory bytes max, restarts)", await arm("GET", `${app}/providers/microsoft.insights/metrics?api-version=2023-10-01&metricnames=UsageNanoCores,WorkingSetBytes,RestartCount,Requests&timespan=${span}&interval=PT15M&aggregation=Maximum,Total`));
} catch (e) { console.log("app metrics failed:", e.message); }
const accts = (await arm("GET", `${RG}/providers/Microsoft.CognitiveServices/accounts?api-version=2024-10-01`)).value ?? [];
for (const a of accts) {
  console.log(`account ${a.name} (${a.location})`);
  try {
    const defs = (await arm("GET", `${a.id}/providers/microsoft.insights/metricDefinitions?api-version=2023-10-01`)).value ?? [];
    const want = defs.map((d) => d.name.value).filter((n) => /TimeToResponse|TTFT|Latency|AzureOpenAIRequests|ProcessedPromptTokens|GeneratedTokens|ClientErrors|ServerErrors|Ratelimit/i.test(n)).slice(0, 6);
    if (!want.length) continue;
    show(`${a.name}: ${want.join(",")}`, await arm("GET", `${a.id}/providers/microsoft.insights/metrics?api-version=2023-10-01&metricnames=${want.join(",")}&timespan=${span}&interval=PT15M&aggregation=Average,Maximum,Total&$filter=ModelDeploymentName eq '*'`));
  } catch (e) { console.log(" metrics failed:", e.message.slice(0, 160)); }
}
