// read-only (production): where did the last N minutes' director.turn / model.call events land (sid shape, cid/gid set?)
import { createRequire } from "node:module";
const require = createRequire(process.cwd() + "/package.json");
const m = await import(require.resolve("@neondatabase/serverless")); const neon = m.neon ?? m.default?.neon; const sql = neon(process.env.DATABASE_URL);
const min = Number(process.argv[2] || 10);
const r = await sql.query(`select kind, case when sid ~ '^[0-9a-f-]{36}$' then 'lesson-uuid' when sid like 'g:%' then 'guardian' when sid = 'server' then 'server' else 'other' end as sidk,
  (cid is not null) has_cid, (gid is not null) has_gid, count(*)::int n from trace_event
  where t > now() - ($1 || ' minutes')::interval and src = 'server' and kind in ('director.turn','model.call','safety.scan','classify.verdict','srv.req','srv.res','tts.first','tts.end')
  group by 1,2,3,4 order by 1,2`, [String(min)]);
for (const x of r) console.log(`${x.kind.padEnd(18)} ${x.sidk.padEnd(12)} cid:${x.has_cid} gid:${x.has_gid} n=${x.n}`);
const routes = await sql.query(`select data->>'route' route, count(*)::int n from trace_event where t > now() - ($1 || ' minutes')::interval and kind = 'srv.res' group by 1 order by 2 desc limit 12`, [String(min)]);
console.log(routes.map((x) => `${x.route}=${x.n}`).join("  "));
