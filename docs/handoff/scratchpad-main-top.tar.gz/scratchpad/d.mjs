import { readFileSync } from "node:fs";
import { paramsFromKit } from "/home/user/Taxila/server/studio/plan.js";
import { aboutTopic } from "/home/user/Taxila/server/studio/seam.js";
for (const c of [4,5,6,7]) { const f = JSON.parse(readFileSync(`/home/user/Taxila/data/kits/c${c}-maths.json`, "utf8"));
  for (const t of f.topics ?? []) { const k = t.kit ?? t; for (const id of ["shade_fraction","number_line_jump"]) { const p = paramsFromKit(id, k); if (!p || !aboutTopic(id, k)) continue;
    console.log(c, t.topicId ?? t.id, id, id==="shade_fraction" ? p.items.map(i=>`${i.n}/${i.d}`).join(" ")+" "+p.picture : `den ${p.den}`); } } }
