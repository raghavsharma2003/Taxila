import { matchTopic } from "/home/user/Taxila/server/lesson/purpose.js";
import { ASK_FIXTURE } from "/home/user/Taxila/tests/fixtures/ask-routing.mjs";
import { getTopic } from "/home/user/Taxila/server/content/curriculum.js";
let ok = 0, wrong = 0, nul = 0;
for (const [cl, q, want] of ASK_FIXTURE) {
  const r = matchTopic(q, cl);
  const id = r?.topicId ?? null;
  const good = want === null ? id === null : want.includes(id);
  if (good) ok++; else if (id === null) nul++; else wrong++;
  if (!good) console.log(`MISS c${cl} "${q}" → ${id} (${id ? getTopic(id).title : ""}) score=${r?.score} want ${want}`);
}
console.log(`ok ${ok}/${ASK_FIXTURE.length} wrong ${wrong} null-miss ${nul}`);
