// TEST trace, read-only, last 10 days: safeguards opened by the content filter, and how many of the child's words carry "teen".
const { q } = await import("/home/user/taxila-int/server/db.js");
const RE = /(?<![\p{L}\p{M}])teen(?![\p{L}\p{M}])/iu;
const opens = await q(`select sid, turn from trace_event where kind = 'safety.scan' and data->>'kind' = 'content_filter' and (data->'sources') ? 'content_filter'
  and t > now() - interval '10 days'`);
let teen = 0; const ex = [];
for (const o of opens) {
  const r = await q(`select data->'body'->>'childText' as t from trace_event where sid = $1 and turn = $2 and kind = 'srv.req' limit 1`, [o.sid, o.turn]);
  const t = r[0]?.t ?? "";
  if (RE.test(t)) { teen++; ex.push(t.slice(0, 110)); } else if (process.argv[2] === "rest") ex.push("REST " + t.slice(0, 120));
}
console.log({ contentFilterOpens: opens.length, withTeen: teen }); for (const e of ex) console.log("  ", e);
process.exit(0);
