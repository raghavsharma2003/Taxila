// A/B on the words-only read: 14.4 V2 brief (distress only) vs V2 + the about note (b145), same lines, same deployment.
// Lines: sim-lab safeguard-turn lines the predicate misses (704) + the curated SURE/CHECK set. Distress rate per arm and
// lines where the arms disagree. Model-only.  node testenvrun.mjs node aboutab.mjs
import { readFileSync, writeFileSync } from "node:fs";
const B = "/tmp/claude-0/-home-user/ecee9fc1-62f9-5f67-a47d-69ca79d9981a/scratchpad/b145";
const { chat } = await import(`${B}/server/azure.js`);
const { filterSafe, scrubPii, scanSafety } = await import(`${B}/server/director/safety.js`);
const src = readFileSync(`${B}/server/director/classify.js`, "utf8");
const ABOUT_NOTE = eval(src.match(/const ABOUT_NOTE = ("[^\n]*");/)[1]);
const ABOUT = ["self_harm", "hurt_by_person", "afraid_of_person_or_home", "unsafe_now", "sad_or_lonely", "other_fright", "none"];
const all = JSON.parse(readFileSync("/tmp/claude-0/-home-user/ecee9fc1-62f9-5f67-a47d-69ca79d9981a/scratchpad/simlab-child-lines2.json", "utf8"));
const lines = all.filter((x) => x.safeTurn && !scanSafety(x.text).distress);
const classOf = (p) => Number(/-c(\d)-/.exec(p)?.[1] ?? 6);
const base = (cl) => `A reply from an Indian school child (class ${cl}) in a lesson, in Hindi, English or Hinglish; the transcript may be misheard. distress: true ONLY for signs the child is unsafe, hurt, abused, frightened of a person, a place or what is happening to them, very sad, or may harm themself — never for ordinary frustration or worry about the lesson itself (scared of numbers, a question, a test or getting it wrong: the teacher reassures). The teacher's last words come first only so you can tell an answer to the lesson's own question from a disclosure.`;
const S1 = { type: "object", additionalProperties: false, required: ["distress"], properties: { distress: { type: "boolean" } } };
const S2 = { type: "object", additionalProperties: false, required: ["distress", "about"], properties: { distress: { type: "boolean" }, about: { type: "string", enum: ABOUT } } };
const c = (t) => filterSafe(scrubPii(t).text);
async function read(x, about) {
  const msgs = [{ role: "system", content: base(classOf(x.persona)) + (about ? ABOUT_NOTE : "") }, { role: "user", content: `TEACHER: ${c(x.heard ?? "").slice(-240)}\nCHILD: ${c(x.text)}` }];
  try { const r = await chat("grok-4-1-fast-non-reasoning", msgs, { schema: about ? S2 : S1, schemaName: "distress_beside", effort: "none", maxTokens: about ? 60 : 40, timeoutMs: 8000, retries: 1 }); return r.json?.distress ? 1 : 0; }
  catch { return null; }
}
const out = new Array(lines.length); let i = 0;
await Promise.all(Array.from({ length: 8 }, async () => { while (i < lines.length) { const j = i++; out[j] = [await read(lines[j], false), await read(lines[j], true)]; } }));
const ok = out.filter(([a, b]) => a != null && b != null);
const v2 = ok.filter(([a]) => a).length, ab = ok.filter(([, b]) => b).length;
const lost = lines.filter((_, k) => out[k][0] === 1 && out[k][1] === 0).map((x) => ({ persona: x.persona, text: x.text.slice(0, 160) }));
const gained = lines.filter((_, k) => out[k][0] === 0 && out[k][1] === 1).map((x) => ({ persona: x.persona, text: x.text.slice(0, 160) }));
writeFileSync("/tmp/claude-0/-home-user/ecee9fc1-62f9-5f67-a47d-69ca79d9981a/scratchpad/aboutab-result.json", JSON.stringify({ n: lines.length, read: ok.length, v2, about: ab, lost, gained }, null, 1));
console.log(JSON.stringify({ n: lines.length, read: ok.length, v2, about: ab, lost: lost.length, gained: gained.length }));
process.exit(0);
