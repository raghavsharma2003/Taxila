import { toSpoken } from "/home/user/Taxila/server/voice/spoken.js";
const C = [["english","english"],["hinglish","english"],["hinglish","hindi"],["hindi","hindi"],["hindi","english"]];
const T = ["The village has 45,000 people and the town 62,314.", "₹25.50 ka pen", "Call Childline 1098 or Tele-MANAS 14416.",
 "Shabash! Bilkul sahi.", "In He As AI IIT stay words.", "COVID-19 aur Class 6-8, 2-3 minutes", "Solve x-3=5", "Tele-MANAS",
 "3 < 5 aur 7 > 2", "10,000,000 vs 100,000 vs 1,00,000", "+91 98765 43210 pe call karo", "call 112 now", "In 1947 India became free; in 2026 we learn.",
 "the 21st and 3rd and 100th", "5वीं कक्षा", "Rs. 5 ka", "₹2 lakh", "₹0.50", "₹1", "1 cm aur 1 kg", "10⁻² m", "√x", "x/4 = 3", "2½ roti", "¾ glass",
 "−3°C", "0.05 mg", "7:30 baje", "ratio 12:30", "A4 sheet, vitamin B12, H2SO4, C6H12O6, NaCl", "Step 1: add 2 and 3.", "12/05/2026", "1,234,56 list", "007", "4 + (−2) = 2", "a + b = c", "3 x 4 = 12", "The 1990s", "1800-11-4000", "2 h baad, 5 s mein", "9876543210", "₹45/-", "5 ≤ 7, 8 ≥ 2, 3 ≠ 4"];
for (const s of T) { console.log("IN  " + s); for (const [m, med] of C) console.log(`  ${m.slice(0,2)}.${med.slice(0,2)} ${toSpoken(s, { mode: m, schoolMedium: med, ageBand: "10-15" })}`); }
