import bpy,sys,numpy as np
sys.path.insert(0,'/home/user/Taxila/scripts/character/stylised/armB')
import lib as L
bpy.ops.wm.open_mainfile(filepath='/tmp/claude-0/char/stylised-armB/stage.blend')
f=bpy.data.objects['face']; b=bpy.data.objects['brows']
P=L.co(f.data); bvh=L.bvh_from_np(P,L.faces_np(f.data))
Pb=L.co(b.data)
Q,N,fi,d=L.nearest(bvh,Pb[:154])
s=np.sign(((Pb[:154]-Q)*(Pb[:154]-np.array([0,0.0,0.22]))).sum(1)); print("normal agrees with outward:", np.mean(np.sign((N*(Q-np.array([0,0,0.22]))).sum(1))))
print('brow signed dist mm', np.round((d*s*1000).reshape(7,22)[:, ::4],2))
R=Pb[:154].reshape(7,22,3); print("z span mm", np.round((R[0,:,2]-R[6,:,2])[::4]*1000,2)); print("x", np.round(R[3,::4,0]*1000,1)); import os; os._exit(0)
