// both-arms string diff: every string >= 6 chars in kits/curriculum JSON and in eval/test JSON + string literals,
// scanSafety on tree A (patched) vs tree B (base). Prints counts and every changed string.
import { readdirSync, readFileSync, statSync } from "node:fs";
import { join } from "node:path";
const [A, B] = process.argv.slice(2);
const a = await import(join(A, "server/director/safety.js")), b = await import(join(B, "server/director/safety.js"));
const out = new Set();
const walkJson = (v) => { if (typeof v === "string") { if (v.length >= 6) out.add(v); } else if (Array.isArray(v)) v.forEach(walkJson); else if (v && typeof v === "object") Object.values(v).forEach(walkJson); };
const walk = (d, lit) => { for (const f of readdirSync(d)) { const p = join(d, f); let s; try { s = statSync(p); } catch { continue; } if (s.isDirectory()) { if (f === "node_modules" || f === "results" && d.includes("owner-truth")) continue; walk(p, lit); } else if (f.endsWith(".json") && s.size < 30e6) { try { walkJson(JSON.parse(readFileSync(p, "utf8"))); } catch {} } else if (lit && /\.(mjs|js)$/.test(f)) { for (const m of readFileSync(p, "utf8").matchAll(/"((?:[^"\\\n]|\\.){6,})"|'((?:[^'\\\n]|\\.){6,})'|`([^`$\n]{6,})`/g)) out.add(m[1] || m[2] || m[3]); } } };
walk(join(B, "data/kits"), false); walk(join(B, "data/curriculum"), false); walk(join(B, "evals"), true); walk(join(B, "tests"), true);
let NEW = [], LOST = [], both = 0;
for (const t of out) { const x = a.scanSafety(t).distress, y = b.scanSafety(t).distress; if (x && !y) NEW.push(t); else if (!x && y) LOST.push(t); else if (x && y) both++; }
console.log(JSON.stringify({ strings: out.size, NEW: NEW.length, LOST: LOST.length, bothFire: both }));
for (const t of NEW) console.log("NEW\t" + t.slice(0, 200));
for (const t of LOST) console.log("LOST\t" + t.slice(0, 200));
