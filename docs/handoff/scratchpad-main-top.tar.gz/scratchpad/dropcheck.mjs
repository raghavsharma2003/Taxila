// read-only: trace.dropped rows and server event volume since a time (argv[2], ISO)
import { createRequire } from "node:module";
const require = createRequire(process.cwd() + "/package.json");
const m = await import(require.resolve("@neondatabase/serverless")); const neon = m.neon ?? m.default?.neon; const sql = neon(process.env.DATABASE_URL);
const since = process.argv[2];
const d = await sql.query("select count(*)::int n, coalesce(sum((data->>'dropped')::int),0)::int dropped from trace_event where kind = 'trace.dropped' and t >= $1::timestamptz", [since]);
const s = await sql.query("select src, count(*)::int n from trace_event where t >= $1::timestamptz group by src order by n desc", [since]);
console.log(`since ${since}: trace.dropped rows ${d[0].n} (events dropped ${d[0].dropped}); events by src ${s.map((r) => `${r.src}=${r.n}`).join(" ")}`);
