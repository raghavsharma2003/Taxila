import { readdirSync, readFileSync } from "fs";
import { checkFits } from "/home/user/Taxila/server/compiler/compile.js";
import { diagnosticItem } from "/home/user/Taxila/server/director/items.js";
const DIR = "/home/user/Taxila/data/kits/";
const need = [];
const minCap = (it) => { let lo = 50, hi = 800; while (lo < hi) { const m = (lo + hi) >> 1; if (checkFits(it, { cap: m })) hi = m; else lo = m + 1; } return lo; };
for (const f of readdirSync(DIR).filter((f) => f.endsWith(".json"))) {
  const d = JSON.parse(readFileSync(DIR + f, "utf8"));
  for (const t of d.topics || []) {
    for (const it of t.items || []) if (it.prompt_en || it.prompt_hi) need.push([minCap({ ...it, prompt_en: it.prompt_en || it.prompt_hi, prompt_hi: it.prompt_hi || it.prompt_en, acceptable: it.acceptable || [] }), it.id]);
    for (const m of t.misconceptions || []) { if (!m.diagnostic?.options?.some((o) => o.correct)) continue; const di = diagnosticItem({ items: t.items }, { ...m, remediation: m.remediation || { representation: "x" } }); if (di) need.push([minCap(di), "diag:" + m.id]); }
  }
}
need.sort((a, b) => a[0] - b[0]);
const q = (p) => need[Math.floor(need.length * p)][0];
console.log({ n: need.length, p50: q(0.5), p90: q(0.9), p99: q(0.99), max: need.at(-1), top: need.slice(-8) });
