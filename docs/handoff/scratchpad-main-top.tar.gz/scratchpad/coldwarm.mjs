import fs from "fs";
for (const line of fs.readFileSync("/home/user/Taxila/.env.local", "utf8").split("\n")) { const m = line.match(/^([A-Z0-9_]+)=(.*)$/); if (m && !process.env[m[1]]) process.env[m[1]] = m[2].replace(/^"(.*)"$/, "$1"); }
const E = process.env.AZURE_OPENAI_ENDPOINT.replace(/\/+$/, ""), KEY = process.env.AZURE_OPENAI_API_KEY;
const model = process.argv[2] || "taxila-ds41";
const one = async () => { const t0 = performance.now(); const r = await fetch(E + "/chat/completions", { method: "POST", headers: { "api-key": KEY, "content-type": "application/json" }, body: JSON.stringify({ model, messages: [{ role: "user", content: "Say ok." }], max_tokens: 5 }) }); await r.text(); return Math.round(performance.now() - t0); };
const par = async (n) => (await Promise.all(Array.from({ length: n }, one))).join(",");
const ping = async () => { const t0 = performance.now(); const r = await fetch(E + "/models", { headers: { "api-key": KEY } }); await r.text(); return `${r.status} ${Math.round(performance.now() - t0)}`; };
console.log("cold 1:", await one(), "warm 1:", await one(), await one());
await new Promise((r) => setTimeout(r, 6000));
console.log("after 6s idle, 4 parallel:", await par(4));
console.log("then 4 parallel warm:", await par(4));
await new Promise((r) => setTimeout(r, 6000));
console.log("ping /models after idle:", await ping(), "ping warm:", await ping());
