import { chromium } from "/home/user/Taxila/node_modules/playwright/index.mjs";
const S = "/tmp/claude-0/-home-user/ecee9fc1-62f9-5f67-a47d-69ca79d9981a/scratchpad/shots";
const b = await chromium.launch({ executablePath: "/opt/pw-browsers/chromium-1194/chrome-linux/chrome" });
const email = `uia-consent+${Date.now()}@taxila.test`;
for (const [w, h] of [[360, 640], [1280, 800]]) {
  const ctx = await b.newContext({ viewport: { width: w, height: h } }); const p = await ctx.newPage();
  if (w === 360) await p.request.post("http://localhost:5173/api/auth/signup", { data: { email, password: "uia-consent-1", name: "U", isGuardianAdult: true } });
  else await p.request.post("http://localhost:5173/api/auth/login", { data: { email, password: "uia-consent-1" } });
  await p.goto("http://localhost:5173/start/consent"); await p.waitForTimeout(1000);
  const g = p.getByRole("radiogroup", { name: "Remember what your child likes" }).or(p.locator('[aria-label="Remember what your child likes"]'));
  const html = await g.first().evaluate((el) => el.outerHTML.slice(0, 400));
  const sel = await g.first().locator('[aria-checked="true"],[aria-pressed="true"]').count();
  const btn = await p.getByRole("button", { name: "Save and continue" }).isDisabled();
  console.log(w, "likes selected:", sel, "save disabled:", btn, html.slice(0, 160));
  await p.screenshot({ path: `${S}/fix-consent-${w}.png`, fullPage: true });
  await ctx.close();
}
await b.close();
console.log("EMAIL", email);
