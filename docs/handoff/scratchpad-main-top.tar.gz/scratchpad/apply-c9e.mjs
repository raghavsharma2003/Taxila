import fs from "node:fs";
const P="/home/user/Taxila/data/kits/c9-english.json";
const S="/tmp/claude-0/-home-user/ecee9fc1-62f9-5f67-a47d-69ca79d9981a/scratchpad/";
const kit=JSON.parse(fs.readFileSync(P,"utf8"));
const blind=JSON.parse(fs.readFileSync(S+"blind.json","utf8"));
const LEAK="prompt_hi adds scaffolding absent from prompt_en that gives away the rule/answer early (hint-2+ level); trim prompt_hi to a faithful rendering of prompt_en.";
const notes={
"ch01-t01-i03":"Key agrees. targetsMisconception theme-is-summary does not fit a feelings-inference item; consider removing.",
"ch01-t01-i09":"Key agrees. "+LEAK,
"ch02-t01-i03":"Key agrees. prompt_hi ('Desert koi insaan hai kya? Phir bhi woh keep kar raha hai') points straight at personification; "+LEAK,
"ch02-t01-i04":"Key agrees. prompt_hi drops the two asks in prompt_en (label simile vs personification; which feels stronger) and adds the 'like' clue; not faithful.",
"ch03-t01-i05":"Key agrees (both). But prompt_en 'Which story has a conflict?' invites a single choice, so a child answering B (the intended insight) may be marked wrong; reword to 'Does each story have a conflict? What kind?'. prompt_hi asks a different question ('Dono mein conflict hai kya? Ek mein ladai hai, ek mein nahi') and is not faithful.",
"ch03-t01-i07":"Key agrees. prompt_hi \"'can' ka past\" gives the answer (= hint 2); "+LEAK,
"ch03-t01-i12":"Key agrees. prompt_hi ('Ek pronoun galat hai. Kavya ladka hai ya ladki?') locates and resolves the error; "+LEAK,
"ch04-t01-i05":"Key agrees. prompt_hi \"'Her' ki jagah 'whose' aayega\" is hint 2 verbatim; "+LEAK,
"ch04-t01-i11":"Key agrees. Acceptable example 'never late in time' is awkward English; replace with a cleaner model line.",
"ch07-t01-i07":"Key agrees. prompt_hi flags exactly which words change (I, am); mild leak.",
"ch07-t01-i08":"Key agrees. prompt_hi states the structure 'told ... to'; "+LEAK,
"ch07-t01-i09":"Key agrees. Also accept 'Dadaji said that he lives on Gandhi Street.' (no backshift is correct for a still-true fact). prompt_hi names both errors ('I' aur 'live'); "+LEAK,
"ch07-t01-i10":"Key agrees. prompt_hi ('Pehle mein yaad aana, doosre mein yaad dilana') maps each blank to its meaning; "+LEAK,
"ch07-t01-i11":"Key agrees. prompt_hi (\"Gaana kisi ko 'yaad dilata' hai\") gives the meaning of the answer; "+LEAK,
"ch08-t01-i06":"Key agrees. Poem speaker's gender is unspecified; 'he' in prompt is an assumption (minor).",
"ch08-t01-i13":"Key agrees, but 'uski' is gender-neutral: acceptable should include 'I miss him a lot.' / 'I miss them a lot.'",
"ch09-t01-i10":"Key agrees. prompt_hi \"'despite' ke baad noun aata hai\" is hint 2; "+LEAK,
"ch10-t01-i01":"Key agrees. Hint 2 'It is in the title too' refers to a title ('Nine Gold Medals') the child is never shown in this item.",
"ch10-t01-i03":"Key agrees in substance, but key/acceptable are too narrow: 'until the smallest stumbled' is a defensible turning point (the 'until' marks the shift). Add 'when the smallest runner stumbled' to acceptable.",
"ch10-t01-i04":"Key agrees (open prediction). Sequencing risk: i01/i03/i05 in this topic print the whole poem, so this 'before reading stanza two' item only works if posed first; Director must order it before any full-poem item.",
"ch10-t01-i11":"Key agrees. prompt_hi (\"Match 'win' karte hain, team ko 'beat'\") gives the answer; "+LEAK,
"ch11-t01-i07":"Key agrees. Key mentions the title 'Twin Melodies', which the child never sees in the item; drop it from the key idea or show the title.",
"ch11-t01-i10":"Key agrees. prompt_hi states the flip rule (= hint 2); "+LEAK,
"ch13-t01-i01":"Key agrees. 'summer' is inferred, not stated (passage says every morning, mule; winter, walks); fine but could say 'usually'.",
"ch14-t01-i04":"Key agrees partly. The line also compares a word to something with weight ('weigh each word'); acceptable should include 'something heavy that you weigh / measure' alongside bird/arrow.",
"ch15-t01-i08":"Key agrees. prompt_hi (\"'If' ke saath present simple, doosre hisse mein will\") gives the full rule; "+LEAK,
};
let n=0,agree=0,dis=0;
for(const t of kit.topics) for(const it of t.items){
  const id=it.id.replace("c9-english-","");
  const s=blind[id]; if(!s) throw new Error("missing blind "+id);
  const agrees=true;
  it.verified={solverAnswer:s,agrees,note:notes[id]||"Blind answer matches key; English correct, class-9 appropriate, original text, prompt_hi faithful, hints graded."};
  n++; agrees?agree++:dis++;
}
fs.writeFileSync(P,JSON.stringify(kit,null,2)+"\n");
console.log({n,agree,dis,noted:Object.keys(notes).length});
