import fs from "node:fs";
const dir="/tmp/claude-0/-home-user/ecee9fc1-62f9-5f67-a47d-69ca79d9981a/scratchpad/ami/frames";
for (const f of fs.readdirSync(dir)) { const M=JSON.parse(fs.readFileSync(dir+"/"+f)); const A=Object.keys(M.chans);
  const on={}; for (const a of A){ const o=new Uint8Array(M.chans[a].db.length); for (const [s,e] of M.chans[a].words) for(let k=Math.floor(s/20);k<Math.ceil(e/20)&&k<o.length;k++) o[k]=1; on[a]=o; }
  const out=[];
  for (const X of A) for (const Y of A) { if (X===Y) continue; const d=[]; for (let k=0;k<on[X].length;k++){ if(!on[Y][k]) continue; if (A.some(z=>z!==Y&&on[z][k])) continue; d.push(M.chans[X].db[k]-M.chans[Y].db[k]); } d.sort((a,b)=>a-b); out.push(`${X}<${Y}:${d[d.length>>1]?.toFixed(0)}`); }
  console.log(M.meeting, out.join(" "));
}
