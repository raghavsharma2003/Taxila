import { runArm } from "/home/user/Taxila/evals/duplex/tick-sim.mjs";
const arm = process.argv[2] || "cce-fast";
const recs = runArm(arm, { seeds: 3 });
for (const r of recs) {
  const bad = [];
  if (r.expect === "commit" || r.expect === "hold") {
    for (const c of r.speaks) if (c.t < r.trueEnd - 20) bad.push(`EARLY ${c.op}:${c.reason}@${c.t} fa=${c.firstAudio} rev=${c.revokedAt} v=${c.verdictAt} "${c.text}"`);
    for (const c of r.speaks) if (c.verdictAt !== null && c.verdictAt < r.trueEnd) bad.push(`VERDICT-EARLY v=${c.verdictAt} "${c.text}"`);
  }
  if (r.expect === "safety") for (const c of r.speaks) if (c.reason !== "safeguard" && c.reason !== "safety" && (c.revokedAt === null || c.revokedAt > c.firstAudio)) bad.push(`UNSAFE ${c.reason}@${c.t} fa=${c.firstAudio} "${c.text}"`);
  if (bad.length) console.log(r.id, "s" + r.seed, r.cat, "trueEnd", r.trueEnd, "segs", JSON.stringify(r.segs), "\n   " + bad.join("\n   "));
}
