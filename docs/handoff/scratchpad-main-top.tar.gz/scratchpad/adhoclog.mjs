import { arm, loadEnv, laQuery, sleep } from "/home/user/Taxila/infra/azure.mjs";
loadEnv();
const API = "api-version=2024-03-01", JOB = process.argv[2] || "taxila-probe-adhoc";
const ex = (await arm("GET", `/providers/Microsoft.App/jobs/${JOB}/executions?${API}`)).value
  .sort((a, b) => (b.properties.startTime || "").localeCompare(a.properties.startTime || ""));
const e = ex[0];
console.log("latest", e.name, e.properties.status, e.properties.startTime, e.properties.endTime || "");
if (process.argv[3] !== "nolog") {
  const kql = `ContainerAppConsoleLogs_CL | where ContainerJobName_s == "${JOB}" and ContainerGroupName_s startswith "${e.name}" | order by TimeGenerated asc | project TimeGenerated, Log_s`;
  const r = await laQuery("6e002127-81d9-4e86-8a6d-c61115eeb490", kql, "PT3H");
  console.log("rows", r.length);
  for (const row of r) console.log(row.Log_s);
}
