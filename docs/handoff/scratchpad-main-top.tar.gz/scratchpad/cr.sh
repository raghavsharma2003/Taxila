#!/bin/bash
q="$1"; n="${2:-1}"
curl -sS --max-time 40 -G "https://api.crossref.org/works" --data-urlencode "query.bibliographic=$q" --data-urlencode "rows=$n" --data-urlencode "select=title,author,issued,DOI,container-title,abstract,volume,page" | python3 -c '
import sys,json,re
try: d=json.load(sys.stdin)
except Exception: print("ERR"); sys.exit()
for r in d["message"]["items"]:
  au=", ".join((a.get("family") or "") for a in r.get("author",[])[:5])
  print("##",au,"|",r.get("issued",{}).get("date-parts",[[None]])[0][0],"|",(r.get("container-title") or [""])[0],r.get("volume"),r.get("page"),"| doi:",r.get("DOI"))
  print("T:",(r.get("title") or [""])[0])
  a=re.sub("<[^>]+>"," ",r.get("abstract") or "")
  if a: print("A:",a[:1200])
  print()
'
