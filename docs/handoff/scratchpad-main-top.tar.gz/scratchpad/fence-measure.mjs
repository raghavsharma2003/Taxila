process.env.DATABASE_URL = process.env.TEST_DATABASE_URL;
const { q } = await import("/home/user/taxila-1441/server/db.js");
const L = await import("/home/user/taxila-1441/server/routes/lesson.js");
const rows = (r) => r.rows ?? r;
await q("begin read only");
const ls = rows(await q(`select l.id::text id, l.parent_note pn, l.summary sm, (select count(*)::int from incident i where i.lesson_id = l.id) inc from lesson l where l.parent_note is not null and l.ended_at > now() - interval '60 days'`));
await q("rollback");
const sents = (s) => String(s ?? "").split(/(?<=[.!?।])\s+/).length;
const t = { clean: { n: 0, notesTouched: 0, sumsTouched: 0, sentDropped: 0 }, incident: { n: 0, notesTouched: 0, sumsTouched: 0, sentDropped: 0, noteEmptied: 0 } };
const fp = [];
for (const l of ls) {
  const b = l.inc > 0 ? t.incident : t.clean; b.n++;
  const pn = L.recordFence(l.pn), sm = L.recordFence(l.sm, { lines: true });
  if (pn !== l.pn.trim()) { b.notesTouched++; b.sentDropped += sents(l.pn) - (pn ? sents(pn) : 0); if (!l.inc) fp.push(l.pn); }
  if (sm !== String(l.sm ?? "").trim()) { b.sumsTouched++; if (!l.inc) fp.push("SUM " + l.sm); }
  if (l.inc > 0 && !pn) b.noteEmptied++;
}
console.log(JSON.stringify(t));
for (const x of fp.slice(0, 8)) console.log("FP?", x.slice(0, 300).replace(/\n/g, " / "));
const o = JSON.parse((await import("fs")).readFileSync(process.argv[2], "utf8"));
const rep = o.filter((x) => !x.err).map((x) => ({ arm: x.arm, touched: L.recordFence(x.note) !== x.note.trim(), sumT: L.recordFence(x.summary, { lines: true }) !== x.summary.trim(), note: x.note }));
for (const arm of ["old", "new"]) console.log(arm, "replay notes touched", rep.filter((r) => r.arm === arm && r.touched).length, "summaries touched", rep.filter((r) => r.arm === arm && r.sumT).length, "of", rep.filter((r) => r.arm === arm).length);
process.exit(0);
