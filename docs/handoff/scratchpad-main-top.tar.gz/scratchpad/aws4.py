exec(open('awsenv.py').read())
import json
ce=boto3.client('ce',region_name='us-east-1')
for gb in ['RECORD_TYPE','SERVICE']:
  try:
    x=ce.get_cost_and_usage(TimePeriod={'Start':'2026-08-01','End':'2026-10-05'},Granularity='MONTHLY',Metrics=['UnblendedCost'],GroupBy=[{'Type':'DIMENSION','Key':gb}])
    for t in x['ResultsByTime']:
      print(gb, t['TimePeriod']['Start'], [(g['Keys'][0],round(float(g['Metrics']['UnblendedCost']['Amount']),2)) for g in t['Groups'] if abs(float(g['Metrics']['UnblendedCost']['Amount']))>0.001])
  except Exception as e: print('ERR',gb,str(e)[:200])
try:
  x=ce.get_cost_and_usage(TimePeriod={'Start':'2026-08-01','End':'2026-10-05'},Granularity='MONTHLY',Metrics=['UnblendedCost'],GroupBy=[{'Type':'DIMENSION','Key':'BILLING_ENTITY'}])
  for t in x['ResultsByTime']: print('ENTITY',t['TimePeriod']['Start'],[(g['Keys'][0],g['Metrics']['UnblendedCost']['Amount']) for g in t['Groups']])
except Exception as e: print('ERR',str(e)[:200])
