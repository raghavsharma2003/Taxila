import { plainSsml } from "/home/user/Taxila/server/voice/expressive/compile/dhd.js";
import { LINES } from "/home/user/Taxila/evals/face-puppet/lines.mjs";
const mod = await import(process.argv[2]);
const env = { ...process.env, AZURE_SPEECH_REGION: process.env.AZURE_SPEECH_REGION_SIN, AZURE_SPEECH_KEY: process.env.AZURE_SPEECH_KEY_SIN };
const V = { voice: "en-IN-Diya:DragonHDLatestNeural", baseRate: -35 };
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
await mod.prewarmDhdWs(env);
const res = [];
for (let k = 0; k < 5; k++) {
  const ac = new AbortController();
  const r = await mod.dhdStreamWs(plainSsml(LINES[8 + k], V), { env, signal: ac.signal });
  let got = 0; try { for await (const c of r.chunks) { got += c.length; if (got > 20000) ac.abort(); } } catch {}
  await sleep(2500);
  const r2 = await mod.dhdStreamWs(plainSsml(LINES[14 + k], V), { env });
  for await (const c of r2.chunks) {}
  res.push(r2.ttfbMs);
}
console.log(JSON.stringify(res));
process.exit(0);
