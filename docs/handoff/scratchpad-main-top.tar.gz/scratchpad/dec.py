import sys,re,html,subprocess,json
from googlenewsdecoder import gnewsdecoder
q=sys.argv[1]; n=int(sys.argv[2]) if len(sys.argv)>2 else 6
import urllib.request
s=urllib.request.urlopen(f"https://news.google.com/rss/search?q={q}&hl=en-IN&gl=IN&ceid=IN:en").read().decode()
for it in re.findall(r'<item>(.*?)</item>',s,re.S)[:n]:
  t=html.unescape(re.search(r'<title>(.*?)</title>',it).group(1)); d=re.search(r'<pubDate>(.*?)</pubDate>',it).group(1)[5:16]; l=re.search(r'<link>(.*?)</link>',it).group(1)
  try: u=gnewsdecoder(l,interval=1).get('decoded_url')
  except Exception as e: u='?'
  print(d,'|',t[:110],'|',u)
