import fs from "fs";
for (const line of fs.readFileSync("/home/user/Taxila/.env.local", "utf8").split("\n")) { const m = line.match(/^([A-Z0-9_]+)=(.*)$/); if (m && !process.env[m[1]]) process.env[m[1]] = m[2].replace(/^"(.*)"$/, "$1"); }
if (process.argv[2] === "ka") { const { EnvHttpProxyAgent, setGlobalDispatcher } = await import("undici").catch(() => ({})); if (EnvHttpProxyAgent) setGlobalDispatcher(new EnvHttpProxyAgent({ keepAliveTimeout: 60_000, keepAliveMaxTimeout: 600_000 })); else console.log("no undici pkg"); }
const { q } = await import("/home/user/Taxila/server/db.js");
const t = async (l) => { const t0 = performance.now(); await q("select 1"); console.log(l, Math.round(performance.now() - t0)); };
await t("first"); await t("warm"); await t("warm");
for (const gap of [2000, 5000, 8000]) { await new Promise((r) => setTimeout(r, gap)); await t(`after ${gap}`); }
