const { q } = await import("/home/user/taxila-int/server/db.js");
const rows = (r) => r.rows ?? r;
await q("begin read only");
// error kinds, codes only (first 50 chars of the error, digits masked)
console.table(rows(await q(`
  with m as (select e.data, e.t from trace_event e where e.kind = 'model.call' and e.t > now() - interval '7 days'
             and exists (select 1 from lesson l where l.id::text = e.sid))
  select data->>'deployment' dep, coalesce(data->>'lane','?') lane, left(regexp_replace(coalesce(data->>'error',''), '[0-9a-f]{8,}', '#', 'g'), 60) err,
         coalesce(data->>'status','?') status, count(*) n, min(t)::date first, max(t)::date last
  from m where data ? 'error' group by 1,2,3,4 order by n desc limit 15`)));
// the beside read's added time per turn: same sid + turn, label call vs beside call
console.table(rows(await q(`
  with m as (select e.sid, e.turn, e.data from trace_event e where e.kind = 'model.call' and e.t > now() - interval '7 days'
             and exists (select 1 from lesson l where l.id::text = e.sid) and e.data ? 'ms' and e.data->>'deployment' = 'grok-4-1-fast-non-reasoning'),
  lab as (select sid, turn, max((data->>'ms')::float) ms from m where data->>'promptId' like 'You label one reply%' group by 1,2),
  bes as (select sid, turn, max((data->>'ms')::float) ms from m where data->>'promptId' like 'A reply from an Indian school child%' group by 1,2)
  select count(*) pairs, round(percentile_cont(0.5) within group (order by greatest(0, b.ms - l.ms))) add_p50,
    round(percentile_cont(0.9) within group (order by greatest(0, b.ms - l.ms))) add_p90, round(max(greatest(0, b.ms - l.ms))) add_max,
    count(*) filter (where b.ms > l.ms) slowed
  from lab l join bes b using (sid, turn)`)));
// per day: reply-call timeouts (6001 ms) on taxila-fast CHAT lane
console.table(rows(await q(`
  select e.t::date d, count(*) n, count(*) filter (where (e.data->>'ms')::float >= 5990) at_timeout, count(*) filter (where e.data ? 'error') errs
  from trace_event e where e.kind = 'model.call' and e.t > now() - interval '7 days' and e.data->>'deployment' = 'taxila-fast' and e.data->>'lane' = 'CHAT'
    and exists (select 1 from lesson l where l.id::text = e.sid) group by 1 order by 1`)));
await q("rollback"); process.exit(0);
