const { q } = await import("/home/user/taxila-int/server/db.js");
const rows = await q(`select l.id, l.state->'ctx'->>'address' as addr, l.state->'ctx'->>'lang' as lang, l.state->>'mode' as mode, c.class_level, c.language_pref,
  (select address from child_controls cc where cc.child_id = c.id) as parent_addr
  from lesson l join child c on c.id = l.child_id where l.id::text like '71e0675e%' or l.id::text like '54c32862%'`);
console.log(JSON.stringify(rows, null, 1));
for (const r of rows) {
  const t = await q(`select seq, speaker, left(text, 120) as text from turn where lesson_id = $1 order by seq limit 8`, [r.id]);
  for (const x of t) console.log(r.id.slice(0, 8), x.seq, x.speaker, x.text);
}
process.exit(0);
