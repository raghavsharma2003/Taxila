import { readFileSync } from "fs";
for (const line of readFileSync("/home/user/Taxila/.env.local", "utf8").split("\n")) { const m = line.match(/^([A-Z0-9_]+)=(.*)$/); if (m && !process.env[m[1]]) process.env[m[1]] = m[2].replace(/^"(.*)"$/, "$1"); }
const { q } = await import("/home/user/Taxila/server/db.js");
const gs = await q("select id from guardian where (email like 'walk+%@taxila.test' or email like 'spk+%@taxila.test') and created_at > now() - interval '2 hours'");
for (const g of gs) { await q("delete from child where guardian_id=$1", [g.id]); await q("delete from guardian where id=$1", [g.id]); await q("delete from audit where guardian_id=$1", [g.id]); }
console.log("deleted", gs.length);
