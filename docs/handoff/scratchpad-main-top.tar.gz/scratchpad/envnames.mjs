// READ-ONLY: which of the given env names exist on taxila-web's live template (name + plain/secretRef only; never a value).
const { arm, loadEnv, SUB_PATH } = await import("/home/user/Taxila/infra/azure.mjs");
loadEnv?.();
const app = await arm("GET", `${SUB_PATH()}/resourceGroups/${process.env.AZURE_RESOURCE_GROUP}/providers/Microsoft.App/containerApps/taxila-web?api-version=2024-03-01`);
const env = new Map((app.properties.template.containers[0].env || []).map((e) => [e.name, e.secretRef ? "secretRef" : "plain"]));
for (const n of process.argv.slice(2)) console.log(`${n}: ${env.get(n) ?? "absent"}`);
