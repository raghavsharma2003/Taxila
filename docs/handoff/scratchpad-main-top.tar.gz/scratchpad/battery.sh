#!/bin/sh
# $1=copy dir $2=port $3=out
cd "$1" && NODE_USE_ENV_PROXY=1 node --env-file=/home/user/Taxila/.env.local evals/conversation-v2/run.mjs --out "$3" --base http://127.0.0.1:$2 --concurrency 2 && cd /home/user/Taxila && NODE_USE_ENV_PROXY=1 node evals/conversation-v2/judge.mjs --dir "$3" && node docs/design/ship5/p5-interaction/battery/score.mjs "$3" > "$3/score.txt"
