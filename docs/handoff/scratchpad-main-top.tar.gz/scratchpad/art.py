import re,html,sys
raw=open(sys.argv[1],encoding='utf-8',errors='ignore').read()
m=re.search(r'<article.*?</article>',raw,flags=re.S)
s=m.group(0) if m else raw
t=re.sub(r'<script.*?</script>|<style.*?</style>','',s,flags=re.S)
t=re.sub(r'<[^>]+>',' ',t); t=html.unescape(re.sub(r'\s+',' ',t))
d=re.findall(r'datetime="([^"]+)"',raw)[:2]
n=int(sys.argv[2]) if len(sys.argv)>2 else 6000
print(d); print(t[:n])
