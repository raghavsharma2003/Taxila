process.env.TAXILA_BASE = "http://127.0.0.1:8797";
const { apiClient, countTestGuardians } = await import("/home/user/Taxila/tests/prod/lib.mjs");
const api = apiClient();
const email = "prod-w2b-paint+17911629725836898i1@taxila.test", password = "prod-pw-1791162972583-6898i1";
console.log("before", await countTestGuardians());
await api("POST", "/api/auth/login", { email, password });
await api("DELETE", "/api/account", { password, confirm: true });
console.log("deleted; after", await countTestGuardians());
