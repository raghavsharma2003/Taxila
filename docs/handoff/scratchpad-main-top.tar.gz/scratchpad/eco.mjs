const IDS = ["grass","insects","deer","frog","snake","tiger"];
const EQ = { grass: 600, insects: 240, deer: 48, frog: 60, snake: 12, tiger: 5 };
const LINKS = [ // [prey, pred, a, e]
  ["grass","insects",0.0035,0.45],["grass","deer",0.004,0.10],["insects","frog",0.008,0.35],["frog","snake",0.012,0.22],["deer","tiger",0.03,0.14]];
const H = 0.4, INTERF = +(process.env.I||0.6), R = +(process.env.R||0.8);
function feed(x, prey, pred, a) { return a * x[prey] / (1 + a * H * x[prey] + INTERF * x[pred] / EQ[pred]); }
// solve mortality and grass K from equilibrium
const M = {}; let K;
{
  const x = EQ;
  for (const id of IDS) if (id !== "grass") {
    const gain = LINKS.filter(l => l[1] === id).reduce((s, l) => s + l[3] * feed(x, l[0], l[1], l[2]), 0);
    const lossPer = LINKS.filter(l => l[0] === id).reduce((s, l) => s + x[l[1]] * feed(x, l[0], l[1], l[2]), 0) / x[id];
    M[id] = gain - lossPer;
  }
  const eaten = LINKS.filter(l => l[0] === "grass").reduce((s, l) => s + x[l[1]] * feed(x, l[0], l[1], l[2]), 0);
  K = x.grass / (1 - eaten / (R * x.grass));
}
console.log("M", M, "K", K.toFixed(1));
function step(x, present, drought=0, dt=0.25) {
  const n = { ...x };
  const d = {}; for (const id of IDS) d[id] = 0;
  for (const [prey, pred, a, e] of LINKS) {
    if (!present.includes(prey) || !present.includes(pred) || x[prey] <= 0 || x[pred] <= 0) continue;
    const f = feed(x, prey, pred, a) * x[pred];
    d[prey] -= f; d[pred] += e * f;
  }
  const Kd = K * (1 - 0.6 * drought);
  d.grass += R * x.grass * (1 - x.grass / Kd) + 2;
  for (const id of IDS) if (id !== "grass") d[id] -= M[id] * x[id];
  for (const id of IDS) { n[id] = present.includes(id) ? Math.max(0, x[id] + d[id] * dt) : 0; if (id !== "grass" && n[id] < 0.5) n[id] = 0; }
  return n;
}
function run(present, days, init = EQ, removeDay0) {
  let x = { ...init }; if (removeDay0) x[removeDay0] = 0;
  const pres = present.filter(p => p !== removeDay0);
  const out = [x];
  for (let dd = 0; dd < days; dd++) { for (let k = 0; k < 4; k++) x = step(x, pres); out.push(x); }
  return out;
}
const r0 = (x) => Object.fromEntries(Object.entries(x).map(([k, v]) => [k, Math.round(v)]));
const start = { grass: 820, insects: 260, deer: 60, frog: 70, snake: 14, tiger: 6 };
const b = run(IDS, 150, start);
for (const d of [0, 20, 50, 100, 150]) console.log("base", d, JSON.stringify(r0(b[d])));
for (const rem of ["snake", "tiger", "frog", "deer", "insects"]) {
  const r = run(IDS, 90, start, rem);
  console.log("rm", rem.padEnd(7), "d30", JSON.stringify(r0(r[30])), "d90", JSON.stringify(r0(r[90])));
}
// drought
let x = { ...start }; const lost = new Set();
for (let dd = 0; dd < 80; dd++) { for (let k = 0; k < 4; k++) x = step(x, IDS, dd >= 25 && dd < 43 ? 1 : 0); for (const id of IDS) if (x[id] <= 0.01) lost.add(id); if (dd==42||dd==79) console.log("drought d"+dd, JSON.stringify(r0(x))); }
console.log("lost", [...lost]);
