#!/bin/bash
# transcribe each oss sample with gpt-4o-transcribe (round-trip intelligibility check)
set -a; . /home/user/Taxila/.env.local; set +a
E=${AZURE_OPENAI_ENDPOINT%/}; E=${E%/openai/v1}
for f in "$@"; do
  r=$(curl -s "$E/openai/deployments/$DEPLOY_TRANSCRIBE/audio/transcriptions?api-version=2025-03-01-preview" -H "api-key: $AZURE_OPENAI_API_KEY" -F file=@$f)
  echo "$(basename $f)	$(echo "$r" | python3 -c 'import sys,json;print(json.load(sys.stdin).get("text"))')"
done
