// TEST trace, read-only: per turn, model.call rows (lane / deployment / status / filter) and the reply guard, for a lesson.
const { q } = await import("/home/user/taxila-int/server/db.js");
const [pre, ...turns] = process.argv.slice(2);
const [l] = await q(`select id from lesson where id::text like $1 limit 1`, [pre + "%"]);
for (const t of turns.map(Number)) {
  const ev = await q(`select kind, data from trace_event where sid = $1 and turn = $2 and kind in ('model.call','safety.scan','director.turn','brain.guard','reply.guard') order by t`, [l.id, t]);
  console.log(`== ${pre} #${t}`);
  for (const e of ev) {
    const d = e.data ?? {};
    if (e.kind === "model.call") console.log(`  model.call ${d.purpose ?? d.schemaName ?? d.lane ?? "?"} dep=${d.deployment} status=${d.status} filter=${JSON.stringify(d.filter ?? d.filterCats ?? d.code ?? null)} ms=${d.ms}`);
    else if (e.kind === "safety.scan") console.log(`  scan kind=${d.kind} sources=${JSON.stringify(d.sources)} distress=${d.distress}`);
    else if (e.kind === "director.turn") console.log(`  director move=${d.move} reasons=${(d.reasons ?? []).join(",").slice(0, 200)}`);
    else console.log(`  ${e.kind} ${JSON.stringify(d).slice(0, 200)}`);
  }
}
process.exit(0);
