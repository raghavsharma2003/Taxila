import { readFileSync } from "node:fs";
import { expand } from "/home/user/Taxila/server/forge/explainer/templates.js";
import { opGeometry } from "/home/user/Taxila/shared/whiteboard.js";
const { chromium } = await import("/home/user/Taxila/node_modules/playwright/index.mjs");
const lib = JSON.parse(readFileSync("/home/user/Taxila/server/forge/explainer/library.json","utf8")).topics;
const calls = Object.entries(lib).map(([k,e])=>[k,e.call]);
calls.push(["sketch-plant",{template:"label@1",sketch:"plant",labels:[{anchor:"flower",text:"flower"},{anchor:"leaf",text:"leaf"},{anchor:"stem",text:"stem"},{anchor:"root",text:"root"}]}]);
calls.push(["pv",{template:"place-value@1",value:4567890}]);
calls.push(["col",{template:"column-op@1",a:99999,b:99999,op:"add"}]);
const scripts = [];
for (const [k,c] of calls) { const x = expand(c,{band:"B3",scriptId:k}); if (!x.ok) continue;
  const byId = new Map(x.script.ops.map(o=>[o.id,o]));
  const texts = []; for (const o of x.script.ops) { const g = opGeometry(o, byId); for (const t of g.texts) texts.push({...t, id:o.id}); }
  scripts.push({k, board:x.script.board, texts}); }
const FONTS = { app: '"Segoe Print", "Chalkboard SE", "Comic Sans MS", "Comic Neue", casual, "Noto Sans Devanagari", system-ui, sans-serif', wide: '"DejaVu Sans", Verdana, sans-serif' };
const b = await chromium.launch(); const p = await b.newPage();
for (const [name, font] of Object.entries(FONTS)) {
  await p.setContent(`<svg id=s xmlns="http://www.w3.org/2000/svg" width=400 height=300 style="font-family:${font.replace(/"/g,"'")}"></svg>`);
  const r = await p.evaluate((scripts) => { const s = document.getElementById("s"); const out = { over: 0, overlap: 0, ex: [] , n: scripts.length};
    for (const sc of scripts) { s.innerHTML = ""; const boxes = [];
      for (const t of sc.texts) { const e = document.createElementNS("http://www.w3.org/2000/svg","text"); e.setAttribute("x",t.x); e.setAttribute("y",t.y); e.setAttribute("font-size",t.size); e.setAttribute("text-anchor", t.align==="start"?"start":t.align==="end"?"end":"middle"); e.setAttribute("dominant-baseline","middle"); e.textContent=t.text; s.appendChild(e); const bb=e.getBBox(); boxes.push({bb, t:t.text, id:t.id}); }
      let bad = false, ov=false;
      for (const {bb,t} of boxes) if (bb.x < -1 || bb.x+bb.width > sc.board.w+1) { bad = true; if (out.ex.length<8) out.ex.push(sc.k+": over '"+t+"' "+Math.round(bb.x)+".."+Math.round(bb.x+bb.width)); }
      for (let i=0;i<boxes.length;i++) for (let j=i+1;j<boxes.length;j++){ const A=boxes[i].bb,B=boxes[j].bb; const ix=Math.min(A.x+A.width,B.x+B.width)-Math.max(A.x,B.x), iy=Math.min(A.y+A.height,B.y+B.height)-Math.max(A.y,B.y); if (ix>3&&iy>3 && boxes[i].id!==boxes[j].id){ ov=true; if(out.ex.length<16) out.ex.push(sc.k+": overlap '"+boxes[i].t+"' / '"+boxes[j].t+"' ix="+Math.round(ix)); } }
      if (bad) out.over++; if (ov) out.overlap++; }
    return out; }, scripts);
  console.log(name, JSON.stringify(r, null, 1));
}
await b.close();
