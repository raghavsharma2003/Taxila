import sys, json, urllib.request, urllib.parse
for line in sys.stdin:
    line=line.strip()
    if not line: continue
    print("#### QUERY:", line)
    u = "https://api.ies.ed.gov/eric/?" + urllib.parse.urlencode(dict(search=line, format="json", rows=1, fields="id,title,author,publicationdateyear,source,description"))
    try:
        d = json.load(urllib.request.urlopen(u, timeout=30))
        for r in d["response"]["docs"]:
            print("==", r.get("id"), r.get("title"), "|", (r.get("author") or [""])[:3], r.get("publicationdateyear"), r.get("source"))
            print(r.get("description","")[:2500]); print()
    except Exception as e: print("ERR", e)
