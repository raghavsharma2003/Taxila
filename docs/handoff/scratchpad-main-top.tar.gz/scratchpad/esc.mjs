import { __lexicon } from "/home/user/Taxila/server/safety/lexicon.js";
for (const s of __lexicon.SHAPES) { const m = s.re.source.match(/.{0,10}\\.{0,3}/g); if (m) console.log(s.id, m.join(" ; ")); }
import { lexiconScan } from "/home/user/Taxila/server/safety/lexicon.js";
console.log(lexiconScan("koi mujhe blackmailing kar raha"), lexiconScan("uncle ne swallowed"), lexiconScan("i swallowed a lot of pills"));
