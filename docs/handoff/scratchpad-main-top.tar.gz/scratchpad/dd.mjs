import fs from 'fs';
const k=JSON.parse(fs.readFileSync('/home/user/Taxila/data/kits/c8-maths.json','utf8'));
const [a,b]=process.argv.slice(2).map(Number);
k.topics.slice(a,b).forEach(t=>{
  console.log('## '+t.topicId);
  t.misconceptions.forEach(m=>{
    const d=m.diagnostic;
    console.log(`* ${m.id.replace('c8-maths-','')} | belief: ${m.belief}\n  Q: ${d.prompt_en}\n  HI: ${d.prompt_hi}`);
    d.options.forEach(o=>console.log(`   ${o.correct?'[OK]':'[  ]'} ${o.text}  -> ${o.misconceptionId?o.misconceptionId.replace('c8-maths-','').replace(/^ch\d+-t\d+-/,''):'-'}`));
  });
});
