import { loadEnv, arm, SUB_PATH } from "/home/user/Taxila/infra/azure.mjs";
loadEnv();
const r = await arm("GET", `${SUB_PATH()}/providers/Microsoft.CognitiveServices/accounts?api-version=2024-10-01`);
for (const a of r.value) console.log(a.name, a.location, a.properties.customSubDomainName, JSON.stringify(a.properties.endpoints || {}).slice(0, 200));
console.log("next", !!r.nextLink);
