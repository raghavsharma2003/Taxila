// Production probe: does a server row WITH a guardian id get written for a plain authed GET? (fresh @taxila.test account, deleted after)
import { createRequire } from "node:module";
import { randomBytes } from "node:crypto";
const require = createRequire(process.cwd() + "/package.json");
const m = await import(require.resolve("@neondatabase/serverless")); const neon = m.neon ?? m.default?.neon; const sql = neon(process.env.DATABASE_URL);
const base = process.argv[2]; let cookie = "";
const api = async (method, path, body) => { const r = await fetch(base + path, { method, headers: { "content-type": "application/json", ...(cookie ? { cookie } : {}) }, body: body === undefined ? undefined : JSON.stringify(body) }); const s = r.headers.get("set-cookie"); if (s) cookie = s.split(";")[0]; return r.status; };
const email = `authrow-${Date.now()}@taxila.test`, password = `p-${randomBytes(8).toString("hex")}`;
console.log("signup", await api("POST", "/api/auth/signup", { email, password, name: "Auth Row", isGuardianAdult: true }));
const g = (await sql.query("select id from guardian where email=$1", [email]))[0];
for (let i = 0; i < 3; i++) console.log("GET /api/me", await api("GET", "/api/me"));
await new Promise((r) => setTimeout(r, 5000));
const byGid = await sql.query("select kind, data->>'route' route, count(*)::int n from trace_event where gid=$1 group by 1,2", [g.id]);
const nullGidMe = await sql.query("select count(*)::int n from trace_event where src='server' and gid is null and t > now() - interval '15 seconds' and data->>'route' = 'GET /api/me'");
console.log("rows with this guardian:", JSON.stringify(byGid), "| GET /api/me rows without a guardian in the last 15 s:", nullGidMe[0].n);
console.log("delete", await api("DELETE", "/api/account", { password, confirm: true }));
