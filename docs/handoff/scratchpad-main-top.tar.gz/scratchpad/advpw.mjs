import { ARCHETYPES_V2, ENGINE_SPECS, validateSpec } from "/home/user/Taxila/shared/studio-spec.ts";
import { launch, runBot, serve, waitReady, stagePainted, visibleFailureText } from "/home/user/Taxila/src/studio-v2/tools/pw.mjs";
let seed = 777; const r = () => (seed = (seed * 1103515245 + 12345) & 0x7fffffff) / 0x7fffffff;
const pick = (a) => a[Math.floor(r() * a.length)];
const nasty = [0, -1, 1, 2, 1e6, -1e6, 0.0001, 99999, "", " ", "x", "😀😀😀", "W".repeat(60), "अआइईउऊ ऋएऐ", [], true];
function mutate(v, d = 0) {
  if (Array.isArray(v)) { let o = v.map((x) => r() < 0.12 ? pick(nasty) : mutate(x, d + 1)); if (r() < 0.15) o = o.concat(o.map((x) => mutate(x, d + 1))); if (r() < 0.1) o = o.slice(0, 1); return o; }
  if (v && typeof v === "object") { const o = {}; for (const [k, x] of Object.entries(v)) o[k] = r() < 0.12 ? pick(nasty) : mutate(x, d + 1); return o; }
  if (typeof v === "number") return r() < 0.35 ? pick([0, -v, v * 10, v / 7, v + 0.5, 1e5, Math.round(v * 3)]) : v;
  if (typeof v === "string") return r() < 0.3 ? pick(nasty.filter((x) => typeof x === "string")) : v;
  return v;
}
const PER = +(process.argv[2] || 5);
const { server, base } = await serve();
const browser = await launch();
const out = [];
for (const a of ARCHETYPES_V2) {
  let got = 0, tries = 0;
  while (got < PER && tries < 400) {
    tries++;
    const raw = mutate(structuredClone(ENGINE_SPECS[a].defaultSpec));
    const v = validateSpec(a, raw); if (v.fellBack || v.repairs.length === 0) continue;
    got++;
    const ctx = await browser.newContext({ viewport: { width: 800, height: 500 } });
    const page = await ctx.newPage(); const errors = [];
    page.on("pageerror", (e) => errors.push(String(e.message).slice(0, 140)));
    await page.addInitScript((spec) => {
      window.__SPEC = spec; window.__badText = [];
      const re = /\b(NaN|undefined|null|Infinity)\b|\[object/;
      for (const m of ["fillText", "strokeText"]) { const o = CanvasRenderingContext2D.prototype[m]; CanvasRenderingContext2D.prototype[m] = function (t, ...rest) { if (re.test(String(t)) && window.__badText.length < 5) window.__badText.push(String(t).slice(0, 60)); return o.call(this, t, ...rest); }; }
    }, raw);
    let ready = true;
    try { await page.goto(base + "?engine=" + encodeURIComponent(a) + "&audio=0&sound=off"); await waitReady(page, 6000); } catch { ready = false; }
    if (ready) { try { await runBot(page, { maxMs: 3500 }); } catch (e) { errors.push("bot:" + String(e.message).slice(0, 80)); } }
    const painted = ready ? await stagePainted(page) : { painted: false };
    const vis = ready ? await visibleFailureText(page) : null;
    const extra = ready ? await page.evaluate(() => ({ bad: window.__badText, rung: window.__sv2.rung(), tooSmall: window.__sv2.tooSmall.length, safe: window.__sv2.safeHits.length })) : {};
    const fail = !ready || errors.length || !painted.painted || vis || (extra.bad && extra.bad.length);
    out.push({ a, ready, errors, painted: painted.painted, vis, ...extra, repairs: v.repairs.slice(0, 4), fail: !!fail });
    if (fail) console.log("FAIL", a, JSON.stringify(out.at(-1)));
    await ctx.close();
  }
}
await browser.close(); server.close();
const byA = {}; for (const o of out) { byA[o.a] ??= { n: 0, fail: 0, board: 0, tiny: 0, safe: 0 }; const b = byA[o.a]; b.n++; if (o.fail) b.fail++; if (o.rung === "board") b.board++; if (o.tooSmall) b.tiny++; if (o.safe) b.safe++; }
console.log(JSON.stringify(byA));
console.log("TOTAL", out.length, "fail", out.filter((o) => o.fail).length);
