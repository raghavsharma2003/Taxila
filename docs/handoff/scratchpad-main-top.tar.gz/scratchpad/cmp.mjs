import fs from 'fs';
const k=JSON.parse(fs.readFileSync('/home/user/Taxila/data/kits/c8-maths.json','utf8'));
const sol=JSON.parse(fs.readFileSync(process.argv[2],'utf8'));
for(const t of k.topics)for(const i of t.items){const id=i.id.replace('c8-maths-','');if(sol[id]!==undefined)console.log(`${id}\n  ME : ${sol[id]}\n  KEY: ${i.answer}`)}
