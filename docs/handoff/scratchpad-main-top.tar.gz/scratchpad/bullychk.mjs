const B = "/tmp/claude-0/-home-user/ecee9fc1-62f9-5f67-a47d-69ca79d9981a/scratchpad/b145";
const { scanSafety, scanSafetyDetail } = await import(`${B}/server/director/safety.js`);
for (const t of ["तुम बोलीओ बुली। ग्रैविटी ग्रैविटी", "बुली", "उसने हिंदी बुली", "मुझे एक बुली परेशान करता है", "हमारी क्लास में एक बुली है जो मुझे मारता है", "वो बुली मुझे रोज़ चिढ़ाता है", "स्कूल में एक बुली है", "they bully me", "bully", "बुली करते हैं सब", "मेरे को बुली किया"]) {
  const d = scanSafetyDetail ? scanSafetyDetail(t) : scanSafety(t);
  console.log(String(!!d.distress).padEnd(6), (d.via ?? d.kind ?? ""), "|", t);
}
