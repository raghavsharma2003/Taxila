const e = process.env;
const tok = await (await fetch(`https://login.microsoftonline.com/${e.AZURE_TENANT_ID}/oauth2/v2.0/token`, { method: "POST",
  body: new URLSearchParams({ grant_type: "client_credentials", client_id: e.AZURE_SP_CLIENT_ID, client_secret: e.AZURE_SP_SECRET, scope: "https://management.azure.com/.default" }) })).json();
if (!tok.access_token) { console.log("token failed:", tok.error, tok.error_description?.slice(0, 200)); process.exit(1); }
const H = { Authorization: `Bearer ${tok.access_token}`, "Content-Type": "application/json" };
const sub = `/subscriptions/${e.AZURE_SUBSCRIPTION_ID}`;
const subInfo = await (await fetch(`https://management.azure.com${sub}?api-version=2022-12-01`, { headers: H })).json();
console.log("subscription:", subInfo.displayName, subInfo.state, subInfo.subscriptionPolicies?.quotaId);
async function q(groupings, from, to, gran = "None") {
  const body = { type: "ActualCost", timeframe: "Custom", timePeriod: { from, to }, dataset: { granularity: gran, aggregation: { c: { name: "Cost", function: "Sum" } }, grouping: groupings.map((n) => ({ type: "Dimension", name: n })) } };
  for (let i = 0; i < 5; i++) {
    const r = await fetch(`https://management.azure.com${sub}/providers/Microsoft.CostManagement/query?api-version=2023-11-01`, { method: "POST", headers: H, body: JSON.stringify(body) });
    if (r.status === 429) { await new Promise((s) => setTimeout(s, 15000)); continue; }
    const j = await r.json(); if (!r.ok) { console.log("query error", r.status, JSON.stringify(j).slice(0, 300)); return null; }
    return j.properties;
  }
}
const from = process.env.FROM ?? "2026-09-01", to = process.env.TO ?? "2026-10-24";
for (const g of (process.env.GG ?? "ResourceGroupName;ServiceName;ResourceId,MeterSubCategory").split(";")) {
  const p = await q(g.split(","), from, to, process.env.GRAN ?? "None"); if (!p) continue;
  const cols = p.columns.map((c) => c.name);
  const rows = p.rows.sort((a, b) => b[0] - a[0]);
  const total = rows.reduce((s, r) => s + r[0], 0);
  console.log(`\n== by ${g} (${from}..${to}) total ${total.toFixed(0)} ${rows[0]?.[cols.indexOf("Currency")] ?? ""}`);
  for (const r of rows.slice(0, Number(process.env.TOP ?? 25))) console.log(r[0].toFixed(0).padStart(9), r.slice(1).filter((x) => typeof x === "string" && !/^(INR|USD)$/.test(x)).map((x) => String(x).replace(/^\/subscriptions\/[^/]+\/resourcegroups\//i, "")).join(" | "));
}
