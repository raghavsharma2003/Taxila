import { __internals as I } from "/home/user/Taxila/server/safety/fuzzy.js";
import * as C from "/home/user/Taxila/evals/safety-robust/corpora.mjs";
import { HARD_NEGATIVES, HELDOUT_DISTRESS } from "/home/user/Taxila/evals/safety-robust/negatives.data.mjs";
const texts = [...C.es1Turns().map(x=>x.text), ...C.transcriptChildTurns().map(x=>x.text), ...HARD_NEGATIVES.map(x=>x.text), ...HELDOUT_DISTRESS.map(x=>x[0])];
for (const it of [...C.taxilaFdbDistress(), ...C.es3Distress()]) for (let k=0;k<5;k++) texts.push(C.perturbedText(it, C.seedOf(it.id, 500+k)).text);
const seen = new Set(); let pairs = 0, diff = 0; const ex = [];
for (const tx of texts) for (const t of I.prep(tx)) {
  if (seen.has(t.raw)) continue; seen.add(t.raw);
  const fast = I.costsOf(t);
  for (const g of I.ALL_GROUPS()) { pairs++; const a = I.slotCost(t, g); const b = fast.get(g.name) ?? Infinity; if (a !== b) { diff++; if (ex.length < 20) ex.push([t.raw, g.name, a, b]); } }
}
console.log({ tokens: seen.size, pairs, diff }, ex);
