import bpy,sys,numpy as np
sys.path.insert(0,'/home/user/Taxila/scripts/character/stylised/armB')
import lib as L
bpy.ops.wm.open_mainfile(filepath='/tmp/claude-0/char/stylised-armB/stage.blend')
key=sys.argv[-1]
for o in bpy.data.objects:
    if o.type=='MESH' and o.data.shape_keys:
        for kb in o.data.shape_keys.key_blocks[1:]: kb.value = float(sys.argv[-2]) if kb.name==key else 0.0
    if o.type=='MESH' and o.name=='hair': o.hide_render=True
L.setup_render(res=512,samples=8)
for o in list(bpy.data.objects):
    if o.type in ('LIGHT','CAMERA'): bpy.data.objects.remove(o)
c=np.array([0,-0.06,0.265])
L.area_light('k',c+np.array([-0.3,-1,0.5]),c,40,1)
cam=L.camera('c',c+np.array([0.15,-0.35,0.05]),c,lens=85)
L.render_to(f'/tmp/claude-0/char/stylised-armB/dbg/key_{key}.png',cam)
import os; os._exit(0)
