import json
P='/home/user/Taxila/data/kits/c3-hindi.json'
d=json.load(open(P))
T={t['topicId']:t for t in d['topics']}
def item(iid):
    tid=iid.rsplit('-',1)[0]
    return next(i for i in T[tid]['items'] if i['id']==iid)
FIX=' FIXED (2026-10-02): '
def note(it,txt,agrees=None,solver=None):
    v=it.setdefault('verified',{})
    v['note']=(v.get('note','')+FIX+txt).strip()
    if solver is not None: v['solverAnswer']=solver
    if agrees is not None: v['agrees']=agrees

# ---- ch02 i10: supply the (original) poem + quote candidate lines
t=T['c3-hindi-ch02-t01']
t['passage']=("चींटी (original poem)\n"
 "छोटी-सी चींटी, काली-काली,\n"
 "दाना लेकर चली निराली।\n"
 "लाइन में चलतीं सब मिलकर,\n"
 "थकतीं नहीं कभी भी दिनभर।\n"
 "मेहनत से घर भरती जातीं,\n"
 "हमको भी यह बात सिखातीं।")
it=item('c3-hindi-ch02-t01-i10')
it['prompt_en']="Picture: many ants walking one behind another in a row, all together. Which poem line matches — 'छोटी-सी चींटी, काली-काली', 'लाइन में चलतीं सब मिलकर', or 'थकतीं नहीं कभी भी दिनभर'?"
it['prompt_hi']="तस्वीर देखो — बहुत सारी चींटियाँ एक के पीछे एक, लाइन बनाकर साथ-साथ चल रही हैं। कविता की इन पंक्तियों में से कौन-सी इस तस्वीर से मेल खाती है — ‘छोटी-सी चींटी, काली-काली’, ‘लाइन में चलतीं सब मिलकर’, या ‘थकतीं नहीं कभी भी दिनभर’?"
it['acceptable']=["line mein chalti sab milkar","लाइन में चलतीं","लाइन वाली पंक्ति","दूसरी पंक्ति","दूसरी वाली","doosri wali"]
it['hints']=["Look at the picture: one ant, or many ants together?",
 "The picture shows how the ants are walking, not how tired they are.",
 "लाइन में चलतीं sab ___.",
 "The line is: लाइन में चलतीं सब मिलकर."]
note(it,"poem text added as topic.passage (original verse; all lines already quoted in i01-i03 plus this one) and the three candidate lines are quoted in prompt_hi, so the key is reachable from the prompt alone. Picture reworded to 'many ants in a line, together' so 'दाना लेकर चली निराली' (one ant) is not a rival match. Re-solved blind: only ‘लाइन में चलतीं सब मिलकर’ fits many-ants-in-a-row; matches key. Hint 2 no longer names the word लाइन.",True,"लाइन में चलतीं सब मिलकर")

# ---- ch07: supply the letter + quote holiday line in i02
t=T['c3-hindi-ch07-t01']
t['passage']=("रिया का पत्र (original letter)\n"
 "जयपुर, 5 जून\n"
 "प्रिय मित्र सारा,\n"
 "नमस्ते! तुम कैसी हो? मैं गर्मी की छुट्टियों में नानी के गाँव गई थी। वहाँ आम के बड़े-बड़े पेड़ हैं। नानी ने मुझे मीठे आम खिलाए और रात को कहानियाँ सुनाईं। मैंने आम के पेड़ का एक चित्र भी बनाया है। तुम्हारी छुट्टियाँ कैसी चल रही हैं? जवाब में पत्र ज़रूर लिखना।\n"
 "तुम्हारी मित्र,\n"
 "रिया")
it=item('c3-hindi-ch07-t01-i02')
it['prompt_en']="Riya wrote: 'In the summer holidays I went to my Nani's village.' Where did Riya go in the holidays?"
it['prompt_hi']="रिया ने पत्र में लिखा — ‘मैं गर्मी की छुट्टियों में नानी के गाँव गई थी।’ बताओ, रिया छुट्टियों में कहाँ गई?"
it['hints']=["Listen to the line about the holidays again.",
 "Whose village was it — which family member?",
 "She went to ___ ke gaon.",
 "She went to her नानी's village (नानी के गाँव)."]
note(it,"full letter text added as topic.passage (original; consistent with i01's opening/closing and i03's 'जयपुर, 5 जून'), and the holiday line is quoted in prompt_hi. Re-solved blind from prompt_hi: नानी के गाँव; matches key.",True,"नानी के गाँव")

it=item('c3-hindi-ch07-t01-i07')
it['hints']=["Think back to the words in Riya's letter, or words about writing and drawing.",
 "A drawing is also called…",
 "Letter = pa___.",
 "पत्र, चित्र, त्रिभुज all have त्र."]
note(it,"hint 1 now only points where to look (Riya's letter / writing-and-drawing words) instead of naming 'a letter'; the passage now contains both पत्र and चित्र.")

# ---- ch13: textbook spelling थिमक्का
t=T['c3-hindi-ch13-t01']
def respell(o):
    if isinstance(o,str):
        for a,b in [("तिमक्-का","थिमक्-का"),("तिमक्का","थिमक्का"),("तिमकका","थिमकका"),("तिमका","थिमका"),("तिम + क्","थिम + क्")]:
            o=o.replace(a,b)
        return o
    if isinstance(o,list): return [respell(x) for x in o]
    if isinstance(o,dict): return {k:(v if k in('note','solverAnswer') else respell(v)) for k,v in o.items()}
    return o
T['c3-hindi-ch13-t01'].update(respell({k:v for k,v in t.items()}))
t=T['c3-hindi-ch13-t01']
it=item('c3-hindi-ch13-t01-i07')
it['acceptable']=["थिमक्का","thimmakka","thimakka","timakka","तिमक्का","तिम्मक्का","थिम्मक्का","क्क"]
note(it,"canonical spelling aligned to the textbook form थिमक्का across the topic (s1 title, mc-kka-conjunct belief/signs/diagnostic/remediation, i07, i12 and every prompt); error form is now थिमका; तिमक्का/तिम्मक्का/थिम्मक्का accepted as variants. The item still tests only क्क, which the textbook form has; it has a single म, so no double म is being dropped. 'आधा क' dropped from acceptable to stay within ACCEPTABLE_MAX=8 (क्क kept). Re-solved: थिमक्का (क्क); matches key. NOTE: data/curriculum still titles the chapter ‘तिमक्का’ — outside this kit, not changed here.",True,"थिमक्का (क्क)")
it=item('c3-hindi-ch13-t01-i12')
note(it,"respelled तिमक्का→थिमक्का (textbook form) in prompt_hi and answer.")
mc=next(m for m in t['misconceptions'] if m['id']=='c3-hindi-ch13-t01-mc-kka-conjunct')
v=mc['diagnostic']['verified']; v['solverAnswer']='थिमक्का'
v['note']+=FIX+"options respelled to the textbook form: थिमक्का (correct) / थिमका / थिमकका (both mc-kka-conjunct). Still exactly one correct option; prompt_hi does not spell the name. Re-solved: थिमक्का."

# ---- ch03: कीट for insect
t=T['c3-hindi-ch03-t01']
t['expectations']=[e.replace("insects (कीड़े)","insects (कीट)") for e in t['expectations']]
mc=next(m for m in t['misconceptions'] if m['id']=='c3-hindi-ch03-t01-mc-all-small-six')
mc['belief']=mc['belief'].replace("is a कीड़ा with six legs","is a कीट (insect) with six legs")
it=item('c3-hindi-ch03-t01-i02'); it['hints'][0]="Dadi said the spider is not a कीट (insect)."
note(it,"hint 1 uses कीट (insect), not the broad कीड़ा.")
it=item('c3-hindi-ch03-t01-i03'); it['hints'][0]="Which one did Dadi call a कीट (insect)?"
note(it,"hint 1 uses कीट (insect), not the broad कीड़ा.")
it=item('c3-hindi-ch03-t01-i11'); it['hints'][0]="Six legs means it is a कीट (insect)."; it['hints'][1]="Which कीट visits flowers?"
note(it,"hints 1-2 use कीट (insect), not the broad कीड़ा.")
it=item('c3-hindi-ch03-t01-i12')
it['prompt_en']="Be Dadi. Answer Meenu: 'How many legs does a spider have, and is it an insect (कीट)?' Explain in your words."
it['prompt_hi']="अब तुम दादी बनो। मीनू पूछ रही है — ‘मकड़ी के कितने पैर होते हैं, और क्या वह कीट है?’ दादी की तरह समझाओ।"
it['answer']="मकड़ी के आठ पैर होते हैं; कीटों के छह पैर होते हैं, इसलिए मकड़ी कीट नहीं है"
it['acceptable']=["आठ पैर","aath pair","कीट नहीं","keet nahi","कीटों के छह पैर","कीड़ा नहीं","keeda nahi","insect nahi"]
note(it,"insect is now कीट throughout (prompt, key, hints of i02/i03/i11, expectation, misconception belief): key = 'मकड़ी के आठ पैर होते हैं; कीटों के छह पैर होते हैं, इसलिए मकड़ी कीट नहीं है'. A child's everyday 'कीड़ा नहीं' is still accepted. Re-solved: matches key.",True,"मकड़ी के आठ पैर; कीटों के छह पैर, इसलिए मकड़ी कीट नहीं")

# ---- ch11 i09: -ई model, not -ईन
it=item('c3-hindi-ch11-t01-i09')
it['prompt_en']="पहाड़ + ई = पहाड़ी (of the hills). Now add ई to कागज़ — what do we call a boat made of paper, in one word: ___ नाव?"
it['prompt_hi']="‘पहाड़’ में ‘ई’ जोड़ा तो ‘पहाड़ी’ बना। अब ‘कागज़’ में ‘ई’ जोड़ो — कागज़ से बनी नाव को एक शब्द में क्या कहेंगे? ___ नाव।"
it['hints']=["'kaagaz ki naav' is right in meaning — now say it in one word, the way पहाड़ became पहाड़ी.",
 "जादू + ई gave जादुई; just add ई at the end of कागज़.",
 "Kaagaz + ई = ___.",
 "कागज़ी नाव — a paper boat."]
note(it,"model pair changed from रंग→रंगीन (-ईन) to पहाड़→पहाड़ी (plain -ई), so the analogy no longer invites 'कागज़ीन'; prompt asks for one word (___ नाव) and prompt_en now mentions the boat. 'कागज़ की नाव' is NOT added to acceptable (it skips the -ई skill this item tests) but hint 1 accepts it as meaning and nudges to the one-word form. Re-solved blind: कागज़ी (नाव); matches key.",True,"कागज़ी (नाव)")

# ---- ch03 i07 hint 2 rule-only
it=item('c3-hindi-ch03-t01-i07')
it['hints'][1]="We say 'मेरा पैर दुखता है', so पैर is a he-word — and the question word must match a he-word."
note(it,"hint 2 now states only the rule (पैर is a he-word; the question word matches it) without naming the -ने form.")

# ---- self-leak when shown as text: add display_hi (on-screen form with blank)
for iid,disp,why in [
 ('c3-hindi-ch04-t01-i13',"‘च_ड़िया’ बोलो। पहली आवाज़ छोटी है या खिंची हुई — ‘च’ पर छोटी इ (ि) आएगी या बड़ी ई (ी)?","च_ड़िया"),
 ('c3-hindi-ch05-t01-i10',"‘बू_ा’ शब्द में नीचे बिंदी वाला अक्षर ‘ड़’ है या ‘ढ़’?","बू_ा"),
 ('c3-hindi-ch06-t01-i13',"‘ब_रबल’ धीरे-धीरे बोलो। पहले अक्षर ‘ब’ पर कौन-सी मात्रा लगेगी — छोटी इ (ि) या बड़ी ई (ी)?","ब_रबल"),
 ('c3-hindi-ch10-t01-i10',"‘रस्साक_’ के आख़िर में ‘शी’ है या ‘सी’?","रस्साक_"),
 ('c3-hindi-ch11-t01-i07',"‘जादू’ में लंबा ‘ू’ है। ‘जाद_ई’ में ‘ू’ रहेगा या ‘ु’?","जाद_ई"),
]:
    it=item(iid)
    it['display_hi']=disp
    note(it,f"prompt_hi stays the SPOKEN form (the child must hear the whole word); added display_hi = the on-screen form with the asked-about letter blanked ({why}), to be shown instead of prompt_hi whenever the prompt is rendered as text. Checked: display_hi does not contain the answer form.")
json.dump(d,open(P,'w'),ensure_ascii=False,indent=2)
open(P,'a').write('\n')
