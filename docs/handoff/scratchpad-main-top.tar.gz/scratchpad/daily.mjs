const e = process.env;
const tok = await (await fetch(`https://login.microsoftonline.com/${e.AZURE_TENANT_ID}/oauth2/v2.0/token`, { method: "POST", body: new URLSearchParams({ grant_type: "client_credentials", client_id: e.AZURE_SP_CLIENT_ID, client_secret: e.AZURE_SP_SECRET, scope: "https://management.azure.com/.default" }) })).json();
const H = { Authorization: `Bearer ${tok.access_token}`, "Content-Type": "application/json" };
const body = { type: "ActualCost", timeframe: "Custom", timePeriod: { from: "2026-09-15", to: "2026-10-24" }, dataset: { granularity: "Daily", aggregation: { c: { name: "Cost", function: "Sum" } }, grouping: [{ type: "Dimension", name: "ServiceName" }] } };
let p; for (let i = 0; i < 6; i++) { const r = await fetch(`https://management.azure.com/subscriptions/${e.AZURE_SUBSCRIPTION_ID}/providers/Microsoft.CostManagement/query?api-version=2023-11-01`, { method: "POST", headers: H, body: JSON.stringify(body) }); if (r.status === 429) { await new Promise((s) => setTimeout(s, 20000)); continue; } p = (await r.json()).properties; break; }
const cols = p.columns.map((c) => c.name), iC = cols.indexOf("Cost"), iD = cols.indexOf("UsageDate"), iS = cols.indexOf("ServiceName");
const days = {};
for (const r of p.rows) { const d = String(r[iD]); (days[d] ??= {})[r[iS]] = (days[d][r[iS]] ?? 0) + r[iC]; }
for (const d of Object.keys(days).sort()) { const v = days[d]; const t = Object.values(v).reduce((a, b) => a + b, 0);
  console.log(d, String(Math.round(t)).padStart(6), "| models", String(Math.round(v["Foundry Models"] ?? 0)).padStart(6), "| speech/tools", String(Math.round(v["Foundry Tools"] ?? 0)).padStart(5), "| PG", Math.round(v["Azure Database for PostgreSQL"] ?? 0), "| ACA", Math.round(v["Azure Container Apps"] ?? 0)); }
