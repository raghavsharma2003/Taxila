import { chromium } from "/home/user/Taxila/node_modules/playwright/index.mjs";
const S = process.argv[2];
const b = await chromium.launch();
const out = {};
for (const [fx, band] of [["work-pad", "b3"], ["work-pad", "b4"], ["work-pad", "b1"], ["work-pad", "b2"], ["work-pad-help", "b1"], ["work-tiles", "b1"]]) {
  const p = await b.newPage({ viewport: { width: 360, height: 640 }, deviceScaleFactor: 1 });
  await p.goto(`http://127.0.0.1:5232/dev/desk?fixture=${fx}&band=${band}`);
  await p.waitForTimeout(1200);
  await p.screenshot({ path: `${S}/fx-${fx}-${band}.png` });
  out[`${fx}-${band}`] = await p.evaluate(() => {
    const r = (el) => el ? (({ top, bottom }) => [Math.round(top), Math.round(bottom)])(el.getBoundingClientRect()) : null;
    const tray = document.querySelector('[data-testid="tray"]');
    const keys = [...document.querySelectorAll('[data-testid="number-pad"] .dk-key')];
    const tb = tray?.getBoundingClientRect();
    return { card: r(document.querySelector('[data-testid="question-card"]')), tray: r(tray), keyTop: keys.length ? Math.round(Math.min(...keys.map((k) => k.getBoundingClientRect().top))) : null,
      keyBottom: keys.length ? Math.round(Math.max(...keys.map((k) => k.getBoundingClientRect().bottom))) : null, clipped: keys.filter((k) => { const kr = k.getBoundingClientRect(); return tb && (kr.top < tb.top || kr.bottom > tb.bottom); }).length, n: keys.length };
  });
  await p.close();
}
console.log(JSON.stringify(out, null, 0));
await b.close();
