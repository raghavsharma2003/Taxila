const B = process.env.B;
const { classify, targetFor } = await import(`${B}/server/director/classify.js`);
const { kitFor } = await import(`${B}/server/brain/rows.js`);
const K = await kitFor("c8-sst-ch04-t01", {}).catch(() => null) ?? await kitFor("c6-maths-ch06-t01", {});
const item = K.items.find((i) => i.kind !== "teachback" && i.answer);
const target = targetFor({ phase: "teach", hintLevel: 0 }, K, item);
for (const t of ["वो cotton shirt, British लोग control करते होंगे price and all, क्योंकि वोही तो rule कर रहे थे.",
  "अरे, because if outsiders control it, the shopkeepers can't decide prices, या कुछ भी. The British would take all the profit, न? So they'd be upset.",
  "British log khud ko doosri race se better samajhte the, isliye Indians ke saath bura bartaav karte the na?"]) {
  const r = [];
  for (let i = 0; i < 2; i++) { const o = await classify({ target, childText: t, typed: true, asrConfidence: 0.95, classLevel: 8, trace: [] }); r.push(`${o.flags?.distress ? "DISTRESS:" + o.flags.distressKind : "-"}/${o.source}`); }
  console.log(r.join(" "), "|", t.slice(0, 60));
}
process.exit(0);
