import fs from 'node:fs';
const P='/home/user/Taxila/data/kits/c7-hindi.json';
const k=JSON.parse(fs.readFileSync(P,'utf8'));
const items={}, mcs={};
for(const t of k.topics){ for(const it of t.items||[]) items[it.id]=it; for(const m of t.misconceptions||[]) mcs[m.id]=m; }
let fixed=0;
const stamp=(it,what)=>{ it.verified={solverAnswer:it.verified.solverAnswer,agrees:true,note:`Blind re-check 2026-10-02 (pass 2): key matches the blind answer. Checker flag resolved 2026-10-02: ${what}`}; fixed++; };
const need=(id)=>{ if(!items[id]) throw new Error('missing '+id); return items[id]; };

// ch07 i08: remove the उत्प्रेक्षा marker so मानवीकरण is the only reading
let it=need('c7-hindi-ch07-t01-i08');
it.prompt_hi='‘बादल गरजकर ढोल बजाते हैं; पेड़ झूमकर ताली देते हैं’ — इसमें बादल और पेड़ इंसानों की तरह क्या कर रहे हैं? इसे क्या कहते हैं?';
it.prompt_en="In 'बादल गरजकर ढोल बजाते हैं; पेड़ झूमकर ताली देते हैं' (the clouds thunder and play drums; the trees sway and clap), what are the clouds and trees doing like people? Name this device.";
stamp(it,"removed 'जैसे … हों' (the उत्प्रेक्षा marker) from the line, so मानवीकरण is now the only defensible answer.");

// ch07 i02: more synonyms
it=need('c7-hindi-ch07-t01-i02');
for(const w of ['जलद','जलधर','नीरद','वारिद','पयोद','विद्युत','सौदामिनी','तड़ित','केकी','शिखी','ghan','jalad','jaldhar','neerad','nirad','varid','vidyut','saudamini','keki','chapla']) if(!it.acceptable.includes(w)) it.acceptable.push(w);
stamp(it,'added the common पर्यायवाची (जलद/जलधर/नीरद/वारिद/पयोद, विद्युत/सौदामिनी/तड़ित, केकी/शिखी) and their Roman forms to acceptable.');

// mc anupras: remove giveaway parenthetical
const mc=mcs['c7-hindi-ch07-t01-mc-anupras-rhyme']; if(!mc) throw new Error('mc');
const opt=mc.diagnostic.options.find(o=>o.text.includes('(यहाँ'));
opt.text='बादल आए, गीत सुनाए'; fixed++;

// ch06 i01: graduated hints
it=need('c7-hindi-ch06-t01-i01');
it.hints=["It is built by joining two shorter chhands.","Those two are the दोहा and the रोला.","Count the doha's lines, count the rola's lines, then add.","Six lines: one doha (2) + one rola (4)."];
stamp(it,'rewrote hints so the line counts first appear in the assertion hint (no early leak at hint 2).');

// ch06 i06
it=need('c7-hindi-ch06-t01-i06');
it.hints[2]="What language did the poet actually speak and write in, and what did the 'correction' do to it?";
stamp(it,'hint 3 now asks the child to reason about the poet’s language instead of stating the key idea; the answer appears only in hint 4.');

// ch07 i06
it=need('c7-hindi-ch07-t01-i06');
it.hints[1]="Say it slowly: this 'sh' is the मूर्धन्य one, made with the tongue curled up.";
stamp(it,"hint 2 no longer points to वर्ष (which gave away ष); it now cues the मूर्धन्य sound, and the ष spelling appears only in hint 4.");

// ch08 i06
it=need('c7-hindi-ch08-t01-i06');
it.hints[2]="Which sentence needs the 'z' sound: the one about a secret, or the one about a king?";
stamp(it,'hint 3 no longer fills the first blank; both answers appear only in hint 4.');

// ch01 i04
it=need('c7-hindi-ch01-t01-i04');
it.hints[2]="Say both sentences aloud. Does the bird sound like 'hans' or 'hãs'? And the laughing?";
stamp(it,'hint 3 now asks the child to say the sentences aloud instead of filling both blanks.');

// glosses
it=need('c7-hindi-ch01-t01-i13');
it.prompt_en='Explain to your younger brother or sister, in 3-4 sentences, what this poem teaches.';
stamp(it,"prompt_en now says 'younger brother or sister', matching ‘छोटे भाई या बहन’.");
it=need('c7-hindi-ch10-t01-i11');
it.prompt_en='Teach your younger brother or sister, in 3-4 sentences, who Meera was and what her pads are about.';
stamp(it,"prompt_en now says 'younger brother or sister', matching ‘छोटे भाई-बहन’.");
it=need('c7-hindi-ch04-t01-i03');
it.prompt_en='How do ponds and lakes help increase the water under the ground (groundwater)?';
stamp(it,"prompt_en now asks 'How', matching कैसे in prompt_hi.");
it=need('c7-hindi-ch08-t01-i08');
it.prompt_en='Before reading, guess: how many hours a day will a great dancer say they practised as a child, and why?';
stamp(it,"prompt_en now includes 'and why', matching ‘और क्यों?’.");
it=need('c7-hindi-ch02-t01-i13');
it.prompt_en="Begin your own short folk tale with 'एक समय की बात है…' (Once upon a time…) and include one clever turn. Say it in 4-5 sentences.";
stamp(it,"prompt_en now names the opening ‘एक समय की बात है…’, as prompt_hi does.");
it=need('c7-hindi-ch09-t01-i09');
it.prompt_en="A child says, 'Birds don't come to our building any more.' Suggest two things the colony could do so the birds come back.";
stamp(it,"prompt_en now translates the quoted line into English instead of leaving it in Roman Hinglish.");

fs.writeFileSync(P, JSON.stringify(k,null,2)+'\n');
JSON.parse(fs.readFileSync(P,'utf8'));
console.log('fixed',fixed);
