import { readdirSync, readFileSync } from "node:fs";
import { normalizeKit } from "/home/user/Taxila/server/content/kits.js";
import { fadeItem, fadeBoard } from "/home/user/Taxila/server/director/fading.js";
const dir = "/home/user/Taxila/data/kits/";
let n=0, cut=0, lostGap=0, allFade=0;
for (const f of readdirSync(dir)) {
  const m = f.match(/^c(\d)-/); if (!m || !f.endsWith(".json")) continue;
  for (const t of JSON.parse(readFileSync(dir+f,"utf8")).topics ?? []) {
    const kit = normalizeKit(t, { topicId: t.topicId, verified: true });
    const it = fadeItem(kit, { band: +m[1] <= 2 ? "B1" : "B3" }); if (!it) continue; allFade++;
    const b = fadeBoard(kit.workedExample, Number(it.id.slice(5)));
    if (+m[1] >= 4 && +m[1] <= 7) { n++; if (b.value.endsWith("…")) { cut++; if (!/_{2,}/.test(b.value)) lostGap++; } }
  }
}
console.log({ c4to7Fade: n, boardTruncated: cut, gapLostFromBoard: lostGap, allClassesFade: allFade });
