exec(open('awsenv.py').read())
import json
b=boto3.client('bedrock',region_name='ap-south-1')
for i in ['openai.gpt-6-luna','anthropic.claude-sonnet-5-5','cohere.embed-v4:0','moonshotai.kimi-k3','xai.grok-4.7','amazon.nova-2-lite-v1:0']:
    try:
        x=b.list_foundation_model_agreement_offers(modelId=i); x.pop('ResponseMetadata',None)
        print(i, json.dumps(x,default=str)[:700])
    except Exception as e: print(i,'ERR',str(e)[:200])
