// read-only: (1) client ui.render.board rows per scriptId in the two census lessons; (2) cross-lesson page repeats per child
const { q } = await import("/home/user/taxila-int/server/db.js");
const { createHash } = await import("node:crypto");
const rows = (r) => r.rows ?? r;
const sig = (x) => createHash("sha1").update(JSON.stringify(x ?? null)).digest("hex").slice(0, 12);
await q("begin read only");
for (const pre of ["3437b744", "310b8c82"]) {
  const L = rows(await q(`select id::text from lesson where id::text like $1`, [`${pre}%`]))[0].id;
  const r = rows(await q(`select data->>'scriptId' sid, data->>'page' pg, count(*)::int n from trace_event where sid=$1 and kind='ui.render.board' group by 1,2 order by 1,2`, [L]));
  console.log(pre, r.map((x) => `script=${String(x.sid).slice(-10)} page=${x.pg} rows=${x.n}`).join(" | "));
}
// (2) every board.page in a REAL lesson (sid is a lesson id), by child and time
const pages = rows(await q(`select l.child_id::text child, l.id::text lesson, l.started_at, t.data->'ops' ops from trace_event t join lesson l on l.id::text = t.sid::text where t.kind='board.page' order by l.started_at, t.t`));
const seen = new Map(); let total = 0, repeatSameLesson = 0, repeatEarlier7 = 0, repeatEarlierAny = 0; const lessons = new Set(), childrenRep = new Set(), lessonsRep = new Set();
for (const p of pages) {
  total++; lessons.add(p.lesson);
  const k = `${p.child}:${sig(p.ops)}`; const prev = seen.get(k) ?? [];
  if (prev.some((x) => x.lesson === p.lesson)) repeatSameLesson++;
  const earlier = prev.filter((x) => x.lesson !== p.lesson);
  if (earlier.length) { repeatEarlierAny++; if (earlier.some((x) => (p.started_at - x.at) <= 7 * 864e5)) repeatEarlier7++; childrenRep.add(p.child); lessonsRep.add(p.lesson); }
  prev.push({ lesson: p.lesson, at: p.started_at }); seen.set(k, prev);
}
const kids = new Set(pages.map((p) => p.child));
console.log(`board pages in real lessons: ${total} across ${lessons.size} lessons, ${kids.size} children`);
console.log(`same page again in the SAME lesson: ${repeatSameLesson}`);
console.log(`a page the same child saw in an EARLIER lesson: ${repeatEarlierAny} (within 7 days: ${repeatEarlier7}), in ${lessonsRep.size} lessons, ${childrenRep.size} children`);
await q("rollback"); process.exit(0);
