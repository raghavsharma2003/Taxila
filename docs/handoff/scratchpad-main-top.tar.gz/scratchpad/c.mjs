import { readdirSync, readFileSync } from "fs";
import { rowProblem } from "/home/user/Taxila/server/learner/brief.js";
const titles = new Set();
const walk = (x) => { if (Array.isArray(x)) x.forEach(walk); else if (x && typeof x === "object") { if (typeof x.title === "string") titles.add(x.title); Object.values(x).forEach(walk); } };
for (const f of readdirSync("/home/user/Taxila/data/curriculum").filter((f) => f.endsWith(".json"))) walk(JSON.parse(readFileSync("/home/user/Taxila/data/curriculum/" + f, "utf8")));
const bad = [...titles].filter((t) => rowProblem(`TODAY ${t}`));
console.log(titles.size, "titles;", bad.length, "rejected"); console.log(bad.slice(0, 25).map((t) => `${t} -> ${rowProblem("TODAY " + t)}`).join("\n"));
