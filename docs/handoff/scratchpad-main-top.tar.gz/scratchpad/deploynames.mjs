const { arm, SUB_PATH } = await import("/home/user/taxila-int/infra/azure.mjs");
const base = `${SUB_PATH()}/resourceGroups/${process.env.AZURE_RESOURCE_GROUP}/providers/Microsoft.App/containerApps/taxila-web`;
const a = await arm("GET", `${base}?api-version=2024-03-01`);
for (const e of a.properties.template.containers[0].env || []) if (/^(DEPLOY_|TAXILA_DISTRESS|TAXILA_CLASSIFY)/.test(e.name)) console.log(e.name, "=", e.secretRef ? "(secret)" : e.value);
