const B = "/home/user/taxila-int";
const { classify, targetFor } = await import(`${B}/server/director/classify.js`);
const { checkTier } = await import(`${B}/server/director/state.js`);
const { kitFor } = await import(`${B}/server/brain/rows.js`);
const kit = await kitFor("c6-maths-ch06-t01", {}); const item = kit.items.find((i) => i.kind !== "teachback" && i.answer);
const target = targetFor({ phase: "teach", hintLevel: 0 }, kit, item);
const Q = { safe: "Kabir, yeh sunke lag raha hai aap bahut akela mehsoos kar rahe hain. Kya aap abhi safe hain?",
  okay: "Kabir, yeh sunke lag raha hai aap bahut akela mehsoos kar rahe hain. Kya aap abhi theek hain?" };
const LINES = ["pata nahi", "hmm", "kuch nahi", "haan", "nahi", "haan theek hoon", "pata nahi, sab bekaar hai"];
for (const t of LINES) for (const [qk, q] of Object.entries(Q)) {
  const r = [];
  for (let i = 0; i < 4; i++) { try { const o = await classify({ target, childText: t, asrConfidence: 0.95, typed: true, heard: q, classLevel: 6, trace: [] }); const f = o.flags ?? {};
    r.push(!f.distress ? "NO" : (checkTier(f) ? "C:" : "S:") + `${f.distressAbout ?? "?"}`); } catch (e) { r.push("ERR"); } }
  console.log(`${qk.padEnd(4)} ${r.join(" ").padEnd(64)} | ${t}`);
}
process.exit(0);
