const e = process.env;
const tok = await (await fetch(`https://login.microsoftonline.com/${e.AZURE_TENANT_ID}/oauth2/v2.0/token`, { method: "POST",
  body: new URLSearchParams({ grant_type: "client_credentials", client_id: e.AZURE_SP_CLIENT_ID, client_secret: e.AZURE_SP_SECRET, scope: "https://management.azure.com/.default" }) })).json();
const arm = async (p) => (await fetch(`https://management.azure.com${p}`, { headers: { authorization: `Bearer ${tok.access_token}` } })).json();
const r = await arm(`/subscriptions/${e.AZURE_SUBSCRIPTION_ID}/providers/Microsoft.CognitiveServices/accounts?api-version=2024-10-01`);
if (r.error) console.log("ERR", r.error.code);
const host = (u) => { try { return new URL(u).host.split(".")[0].toLowerCase(); } catch { return "?"; } };
const lanes = Object.fromEntries(Object.entries(e).filter(([k, v]) => /ENDPOINT/.test(k) && /^https/.test(v ?? "")).map(([k, v]) => [k, host(v)]));
for (const a of r.value ?? []) {
  const sub = String(a.properties?.customSubDomainName ?? "").toLowerCase();
  const used = Object.entries(lanes).filter(([, h]) => h === sub).map(([k]) => k);
  console.log(a.name.padEnd(36), a.location.padEnd(16), a.kind.padEnd(12), used.join(","));
}
console.log("lanes not matched:", Object.entries(lanes).filter(([, h]) => !(r.value ?? []).some((a) => String(a.properties?.customSubDomainName ?? "").toLowerCase() === h)).map(([k]) => k).join(" "));
