import fs from "node:fs";
const P="/home/user/Taxila/data/kits/c1-english.json";
const blind=JSON.parse(fs.readFileSync("/tmp/claude-0/-home-user/ecee9fc1-62f9-5f67-a47d-69ca79d9981a/scratchpad/c1en-blind.json","utf8"));
const kit=JSON.parse(fs.readFileSync(P,"utf8"));
const x="c1-english-";
const notes={
 [x+"ch01-t01-i01"]:"Key correct. Acceptable list includes singular 'eye', which rewards the dropped-plural error (m1) this topic targets; suggest removing it.",
 [x+"ch01-t01-i02"]:"Key correct. Acceptable list includes singular 'ear' (same plural-s concern as i01); suggest removing it.",
 [x+"ch01-t01-i09"]:"Key correct. The rhyme lines are the traditional 'Two Little Hands' rhyme that NCERT Mridang ch1 reprints (public-domain nursery rhyme, order swapped): low risk, but it is the textbook's own text.",
 [x+"ch01-t01-i13"]:"Key correct. Same traditional-rhyme note as i09.",
 [x+"ch03-t01-i13"]:"Key 'crow' depends on the picture, which is not in the kit. The i03 hint ('sitting on the tree in our picture') matches it, so the picture asset must show a crow on the tree.",
 [x+"ch06-t01-i08"]:"Key correct. Acceptable list includes bare 'i like', which passes a sentence with no fruit in it; minor.",
 [x+"ch07-t01-i07"]:"Key correct. Hint 1 (the pump) says ''Eat' is the second word', which gives away where the answer is on the first rung; a pump should not point to it (e.g. 'Listen again: I eat roti').",
 [x+"ch07-t01-i13"]:"Blind solver answered 'rice'; the key is 'rice and fish', and 'rice' is accepted, so they agree. The read-along text is not stored in the kit, so 'fish' cannot be checked against a source.",
 [x+"ch08-t01-i04"]:"Key correct. Hint 2 quotes 'Spring flowers, a pretty sight!', which gives the answer away on the second rung; move that quote to hint 3 or 4.",
 [x+"ch08-t01-i07"]:"Key 'white' agrees. 'light' also rhymes with 'bright' and could fit the line; hint 2 narrows it to a colour. Consider accepting 'light'.",
 [x+"ch09-t01-i06"]:"Cannot be solved blind: Chotu and the pink kite appear in no prompt, worked example or curriculum entry, only in this key and in i12's key. The kit needs the retold story text (e.g. a story field) before this answer can be checked.",
 [x+"ch09-t01-i12"]:"Key's 'Chotu added a pink kite' detail is not in any source in the kit (see i06). The rest is consistent.",
 [x+"ch09-t01-i14"]:"Key correct. Acceptable list lacks 'violet' and 'indigo', which Indian children learn through VIBGYOR; add both.",
 [x+"ch09-t01-i05"]:"Key correct. The NCERT story is 'Anandi's Rainbow'; the kit renames the girl Tara (this avoids copying the text, but a child using the textbook will hear a different name).",
};
const disagree=new Set([x+"ch09-t01-i06"]);
let n=0,ag=0;
for(const t of kit.topics) for(const it of t.items){
  const s=blind[it.id]; if(!s) throw new Error("missing blind "+it.id);
  const agrees=!disagree.has(it.id);
  it.verified={solverAnswer:s,agrees,note:notes[it.id]||"Blind answer matches key; English, class-1 oral/picture register, Hinglish prompt and hint ladder OK."};
  n++; if(agrees) ag++;
}
fs.writeFileSync(P, JSON.stringify(kit,null,2)+"\n");
console.log({n,ag,dis:n-ag});
