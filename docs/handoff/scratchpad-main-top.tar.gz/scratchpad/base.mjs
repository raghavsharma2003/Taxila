import * as C from "/home/user/Taxila/evals/safety-robust/corpora.mjs";
import { scanSafety } from "/home/user/Taxila/server/director/safety.js";
const d = C.taxilaFdbDistress(); console.log("fdb", d.length);
let miss = {}, tot=0, hit=0, hall=0;
for (let k = 0; k < 20; k++) for (const it of d) { const p = C.perturbedText(it, C.seedOf(it.id, k)); tot++; if (p.hallucinated.includes(it.distressSeg)) hall++; if (scanSafety(p.text).distress) hit++; else if (!p.hallucinated.includes(it.distressSeg)) { miss[p.text]=(miss[p.text]||0)+1; } }
console.log({tot,hit,hall}); console.log(Object.entries(miss).sort((a,b)=>b[1]-a[1]).slice(0,40));
let k0=0; for (const it of d) { const p = C.perturbedText(it, C.seedOf(it.id, 0)); if (scanSafety(p.text).distress) k0++; } console.log("seed0", k0);
let k0n=0; for (const it of d) { const p = C.perturbedText(it, C.seedOf(it.id, 0), {punct:false}); if (scanSafety(p.text).distress) k0n++; } console.log("seed0 nopunct", k0n);
console.log("clean", d.filter(it=>scanSafety(C.cleanText(it)).distress).length, d.filter(it=>scanSafety(C.cleanText(it,{punct:false})).distress).length);
const e=C.es3Distress(); console.log("es3 clean", e.filter(it=>scanSafety(C.cleanText(it)).distress).length, e.length);
