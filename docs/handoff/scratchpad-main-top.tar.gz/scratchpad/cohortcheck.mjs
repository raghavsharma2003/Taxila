// READ-ONLY: does each owner-cohort env var on the LIVE taxila-web revision template equal sha256(owner email)?
// Prints only match / differs / unset per name, never a value. usage: node cohortcheck.mjs <email> NAME...
import { createHash } from "node:crypto";
const { arm, loadEnv, SUB_PATH } = await import("/home/user/Taxila/infra/azure.mjs");
loadEnv?.();
const [email, ...names] = process.argv.slice(2);
const want = createHash("sha256").update(email.trim().toLowerCase()).digest("hex");
const app = await arm("GET", `${SUB_PATH()}/resourceGroups/${process.env.AZURE_RESOURCE_GROUP}/providers/Microsoft.App/containerApps/taxila-web?api-version=2024-03-01`);
const env = new Map((app.properties.template.containers[0].env || []).map((e) => [e.name, e.secretRef ? null : (e.value ?? "")]));
console.log(`latest revision: ${app.properties.latestRevisionName}`);
for (const n of names) {
  if (!env.has(n)) { console.log(`${n}: unset`); continue; }
  const v = env.get(n);
  if (v === null) { console.log(`${n}: secretRef`); continue; }
  const parts = v.split(",").map((s) => s.trim()).filter(Boolean);
  console.log(`${n}: ${parts.includes(want) ? "contains the owner hash" : "does NOT contain the owner hash"} (${parts.length} entr${parts.length === 1 ? "y" : "ies"})`);
}
