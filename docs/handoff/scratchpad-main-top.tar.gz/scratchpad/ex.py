import re,html,sys
s=open(sys.argv[1],encoding='utf-8',errors='ignore').read()
m=re.search(r'<article.*?</article>',s,re.S); t=m.group(0) if m else s
t=re.sub(r'<(script|style).*?</\1>','',t,flags=re.S); t=re.sub(r'<br\s*/?>|</p>|</li>|</h\d>','\n',t); t=html.unescape(re.sub(r'<[^>]+>','',t))
print(re.sub(r'\n\s*\n+','\n',t))
