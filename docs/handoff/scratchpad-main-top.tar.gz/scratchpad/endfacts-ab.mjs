// Model-only A/B of the end-record FACTS (14.4.3): the old facts (teachbackPassed always present, no "practised") vs the new.
const B = "/home/user/taxila-1441";
const { chat, DEPLOY } = await import(`${B}/server/azure.js`);
const L = await import(`${B}/server/routes/lesson.js`);
const { kitFor } = await import(`${B}/server/brain/rows.js`);
const K = await kitFor("c6-maths-ch06-t01", {});
const child = { first_name: "Kabir", class_level: 6 }, teacher = { name: "Asha", pronouns: { subject: "she", object: "her" } };
const sk = K.skills[0].id;
const ev = [{ skill_id: sk, item_id: "x", outcome: "correct", hints_used: 0 }, { skill_id: sk, item_id: "y", outcome: "incorrect", hints_used: 1 }];
const base = { topicId: K.topicId, minutes: 9, teachbackAsked: false, teachbackPassed: false, agent: {} };
const scen = {
  ordinary: { state: base, evidence: ev, held: false, turns: [{ text: "50 plus 30 is 80" }, { text: "160" }] },
  safeguarded: { state: { ...base, minutes: 6 }, evidence: [], held: true, turns: [] },
  teachbackPassed: { state: { ...base, teachbackAsked: true, teachbackPassed: true }, evidence: ev, held: false, turns: [{ text: "perimeter matlab boundary ki poori length" }] },
};
const N = Number(process.env.N ?? 5);
const TB = /teach[- ]?back|explain(ed)? (it )?back/i, PRACT = /practi[sc]ed (the )?perimeter|practi[sc]ed .*perimeter|worked on perimeter/i;
for (const [name, sc] of Object.entries(scen)) for (const arm of ["old", "new"]) {
  let tb = 0, pr = 0; const ex = [];
  for (let i = 0; i < N; i++) {
    let facts = L.__test.lessonFacts(sc.state, sc.evidence, K);
    if (arm === "old") { const { teachback, practised, ...rest } = facts; facts = { ...rest, teachbackPassed: sc.state.teachbackPassed }; }
    const { json } = await chat(DEPLOY.fast, L.endMessages({ child, teacher, facts, childTurns: sc.held ? [] : sc.turns, held: sc.held }), { schema: L.END_SCHEMA, schemaName: "lesson_end", effort: "low", maxTokens: 2000, timeoutMs: 25_000, trace: [] });
    const t = `${json.summary} ${json.parentNote}`;
    if (TB.test(t)) tb++; if (PRACT.test(t)) pr++; if (i < 1) ex.push(json.parentNote.slice(0, 220));
  }
  console.log(`${name.padEnd(16)} ${arm} teachbackMention=${tb}/${N} practisedTopic=${pr}/${N} | ${ex[0]}`);
}
process.exit(0);
