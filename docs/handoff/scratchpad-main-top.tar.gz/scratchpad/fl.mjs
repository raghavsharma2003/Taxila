const { floorViolations, neverRuleHits, relationalViolations } = await import(process.cwd() + "/server/director/safety.js");
const { safeguardStayLine } = await import(process.cwd() + "/server/brain/say.js");
for (const lang of ["english", "hinglish", "hindi"]) for (const address of ["tum", "aap"]) {
  const l = safeguardStayLine({ lang, address });
  console.log(lang, address, JSON.stringify(floorViolations(l, { safeguard: true, requireHelpline: true })), JSON.stringify(neverRuleHits(l)), JSON.stringify(relationalViolations(l, {})));
}
