import fs from "fs"; import path from "path";
const keys = new Set(["teacherReply","reply","teacher_text","teacherText","say","assistant"]);
const by = new Map(); const out = new Map();
function visit(o, file){ if(!o||typeof o!=="object") return; if(Array.isArray(o)){o.forEach(x=>visit(x,file));return;}
 for(const [k,v] of Object.entries(o)){ if(keys.has(k)&&typeof v==="string"&&v.length>20){ if(!out.has(v)){out.set(v,file); by.set(file+"|"+k,(by.get(file+"|"+k)||0)+1);} } else visit(v,file);} }
function walk(d){ for (const f of fs.readdirSync(d,{withFileTypes:true})){ const p=path.join(d,f.name); if(f.isDirectory()){ if(f.name==="node_modules")continue; walk(p);} else if(/\.(json|jsonl)$/.test(f.name)&&fs.statSync(p).size<30e6){ const s=fs.readFileSync(p,"utf8"); if(f.name.endsWith(".jsonl")) s.split("\n").forEach(l=>{try{visit(JSON.parse(l),p)}catch{}}); else {try{visit(JSON.parse(s),p)}catch{}} } } }
walk("evals"); walk("docs");
console.log("unique", out.size); [...by].sort((a,b)=>b[1]-a[1]).slice(0,40).forEach(x=>console.log(x[1],x[0]));
