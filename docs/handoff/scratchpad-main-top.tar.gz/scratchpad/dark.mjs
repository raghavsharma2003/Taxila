import { chromium } from "/home/user/Taxila/node_modules/playwright/index.mjs";
const b = await chromium.launch();
const ctx = await b.newContext({ viewport:{width:360,height:640}, colorScheme:"dark" });
const p = await ctx.newPage();
for (const f of ["your_turn","pause","help","summary","T8"]) {
await p.goto(`http://127.0.0.1:5391/dev/desk?fixture=${f}&band=b2`, { waitUntil: "networkidle" });
await p.waitForTimeout(200);
console.log(f, await p.evaluate(() => { const d=document.querySelector('[data-testid=lesson]'); const s=document.querySelector('.dk-sheet,.dk-help,.dk-full'); return [getComputedStyle(document.body).backgroundColor, d&&getComputedStyle(d).backgroundColor, s&&getComputedStyle(s).backgroundColor, d && d.getBoundingClientRect().height]; }));
}
await p.screenshot({path:"/tmp/claude-0/-home-user/ecee9fc1-62f9-5f67-a47d-69ca79d9981a/scratchpad/d.png"});
await b.close();
