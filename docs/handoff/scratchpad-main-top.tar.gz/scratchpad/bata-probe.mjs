const { numberPhrases } = await import("/home/user/taxila-int/server/grading/spoken-number.js");
for (const t of ["2 बता दो", "मुझे बता दो", "एक बटा दो", "एक बता दो", "ek bata do", "mujhe bata do", "answer bata do", "teen bata chaar", "didi mujhe answer bata do na", "aap bata do"]) console.log(JSON.stringify(t), "→", JSON.stringify(numberPhrases(t)));
