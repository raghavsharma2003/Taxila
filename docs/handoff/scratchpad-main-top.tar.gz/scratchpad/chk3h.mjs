import fs from 'fs';
const k=JSON.parse(fs.readFileSync('/home/user/Taxila/data/kits/c3-hindi.json','utf8'));
const items={},diags={};
for(const t of k.topics){for(const i of t.items)items[i.id]=[i,t];for(const d of (t.diagnostics||[]))diags[d.id]=[d,t];}
const show=(id)=>{const x=items[id]||diags[id];console.log('\n==',id);console.log(JSON.stringify(x?x[0]:null,null,1).slice(0,1800));};
for(const id of ['c3-hindi-ch04-t01-i02','c3-hindi-ch13-t01-i08','c3-hindi-ch02-t01-i04','c3-hindi-ch05-t01-i03','c3-hindi-ch05-t01-i02','c3-hindi-ch12-t01-i02','c3-hindi-ch14-t01-i05','c3-hindi-ch15-t01-i04','c3-hindi-ch01-t01-i03','c3-hindi-ch11-t01-i05','c3-hindi-ch14-t01-i08'])show(id);
let bad=0,tot=0;for(const [id,[x]] of Object.entries({...items,...diags})){tot++;if(!x.verified||x.verified.agrees!==true){bad++;console.log('NOTAGREE',id)}}
console.log('total',tot,'notagree',bad);
console.log(Object.keys(diags).filter(d=>!diags[d]).length);
