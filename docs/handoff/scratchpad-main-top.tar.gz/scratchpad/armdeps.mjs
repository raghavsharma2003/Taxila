// Read-only ARM: every Cognitive Services account in the subscription, its deployments with model and capacity. No secrets printed.
const e = process.env;
const tok = await (await fetch(`https://login.microsoftonline.com/${e.AZURE_TENANT_ID}/oauth2/v2.0/token`, { method: "POST",
  body: new URLSearchParams({ grant_type: "client_credentials", client_id: e.AZURE_SP_CLIENT_ID, client_secret: e.AZURE_SP_SECRET, scope: "https://management.azure.com/.default" }) })).json();
const arm = async (p) => (await fetch(`https://management.azure.com${p}`, { headers: { authorization: `Bearer ${tok.access_token}` } })).json();
const accts = (await arm(`/subscriptions/${e.AZURE_SUBSCRIPTION_ID}/providers/Microsoft.CognitiveServices/accounts?api-version=2024-10-01`)).value ?? [];
const want = new RegExp(process.argv[2] ?? ".", "i");
const chatHost = new URL(e.AZURE_OPENAI_ENDPOINT).host.split(".")[0].toLowerCase();
for (const a of accts) {
  const sub = String(a.properties?.customSubDomainName ?? "").toLowerCase();
  const deps = (await arm(`${a.id}/deployments?api-version=2024-10-01`)).value ?? [];
  const hit = deps.filter((d) => want.test(d.name) || want.test(d.properties?.model?.name ?? ""));
  if (!hit.length) continue;
  console.log(`${a.name} (${a.location})${sub === chatHost ? "  <- AZURE_OPENAI_ENDPOINT" : ""}`);
  for (const d of hit) console.log("   ", d.name.padEnd(32), (d.properties?.model?.name ?? "") + "@" + (d.properties?.model?.version ?? ""), d.sku?.name, "cap", d.sku?.capacity, d.properties?.rateLimits?.map((r) => `${r.key}:${r.count}/${r.renewalPeriod}s`).join(" ") ?? "");
}
