const { arm, SUB_PATH } = await import("/home/user/taxila-int/infra/azure.mjs");
const accts = (await arm("GET", `${SUB_PATH()}/providers/Microsoft.CognitiveServices/accounts?api-version=2024-10-01`)).value ?? [];
const a = accts.find((x) => /raghavsharma1729-compan-resource/.test(x.properties?.endpoint ?? "") || /raghavsharma1729-compan-resource/i.test(x.name));
console.log("account:", a?.name, a?.location, a?.kind);
if (!a) process.exit(0);
const span = "2026-10-16T07:30:00Z/2026-10-16T10:30:00Z";
const day = "2026-10-15T11:30:00Z/2026-10-15T14:30:00Z";
for (const [label, ts0] of [["10-16 window", span], ["10-15 (14.3, normal)", day]]) {
  console.log(`== ${label}`);
  for (const names of ["AzureOpenAIRequests", "AzureOpenAITimeToResponse", "Latency", "ServerErrors", "ClientErrors"]) {
    try {
      const r = await arm("GET", `${a.id}/providers/microsoft.insights/metrics?api-version=2023-10-01&metricnames=${names}&timespan=${ts0}&interval=PT15M&aggregation=Average,Maximum,Total`);
      for (const m of r.value ?? []) for (const t of m.timeseries ?? []) { const pts = (t.data ?? []).filter((d) => (d.maximum ?? d.total ?? d.average ?? 0) > 0); if (pts.length) console.log(` ${m.name.value}: ` + pts.map((d) => `${d.timeStamp.slice(11, 16)} max ${Math.round(d.maximum ?? 0)} avg ${Math.round(d.average ?? 0)} tot ${Math.round(d.total ?? 0)}`).join(" | ")); }
    } catch (e) { console.log(` ${names}: n/a`); }
  }
}
