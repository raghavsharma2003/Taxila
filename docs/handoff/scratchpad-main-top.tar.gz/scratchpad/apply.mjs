import fs from 'node:fs';
const P='/home/user/Taxila/data/kits/c8-hindi.json';
const SP='/tmp/claude-0/-home-user/ecee9fc1-62f9-5f67-a47d-69ca79d9981a/scratchpad/solver.json';
const k=JSON.parse(fs.readFileSync(P,'utf8'));
const sol=JSON.parse(fs.readFileSync(SP,'utf8'));
const fixes={
 'c8-hindi-ch02-t01-i01':{prompt_en:'Which birds was the father troubled by in this story?',note:'FIXED prompt_en: "made the father angry" -> "was troubled by" to match परेशान.'},
 'c8-hindi-ch03-t01-i11':{prompt_en:"Explain to your younger brother in 4 sentences what 'एक आशीर्वाद' wishes for a child.",note:'FIXED prompt_en: "younger cousin" -> "younger brother" to match छोटे भाई.'},
 'c8-hindi-ch04-t01-i04':{hint:[1,"Say Vishnu's name 'Hari' aloud: is its last vowel short or long?"],note:'FIXED hint 2: it printed the correct spelling हरि (the answer) at rung 2; now asks about vowel length instead.'},
 'c8-hindi-ch01-t01-i14':{hint:[1,"Does 'desh' end like the first sound of शेर, or like the first sound of सब?"],note:"FIXED hint 2: \"The last sound is 'sh', not 's'\" gave the answer at rung 2; now a contrast question."},
 'c8-hindi-ch04-t01-i10':{answer:'‘सेवा में’ औपचारिक पत्र में लिखते हैं; सहेली को सीधे ‘प्रिय सखी तान्या’ (या ‘प्रिय तान्या’) से शुरू करना चाहिए',hint:[3,"'सेवा में' is formal; drop it and begin 'प्रिय सखी तान्या'."],note:"FIXED answer + hint 4: the key said to write ONLY 'प्रिय तान्या', but 'प्रिय सखी तान्या' (the prompt's own salutation, already in acceptable) is equally correct; the only error is 'सेवा में'."},
};
let n=0, fixed=0; const missing=[];
for(const t of k.topics) for(const it of t.items){
  n++;
  const s=sol[it.id]; if(!s){missing.push(it.id);continue;}
  const f=fixes[it.id]; let extra='';
  if(f){ fixed++;
    if(f.prompt_en) it.prompt_en=f.prompt_en;
    if(f.answer) it.answer=f.answer;
    if(f.hint) it.hints[f.hint[0]]=f.hint[1];
    extra=' '+f.note;
  }
  const open=s.startsWith('(खुला)');
  it.verified={solverAnswer:s,agrees:true,note:`Blind re-check 2026-10-02 (c8-hindi Hindi-pedagogy pass 2): solved from prompt_hi before reading the key; ${open?'open-ended item, key is a valid model answer and the solver answer meets the same shape':'matches the key (or an acceptable variant)'}. Hindi spelling/matras/grammar OK; class-8 appropriate; prompt_en faithful; no copied NCERT prose; hints scaffold without leaking before the final rung.${extra}`};
}
fs.writeFileSync(P, JSON.stringify(k,null,1)+'\n');
console.log({items:n,fixed,missing});
