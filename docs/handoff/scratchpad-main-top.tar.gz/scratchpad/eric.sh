#!/bin/bash
q=$(python3 -c "import urllib.parse,sys;print(urllib.parse.quote(sys.argv[1]))" "$1")
n=${2:-4}
curl -sS --max-time 40 "https://api.ies.ed.gov/eric/?search=$q&format=json&rows=$n&fields=id,title,author,publicationdateyear,source,description,url" | python3 -c "
import json,sys
d=json.load(sys.stdin)
for r in d.get('response',{}).get('docs',[]):
    print('##',r.get('id'),'|',', '.join(r.get('author',[])[:4]),'|',r.get('publicationdateyear'),'|',r.get('source'))
    print('T:',r.get('title'))
    print('A:',(r.get('description') or '')[:1500])
    print()
"
