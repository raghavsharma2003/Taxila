// Starts the real API on the TEST branch and drives the parent report routes as a guardian would.
import { readFileSync } from "fs";
const ROOT = "/home/user/Taxila/";
const env = Object.fromEntries(readFileSync(ROOT + ".env.local", "utf8").split("\n").map((l) => l.match(/^([A-Z0-9_]+)=(.*)$/)).filter(Boolean).map((m) => [m[1], m[2].replace(/^"(.*)"$/, "$1")]));
for (const [k, v] of Object.entries(env)) if (!process.env[k]) process.env[k] = v;
const host = (u) => new URL(u).hostname.replace(/-pooler\./, ".");
if (host(env.CONDUCTOR_TEST_DATABASE_URL) === host(env.DATABASE_URL)) throw new Error("not a test branch");
process.env.DATABASE_URL = env.CONDUCTOR_TEST_DATABASE_URL;
const http = await import("http");
const { handle } = await import(ROOT + "server/index.js");
const { q, one } = await import(ROOT + "server/db.js");
const PORT = process.argv.includes("--serve") ? 8790 : 8791;
const srv = http.createServer(handle).listen(PORT);
let cookie = "";
const call = async (method, path, body) => {
  const r = await fetch(`http://localhost:${PORT}` + path, { method, headers: { "content-type": "application/json", cookie }, body: body ? JSON.stringify(body) : undefined });
  const sc = r.headers.get("set-cookie"); if (sc) cookie = sc.split(";")[0];
  const ct = r.headers.get("content-type") || "";
  return { status: r.status, body: ct.includes("json") ? await r.json() : await r.arrayBuffer().then((b) => b.byteLength) };
};
const email = `reports-ui+${Date.now()}@test.invalid`;
console.log("signup", (await call("POST", "/api/auth/signup", { email, password: "testpass123", name: "UI Test", isGuardianAdult: true })).status);
console.log("pin", (await call("POST", "/api/parent/pin", { pin: "4826" })).status);
console.log("unlock", (await call("POST", "/api/parent/unlock", { pin: "4826" })).status);
const g = await one("select id from guardian where email = $1", [email]);
// adopt the latest simulated child (test data) for this guardian, with consent
const kid = await one(`select c.id, c.first_name from child c join guardian gg on gg.id = c.guardian_id where gg.email like 'reports-sim+%' and c.first_name = 'Meher' order by c.created_at desc limit 1`);
await q("update child set guardian_id = $1 where id = $2", [g.id, kid.id]);
await q("insert into consent (guardian_id, child_id, purpose, version, granted, method) values ($1, null, 'core_tutoring', 't', true, 't'), ($1, null, 'memory', 't', true, 't')", [g.id]);
const list = await call("GET", `/api/parent/reports?childId=${kid.id}`);
console.log("reports", list.status, list.body.reports?.length, list.body.lang, list.body.today);
const weekly = list.body.reports.find((r) => r.cadence === "weekly");
const rep = await call("GET", `/api/parent/report?childId=${kid.id}&id=${weekly.id}`);
console.log("report", rep.status, rep.body.report?.renders?.en?.lines?.map((l) => l.section).join(","));
const tricky = rep.body.report.renders.en.lines.find((l) => l.section === "tricky");
const ev = await call("GET", `/api/parent/report/evidence?childId=${kid.id}&id=${weekly.id}&claimId=${encodeURIComponent(tricky.claimId)}`);
console.log("evidence", ev.status, ev.body.evidence?.length, JSON.stringify(ev.body.evidence?.[0]), ev.body.claim?.rule);
const hdr = rep.body.report.renders.en.lines.find((l) => l.section === "header");
const evh = await call("GET", `/api/parent/report/evidence?childId=${kid.id}&id=${weekly.id}&claimId=${encodeURIComponent(hdr.claimId)}`);
console.log("header evidence lessons", evh.body.lessons?.length);
const pv = await call("GET", `/api/parent/report?childId=${kid.id}&cadence=daily&period=2026-09-22&preview=1`);
console.log("preview", pv.status, pv.body.report?.preview, pv.body.report?.renders?.hi?.lines?.length);
const pvt = await call("GET", `/api/parent/report?childId=${kid.id}&cadence=daily&preview=1`);
console.log("preview today", pvt.status, pvt.body.skipped ?? "has report");
// another guardian's child id → 403/404, never data
const other = await one(`select c.id from child c join guardian gg on gg.id = c.guardian_id where gg.email like 'reports-sim+%' order by c.created_at desc limit 1`);
console.log("foreign child", (await call("GET", `/api/parent/reports?childId=${other.id}`)).status);
console.log("bad claim", (await call("GET", `/api/parent/report/evidence?childId=${kid.id}&id=${weekly.id}&claimId=row:row.work:0000000000`)).status);
if (process.argv.includes("--tts")) console.log("speak bytes", JSON.stringify(await call("GET", `/api/parent/speak?what=report&childId=${kid.id}&id=${weekly.id}&lang=hi`)));
console.log(JSON.stringify({ email, childId: kid.id, weeklyId: weekly.id, cookie }));
if (!process.argv.includes("--serve")) { srv.close(); process.exit(0); }
