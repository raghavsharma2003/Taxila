process.env.DATABASE_URL = process.env.TEST_DATABASE_URL;
const { q } = await import("/home/user/taxila-1441/server/db.js");
const rows = (r) => r.rows ?? r;
await q("begin read only");
const f = rows(await q(`select data->>'promptId' pid, data->>'status' st, count(*)::int n from trace_event where t > now() - interval '14 days' and kind = 'model.call' and data->>'promptId' ilike '%distress%' group by 1,2 order by 3 desc limit 15`));
console.log(f);
const g = rows(await q(`select data->>'status' st, left(data->>'output', 120) o from trace_event where t > now() - interval '14 days' and kind = 'model.call' and data->>'promptId' ilike '%distress%' and data->>'status' <> '200' limit 6`));
console.log(g);
await q("rollback"); process.exit(0);
