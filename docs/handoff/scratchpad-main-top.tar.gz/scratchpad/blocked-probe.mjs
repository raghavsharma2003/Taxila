// Model-only (TEST routing): re-probe each failed-closed turn's child words (probeWords: last 4 + this one) under the reply
// probe brief; prints counts and the clear ones' last child line (TEST accounts' words) for a human read.
import { readFileSync } from "node:fs";
const { childWordsTrip, probeWords } = await import("/home/user/taxila-int/server/brain/say.js");
const d = JSON.parse(readFileSync(process.argv[2], "utf8"));
const tally = { clear: 0, harm: 0, unknown: 0 }; const clear = [];
for (const r of d) {
  const hist = r.texts.slice(0, -1).map((x) => ({ who: "child", text: x.text }));
  const last = r.texts.at(-1).text;
  const p = await childWordsTrip(probeWords(hist, last));
  tally[p]++;
  if (p !== "clear") console.log("  " + p.toUpperCase(), r.sid.slice(0, 8), "t" + r.turn + ":", r.texts.map((x) => x.text.slice(0, 120)).join(" || "));
  if (p === "clear") clear.push(`${r.sid.slice(0, 8)} #${r.turn}: ${last.slice(0, 150)}`);
}
console.log(tally); for (const c of clear) console.log("  CLEAR", c);
process.exit(0);
