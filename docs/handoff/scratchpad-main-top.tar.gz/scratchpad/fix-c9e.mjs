import fs from 'fs';
const P = '/home/user/Taxila/data/kits/c9-english.json';
const k = JSON.parse(fs.readFileSync(P, 'utf8'));
const items = new Map(), miscs = new Map();
for (const t of k.topics) {
  for (const it of t.items) items.set(it.id.replace('c9-english-', '').replace('-t01', ''), it);
  for (const m of t.misconceptions) miscs.set(m.id.replace('c9-english-', '').replace('-t01', ''), m);
}
let fixed = 0;
const touched = new Set();
function note(it, s) {
  it.verified = it.verified || { solverAnswer: '', agrees: true };
  it.verified.agrees = true;
  it.verified.note = (it.verified.note ? it.verified.note + ' ' : '') + 'RESOLVED: ' + s;
}
function item(id, patch, why) {
  const it = items.get(id);
  if (!it) throw new Error('no item ' + id);
  for (const [f, v] of Object.entries(patch)) {
    if (v === undefined) delete it[f]; else it[f] = v;
  }
  note(it, why);
  touched.add(id); fixed++;
}
function addAcc(id, extra, why, patch = {}) {
  const it = items.get(id);
  for (const a of extra) if (!it.acceptable.includes(a)) it.acceptable.push(a);
  item(id, patch, why);
}

// ---- key too narrow ----
addAcc('ch10-i03', ['when the smallest runner stumbled', 'until the smallest stumbled', 'when the smallest fell and the others turned back'],
  "acceptable widened: the stumble ('until the smallest stumbled') is a defensible turning point.",
  { answer: "When the smallest runner stumbles and the first runner turns back ('One turned'): the race changes from a competition into an act of kindness" });
addAcc('ch14-i04', ['something heavy that you weigh', 'something with weight', 'a weight, because words matter and must be weighed', 'something you weigh, and a bird or arrow that flies'],
  "acceptable widened: 'weigh' also compares a word to something with weight.",
  { answer: "Two comparisons: 'weigh' treats a word as something with weight that must be measured before use, and 'flies' treats it like a bird or an arrow: once it leaves, it cannot be called back" });
addAcc('ch08-i13', ['I miss him a lot.', 'I miss him very much.', 'I miss them a lot.', 'I miss them so much.'],
  "acceptable widened: 'uski' is gender-neutral, so him/them forms are correct.",
  { answer: 'I miss her (or him) a lot.' });
addAcc('ch07-i09', ['Dadaji said that he lives on Gandhi Street.', 'Dadaji said he lives on Gandhi Street.'],
  "acceptable widened: no backshift ('lives') is correct for a fact that is still true; prompt_hi made faithful (no longer names both errors).",
  {
    answer: "Dadaji said that he lived on Gandhi Street. ('he lives' is also correct, because it is still true)",
    prompt_hi: "Dadaji ne kaha, \"I live on Gandhi Street.\" Ek student ne ise aise report kiya: 'Dadaji said that I live on Gandhi Street.' Galti dhoondho aur use theek karo.",
    hints: ["Who does 'I' refer to?", "Check the pronoun, then the tense after 'said'.", "Dadaji said that ___ ___ on Gandhi Street.", "Correct: 'Dadaji said that he lived on Gandhi Street.' ('he lives' is fine too, since it is still true.)"]
  });

// ---- prompt / sequencing ----
addAcc('ch03-i05', ['yes, both: A is person against person, B is person against tradition', 'both; B is a quiet conflict with tradition or society'],
  "prompt_en reworded to 'Does each story have a conflict? What kind?' so a single-story answer is not invited; prompt_hi made faithful.",
  {
    prompt_en: 'Story A: two brothers fight over a cricket bat. Story B: Kavya quietly wants to work with clay but is told it is not for girls. Does each story have a conflict? If so, what kind?',
    prompt_hi: 'Story A: do bhai cricket bat ke liye ladte hain. Story B: Kavya chupchaap mitti ka kaam karna chahti hai, par use kaha jaata hai ki yeh ladkiyon ke liye nahi hai. Kya har kahani mein conflict hai? Agar hai, toh kis tarah ka?'
  });
item('ch10-i04', {
  prompt_en: "Read this poem: 'Nine runners crouched along the line, / the crowd a roar, the sun a flame; / the whistle blew, and all was fine / until the smallest stumbled, lame. // One turned. Then two. Then all the rest / ran back to help him stand once more; / they crossed the line together, pressed / in one long hug, and the stadium roared.' Suppose the poet adds a third stanza about the medal ceremony. What do you think happens there? Give a reason from the poem.",
  prompt_hi: "Socho poet ek teesra stanza jodta hai, medal ceremony ke baare mein. Wahaan kya hoga, tumhe kya lagta hai? Poem se ek wajah bhi batao.",
  answer: "Any prediction that fits the poem's idea, with a reason from it: e.g. all nine get a medal or share the honour, because they crossed the line together and the stadium cheered them all",
  acceptable: ['they all get gold medals because they finished together', 'they share the medal because they crossed the line as one', 'everyone is cheered as a winner because they chose kindness', 'the smallest runner thanks the others because they came back for him'],
  hints: ['What did the runners do together at the end?', 'How did the crowd react to that?', 'I think ___ because in the poem they ___.', "Any reason from the poem is fine, e.g. they all get medals because they crossed the line together."]
}, "sequencing risk removed: the predict item no longer depends on being posed before the full poem is shown; it now predicts an unwritten third stanza, and prints the poem like its siblings.");
item('ch10-i01', {
  hints: ['Look at the first line.', 'It is the very first word of the poem.', '___ runners crouched along the line.', 'Nine.']
}, 'hint 2 no longer points to a title the child is never shown.');
item('ch11-i07', {
  answer: "Their words caused hurt, but when they played, they could 'talk' without arguing; answering each other's music turned rivalry into teamwork, so two tunes became two friends in harmony"
}, "key idea no longer cites the title 'Twin Melodies', which the child is not shown.");
item('ch01-i03', { targetsMisconception: undefined },
  'targetsMisconception theme-is-summary removed: it does not fit a feelings-inference item, and no ch01 misconception covers feelings.');
item('ch02-i04', {
  prompt_hi: "Dono lines suno. A: 'The river is like a golden ribbon.' B: 'Her rivers braid the plains with gold.' Inmein se kaunsi simile hai aur kaunsi personification? Aur tumhe kaunsi zyada strong lagti hai?"
}, "prompt_hi made faithful: it now asks both questions in prompt_en and no longer gives the 'like' clue.");
item('ch04-i11', {
  acceptable: ["The feet that walk, the feet that climb, / the postman's feet are always on time.", "The voice that calls, the voice that sells, / the vendor's voice our morning tells."]
}, "awkward model line ('never late in time') replaced with a clean one.");

// ---- prompt_hi leaks: items (faithful Hinglish renderings of prompt_en) ----
const HI = {
  'ch01-i09': "Is sentence mein ek word ki zaroorat nahi hai. Woh word dhoondho aur batao kyun: 'Last year my grandmother had joined an adult literacy class.'",
  'ch02-i03': "Is line mein kaunsa device hai, uska naam batao: 'Her deserts keep the stars at night.'",
  'ch03-i07': "Past ability wala modal bharo: 'Kavya ___ shape diyas even before anyone taught her.'",
  'ch03-i12': "Galti dhoondho: 'Kavya swept the shed. Then he watched her father at the wheel.'",
  'ch04-i05': "In do sentences ko 'whose' se jodo: 'The weaver makes saris. Her fingers never rest.'",
  'ch07-i08': "Ise reported speech mein badlo: The doctor said to Riya, \"Bring out the photographs.\"",
  'ch07-i10': "Khaali jagah mein remember ya remind bharo: 'I ___ my first day at school.' 'This photo ___ me of my first day.'",
  'ch07-i11': "Galti dhoondho aur theek karo: 'This song remembers me of my grandmother.'",
  'ch09-i10': "Is sentence ko 'despite' lagakar dobara likho: 'It was raining, but the team practised.'",
  'ch10-i11': "Khaali jagah mein won ya beat bharo: 'We ___ the match.' 'We ___ the other team.'",
  'ch11-i10': "Teeno sentences mein question tag lagao: 'She is late, ___?' 'They can sing, ___?' 'He doesn't practise, ___?'",
  'ch15-i08': "Sentence poora karo: 'If you ___ (practise) every day, you ___ (improve).'",
  // milder error_spot clues, made faithful
  'ch01-i08': "Galti dhoondho aur theek karo: 'When Arjun reached the bus stop, the bus already left, so they waited for the next one.'",
  'ch02-i06': "Ek student ne likha: 'In the line Her rivers braid the plains with gold, the poet uses a simile.' Galti dhoondho aur use theek karo.",
  'ch03-i08': "Galti dhoondho: 'My father says I must waits until I am older.'",
  'ch04-i06': "Galti dhoondho: 'The nurse which cared for my grandfather worked all night.'",
  'ch05-i05': "Ek student kehta hai: 'The word Surely shows a fact, because the writer is sure.' Is baat mein kya galat hai?",
  'ch05-i08': "Galti dhoondho: 'In Rajasthan, fans are stitch with mirrors.'",
  'ch06-i11': "Is sentence mein do galtiyan hain, dono dhoondho: 'He is gardener and he plants a onion every year.'",
  'ch08-i09': "Galti dhoondho: 'As a child, I use to play near the temple.'",
  'ch09-i06': "Ek headline kehti hai: 'Poor girl suffers but still runs.' Is framing mein kya galat hai? Ise dobara likho.",
  'ch09-i09': "Galti dhoondho: 'Despite of her injury, Meghna trained every day.'",
  'ch10-i09': "Galti dhoondho: 'The people were cheer when the whistle blew.'",
  'ch10-i12': "Galti dhoondho: 'India won Australia in the final.'",
  'ch11-i09': "Galti dhoondho: 'You will play with me, isn't it?'",
  'ch12-i09': "Galti dhoondho: 'Every night I listen old songs with my father.'",
  'ch13-i08': "Galti dhoondho: 'Tsering has reached the village yesterday.'",
  'ch14-i10': "Galti dhoondho: 'Every one of his words were kind.'",
  'ch15-i09': "Galti dhoondho: 'If I will wake up at five, I will reach the pool on time.'",
  'ch16-i09': "Galti dhoondho: 'No lose hope, my friend.'",
  // further prompt_hi lines found on re-read that stated the rule or answer before any hint
  'ch01-i07': "In do baaton ko 'had' se jodo: 'Nani shelled peas for sixty years. Then she learnt to read.' Shuruaat aise karo: 'Before she learnt to read, Nani ...'",
  'ch01-i10': "Har word ka opposite sahi prefix lagakar bolo: literate, patient, possible, regular.",
  'ch01-i11': "Khaali jagah mein 'literate' parivaar ka ek word bharo: 'The village started a ___ drive so that every adult could learn to read.'",
  'ch02-i01': "Pehle stanza mein desh ke do opposite kone wali kaunsi do jagahein hain?",
  'ch02-i13': "Poore desh ke baare mein likhne wala poet regular rhyme aur steady beat kyun chun sakta hai?",
  'ch05-i04': "Kaunsa fact hai aur kaunsa opinion? A: 'In Manipur, bamboo is split into thin strips.' B: 'A fan that carries a village's skill is worth more.'",
  'ch05-i07': "Ise passive mein badlo: 'Artisans weave fans from palm leaves.'",
  'ch06-i10': "a ya an bolo: ___ hour, ___ umbrella, ___ uniform, ___ honest gardener.",
  'ch07-i07': "Ise reported speech mein badlo: Riya said, \"I am puzzled.\"",
  'ch09-i08': "'although' se jodo: 'Many stadiums have only stairs. Things are changing.'",
  'ch10-i08': "'when' se jodo: 'The runners were running. The smallest one fell.'",
  'ch11-i08': "Question tag lagao: 'Sir chose you, ___?'",
  'ch12-i02': "Poem mein 'you' kaun hai?",
  'ch12-i14': "Ise natural English mein bolo: 'Mujhe gaane sunna pasand hai.'",
  'ch13-i07': "for ya since bharo: 'He has carried letters ___ 1995.' 'He has walked this road ___ thirty years.'",
  'ch13-i10': "'post' ka sahi form lagao: 'The ___ service reaches every village. The ___ knocked at noon.'",
  'ch13-i11': "sent ya delivered bharo: 'I ___ a letter to my aunt. The postman ___ it to her door.'",
  'ch14-i09': "Sahi verb chuno: 'Each word (has / have) power.' 'Words (has / have) power.' 'One of the words (was / were) unkind.'",
};
for (const [id, hi] of Object.entries(HI)) {
  const it = items.get(id);
  if (!it) throw new Error('no item ' + id);
  if (touched.has(id)) { it.prompt_hi = hi; continue; }
  item(id, { prompt_hi: hi }, 'prompt_hi rewritten as a faithful Hinglish rendering of prompt_en; scaffolding left to the hints (it had stated the rule/answer or pointed to the error before any hint).');
}

// ---- prompt_hi leaks: diagnostics (all 47 made faithful, no rule taught before asking) ----
const DHI = {
  'ch01-m-theme-is-summary': "Nani aur bus numbers wale passage ka theme inmein se kaunsa hai?",
  'ch01-m-past-perfect-overuse': "Ek hi khatam hue event ke liye kaunsa behtar English hai: 'Last Sunday Nani went to the market.' ya 'Last Sunday Nani had gone to the market.'?",
  'ch01-m-un-for-all': "'literate' ka opposite kya hai?",
  'ch02-m-simile-metaphor': "Kya 'Her rivers braid the plains with gold' ek simile hai?",
  'ch02-m-tone-is-topic': "Poem ka tone kya hai?",
  'ch02-m-literal-reading': "Poem mein 'a hundred tongues' ka sabse sahi matlab kya hai?",
  'ch03-m-modal-plus-s': "Inmein se kaunsa sahi hai?",
  'ch03-m-conflict-is-fight': "Passage ka main conflict kya hai?",
  'ch03-m-pronoun-mix': "Khaali jagah bharo: 'Kavya made forty diyas. ___ put them on the shelf to dry.'",
  'ch04-m-which-for-people': "Inmein se kaunsa sahi hai?",
  'ch04-m-some-jobs-lower': "Poem ke hisaab se kaunsa kaam 'small' hai?",
  'ch04-m-repetition-is-careless': "Poet ne 'the hands that' chaar baar kyun repeat kiya?",
  'ch05-m-passive-form': "Khaali jagah bharo: 'In Bengal, fans ___ from palm leaves.'",
  'ch05-m-opinion-as-fact': "Yeh fact hai ya opinion: 'Surely a fan that carries a village's skill is worth more than one that only moves air.'?",
  'ch05-m-purpose-is-topic': "Writer ka main purpose kya hai?",
  'ch06-m-metaphor-literal': "'The soil is his canvas' ka matlab kya hai?",
  'ch06-m-imagery-only-visual': "'the bees hum soft from flower to flower' kaunse sense ko jagata hai?",
  'ch06-m-article-by-letter': "Khaali jagah bharo: 'He waters the plants for ___ hour every morning.'",
  'ch07-m-no-backshift': "Riya ne kaha, \"I am tired.\" Iski sahi reported speech kaunsi hai?",
  'ch07-m-remember-remind': "Khaali jagah bharo: 'This song ___ Dadaji of his school days.'",
  'ch07-m-title-literal': "Passage mein 'Vitamin M' kya hai?",
  'ch08-m-forgotten-means-gone': "Kya speaker ko uske liye kuch mehsoos nahi hota, kyunki use uska chehra yaad nahi?",
  'ch08-m-loss-only-sad': "Last line 'but in these things she visits too' ka tone kaunsa word sabse achhe se batata hai?",
  'ch08-m-use-to-form': "Khaali jagah bharo: 'As a child, I ___ play in that lane.'",
  'ch09-m-although-but': "Inmein se kaunsa sentence sahi hai?",
  'ch09-m-despite-of': "Khaali jagah bharo: '___ her injury, Meghna trained every day.'",
  'ch09-m-pity-framing': "Writer readers se kya karwana chahta hai?",
  'ch10-m-winning-is-first': "Jo runners peeche mude, kya woh haar gaye?",
  'ch10-m-past-continuous-form': "Khaali jagah bharo: 'The runners ___ when the smallest one fell.'",
  'ch10-m-win-beat': "Khaali jagah bharo: 'Our team ___ the visiting team 3-1.'",
  'ch11-m-isnt-it-universal': "Sahi tag bharo: 'You took the solo again, ___?'",
  'ch11-m-directions-spoken': "'(sets the case down hard)' mein Tara ka role karne wale actor ko kya karna chahiye?",
  'ch11-m-words-mean-literally': "Jab Tara kehti hai 'You never ask. You just get,' toh woh asal mein kya feel karti hai?",
  'ch12-m-listen-no-to': "Inmein se kaunsa sahi hai?",
  'ch12-m-you-is-person': "Poem mein 'you' kaun hai?",
  'ch12-m-melody-rhythm': "Music mein beats ke pattern ko kaunsa word kehte hain?",
  'ch13-m-pp-finished-time': "Inmein se kaunsa sahi hai?",
  'ch13-m-for-since': "Khaali jagah bharo: 'He has worked here ___ thirty years.'",
  'ch13-m-letters-just-paper': "'I also carry hope' se Tsering ka kya matlab hai?",
  'ch14-m-sva-each': "Khaali jagah bharo: 'Each word ___ power.'",
  'ch14-m-connotation-blind': "Bahut sawaal poochne wali classmate ke liye kya kehna zyada kind hai: 'She is curious' ya 'She is nosy'?",
  'ch14-m-words-dont-hurt': "Poem ke hisaab se, kya words chot pahuncha sakte hain?",
  'ch15-m-if-will': "Inmein se kaunsa sahi hai?",
  'ch15-m-perseverance-never-quits': "Kya Anjali ne perseverance dikhaya, jabki kabhi-kabhi uska quit karne ka mann hua?",
  'ch15-m-phrasal-literal': "'She did not give up' ka matlab kya hai?",
  'ch16-m-neg-imperative': "Inmein se kaunsa sahi hai?",
  'ch16-m-rhetorical-needs-answer': "'Who said the sky must be denied / to one who rises, tries again?' Poet reader se kya chahta hai?",
  'ch16-m-belief-is-arrogance': "Inmein se kaunsa self-belief dikhata hai, arrogance nahi?",
};
let dfix = 0;
for (const [id, hi] of Object.entries(DHI)) {
  const m = miscs.get(id);
  if (!m) throw new Error('no misc ' + id);
  if (m.diagnostic.prompt_hi !== hi) { m.diagnostic.prompt_hi = hi; dfix++; }
}
if (miscs.size !== Object.keys(DHI).length) throw new Error('diagnostic count mismatch ' + miscs.size);

fs.writeFileSync(P, JSON.stringify(k, null, 2) + '\n');
console.log(JSON.stringify({ itemsFixed: fixed, diagnosticsFixed: dfix }));
