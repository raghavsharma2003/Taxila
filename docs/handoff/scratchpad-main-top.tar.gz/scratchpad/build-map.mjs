// Builds docs/research/content/science-engine-map.json and checks every topic id against data/curriculum.
// p = primary engine scene, s = supporting; g:<kind> = generic module (not a simulation engine) is the better fit.
import fs from "node:fs";
const CUR = "/home/user/Taxila/data/curriculum";
const OUT = "/home/user/Taxila/docs/research/content/science-engine-map.json";
const files = ["c3-evs", "c4-evs", "c5-evs", "c6-science", "c7-science", "c8-science", "c9-science"];

const M = {
  // ---- Class 3 EVS
  "c3-evs-ch01-t01": "g:story", "c3-evs-ch01-t02": "g:story", "c3-evs-ch02-t01": "g:story", "c3-evs-ch02-t02": "g:scenario",
  "c3-evs-ch03-t01": "g:map", "c3-evs-ch03-t02": "g:sorter",
  "c3-evs-ch04-t01": "g:label-diagram", "c3-evs-ch04-t02": "g:sorter",
  "c3-evs-ch05-t01": "p:ecosystem/tree-survey", "c3-evs-ch05-t02": "p:ecosystem/soil-life",
  "c3-evs-ch06-t01": "p:ecosystem/depend", "c3-evs-ch06-t02": "g:scenario",
  "c3-evs-ch07-t01": "p:water-cycle/home-supply", "c3-evs-ch07-t02": "s:water-cycle/home-supply",
  "c3-evs-ch08-t01": "g:sorter", "c3-evs-ch08-t02": "g:sorter",
  "c3-evs-ch09-t01": "g:scenario", "c3-evs-ch09-t02": "g:spot-the-hazard",
  "c3-evs-ch10-t01": "g:sorter", "c3-evs-ch10-t02": "p:optics/materials",
  "c3-evs-ch11-t01": "g:sequence", "c3-evs-ch11-t02": "g:pattern",
  "c3-evs-ch12-t01": "g:sorter", "c3-evs-ch12-t02": "g:sorter",
  // ---- Class 4 EVS
  "c4-evs-ch01-t01": "g:story", "c4-evs-ch01-t02": "g:story", "c4-evs-ch02-t01": "g:map", "c4-evs-ch02-t02": "g:story",
  "c4-evs-ch03-t01": "g:label-diagram", "c4-evs-ch03-t02": "p:ecosystem/farm-chain",
  "c4-evs-ch04-t01": "g:story", "c4-evs-ch04-t02": "g:sorter",
  "c4-evs-ch05-t01": "g:thali-builder", "c4-evs-ch05-t02": "g:label-reader",
  "c4-evs-ch06-t01": "g:story", "c4-evs-ch06-t02": "g:sequence",
  "c4-evs-ch07-t01": "p:float-sink/kitchen-tub", "c4-evs-ch07-t02": "p:motion-lab/spinner",
  "c4-evs-ch08-t01": "g:sequence", "c4-evs-ch08-t02": "g:sorter",
  "c4-evs-ch09-t01": "g:map", "c4-evs-ch09-t02": "g:map",
  "c4-evs-ch10-t01": "p:sky/shadow-stick", "c4-evs-ch10-t02": "p:sky/phases",
  // ---- Class 5 EVS
  "c5-evs-ch01-t01": "p:water-cycle/distribution", "c5-evs-ch01-t02": "p:plant-lab/transport",
  "c5-evs-ch02-t01": "p:water-cycle/river", "c5-evs-ch02-t02": "s:water-cycle/landcover",
  "c5-evs-ch03-t01": "g:time-lapse", "c5-evs-ch03-t02": "g:sorter",
  "c5-evs-ch04-t01": "g:scenario", "c5-evs-ch04-t02": "g:spot-the-hazard",
  "c5-evs-ch05-t01": "g:map", "c5-evs-ch05-t02": "g:story",
  "c5-evs-ch06-t01": "g:map", "c5-evs-ch06-t02": "g:scenario",
  "c5-evs-ch07-t01": "p:motion-lab/energy-chain", "c5-evs-ch07-t02": "s:circuits/energy-meter",
  "c5-evs-ch08-t01": "g:sequence", "c5-evs-ch08-t02": "g:story",
  "c5-evs-ch09-t01": "p:sky/daynight", "c5-evs-ch09-t02": "p:sky/seasons",
  "c5-evs-ch10-t01": "s:water-cycle/cycle", "c5-evs-ch10-t02": "g:scenario",
  // ---- Class 6 Curiosity
  "c6-science-ch01-t01": "g:story", "c6-science-ch01-t02": "p:harness/investigation",
  "c6-science-ch02-t01": "g:sorter", "c6-science-ch02-t02": "g:label-diagram", "c6-science-ch02-t03": "g:habitat-match",
  "c6-science-ch02-t04": "p:ecosystem/vulture",
  "c6-science-ch03-t01": "g:sorter", "c6-science-ch03-t02": "p:indicator-lab/food-tests", "c6-science-ch03-t03": "g:thali-builder",
  "c6-science-ch03-t04": "g:map",
  "c6-science-ch04-t01": "p:magnets/test-tray", "c6-science-ch04-t02": "p:magnets/poles", "c6-science-ch04-t03": "p:magnets/compass",
  "c6-science-ch05-t01": "p:measure-lab/ruler", "c6-science-ch05-t02": "p:measure-lab/thread", "c6-science-ch05-t03": "p:motion-lab/motion-types",
  "c6-science-ch06-t01": "p:measure-lab/material-tester", "c6-science-ch06-t02": "g:sorter",
  "c6-science-ch07-t01": "p:measure-lab/three-bowls", "c6-science-ch07-t02": "p:measure-lab/thermometers",
  "c6-science-ch08-t01": "p:particles/states", "c6-science-ch08-t02": "p:particles/evap-condense", "c6-science-ch08-t03": "p:particles/matka",
  "c6-science-ch09-t01": "p:mixtures-lab/kitchen-separation", "c6-science-ch09-t02": "p:mixtures-lab/water-separation",
  "c6-science-ch10-t01": "g:sorter", "c6-science-ch10-t02": "p:plant-lab/germination", "c6-science-ch10-t03": "g:sequence",
  "c6-science-ch11-t01": "g:sorter", "c6-science-ch11-t02": "g:sorter",
  "c6-science-ch12-t01": "p:sky/stars", "c6-science-ch12-t02": "p:sky/solarsystem", "c6-science-ch12-t03": "s:sky/solarsystem",
  // ---- Class 7 Curiosity
  "c7-science-ch01-t01": "g:story", "c7-science-ch01-t02": "g:story",
  "c7-science-ch02-t01": "p:indicator-lab/indicators", "c7-science-ch02-t02": "p:indicator-lab/neutralise",
  "c7-science-ch03-t01": "p:circuits/build", "c7-science-ch03-t02": "p:circuits/diagram", "c7-science-ch03-t03": "p:circuits/conductor-test",
  "c7-science-ch04-t01": "s:circuits/conductor-test", "c7-science-ch04-t02": "p:indicator-lab/rusting", "c7-science-ch04-t03": "g:sorter",
  "c7-science-ch05-t01": "p:indicator-lab/change-sort", "c7-science-ch05-t02": "p:indicator-lab/combustion", "c7-science-ch05-t03": "g:time-lapse",
  "c7-science-ch06-t01": "g:reviewed-content", "c7-science-ch06-t02": "g:reviewed-content", "c7-science-ch06-t03": "g:reviewed-content",
  "c7-science-ch07-t01": "p:heat-flow/conduction", "c7-science-ch07-t02": "p:heat-flow/convection", "c7-science-ch07-t03": "p:heat-flow/radiation",
  "c7-science-ch07-t04": "p:water-cycle/groundwater",
  "c7-science-ch08-t01": "p:motion-lab/pendulum", "c7-science-ch08-t02": "p:motion-lab/speed", "c7-science-ch08-t03": "p:motion-lab/strobe",
  "c7-science-ch09-t01": "p:body-systems/digestion", "c7-science-ch09-t02": "s:body-systems/digestion", "c7-science-ch09-t03": "p:body-systems/respiration",
  "c7-science-ch10-t01": "p:plant-lab/photosynthesis", "c7-science-ch10-t02": "p:plant-lab/leaf-gas", "c7-science-ch10-t03": "p:plant-lab/transport",
  "c7-science-ch11-t01": "p:optics/materials", "c7-science-ch11-t02": "p:optics/shadows", "c7-science-ch11-t03": "p:optics/plane-mirror",
  "c7-science-ch11-t04": "p:optics/pinhole",
  "c7-science-ch12-t01": "p:sky/daynight", "c7-science-ch12-t02": "p:sky/seasons", "c7-science-ch12-t03": "p:sky/eclipse",
  // ---- Class 8 Curiosity
  "c8-science-ch01-t01": "p:harness/investigation", "c8-science-ch01-t02": "p:harness/investigation",
  "c8-science-ch02-t01": "g:microscope", "c8-science-ch02-t02": "p:body-systems/levels", "c8-science-ch02-t03": "g:sorter",
  "c8-science-ch03-t01": "g:reviewed-content", "c8-science-ch03-t02": "g:reviewed-content", "c8-science-ch03-t03": "g:reviewed-content",
  "c8-science-ch04-t01": "p:circuits/electromagnet", "c8-science-ch04-t02": "p:circuits/heating", "c8-science-ch04-t03": "p:circuits/lemon-cell",
  "c8-science-ch05-t01": "p:motion-lab/push-cart", "c8-science-ch05-t02": "p:motion-lab/friction-surfaces", "c8-science-ch05-t03": "p:float-sink/upthrust",
  "c8-science-ch06-t01": "p:motion-lab/pressure", "c8-science-ch06-t02": "p:water-cycle/seabreeze", "c8-science-ch06-t03": "g:scenario",
  "c8-science-ch07-t01": "p:particles/diffusion", "c8-science-ch07-t02": "p:particles/states",
  "c8-science-ch08-t01": "p:mixtures-lab/classify", "c8-science-ch08-t02": "s:mixtures-lab/classify", "c8-science-ch08-t03": "g:map",
  "c8-science-ch09-t01": "p:mixtures-lab/dissolve", "c8-science-ch09-t02": "p:mixtures-lab/solubility-T", "c8-science-ch09-t03": "p:float-sink/density",
  "c8-science-ch10-t01": "p:optics/spherical-mirror", "c8-science-ch10-t02": "p:optics/lens",
  "c8-science-ch11-t01": "p:sky/phases", "c8-science-ch11-t02": "s:sky/phases",
  "c8-science-ch12-t01": "p:ecosystem/pond", "c8-science-ch12-t02": "p:ecosystem/farm-web",
  "c8-science-ch13-t01": "s:sky/solarsystem", "c8-science-ch13-t02": "s:ecosystem/pond", "c8-science-ch13-t03": "g:sequence",
  // ---- Class 9 Exploration
  "c9-science-ch01-t01": "g:story", "c9-science-ch01-t02": "p:measure-lab/units", "c9-science-ch01-t03": "g:story",
  "c9-science-ch02-t01": "g:microscope", "c9-science-ch02-t02": "g:sequence", "c9-science-ch02-t03": "g:story",
  "c9-science-ch03-t01": "g:microscope", "c9-science-ch03-t02": "g:microscope", "c9-science-ch03-t03": "p:body-systems/musculoskeletal",
  "c9-science-ch04-t01": "p:motion-lab/track", "c9-science-ch04-t02": "p:motion-lab/freefall", "c9-science-ch04-t03": "p:motion-lab/graphs",
  "c9-science-ch04-t04": "p:motion-lab/sling",
  "c9-science-ch05-t01": "p:mixtures-lab/concentration", "c9-science-ch05-t02": "p:mixtures-lab/advanced-separation", "c9-science-ch05-t03": "p:mixtures-lab/tyndall",
  "c9-science-ch06-t01": "p:motion-lab/tugofwar", "c9-science-ch06-t02": "p:motion-lab/bus-brake", "c9-science-ch06-t03": "p:motion-lab/recoil",
  "c9-science-ch07-t01": "p:motion-lab/work", "c9-science-ch07-t02": "p:motion-lab/swing-energy", "c9-science-ch07-t03": "s:motion-lab/work",
  "c9-science-ch07-t04": "p:motion-lab/lever",
  "c9-science-ch08-t01": "g:atom-builder", "c9-science-ch08-t02": "g:atom-builder", "c9-science-ch08-t03": "g:atom-builder", "c9-science-ch08-t04": "g:atom-builder",
  "c9-science-ch09-t01": "p:indicator-lab/mass-conservation", "c9-science-ch09-t02": "s:circuits/conductor-test", "c9-science-ch09-t03": "g:formula-builder",
  "c9-science-ch10-t01": "p:sound/chain", "c9-science-ch10-t02": "p:sound/string", "c9-science-ch10-t03": "p:sound/echo",
  "c9-science-ch11-t01": "g:sequence", "c9-science-ch11-t02": "g:reviewed-content", "c9-science-ch11-t03": "g:reviewed-content",
  "c9-science-ch12-t01": "g:map", "c9-science-ch12-t02": "g:classification-key", "c9-science-ch12-t03": "g:classification-key",
  "c9-science-ch13-t01": "p:sky/uneven-heating", "c9-science-ch13-t02": "p:water-cycle/winds-currents", "c9-science-ch13-t03": "s:water-cycle/cycle",
  "c9-science-ch13-t04": "g:scenario",
};

const all = [];
for (const f of files) {
  const j = JSON.parse(fs.readFileSync(`${CUR}/${f}.json`, "utf8"));
  for (const ch of j.chapters) for (const t of ch.topics) all.push({ id: t.id, title: t.title, cls: j.class, misconceptions: t.misconceptions || [] });
}
const ids = new Set(all.map((t) => t.id));
const unknown = Object.keys(M).filter((k) => !ids.has(k));
const unmapped = all.filter((t) => !(t.id in M)).map((t) => t.id);
if (unknown.length || unmapped.length) { console.error({ unknown, unmapped }); process.exit(1); }

const topics = all.map((t) => {
  const v = M[t.id];
  if (v.startsWith("g:")) return { id: t.id, title: t.title, class: t.cls, format: "generic", generic: v.slice(2) };
  const [role, es] = [v[0], v.slice(2)];
  const [engine, scene] = es.split("/");
  return { id: t.id, title: t.title, class: t.cls, format: "engine", role: role === "p" ? "primary" : "support", engine: engine === "harness" ? "investigation-harness@1" : `${engine}@1`, scene };
});
const byEngine = {};
for (const t of topics) if (t.format === "engine") (byEngine[t.engine] ??= []).push(t.id);
const byClass = {};
for (const t of topics) { const c = (byClass[t.class] ??= { topics: 0, engine: 0 }); c.topics++; if (t.format === "engine") c.engine++; }
const genericKinds = {};
for (const t of topics) if (t.format === "generic") genericKinds[t.generic] = (genericKinds[t.generic] || 0) + 1;
const out = {
  generatedOn: "2026-10-02",
  source: "data/curriculum/c3-c5 evs + c6-c9 science (verified 2026-10-02)",
  spec: "docs/research/content/science-engines.md",
  totals: { topics: topics.length, engine: topics.filter((t) => t.format === "engine").length, generic: topics.filter((t) => t.format === "generic").length },
  byClass, byEngine, genericKinds, topics,
};
fs.writeFileSync(OUT, JSON.stringify(out, null, 1) + "\n");
console.log(JSON.stringify({ totals: out.totals, byClass, engines: Object.fromEntries(Object.entries(byEngine).map(([k, v]) => [k, v.length])), genericKinds }, null, 1));
