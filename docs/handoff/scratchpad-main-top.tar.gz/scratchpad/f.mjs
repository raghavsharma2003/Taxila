import { readForm } from "/home/user/Taxila/src/duplex/form.ts";
import { MarkerTracker } from "/home/user/Taxila/src/duplex/markers.ts";
import { contextOf } from "/home/user/Taxila/evals/duplex/tick-sim.mjs";
import { SCENARIOS } from "/home/user/Taxila/evals/duplex/scenarios.mjs";
const ctx = contextOf(SCENARIOS.find(s=>s.id==="a09"));
console.log(JSON.stringify(readForm("दूसरा वाला", ctx.expected)));
const m = new MarkerTracker(); console.log(JSON.stringify(m.read("दूसरा वाला।", ctx, 1000, 900, null, false).markers));
