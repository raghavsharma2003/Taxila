cd /home/user/Taxila
F=/tmp/claude-0/-home-user/ecee9fc1-62f9-5f67-a47d-69ca79d9981a/scratchpad/ami/frames
S=/tmp/claude-0/-home-user/ecee9fc1-62f9-5f67-a47d-69ca79d9981a/scratchpad
for lane in D4 FAST; do
  timeout 3600 node evals/p1-duplex/ami.mjs $F --lane $lane --meetings ES2004b,ES2005b,IS1004b --name r2-heldout-$lane > $S/ami-ho-$lane.log 2>&1 &
  timeout 3600 node evals/p1-duplex/ami.mjs $F --lane $lane --meetings IS1008b --name r2-dev-$lane > $S/ami-dev-$lane.log 2>&1 &
done
wait
echo AMI_ALL_DONE
