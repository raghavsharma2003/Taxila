import { readFileSync, readdirSync } from "fs";
import { planEngine } from "/home/user/Taxila/shared/engine-catalog.js";
import * as NL from "/home/user/Taxila/src/modules/frame/engines/numberLine.logic.ts";
import * as MD from "/home/user/Taxila/src/modules/frame/engines/multiplyDivide.logic.ts";
import * as MS from "/home/user/Taxila/src/modules/frame/engines/measure.logic.ts";
import * as GEO from "/home/user/Taxila/src/modules/frame/engines/geoboard.logic.ts";
import * as PV from "/home/user/Taxila/src/modules/frame/engines/placeValue.logic.ts";
import * as PT from "/home/user/Taxila/src/modules/frame/engines/patterns.logic.ts";
import * as FR from "/home/user/Taxila/src/modules/frame/engines/fractions.logic.ts";
const L = { "number-line@1": NL.normalize, "multiply-divide@1": MD.normalize, "measure@1": MS.normalize, "geoboard@1": (p) => GEO.normalize(p, 48), "place-value@1": PV.normalize, "patterns@1": PT.normalize, "fractions@1": FR.normalize };
const stable = (c) => JSON.stringify(c, (k, x) => (k === "issues" ? undefined : x instanceof Set ? [...x].sort() : x));
const root = "/home/user/Taxila/";
const topicMap = JSON.parse(readFileSync(root + "shared/engine-topic-map.json", "utf8"));
const want = process.argv[2];
let n = 0;
for (const f of readdirSync(root + "data/kits").filter((f) => /^c[4-7]-/.test(f))) for (const kit of JSON.parse(readFileSync(root + "data/kits/" + f)).topics) for (const item of kit.items ?? []) {
  const p = planEngine({ kit, item, lang: "english", topicMap });
  if (!p || p.bindItem || p.engine !== want) continue;
  const { numbers, fractions, ...bare } = p.params;
  if (stable(L[want](p.params)) === stable(L[want](bare)) && n++ < 10) console.log(JSON.stringify({ pre: p.params.mode, nums: numbers, fr: fractions, prompt: item.prompt_en.slice(0, 90) }));
}
