// read-only: stream 3's ack-cohort-query.sql on PRODUCTION, aggregated rows only (codes and counts; no ids, no emails)
import { readFileSync } from "node:fs";
const { q } = await import("/home/user/taxila-int/server/db.js");
const sql = readFileSync("/home/user/taxila-int/docs/design/round5/results/latency/ack-cohort-query.sql", "utf8");
const parts = sql.split(/;\s*\n/).map((s) => s.replace(/^\s*--.*$/gm, "").trim()).filter(Boolean);
const since = "2026-10-15T15:30:00Z", until = new Date().toISOString();
await q("begin read only");
for (const [i, p] of parts.entries()) {
  const text = p.replaceAll(":since", "$1").replaceAll(":until", "$2");
  const r = await q(text, [since, until]);
  console.log(`-- query ${i + 1}`); console.table(r.rows ?? r);
}
await q("rollback");
process.exit(0);
