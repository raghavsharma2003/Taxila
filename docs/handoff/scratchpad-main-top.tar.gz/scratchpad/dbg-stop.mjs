import { step, initLessonState } from "/home/user/Taxila/server/director/state.js";
import { kit, CTX, cls } from "/home/user/Taxila/tests/fixtures/kit.mjs";
const K = kit();
const fresh = () => initLessonState({ topicId: K.topicId, kit: K, ctx: CTX, seed: 11, now: 0 });
const turn = (r, c) => step(r.state, { event: "turn", kit: K, cls: c, now: (r.state.turn + 1) * 20_000 });
const req = (type) => ({ ...cls("no_evidence"), source: "request", request: { type, whole: true, src: "p5" } });
let r = step(fresh(), { event: "start", kit: K, now: 0 });
while (r.state.phase !== "practice" || !r.move.itemId || r.move.itemId.startsWith("fade:")) r = turn(r, cls("no_evidence"));
for (const t of ["stop", "break"]) { const x = turn(r, req(t)); console.log(t, x.state.lastMove.kind, x.state.lastMove.request, x.state.lastMove.itemId, JSON.stringify(x.ui?.ask)?.slice(0,120)); }
