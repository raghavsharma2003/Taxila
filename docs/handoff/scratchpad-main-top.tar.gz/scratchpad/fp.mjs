import { correctsRight, stripCorrection } from "/home/user/Taxila/server/director/say.js";
const o = { key: "9", wrong: ["1","10"], nextPrompt: "5, 10, 15, ___, 25. Beech mein kaunsa number gayab hai?" };
for (const s of ["Bilkul sahi! 8 ke baad 1 aur chappal, toh count aage badha.", "Shabaash, tumne 1 chappal ko bhi gina. Ab agla?", "Haan nau! Tumne 8 se aage gina.", "Sahi! 10 se ek kam."]) console.log(correctsRight(s,o), "|", stripCorrection(s,o));
const f = { key: "3/4", wrong: ["2/3","1/2"], nextPrompt: "Which is bigger?" };
console.log(correctsRight("Right, because 1/2 is less than both. Next one?", f));
