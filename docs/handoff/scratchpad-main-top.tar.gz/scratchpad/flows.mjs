import { chromium } from '/home/user/Taxila/node_modules/playwright/index.mjs';
const b = await chromium.launch(); const ctx = await b.newContext({ viewport: { width: 390, height: 844 } });
await ctx.route(/^https?:/, async (route) => { try { const r = await fetch(route.request().url()); const body = Buffer.from(await r.arrayBuffer()); const headers={}; r.headers.forEach((v,k)=>{ if(!['content-encoding','content-length','transfer-encoding'].includes(k)) headers[k]=v; }); await route.fulfill({status:r.status, headers, body}); } catch { await route.abort(); } });
const U = (f) => 'file:///home/user/Taxila/prototypes/reset/design-v3/' + f; const res = {}; const errs = [];
let p = await ctx.newPage(); p.on('pageerror', e => errs.push(String(e)));
// parent: reschedule
await p.goto(U('08-parent.html'), { waitUntil: 'networkidle' });
await p.click('[data-edit="0"]'); await p.click('.date[data-i="5"]'); await p.click('.time[data-m="1080"]');
res.sumBeforeSave = await p.textContent('#edSum'); await p.click('#edSave');
res.row0 = (await p.textContent('#slots .slot:nth-child(1)')).replace(/\s+/g, ' ').trim();
res.editorClosed = !(await p.isVisible('#editor'));
// clash disabled: open lesson 0 again, Wed 7 (i=3) should be disabled (lesson 1 there)
await p.click('[data-edit="0"]'); res.clashDisabled = await p.isDisabled('.date[data-i="3"]');
// lesson hours: drop end to 6 PM -> 7 PM time disabled
for (let i = 0; i < 6; i++) await p.click('#endM'); res.endV = await p.textContent('#endV'); res.t7pmDisabled = await p.isDisabled('.time[data-m="1140"]');
for (let i = 0; i < 3; i++) await p.click('#limM'); res.lim = await p.textContent('#limV');
await p.click('#lang button:nth-child(2)'); res.hindi = (await p.textContent('#wkH')).slice(0, 20);
await p.click('.how[data-ev="e1"]'); res.evidenceOpen = await p.isVisible('#e1');
// onboarding: walk through, zero days disables save
await p.goto(U('01-onboarding.html'), { waitUntil: 'networkidle' });
for (let i = 0; i < 4; i++) await p.click('#next');
for (const d of await p.$$('#days .day[aria-pressed="true"]')) await d.click();
res.zeroDaysDisabled = await p.isDisabled('#next'); res.zeroMsg = await p.textContent('#sumA');
await p.click('#weekdays'); await p.click('#tPlus'); res.sum = await p.textContent('#sumA'); res.sumB = await p.textContent('#sumB');
await p.click('#next'); await p.click('#next'); res.ready = (await p.textContent('#kvW'));
// diversion scenarios
for (const s of ['park', 'insist', 'oob', 'stop']) { await p.goto(U('05-diversion.html?s=' + s), { waitUntil: 'networkidle' }); await p.waitForTimeout(1600); res['div_' + s] = await p.textContent('#card .k'); }
console.log(JSON.stringify(res, null, 1), 'errors:', errs.length); await b.close();
