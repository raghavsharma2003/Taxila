const { q } = await import("/home/user/taxila-int/server/db.js");
const rows = (r) => r.rows ?? r;
await q("begin read only");
for (const pre of ["3437b744", "310b8c82"]) {
  const L = rows(await q(`select id::text from lesson where id::text like $1`, [`${pre}%`]))[0].id;
  const r = rows(await q(`select data from trace_event where sid=$1 and kind='ui.render.board' order by t`, [L]));
  for (const { data: d } of r) console.log(pre, `script=${String(d.scriptId).split(":").slice(-2).join(":")} page=${d.page} domOps=${d.domOps} visibleOps=${d.visibleOps} expectedOps=${d.expectedOps} expectedPrior=${d.expectedPrior} earlierVisible=${d.earlierVisible} onScreen=${JSON.stringify(d.onScreen)}`.slice(0, 260));
}
await q("rollback"); process.exit(0);
