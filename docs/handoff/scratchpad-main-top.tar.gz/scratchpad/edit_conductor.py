import os, sys
p = '/home/user/Taxila/docs/research/conductor/CONDUCTOR.md'
m0 = os.stat(p).st_mtime
s = open(p).read()
T = '(gap-fill G2-content-orchestration-media)'
def rep(old, new, count=1):
    global s
    n = s.count(old)
    if n != count:
        sys.exit(f'anchor count {n} != {count}: {old[:90]!r}')
    s = s.replace(old, new)

# 1. intro: the fragment note becomes revision 4
a = s.index('**Gap-fill fragment still on disk without its design doc**')
b = s.index('**Tags:** **[V]**')
s = s[:a] + f"""**Revision 4 {T}, 2026-10-02).** `content-orchestration.md` is now written and ruled in as X49-X58 (§0.2):
the `forge.demand` horizons and who emits each (§3.5), the waiter fan-out state machine, delivery of ready modules to
`LessonBrief.preparedModules` and to a live lesson against the 3 s inline budget (§4.6), the review queue's SLA and
ordering, and the media the brief demands: songs (chant + code-composed jingle, Azure first-party), video after
sora-2 (re-verified: retires 2026-10-15, no replacement), and lesson images (CM4, `prefetch` ranking). The
`content-orchestration.sql` header now states the X29 order (`forge_request` → `forge_waiter`/`module_ready`, never
`child_seq`), and its scratch-PG16 probe (30/30) found and fixed four revision-G1 defects: retirement was unreachable,
two lock cycles (publish/supersede, two reviewers), and a child-carrying `two_weeks` demand that aborted the commit.
New pieces: `forge.*` job kinds (§8.2), degrade rows (§9.5), invariants I-F1…I-F16 (§9.9), CM4 defined (§9.12),
owner decisions D-VIDEO, D-ASR, D-SPEECH, D-SONG, D-REVIEW (§10.5). Every revision-4 edit is marked "{T}".
The note on the "(X31)" tag in `content-orchestration.sql` is resolved: the `lib/` prefix check now cites §5.8.
""" + s[b:]

# 2. binding constraints
rep("`taxila-codex`, `taxila-image`, `taxila-sora`, gpt-4o-mini-tts, `taxila-transcribe`, text-embedding-3-small.",
    "`taxila-codex`, `taxila-image`, `taxila-sora`, gpt-4o-mini-tts, `taxila-transcribe`, text-embedding-3-small.\n"
    f"  {T} Retirement dates, re-checked today against the Foundry schedule [V], live in `allowed_model`: `taxila-sora`\n"
    "  (sora-2 2025-12-08, Preview) **and `taxila-transcribe` (gpt-4o-transcribe 2025-03-20) both retire 2026-10-15**\n"
    "  with no listed replacement (X58). Azure AI Speech neural TTS (chant clips, explainer narration) is an Azure\n"
    "  service, not a Foundry model, and is not yet named on the list (D-SPEECH).")

# 3. §0.2 rulings X49-X58 (after the last X48 row)
i = s.index('| X48 |'); j = s.index('\n', i)
rows = f"""
| X49 | `forge.demand` horizons {T} | §3.5 "proposed"; G1 SQL let any horizon carry a child | **`in_lesson`/`next_lesson` carry a child and a `forge_waiter`; `two_weeks`/`term` are child-less aggregate demand, even when the Conductor emits them** (content-orchestration §2) | a child-carrying `two_weeks` demand hit the waiter's horizon check and aborted the whole commit [M F7c] |
| X50 | the live 3 s path {T} | §8.2: `forge.spec`/`forge.scene` inline on web, ≤ 3 s | **T1 params and T2a template fills in a lesson are the Director's own `generate_now`** (ARCHITECTURE §1.2), charged to `child_content`; Forge gets them afterwards through `forge.demand{{in_lesson}}` with `need:'promote'` | a Conductor step plus a job and a publish cannot fit inside a 1.9-3.4 s model call [Me genui]; a live fill is not a Forge result, so rule 2 holds |
| X51 | mid-lesson delivery {T} | §4.6: "through `brief.refresh`/`module.ready` on its existing poll" | **the Director's turn-boundary read `forge_ready_for(child, lastPoll)`; no mid-lesson `brief.refresh` for modules.** `brief.refresh` builds `preparedModules` at start and on resume. A mounted module is never replaced (I-F9) | one publish × N children of `brief.refresh` is the thundering herd §3.8 forbids; the Director's turn is already off the critical path |
| X52 | never live {T} | MO §6.1 `build_race` live | **no T3/G2, image, video, audio or chant build starts with horizon `in_lesson`**: downgraded to `next_lesson` (I-F10) | G2 P50 12-15 min, about 1 build per codex deployment; images at 4 RPM company-wide (MO R1, R2) |
| X53 | Forge lock order {T} | G1 SQL header: `child_seq → conductor_state → forge_request` | **`forge_request` rows in ascending `library_key`, then child-owned forge rows; never `child_seq`.** The commit sorts its `forge.demand` batch; `forge_publish` locks {{new, superseded}} in one ordered statement; `review_decide` locks `forge_request` first | controls 5/5 deadlocks in each of three cells, G2 0/5 in each, commit ‖ publish 0/10 with no lost waiter (content-orchestration §4.4) |
| X54 | review capacity {T} | §8.5: "review queue ordered by `demand_count`" | **review seconds are admitted by `forge.admit` against named reviewers' capacity before the SLA; queue order = due-within-2 h, then ln(1 + demand) × horizon weight, then due date** (`review_sla`, `review_next`) | ≈ 30 G2 misses/day at 300 children × 600-900 s = 5-7.5 h/day against one reviewer (MO §7.4) [I] |
| X55 | video {T} | §8.2 `forge.video`: sora-2 "[not re-checked]" | **re-checked [V]: sora-2 2025-12-08 retires 2026-10-15, replacement "—", the only Foundry video model; retired = `410 Gone`, not extendable. M3 video is code:** `explainer@1` (performed, clip, seek-rendered MP4), Manim in ACA dynamic sessions for Class 8-9 maths, stills-with-motion for phenomena | code-rendered media is exact on text and numbers; sora drew 3+3 under "3+4=7" [Me AV] |
| X56 | songs {T} | CONDUCTOR: none | **v1 = `chant-track@1` (Azure Speech Swara clips on a client beat) + v1.5 `jingle@1` (a reviewed, codex-composed tune template under the chant). Sung render rejected. Eligibility is the predicate `verbatim_sequence` (LS rule 24); every kit passes the recitation lint L1-L5 and a native-ear lang key** | no first-party model sings (n = 18, SR §4) [Me]; lint 11/11 golden cases [M] |
| X57 | lesson images and CM4 {T} | X10 "topic-level prefetch of the next two weeks of syllabus"; CM4 undefined | **`prefetch` ranked by cohort demand Σ P(child on topic, day d)·γ^d within the nightly image quota; CM4/CM4b/CM4-img computed from `module_run.source` (Director-only writer)** | calendar-only prefetch plateaus at 86%; demand ranking 99% at 300 images/night [sim, `image-prefetch-sim.py`] |
| X58 | model retirement dates {T} | `allowed_model.allowed_until` null for most rows | **every row carries the Foundry date; `verify` fails at < 30 days (I-F13); `taxila-transcribe` must be re-pinned before 2026-10-15 (D-ASR)** | gpt-4o-transcribe 2025-03-20 retires 2026-10-15 [V] and gates the TTS WER and chant ASR checks |"""
s = s[:j] + rows + s[j:]

# 4. §1.2 Forge component row
rep("| Forge | `forge_artifact`, `forge_request`, library Blob | inline (T1/T2); worker + ACA Sandboxes (T3, M3) | luna, codex, image, sora | library key (objective, engine, specHash, modelV) |",
    f"| Forge | `forge_request`, `forge_transition`, `forge_artifact`, review queue, library Blob (+ consumes `forge_waiter`, writes `module_ready`) | worker (`forge.*` §8.2) + ACA jobs (seek render) + ACA dynamic sessions (T3, Manim; M3). Live T1/T2a fills are the Director's, not Forge's (X50) | luna, sol, codex, image, Azure Speech; sora only until 2026-10-15 (X55) | `library_key` (build) + `identity_key` (serving family) {T} |")

# 5. §2.2 module.requested
rep("  | { type: 'module.requested'; lessonId: string; objectiveId: string; engine: string; specHash: string }  // library miss → forge_request",
    "  | { type: 'module.requested'; lessonId: string; slotId?: string; topicId: string; key: IdentityKeyFields & { engine: string; specHash: string };\n"
    f"      need: 'promote' | 'near_line' | 'next_lesson'; needBySec?: number }}   // {T}: content-orchestration §3")

# 6. §3.4 commit comment + writer table
rep("  await forgeDemand(t, childId, commands);                      // 'forge.demand' → forge_file_demand() (gap-fill\n"
    "                                                                //  content-orchestration.sql; its doc is pending)",
    "  await forgeDemand(t, childId, commands);                      // 'forge.demand' → forge_file_demand(), batch SORTED by\n"
    f"                                                                //  libraryKey; child id passed only for in_lesson/next_lesson (X49, X53) {T}")
rep("| Forge functions (`content-orchestration.sql`) | `forge_request` → `forge_waiter`/`module_ready`/`review_item`. Never `child_seq` |",
    f"| Forge functions (`content-orchestration.sql`) | `forge_request` (several: ascending `library_key`; publish locks {{new, superseded}} in one statement) → `forge_waiter`/`module_ready`/`review_item`. `review_decide`: `forge_request` → the artefact's items in id order. `review_next`, `review_escalate`, `forge_sweep`: single statements with `SKIP LOCKED`. Never `child_seq` {T}: X53, probe D1-D4 |")

# 7. §3.5 command
rep("  | { kind: 'forge.demand'; libraryKey: string; horizon: 'in_lesson' | 'next_lesson' | 'two_weeks' | 'term';\n"
    "      lessonId?: string; slotId?: string; wantedBy: string }        // proposed by the content-orchestration gap-fill",
    "  | { kind: 'forge.demand'; libraryKey: string; identityKey: string; key: LibraryKeyFields;\n"
    "      meta: { tier: ForgeTier; buildClass: string; modality: Modality };\n"
    "      horizon: 'in_lesson' | 'next_lesson' | 'two_weeks' | 'term'; childScoped: boolean;   // false for two_weeks/term/promote (X49)\n"
    f"      lessonId?: string; slotId?: string; wantedBy: string; predicted?: number }}  // {T}: content-orchestration §2-§3")

# 8. §4.5 LessonBrief
rep("  preparedModules: Array<{ artifactId?: string; engine: string; params: Record<string, unknown> }>;",
    "  preparedModules: PreparedModule[];                  // " + T + " superset of the old element: + source, libraryKey,\n"
    "                                                      // contentHash (blocklist check), tier, reviewGrade, forSegment, fallbacks[] ending\n"
    "                                                      // in a device-cached marginal-zero floor (content-orchestration §3, §5.1)")

# 9. §4.6 boundary row
old_row_start = s.index('| a ready Forge module |'); old_row_end = s.index('\n', old_row_start)
s = s[:old_row_start] + (f"| a ready Forge module {T} | **lesson start / resume:** `brief.refresh` fills `preparedModules` from `forge_ready_for(child)` (published, not blocklisted, not yet served) ∪ inventory hits ∪ kit floors; the device caches every floor. **Mid-lesson:** the Director reads `forge_ready_for(child, lastPoll)` at each turn boundary (X51) and offers a new module at the next natural stop, only if nothing is mounted for that segment (I-F9). **Live fills** (T1 params, T2a template) are the Director's own, with a **3 s hard timeout** from the move decision: T1 fits (2.05 s p90); T2a (3.35 s p90) only with one turn of lookahead; T2b only via `forge.demand{{in_lesson}}` with need-by ≥ 45 s (next segment, or the minute-3 diagnostic for practice). **On a miss** at need-by: mount `fallbacks[0]` silently (no \"loading\"), log `module_run.missed_primary`, promote the late live fill, carry a late T2b to next lesson unless ≥ 90 s of the segment remain; after 3 misses in a lesson, stop requesting T2 (content-orchestration §5) |") + s[old_row_end:]

# 10. §8.1 sandboxes row
i = s.index('| **ACA Sandboxes / dynamic sessions** (M3) |'); j = s.index('\n', i)
s = s[:i] + f"| **ACA Sandboxes / dynamic sessions** (M3) | Forge T3 builds and codex-written Manim renders: egress denied, Hyper-V isolation, headless validation, human review before library. Custom-container pool kept at **0 ready sessions outside 23:00-05:00 IST** (≈ $5.2/day per warm 2 vCPU session [I]) {T} | anything per child |" + s[j:]
rep("| **ACA manual jobs** |", f"| **ACA jobs** (Forge render, {T}) | `forge.explainer`/`forge.animation{{renderer:'seek'}}`: headless Chromium + ffmpeg on our own player and JSON (trusted code), ≈ $0.005 per video-minute | LLM-written code (that is the sandbox's) |\n| **ACA manual jobs** |")

# 11. §8.2 forge.* rows
i = s.index('| `forge.spec` (T1), `forge.scene` (T2) |')
j = s.index('| `parent.letter` |')
s = s[:i] + f"""| `forge.admit` {T} | slow / worker | 2 | `forge.admit:{{window}}` | code (knapsack: content-orchestration §6) | every 15 min, night every 5; review-seconds admitted (X54) |
| `forge.horizon` {T} | slow / worker | 3 | `forge.horizon:{{day}}` / `:{{isoWeek}}` | code | nightly 22:30 IST (`two_weeks`, demand-ranked prefetch X57); Sunday (`term`, H0 catalogue) |
| `forge.spec` (promote) {T} | fast / worker | 2 | `forge.spec:{{libraryKey}}` | luna re-fill + validate → reject | publishes a served live fill (X50) |
| `forge.scene` (near-line T2b / free-form explainer) {T} | fast / worker | 0 | `forge.scene:{{libraryKey}}` | brain → luna → T2a | only with need-by ≥ 45 s; single-flight per key |
| `forge.prefetch` (library, topic-level) | slow / worker | 3 | `forge.prefetch:{{libraryKey}}:{{modelV}}` | luna/image within `budget(global, forge, day)` | **ranked by cohort demand, not the calendar** (X57) {T} |
| `forge.image` | slow / worker | 3 | `forge.image:{{libraryKey}}:{{style}}:{{modelV}}` | gpt-image-2 medium → low → SVG / none | `azure:image ≤ 3` bucket (4 RPM quota); night only (X52) |
| `forge.build` (T3) | sandbox (M3) | 3 | `forge.build:{{libraryKey}}` | codex → existing engine | **offline only**, from `forge_request` demand, review-admitted, → human review; 24 h cool-down after 2 gate fails {T} |
| `forge.explainer` {T} | ACA job / worker | 3 | `forge.explainer:{{libraryKey}}:{{lang}}` | sol plan + Azure Speech narration → template-only core | library; narration is a per-lang layer beside the core |
| `forge.animation` {T} | ACA job (seek) / sessions (Manim, M3) | 3 | `forge.animation:{{libraryKey}}:{{renderer}}:{{lang}}` | Manim → explainer seek MP4 → none | **M3 video** (X55): ≈ $0.10 per Manim segment, ≈ $0.005 per MP4 minute; two-key for chapter video |
| `forge.chant` {T} | slow / worker | 3 | `forge.chant:{{kitId}}:{{v}}:{{voice}}:{{tempo}}` | Azure Speech → human-clip queue (ङ ञ ण, conjuncts) | ASR phonMatch 1.0 + native-ear lang key (X56) |
| `forge.jingle` {T} | slow / worker | 3 | `forge.jingle:{{kitId}}:{{tuneId}}` | code fit → chant only | L1-L5 recitation lint; lang + kid_ux keys |
| `forge.video` | — | — | — | **sora-2 retires 2026-10-15 [V re-checked {T}]**; `allowed_model` refuses publish from that day | replaced by `forge.animation` + stills-with-motion; optional pre-retirement batch D-VIDEO |
| `forge.sweep` {T} | slow / worker | 3 | `forge.sweep:{{day}}` | SQL (`SKIP LOCKED`) | nightly; expires waiters and `module_ready` rows |
""" + s[j:]

# 12. §8.5 SPOF row
rep("| one human reviews Forge T3 | T1/T2 carry v1; the review queue is ordered by `demand_count` | reviewer rota |",
    f"| one human reviews Forge T3 | T1/T2 carry v1; review seconds are admitted against capacity and the queue is ordered by SLA, then demand × horizon weight (X54) {T} | reviewer rota incl. a native Hindi ear (D-REVIEW) |")

# 13. §9.5 degrade ladder
rep("| video | library | — | — | none |",
    f"| video {T} | library MP4 / chapter video | explainer clip (DSL + narration) | stills with motion | voice description |\n"
    f"| animation {T} | library explainer core (performed) | T2a explainer template (live, with lookahead) | static diagram sequence | voice + anchor |\n"
    f"| near-line scene (T2b) {T} | `module_ready` | T2a template | T1 engine | kit worked example |\n"
    f"| song / chant {T} | `jingle@1` | `chant-track@1` | teacher-led call-and-response | text list |\n"
    f"| T3 game {T} | library core + G1 fill | G1 kit default levels | T1 engine practice | tap items from the kit |")

# 14. §9.9 invariants
rep("| W-map | every `child_id` table mapped, cascading, indexed; no free text in event schemas | ws W2, §5.2 |",
    "| W-map | every `child_id` table mapped, cascading, indexed; no free text in event schemas | ws W2, §5.2 |\n"
    f"| I-F1 | {T} no publish without `reviewed_by`; a human tier needs every key-required item approved and no `auto:` reviewer. **Control:** probe F15 | content-orchestration §11.3 |\n"
    "| I-F2 | no child field in `forge_request.key`, `forge_transition.evidence`, `forge_artifact.manifest`; no lesson or child id in a library row. **Control:** F8 (a `childId` key is refused) | MO R8, X49 |\n"
    "| I-F3 | `forge_waiter` is inserted only by the Conductor commit and only for `in_lesson`/`next_lesson`. **Control:** F7/F7c + writer census | X49 |\n"
    "| I-F4 | ≤ `per_child_daily_demand` (3) waiters per child-day, ≤ `per_child_daily_races` (2) on non-T1/T2 tiers. **Control:** F4, F5 | MO §9.1 |\n"
    "| I-F5 | after a publish no waiter remains for the request and every in-window waiter has a `module_ready` row, under any commit ‖ publish interleaving. **Control:** D4 (10/10), F9 | X53 |\n"
    "| I-F6 | Forge lock order (X53); no `40P01` in the G3 probe cells. **Control:** the G1 bodies deadlock 5/5 (D1-D3) | X53 |\n"
    "| I-F7 | no mount of an artefact that is not the published one or whose hash is on `lib-blocklist`. **Control:** F18 | §5.8 |\n"
    "| I-F8 | T3 and Manim artefacts attest egress deny, runner identity none, AST ban list; T3 the current CSP. **Control:** F17 | ws I17 |\n"
    "| I-F9 | a late artefact never replaces a mounted module. **Control:** a planted late `module_ready` mid-play must be deferred (conductor-sim) | X51, MO C1 |\n"
    "| I-F10 | no T3, image, video, audio or chant build starts with horizon `in_lesson`. **Control:** a planted in-lesson T3 demand must come out `next_lesson` | X52 |\n"
    "| I-F11 | quarantine is one transaction: `module_ready` rows gone and the hash on the blocklist. **Control:** F18 | — |\n"
    "| I-F12 | no lyric, narration or artefact string enters a `compile()` lane (ids and shapes only). **Control:** lint L4 golden case | inherited law |\n"
    "| I-F13 | no publish with a model off `allowed_model` or on or after `allowed_until`; `verify` fails when a deployment in use is within 30 days of it. **Control:** F12, F13; today's run must flag `taxila-sora` and `taxila-transcribe` | X55, X58 |\n"
    "| I-F14 | song/chant only for `verbatim_sequence` objectives; every chant line phonMatch = 1.0; lang key present; `rights ≠ ncert-pending`; L1-L5 clean. **Control:** lint golden cases (11/11) | X56, LS rule 24 |\n"
    "| I-F15 | no library build is charged to a child (`cost_ledger.child_id` null for `forge.*`); live fills are charged to `child_content`. **Control:** ledger fixture | MO8 |\n"
    "| I-F16 | no name, transcript or memory crosses into a module iframe; `init` carries ids and numbers only. **Control:** a planted free-text `init` field is rejected | MO R9 |")

# 15. §9.12 CM4
rep("| CM4 | Forge library hit rate per lesson (T1/T2 definition) | the \"built while she teaches\" claim |",
    f"| CM4 {T} | from `module_run.source` (Director-only writer): **CM4** = library-class mounts ÷ library-class wants per lesson; **CM4b** = `module_ready` mounts from an `in_lesson` waiter ÷ all mounts (the owner's \"built while she teaches\", measured); **CM4-img** = planned image slots served from the library ÷ planned, per topic over 30 d. Prior [sim]: CM4-img 99% with demand-ranked prefetch at 300 images/night, 86% calendar-only | the \"built while she teaches\" claim; X57 |\n"
    f"| `content-orchestration-pg16-2026-10-02` {T} | done: F1-F21 (n = 1) + race cells D1-D4 (n = 5 each), 30/30 as expected; 4 G1 defects found and fixed (`content-orchestration-pg16-probe.py`) | X49, X53 |\n"
    f"| `image-prefetch-sim-2026-10-02` {T} | done [sim]: 4 seeds × 18 cells (`image-prefetch-sim.py`) | X57 |\n"
    f"| M-CO1…M-CO5, M-SONG-5/6/7, M-VID1 {T} | near-line ready vs need-by; CM4 family; review throughput and SLA hit; `forge_ready_for` DB share; the probe on Neon; chant/melody A/B; lite-device MP4 (content-orchestration §12) | X50-X57 |")

# 16. §10.3 / §10.4
rep("relayed routes; test windows v1 and the pointer chip; topic-level Forge T1/T2 library prefetch within the global\nForge budget;",
    f"relayed routes; test windows v1 and the pointer chip; topic-level Forge T1/T2 library prefetch within the global\nForge budget, demand-ranked (X57), with `forge.admit`, `forge.horizon`, near-line `forge.scene` and the review queue's SLA ordering {T}; `chant-track@1` library (X56);")
rep("Forge T3 offline (ACA Sandboxes, egress denied, headless validation, demand-ranked review queue); library video;",
    f"Forge T3 offline (ACA Sandboxes, egress denied, headless validation, review-admitted queue); library video **as code** {T}: `explainer@1` clips and seek-rendered MP4, Manim (Class 8-9 maths) in dynamic sessions, stills-with-motion for phenomena (X55); `jingle@1` after M-SONG-5;")

# 17. §10.5 owner decisions
rep("| D-SUPPORT | a support rota and SLA (or the honest no-SLA shape) | M1 |",
    "| D-SUPPORT | a support rota and SLA (or the honest no-SLA shape) | M1 |\n"
    f"| D-ASR {T} | re-pin `taxila-transcribe` before **2026-10-15** (gpt-4o-mini-transcribe 2025-12-15 → 2027-06-15, or gpt-4o-transcribe-diarize 2025-10-15 → 2027-04-15) and re-run the phonkey probe set | TTS round-trip WER, chant gate A |\n"
    f"| D-VIDEO {T} | optional ≤ 20 sora-2 phenomenon hooks under a hard $50 cap, reviewed and **published before 2026-10-15** (I-F13 checks at publish); default: none | nothing (M3 video is code) |\n"
    f"| D-SPEECH {T} | name Azure AI Speech neural TTS in `azure-only-compute` (already used for chant and narration) | chant library, explainer narration |\n"
    f"| D-SONG {T} | accept chant + jingle for v1; whether an open-weight singer (ACE-Step, MIT) on an Azure GPU may be probed for v2 (allowed as open-source on Azure compute, not first-party) | songs v2 |\n"
    f"| D-REVIEW {T} | a reviewer rota with hours per day, including a native Hindi ear for lang keys | T3 library growth; every chant kit |")

# 18. §10.6 not to build
rep("`child_seq` before another existing row (X29). `NOTIFY` as a correctness path (X35).",
    "`child_seq` before another existing row (X29). `NOTIFY` as a correctness path (X35).\n"
    f"{T} Anything new on sora-2 after 2026-10-13, or any pixel video that carries a fact (X55). A sung render from TTS\n"
    "instructions (X56). LLM-authored lyrics for verbatim content: luna arranges kit tokens, never writes them (L1). A\n"
    "mid-lesson `brief.refresh` per published module (X51). Calendar-only image prefetch (X57).")

# 19. sources
rep("Primary sources checked this session or by the cited sibling doc ([V]):",
    "Primary sources checked this session or by the cited sibling doc ([V]):\n"
    f"- {T} Microsoft Learn, *Model retirement schedule — Microsoft Foundry* (updated 2026-09-23) — https://learn.microsoft.com/en-us/azure/foundry/openai/concepts/model-retirement-schedule\n"
    f"- {T} Microsoft Learn, *Foundry Models lifecycle and support policy* (retired = `410 Gone`; preview 30-day notice; not extendable) — https://learn.microsoft.com/en-us/azure/foundry/openai/concepts/model-retirements\n"
    f"- {T} Microsoft Learn, *Sora 2 video generation overview (preview)* (jobs kept 24 h) — https://learn.microsoft.com/en-us/azure/foundry/openai/concepts/video-generation\n"
    f"- {T} Microsoft Learn, *Dynamic sessions in Azure Container Apps* (custom-container pools billed on pool resources) — https://learn.microsoft.com/en-us/azure/container-apps/sessions")
rep("the gap-fill fragments `content-orchestration.sql`, `adaptation.contracts.ts`, `adaptation-hysteresis-sim.py`;",
    f"the gap-fill fragments `content-orchestration.sql`, `adaptation.contracts.ts`, `adaptation-hysteresis-sim.py`; {T} `content-orchestration.md`, `content-orchestration-pg16-probe.py` (+ `.g1-frozen.sql`, output `-2026-10-02.txt`), `image-prefetch-sim.py`, `media-recitation-lint.mjs`, and the content docs it rests on (`factory/multimodal-orchestration.md`, `factory/video-animation-gen.md`, `factory/asset-pipeline.md`, `content/animation-video.md`, `content/songs-rhymes-audio.md`, `content/genui-reliability.md`);")

if os.stat(p).st_mtime != m0:
    sys.exit('CONDUCTOR.md changed underneath; re-run')
open(p, 'w').write(s)
print('ok', len(s))
