const { compose } = await import("/home/user/taxila-int/server/forge3/compose.js");
const { getTopic } = await import("/home/user/taxila-int/server/content/curriculum.js");
for (const topicId of process.argv.slice(2)) {
  const t = getTopic(topicId);
  const p = compose({ ask: "game", topicId, skillId: null, classLevel: Number(topicId.slice(1, 2)) });
  console.log(topicId, t?.title ?? "?", "→ ladder", JSON.stringify(p.ladder.map((x) => x.kind + (x.family ? `:${x.family}` : ""))), "why", JSON.stringify(p.why).slice(0, 220));
}
