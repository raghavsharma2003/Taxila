import bpy,sys,numpy as np
sys.path.insert(0,'/home/user/Taxila/scripts/character/stylised/armB')
import lib as L
bpy.ops.wm.open_mainfile(filepath='/tmp/claude-0/char/stylised-armB/stage.blend')
show=sys.argv[-1].split(',')
for o in bpy.data.objects:
    if o.type=='MESH': o.hide_render = o.name not in show
L.setup_render(res=400,samples=8)
for o in list(bpy.data.objects):
    if o.type in ('LIGHT','CAMERA'): bpy.data.objects.remove(o)
c=np.array([0,-0.0,0.24])
L.area_light('k',c+np.array([-0.3,-1,0.5]),c,40,1); L.area_light('k2',c+np.array([0.5,1,0.5]),c,30,1)
for y in (0,60,90):
    r=np.radians(y)
    cam=L.camera('c',c+np.array([np.sin(r)*0.7,-np.cos(r)*0.7,0]),c,lens=60)
    L.render_to(f'/tmp/claude-0/char/stylised-armB/dbg/part_{y}.png',cam)
import os; os._exit(0)
