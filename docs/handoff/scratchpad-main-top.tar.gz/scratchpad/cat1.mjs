const body = { filters: [{ field: "labels", operator: "eq", values: ["latest"] }], pageSize: 3 };
const r = await fetch("https://api.catalog.azureml.ms/asset-gallery/v1.0/models", { method: "POST", headers: { "content-type": "application/json" }, body: JSON.stringify(body) });
const j = await r.json(); console.log(r.status, Object.keys(j), j.totalCount, JSON.stringify(j.summaries?.[0]).slice(0,2500)); console.log(j.continuationToken?.slice?.(0,80));
