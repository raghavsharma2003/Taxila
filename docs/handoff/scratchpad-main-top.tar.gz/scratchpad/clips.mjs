import { readFileSync, writeFileSync } from "fs";
const ROOT = "/home/user/Taxila/";
for (const line of readFileSync(ROOT + ".env.local", "utf8").split("\n")) {
  const m = line.match(/^([A-Z0-9_]+)=(.*)$/);
  if (m && !process.env[m[1]]) process.env[m[1]] = m[2].replace(/^"(.*)"$/, "$1");
}
const { tts } = await import(ROOT + "server/azure.js");
const clips = {
  hi: "नमस्ते! मैं आशा दीदी हूँ, एक कंप्यूटर टीचर, इंसान नहीं। मैं आपके बच्चे से बात करके पढ़ाती हूँ, और आपको दिखाती हूँ कि उसने सच में क्या समझा।",
  hinglish: "Namaste! Main Asha didi hoon, ek computer teacher, insaan nahi. Main aapke bacche se baat karke padhaati hoon, aur aapko dikhaati hoon ki usne sach mein kya samjha.",
  en: "Hello! I am Asha didi, a computer teacher, not a person. I teach your child by talking with them, and I show you what they have really understood.",
};
for (const [k, text] of Object.entries(clips)) {
  const buf = await tts(text, "marin");
  writeFileSync(`${ROOT}public/audio/hello-${k}.mp3`, buf);
  console.log(k, buf.length);
}
