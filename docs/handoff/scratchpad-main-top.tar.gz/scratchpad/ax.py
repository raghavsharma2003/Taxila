import sys,re,urllib.request,urllib.parse
q=sys.argv[1]; n=sys.argv[2] if len(sys.argv)>2 else '12'
u="https://export.arxiv.org/api/query?"+urllib.parse.urlencode({'search_query':q,'sortBy':'submittedDate','sortOrder':'descending','max_results':n})
t=urllib.request.urlopen(u,timeout=60).read().decode()
for e in t.split('<entry>')[1:]:
  g=lambda k: re.sub(r'\s+',' ',re.search('<'+k+'>(.*?)</'+k+'>',e,re.S).group(1)).strip()
  print('##',g('published')[:10],g('title'),re.search('<id>(.*?)</id>',e).group(1));print(g('summary')[:int(sys.argv[3]) if len(sys.argv)>3 else 600]);print()
