import { readdirSync, readFileSync } from "node:fs";
import { normalizeKit } from "/home/user/Taxila/server/content/kits.js";
import { fadeItem, fadeStepIndex, blankOf, workedLeadContent, fadedContent } from "/home/user/Taxila/server/director/fading.js";
const dir = "/home/user/Taxila/data/kits/";
let n=0, withFade=0, inShown=0, inProblem=0, inLead=0, trivial=0; const ex=[];
const norm = (x) => String(x).toLowerCase().replace(/\s+/g," ").trim();
for (const f of readdirSync(dir)) {
  const m = f.match(/^c(\d)-/); if (!m || +m[1] < 4 || +m[1] > 7 || !f.endsWith(".json")) continue;
  const j = JSON.parse(readFileSync(dir+f,"utf8"));
  for (const t of j.topics ?? []) {
    const kit = normalizeKit(t, { topicId: t.topicId, verified: true }); n++;
    const it = fadeItem(kit, { band: "B3" }); if (!it) continue; withFade++;
    const i = Number(it.id.slice(5)); const we = kit.workedExample; const a = norm(it.answer);
    const shown = norm(fadedContent(we, i).join(" | ").replace(we.fadedVersion[i], ""));
    const lead = norm(workedLeadContent(we, i).join(" "));
    const re = new RegExp(`(^|[^\\w])${a.replace(/[.*+?^${}()|[\]\\]/g,"\\$&")}($|[^\\w])`);
    if (re.test(norm(we.problem))) inProblem++;
    if (re.test(lead)) inLead++;
    if (re.test(shown)) { inShown++; if (ex.length < 6) ex.push({ topic: t.topicId, answer: it.answer, line: we.fadedVersion[i], prev: we.steps.slice(0,i) }); }
    if (a.length <= 1) trivial++;
  }
}
console.log({ n, withFade, inProblem, inLead, inShown, trivial });
console.log(JSON.stringify(ex, null, 1));
