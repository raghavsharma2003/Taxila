exec(open('awsenv.py').read())
import json
p=boto3.client('polly',region_name='us-east-1')
for lang in ['hi-IN','en-IN']:
    for x in p.describe_voices(LanguageCode=lang,IncludeAdditionalLanguageCodes=True)['Voices']: print('polly-use1',lang,x['Id'],x['SupportedEngines'])
for r in ['us-east-1','ap-south-1']:
    sq=boto3.client('service-quotas',region_name=r); qs=[]; tok=None
    while True:
        kw={'ServiceCode':'bedrock','MaxResults':100}
        if tok: kw['NextToken']=tok
        x=sq.list_service_quotas(**kw); qs+=x['Quotas']; tok=x.get('NextToken')
        if not tok: break
    for q in qs:
        n=q['QuotaName']
        if any(s in n.lower() for s in ['per day']) and any(s in n.lower() for s in ['nova','kimi','grok','glm','minimax','gpt-oss','qwen3 next','mistral large 3','sonic']):
            print(r, n[:95], q['Value'], q.get('Adjustable'))
