import sys, urllib.parse, subprocess, json
q=sys.argv[1]; n=sys.argv[2] if len(sys.argv)>2 else "5"
url="https://www.ebi.ac.uk/europepmc/webservices/rest/search?query="+urllib.parse.quote(q)+f"&format=json&resultType=core&pageSize={n}"
x=subprocess.run(["curl","-sS","-L","--max-time","40",url],capture_output=True,text=True).stdout
try: d=json.loads(x)
except Exception: print("ERR",x[:300]); sys.exit()
for r in d.get("resultList",{}).get("result",[]):
  print(f"## {r.get('pubYear')} | {r.get('title')} | {r.get('authorString','')[:80]} | {r.get('journalTitle') or r.get('journalInfo',{}).get('journal',{}).get('title','')} | doi:{r.get('doi')} pmid:{r.get('pmid')}")
  print("   ",(r.get('abstractText') or '')[:1100].replace('<h4>','').replace('</h4>',' '),"\n")
