// Stream 3's checks 4 + 5, read-only ARM: the reply account's metrics and resource health, and the web app's replica
// CPU / memory / restarts, 2026-10-16 08:30-09:45Z (the census lessons 11-13 window). Prints aggregates only; no secret
// is printed. node --env-file=.env.local armmetrics1016.mjs
const E = process.env;
const tok = await (await fetch(`https://login.microsoftonline.com/${E.AZURE_TENANT_ID}/oauth2/v2.0/token`, { method: "POST",
  body: new URLSearchParams({ grant_type: "client_credentials", client_id: E.AZURE_SP_CLIENT_ID, client_secret: E.AZURE_SP_SECRET, scope: "https://management.azure.com/.default" }) })).json();
if (!tok.access_token) { console.log("no token:", tok.error); process.exit(1); }
const H = { Authorization: `Bearer ${tok.access_token}` };
const get = async (p) => { const r = await fetch(p.startsWith("http") ? p : `https://management.azure.com${p}`, { headers: H }); const j = await r.json().catch(() => ({})); if (!r.ok) console.log("  !", r.status, p.slice(0, 120), j.error?.code); return j; };
const T = "2026-10-16T08:30:00Z/2026-10-16T09:45:00Z";
const subs = (await get("/subscriptions?api-version=2022-12-01")).value ?? [];
console.log("subscriptions visible:", subs.length);
const host = new URL(E.AZURE_OPENAI_ENDPOINT).host.split(".")[0];
let acct = null;
for (const s of subs) {
  const list = (await get(`/subscriptions/${s.subscriptionId}/providers/Microsoft.CognitiveServices/accounts?api-version=2023-05-01`)).value ?? [];
  acct ??= list.find((a) => (a.properties?.endpoint ?? "").includes(host) || a.name === host || (a.properties?.customSubDomainName ?? "") === host);
  const all = list.map((a) => `${a.name}@${a.location}`);
  console.log(`sub ${s.displayName?.slice(0, 20)}: ${list.length} AI accounts`, all.slice(0, 12).join(", "));
}
console.log("reply account:", acct ? `${acct.name} (${acct.location}, ${acct.kind})` : `not found for host ${host}`);
const metrics = async (id, names, extra = "") => {
  const j = await get(`${id}/providers/microsoft.insights/metrics?api-version=2023-10-01&timespan=${T}&interval=PT5M&metricnames=${encodeURIComponent(names)}${extra}`);
  for (const m of j.value ?? []) for (const ts of m.timeseries ?? []) {
    const dims = (ts.metadatavalues ?? []).map((d) => `${d.name?.value}=${d.value}`).join(",");
    const pts = (ts.data ?? []).map((d) => d.average ?? d.total ?? d.maximum ?? null).filter((x) => x != null);
    if (!pts.length) continue;
    console.log(`  ${m.name.value}${dims ? `[${dims}]` : ""}: ${pts.map((x) => Math.round(x)).join(" ")}`);
  }
};
if (acct) {
  console.log("4) reply account metrics, 5-min buckets 08:30-09:45Z");
  await metrics(acct.id, "AzureOpenAIRequests", "&aggregation=Total&$filter=" + encodeURIComponent("StatusCode eq '*'"));
  await metrics(acct.id, "AzureOpenAITimeToResponse,AzureOpenAIProvisionedManagedUtilizationV2", "&aggregation=Average,Maximum");
  await metrics(acct.id, "ServerErrors,ClientErrors,Ratelimit", "&aggregation=Total");
  const rh = await get(`${acct.id}/providers/Microsoft.ResourceHealth/availabilityStatuses?api-version=2022-10-01&$filter=${encodeURIComponent("properties/occuredTime ge 2026-10-15T00:00:00Z")}`);
  console.log("  resource health:", (rh.value ?? []).slice(0, 8).map((x) => `${x.properties?.occuredTime ?? x.properties?.occurredTime} ${x.properties?.availabilityState} ${x.properties?.reasonType ?? ""}`).join(" | ") || "none / not readable");
}
const sub0 = E.AZURE_SUBSCRIPTION_ID;
const ev = await get(`/subscriptions/${sub0}/providers/Microsoft.ResourceHealth/events?api-version=2022-10-01&queryStartTime=2026-10-15T00:00:00Z`);
console.log("service health events since 10-15:", (ev.value ?? []).map((x) => `${x.properties?.eventType} ${x.properties?.title?.slice(0, 80)} [${(x.properties?.impact ?? []).map((i) => i.impactedService).join(",")}]`).join(" | ") || "none");
console.log("5) web app replicas, 5-min buckets");
const app = `/subscriptions/${sub0}/resourceGroups/${E.AZURE_RESOURCE_GROUP}/providers/Microsoft.App/containerApps/taxila-web`;
await metrics(app, "UsageNanoCores,WorkingSetBytes", "&aggregation=Average,Maximum");
await metrics(app, "RestartCount,Replicas,Requests", "&aggregation=Maximum,Total");
process.exit(0);
