// Real-model lines for the 14.3 fine release (resumeAfterFine) vs the shipped stay line, through the SAME compile +
// textReply the text lane uses. Run with DATABASE_URL= (empty): model calls only, nothing written to any trace.
import { initLessonState, step } from "/home/user/taxila-int/server/director/state.js";
import { instructionsFor } from "/home/user/taxila-int/server/compiler/instructions.js";
import { textReply } from "/home/user/taxila-int/server/brain/say.js";
import { floorViolations } from "/home/user/taxila-int/server/director/safety.js";
import { kit, CTX, BRIEF, cls } from "/home/user/taxila-int/tests/fixtures/kit.mjs";
const K = kit();
const replies = ["haan… ab safe hoon… wo bhag gaya tha…", "Haan ji, I am okay, mummy ne medicine lagayi. It's just a scratch.", "main theek hoon didi, kuch nahi hua", "I'm okay, it was just a small scratch"];
const N = Number(process.argv[2] ?? 2);
for (const lang of ["hinglish", "english"]) for (const t of replies) for (let i = 0; i < N; i++) {
  const s0 = step(initLessonState({ topicId: K.topicId, kit: K, ctx: { ...CTX, lang }, seed: 7 + i, now: 0 }), { event: "start", kit: K, now: 0 }).state;
  const base = cls("no_evidence");
  const o = step(s0, { event: "turn", kit: K, cls: { ...base, source: "classifier", flags: { ...base.flags, distress: true, distressKind: "model" } }, text: "my cat scratched me yesterday, it bled a little", now: 10_000 });
  const r = step(o.state, { event: "turn", kit: K, cls: cls("no_evidence"), text: t, now: 20_000 });
  const st = { ...r.state, brief: BRIEF, mode: "text" };
  const instructions = instructionsFor(st, K, "text");
  const out = await textReply({ instructions, state: st, kit: K, childText: t, ui: r.ui, module: null });
  const line = typeof out === "string" ? out : out?.text ?? out?.reply ?? JSON.stringify(out).slice(0, 200);
  console.log(`[${lang}] ${r.move.kind}/${r.move.shape ? "shape" : "-"} chips=${(r.ui?.chips ?? []).map((c) => c.id).join(",")} floor=${JSON.stringify(floorViolations(line))}\n   child: ${t}\n   asha:  ${line}`);
}
process.exit(0);
