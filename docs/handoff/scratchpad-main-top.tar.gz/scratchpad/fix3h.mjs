import fs from 'fs';
const P='/home/user/Taxila/data/kits/c3-hindi.json';
const k=JSON.parse(fs.readFileSync(P,'utf8'));
const D='2026-10-02';
const topic=c=>k.topics.find(t=>t.topicId===`c3-hindi-${c}-t01`);
const mc=id=>{for(const t of k.topics)for(const m of t.misconceptions)if(m.id===id)return m;throw id};
const item=id=>{for(const t of k.topics)for(const i of t.items)if(i.id===id)return i;throw id};
let n=0;
// 1. spelling diagnostics: replace the spelled answer with a meaning cue
const rw={
 'c3-hindi-ch01-t01-mc-chandrabindu':['खिलखिलाकर ठहाका लगाने को क्या कहते हैं? इनमें से सही लिखा शब्द चुनो।','What do we call laughing out loud? Pick the correctly written word.'],
 'c3-hindi-ch02-t01-mc-bindu-drop':['कविता वाली नन्ही, मेहनती जीव, जो लाइन में दाना ढोती है — उसका नाम इनमें से सही कैसे लिखा है?','The tiny hard-working creature from the poem that carries grain in a line — which spelling of its name is right?'],
 'c3-hindi-ch03-t01-mc-ai-e':['जिनसे हम चलते और दौड़ते हैं, उन्हें क्या कहते हैं? सही लिखा शब्द चुनो।','What do we walk and run with? Pick the correctly written word.'],
 'c3-hindi-ch04-t01-mc-da-rha':['जो पंखों से उड़ती है और डाली पर घोंसला बनाती है, उसे क्या कहते हैं? सही लिखा शब्द चुनो।','What do we call the one that flies with wings and builds a nest on a branch? Pick the correctly written word.'],
 'c3-hindi-ch05-t01-mc-da-dha':['जो बहुत उम्र का हो, उसे क्या कहते हैं? सही लिखा शब्द चुनो।','What do we call someone who is very old? Pick the correctly written word.'],
 'c3-hindi-ch05-t01-mc-patta-pata':['पेड़ की डाली पर जो हरी चीज़ लगती है और पतझड़ में गिर जाती है, उसे क्या कहते हैं? सही शब्द चुनो।','What is the green thing on a tree branch that falls in autumn called? Pick the right word.'],
 'c3-hindi-ch06-t01-mc-da-rha':['बीरबल ने हाँडी में चावल-दाल मिलाकर जो पकाई, उसे क्या कहते हैं? सही लिखा शब्द चुनो।','What is the rice-and-dal dish Birbal cooked in the pot called? Pick the correctly written word.'],
 'c3-hindi-ch07-t01-mc-tra-split':['रिया ने पत्र में ‘प्रिय ___ सारा’ लिखा — दोस्त के लिए जो शब्द आया, वह सही कैसे लिखा है?','Riya wrote "प्रिय ___ सारा" in the letter — which spelling of the word for friend is right?'],
 'c3-hindi-ch08-t01-mc-da-rha':['बाघ को चालाकी से वापस पिंजरे में भेजने वाला जानवर कौन था? उसका नाम सही कैसे लिखा है?','Which animal cleverly sent the tiger back into the cage? Which spelling of its name is right?'],
 'c3-hindi-ch09-t01-mc-ri-matra':['पेड़, फूल, नदी, पहाड़ — इन सबको मिलाकर क्या कहते हैं? सही लिखा शब्द चुनो।','Trees, flowers, rivers, mountains — what do we call all of these together? Pick the correctly written word.'],
 'c3-hindi-ch11-t01-mc-jadui-matra':['‘जादू’ वाली चीज़ — ‘___ पिटारा’। खाली जगह का शब्द सही कैसे लिखा है?','Something with जादू (magic) — "___ पिटारा". Which spelling of the missing word is right?'],
 'c3-hindi-ch11-t01-mc-ta-tha':['दादी का वह बड़ा डिब्बा, जिसमें से कहानियाँ निकलती हैं — कविता में उसे क्या कहा है? सही लिखा शब्द चुनो।','Grandma\'s big box that stories come out of — what does the poem call it? Pick the correctly written word.'],
 'c3-hindi-ch13-t01-mc-kka-conjunct':['जो दादी सड़क किनारे बरगद लगाकर ‘पेड़ों की अम्मा’ कहलाईं, उनका नाम सही कैसे लिखा है?','The grandmother who planted banyans by the road and was called the mother of trees — which spelling of her name is right?'],
 'c3-hindi-ch14-t01-mc-sha-sa':['दिमाग़ और समझदारी से काम निकालने को क्या कहते हैं? सही लिखा शब्द चुनो।','What do we call getting things done with brains and good sense? Pick the correctly written word.'],
 'c3-hindi-ch15-t01-mc-uttar-utar':['भारत में हिमालय जिस दिशा में है, उस दिशा का नाम सही कौन-सा है?','Which is the right name of the direction in which the Himalaya lies in India?'],
 'c3-hindi-ch16-t01-mc-dra-split':['भारत का जो यान चाँद पर उतरा, उसका नाम सही कैसे लिखा है?','India\'s craft that landed on the Moon — which spelling of its name is right?'],
 'c3-hindi-ch16-t01-mc-kshya-chha':['धरती के ऊपर, जहाँ तारे और ग्रह हैं, उस खुली जगह को क्या कहते हैं? सही लिखा शब्द चुनो।','The open place above the Earth where the stars and planets are — what is it called? Pick the correctly written word.'],
 'c3-hindi-ch17-t01-mc-bindu-maand':['गीदड़ का गुफा जैसा घर, जिसमें शेर छिपा था, उसे क्या कहते हैं? सही लिखा शब्द चुनो।','The jackal\'s cave-like home where the lion hid — what is it called? Pick the correctly written word.'],
};
for(const [id,[hi,en]] of Object.entries(rw)){const d=mc(id).diagnostic;const c=d.options.find(o=>o.correct).text;
 if(hi.includes(c))throw 'still leaks '+id;
 d.prompt_hi=hi;d.prompt_en=en;
 d.verified.note=(d.verified.note?d.verified.note+' ':'')+`Fixed after checker review (${D}): prompt_hi used to spell the correct option, so a child shown the prompt as text could copy it. It now gives a meaning cue. Solved again: exactly one option fits the cue and is correctly spelled. Spoken options can sound alike (nasal/matra contrasts), so this diagnostic needs the on-screen option chips.`;
 n++;}
// 2. minor notes
let it=item('c3-hindi-ch03-t01-i07');it.hints[1]="We say 'मेरा पैर दुखता है' — पैर is a he-word, so the question uses -ने.";
it.verified.note=`Fixed after checker review (${D}): hint 2 used to reason from 'एक पैर', but एक does not show gender. It now reasons from 'मेरा पैर दुखता है'. Key agrees.`;n++;
it=item('c3-hindi-ch15-t01-i07');it.acceptable=it.acceptable.filter(a=>a!=='छोटा');
it.verified.note=`Fixed after checker review (${D}): removed 'छोटा' from acceptable. It is the opposite of बड़ा; the opposite of ऊँचा is नीचा. Key agrees.`;n++;
it=item('c3-hindi-ch17-t01-i09');it.acceptable.push('मीठी आवाज़','meethi awaaz','बुलाने वाली आवाज़','sweet');
it.verified.note=`Fixed after checker review (${D}): the lion is luring the jackal in, so a falsely sweet, inviting voice is also a valid reading; added those forms to acceptable. Key (deep, echoing) unchanged and agrees.`;n++;
// 3. targeted items for untargeted misconceptions
const add=(c,obj)=>{const t=topic(c);if(t.items.find(i=>i.id===obj.id))return;if(!t.skills.find(s=>s.id===obj.skillId))throw obj.skillId;
 if(!t.misconceptions.find(m=>m.id===obj.targetsMisconception))throw obj.targetsMisconception;t.items.push(obj);n++;};
const V=(s,why)=>({solverAnswer:s,agrees:true,note:`Added after checker review (${D}): no item targeted ${why}, so its diagnostic was anchored to items[0] and recorded evidence against the wrong skill. Solved independently; key agrees.`});
add('ch02',{id:'c3-hindi-ch02-t01-i13',skillId:'c3-hindi-ch02-t01-s4',kind:'error_spot',difficulty:2,
 prompt_en:"Meena wrote 'चीटी दाना ले गई'. What is missing in 'चीटी'?",
 prompt_hi:'मीना ने लिखा — ‘चीटी दाना ले गई।’ ‘चीटी’ में क्या छूट गया?',
 answer:'ची के ऊपर बिंदु (ं) छूट गया — सही है चींटी',
 acceptable:['चींटी','बिंदु','bindu','बिंदी','bindi','ऊपर बिंदु','cheenti'],
 hints:['Say the word slowly. Do you feel a hum in your nose after ची?','That nose-hum needs a mark on top of the letter.','ची + a dot on top + टी = ?','चींटी needs a bindu (ं) on ची.'],
 targetsMisconception:'c3-hindi-ch02-t01-mc-bindu-drop',verified:V('बिंदु छूटा — चींटी','ch02 bindu-drop')});
add('ch04',{id:'c3-hindi-ch04-t01-i13',skillId:'c3-hindi-ch04-t01-s4',kind:'contrast',difficulty:2,
 prompt_en:"Say 'चिड़िया'. Is the first sound short or long — does it take छोटी इ (ि) or बड़ी ई (ी)?",
 prompt_hi:'‘चिड़िया’ बोलो। पहली आवाज़ छोटी है या खिंची हुई — ‘च’ पर छोटी इ (ि) आएगी या बड़ी ई (ी)?',
 answer:'छोटी इ (ि) — चिड़िया',
 acceptable:['छोटी इ','chhoti i','ि','छोटी','chhoti','छोटी वाली','चिड़िया'],
 hints:['Clap it: चि-ड़ि-या. Is the first beat quick or stretched?','A quick sound gets the small matra.','च + ___ = चि (ि or ी)?','चिड़िया starts with छोटी इ: चि.'],
 targetsMisconception:'c3-hindi-ch04-t01-mc-i-ii',verified:V('छोटी इ (ि)','ch04 i-ii')});
add('ch06',{id:'c3-hindi-ch06-t01-i13',skillId:'c3-hindi-ch06-t01-s4',kind:'contrast',difficulty:2,
 prompt_en:"Say 'बीरबल' slowly. Which matra goes on the first letter ब — छोटी इ (ि) or बड़ी ई (ी)?",
 prompt_hi:'‘बीरबल’ धीरे-धीरे बोलो। पहले अक्षर ‘ब’ पर कौन-सी मात्रा लगेगी — छोटी इ (ि) या बड़ी ई (ी)?',
 answer:'बड़ी ई (ी) — बीरबल',
 acceptable:['बड़ी ई','badi ee','badi i','ी','लंबी ई','lambi ee','बड़ी','बड़ी वाली','बीरबल'],
 hints:['Clap it: बी-र-बल. Is the first beat quick or stretched?','A stretched ई sound gets the long matra.','ब + ___ = बी (ि or ी)?','बीरबल takes बड़ी ई (ी).'],
 targetsMisconception:'c3-hindi-ch06-t01-mc-ii-name',verified:V('बड़ी ई (ी)','ch06 ii-name')});
add('ch11',{id:'c3-hindi-ch11-t01-i13',skillId:'c3-hindi-ch11-t01-s2',kind:'error_spot',difficulty:2,
 prompt_en:"Golu wrote 'दादी का पिठारा'. Which letter in 'पिठारा' is wrong?",
 prompt_hi:'गोलू ने लिखा — ‘दादी का पिठारा।’ ‘पिठारा’ में कौन-सा अक्षर गलत है?',
 answer:'ठ गलत है, ट आएगा — पिटारा',
 acceptable:['ठ','ट','ठ गलत है','टमाटर वाला ट','पिटारा','pitara','tha','ta'],
 hints:['Say पि-टा-रा. Is there a puff of air after the middle sound?','ठ has a puff (ठंडा); ट has none (टमाटर).','पि___ारा — ट or ठ?','It is पिटारा, with ट, not ठ.'],
 targetsMisconception:'c3-hindi-ch11-t01-mc-ta-tha',verified:V('ठ की जगह ट — पिटारा','ch11 ta-tha')});
fs.writeFileSync(P,JSON.stringify(k,null,2)+'\n');
console.log('changes',n);
