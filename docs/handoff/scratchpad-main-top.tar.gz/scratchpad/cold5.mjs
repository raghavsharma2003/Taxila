import { performance } from "node:perf_hooks";
const L = await import("/home/user/Taxila/server/safety/lexicon.js");
for (const l of ["aap mummy se achhi ho", "main buddhu hoon", "aapka number do na", "kuch naya sentence bolo"]) {
  let a = performance.now(); const r = L.canonicalReadings(l); const t1 = performance.now() - a;
  a = performance.now(); L.lexiconScan(l); const t2 = performance.now() - a;
  console.log(l, "readings", t1.toFixed(2), r.length, "scan(again)", t2.toFixed(2));
}
