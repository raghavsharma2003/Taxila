// READ-ONLY: env var NAMES (never values) of two taxila-web revisions, and which differ
const { arm, loadEnv, SUB_PATH } = await import("/home/user/Taxila/infra/azure.mjs");
loadEnv?.();
const base = `${SUB_PATH()}/resourceGroups/${process.env.AZURE_RESOURCE_GROUP}/providers/Microsoft.App/containerApps/taxila-web`;
const names = async (rev) => { const r = await arm("GET", `${base}/revisions/${rev}?api-version=2024-03-01`); return new Set((r.properties.template.containers[0].env || []).map((e) => e.name)); };
const [a, b] = await Promise.all(process.argv.slice(2, 4).map(names));
console.log(`${process.argv[2]}: ${a.size} names; ${process.argv[3]}: ${b.size} names`);
console.log("only in first:", [...a].filter((n) => !b.has(n)).join(", ") || "none");
console.log("only in second:", [...b].filter((n) => !a.has(n)).join(", ") || "none");
console.log("TRACE names in second:", [...b].filter((n) => /TRACE/.test(n)).join(", "));
