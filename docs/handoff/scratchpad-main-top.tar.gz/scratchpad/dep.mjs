import { arm, loadEnv, SUB_PATH } from "/home/user/Taxila/infra/azure.mjs";
loadEnv();
const base=`${SUB_PATH()}/resourceGroups/rg-raghavsharma1729-7190/providers/Microsoft.CognitiveServices/accounts`;
for (const n of ["taxila-fast","taxila-realtime","taxila-flux2","DeepSeek-V4-Pro"]) { const j=await arm("GET",`${base}/raghavsharma1729-compan-resource/deployments/${n}?api-version=2024-10-01`); console.log(n, JSON.stringify({sku:j.sku,p:{...j.properties, capabilities:undefined, rateLimits:undefined}})); }
const rai=await arm("GET",`${base}/raghavsharma1729-compan-resource/raiPolicies?api-version=2024-10-01`); console.log("eus2 rai", (rai.value||[]).map(r=>r.name));
const rai2=await arm("GET",`${base}/taxila-ai-southindia/raiPolicies?api-version=2024-10-01`); console.log("si rai", (rai2.value||[]).map(r=>r.name));
const a=await arm("GET",`${base}/taxila-ai-southindia?api-version=2024-10-01`); console.log(JSON.stringify({kind:a.kind,sku:a.sku,endpoints:a.properties.endpoints,pna:a.properties.publicNetworkAccess,local:a.properties.disableLocalAuth}));
