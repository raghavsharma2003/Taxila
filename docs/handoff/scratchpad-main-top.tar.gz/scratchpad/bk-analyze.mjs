import fs from "fs";
const R = JSON.parse(fs.readFileSync("/home/user/Taxila/evals/conversation-v2/results/2026-10-04-run1/understand-bakeoff/results.json", "utf8"));
const by = {}; for (const a of Object.keys(R.results)) by[a] = new Map(R.results[a].map((r) => [r.id, r]));
const ids = [...by.grok.keys()];
let seed = 5; const rnd = () => { seed = (seed * 1103515245 + 12345) % 2147483648; return seed / 2147483648; };
function paired(a, b) {
  const d = ids.map((id) => (by[a].get(id)?.action ? 1 : 0) - (by[b].get(id)?.action ? 1 : 0));
  const mean = d.reduce((x, y) => x + y, 0) / d.length;
  const ms = []; for (let k = 0; k < 4000; k++) { let s = 0; for (let i = 0; i < d.length; i++) s += d[Math.floor(rnd() * d.length)]; ms.push(s / d.length); }
  ms.sort((x, y) => x - y);
  return { mean: +(mean * 100).toFixed(1), ci80: [+(ms[400] * 100).toFixed(1), +(ms[3599] * 100).toFixed(1)], winsA: d.filter((x) => x > 0).length, winsB: d.filter((x) => x < 0).length };
}
for (const [a, b] of [["sol6", "grok"], ["sol6", "fast"], ["sol6", "luna6"], ["sol6low", "sol6"], ["luna6", "grok"], ["fast", "grok"]]) console.log(`${a} - ${b}:`, JSON.stringify(paired(a, b)));
// where grok fails
const fails = {}; for (const id of ids) { const g = by.grok.get(id); if (!g.action) { const k = g.gold[0]; (fails[k] ??= []).push(`${g.note?.intent ?? "ERR"}${by.sol6.get(id)?.action ? "" : "*"}`); } }
console.log("grok action misses by gold (pred; * = sol6 also wrong):"); for (const [k, v] of Object.entries(fails).sort((x, y) => y[1].length - x[1].length)) console.log(`  ${k} (${v.length}): ${v.join(", ")}`);
const sf = {}; for (const id of ids) { const g = by.sol6.get(id); if (!g.action) (sf[g.gold[0]] ??= []).push(g.note?.intent ?? "ERR"); }
console.log("sol6 misses:"); for (const [k, v] of Object.entries(sf).sort((x, y) => y[1].length - x[1].length)) console.log(`  ${k} (${v.length}): ${v.join(", ")}`);
// distress misses
for (const a of ["grok", "fast", "luna6", "sol6", "sol6low"]) console.log(a, "distress missed:", ids.filter((id) => by[a].get(id).goldDistress && !by[a].get(id).distress).join(","));
// cascade simulation: grok first; escalate to sol6 when grok confidence < t, or grok intent in HARD, or grok error
const HARD = new Set(process.argv[2]?.split(",") ?? []);
for (const t of [0, 0.6, 0.7, 0.8, 0.85, 0.9, 0.95]) {
  let ok = 0, esc = 0; const ms = [];
  for (const id of ids) {
    const g = by.grok.get(id), s = by.sol6.get(id);
    const go = !g.note || g.note.confidence < t || HARD.has(g.note.intent);
    if (go) { esc++; ok += s.action ? 1 : 0; ms.push(g.ms + s.ms); } else { ok += g.action ? 1 : 0; ms.push(g.ms); }
  }
  ms.sort((a, b) => a - b);
  console.log(`cascade t=${t}${HARD.size ? " +hard" : ""}: action ${ok}/${ids.length} (${(100 * ok / ids.length).toFixed(1)}%), escalated ${esc} (${(100 * esc / ids.length).toFixed(0)}%), p50 ${ms[Math.floor(ms.length / 2)]} p90 ${ms[Math.floor(ms.length * 0.9)]}`);
}
// parallel race: run both, take sol6 when it returns within budget else grok
// deadline race: sol6 and grok start together at the turn boundary; use sol6 if it lands within D ms, else grok
for (const D of [1200, 1500, 1800, 2000, 2500, 3000]) {
  let ok = 0, usedSol = 0; const lat = [];
  for (const id of ids) {
    const g = by.grok.get(id), s = by.sol6.get(id);
    const solIn = s.note && s.ms <= D;
    if (solIn) { usedSol++; ok += s.action ? 1 : 0; lat.push(s.ms); }
    else { ok += g.action ? 1 : 0; lat.push(Math.max(Math.min(D, s.ms), g.ms)); }
  }
  lat.sort((a, b) => a - b);
  console.log(`race D=${D}: action ${ok}/${ids.length} (${(100 * ok / ids.length).toFixed(1)}%), sol6 used ${usedSol}, latency p50 ${lat[Math.floor(lat.length / 2)]} p90 ${lat[Math.floor(lat.length * 0.9)]}`);
}
