import os, json, urllib.request, urllib.parse
t = json.load(urllib.request.urlopen(urllib.request.Request(f"https://login.microsoftonline.com/{os.environ['AZURE_TENANT_ID']}/oauth2/v2.0/token",
  data=urllib.parse.urlencode({"grant_type":"client_credentials","client_id":os.environ["AZURE_SP_CLIENT_ID"],"client_secret":os.environ["AZURE_SP_SECRET"],"scope":"https://management.azure.com/.default"}).encode())))["access_token"]
def get(u): return json.load(urllib.request.urlopen(urllib.request.Request("https://management.azure.com"+u, headers={"Authorization":"Bearer "+t})))
sub=os.environ["AZURE_SUBSCRIPTION_ID"]
accts=[]
for a in accts:
    print("ACCOUNT", a["name"], a["location"], a["kind"], a["properties"].get("endpoint"))
    try:
        ds=get(a["id"]+"/deployments?api-version=2024-10-01")["value"]
        for d in ds:
            m=d["properties"]["model"]
            if any(k in m["name"].lower() for k in ("tts","transcribe","audio","mai","speech","whisper")):
                print("   ", d["name"], m["name"], m.get("version"), d["sku"]["name"])
    except Exception as e: print("   err", e)
print("---catalog")
for loc in ("southindia","eastus2"):
    ms=get(f"/subscriptions/{sub}/providers/Microsoft.CognitiveServices/locations/{loc}/models?api-version=2024-10-01")["value"]
    hits=sorted({(m["model"]["name"],m["model"].get("version"),",".join(s["name"] for s in m["model"].get("skus",[]))) for m in ms if "tts" in m["model"]["name"].lower() or "voice" in m["model"]["name"].lower()})
    print(loc, hits)
