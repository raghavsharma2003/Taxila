import { openHarness } from "/home/user/Taxila/scripts/character/harness.mjs";
process.chdir("/home/user/Taxila");
const hx = await openHarness({ w: 300, h: 300 });
try {
  await hx.page.evaluate(() => TX.load("plum", "H"));
  const r = await hx.page.evaluate(() => {
    const o = {};
    for (const [n, m] of Object.entries(TX.rig.meshes)) {
      const u = m.material.uniforms || {};
      const t = (u.tAlbedo || {}).value;
      const uv = m.geometry.attributes.uv;
      o[n] = t ? { name: t.name, off: t.offset.toArray(), rep: t.repeat.toArray(), w: t.image && t.image.width, uvNorm: uv.normalized, uvType: uv.array.constructor.name } : null;
    }
    return o;
  });
  console.log(JSON.stringify(r, null, 0));
} finally { await hx.close(); }
