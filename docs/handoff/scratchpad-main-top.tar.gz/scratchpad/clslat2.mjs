const { q } = await import("/home/user/taxila-int/server/db.js");
const rows = (r) => r.rows ?? r;
await q("begin read only");
const r = rows(await q(`
  with m as (select e.data from trace_event e where e.kind = 'model.call' and e.t > now() - interval '7 days'
             and exists (select 1 from lesson l where l.id::text = e.sid) and e.data ? 'ms')
  select data->>'deployment' dep, coalesce(data->>'promptId', '?') pid, coalesce(data->>'kind','?') k, coalesce(data->>'lane','?') lane,
         count(*) n, round(percentile_cont(0.5) within group (order by (data->>'ms')::float)) p50,
         round(percentile_cont(0.9) within group (order by (data->>'ms')::float)) p90,
         round(percentile_cont(0.95) within group (order by (data->>'ms')::float)) p95,
         count(*) filter (where data ? 'error') errs
  from m where data->>'deployment' in ('grok-4-1-fast-non-reasoning','taxila-fast') group by 1,2,3,4 having count(*) >= 3 order by n desc limit 25`));
console.table(r);
await q("rollback"); process.exit(0);
