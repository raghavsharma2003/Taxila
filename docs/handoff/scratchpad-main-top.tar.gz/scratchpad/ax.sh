for q in "$@"; do
 echo "=== $q"
 curl -sS --max-time 30 -G "https://export.arxiv.org/api/query" --data-urlencode "search_query=$q" --data-urlencode "max_results=4" --data-urlencode "sortBy=relevance" | python3 -c 'import sys,re
x=sys.stdin.read()
for e in x.split("<entry>")[1:]:
  t=re.search(r"<title>(.*?)</title>",e,re.S).group(1).split()
  i=re.search(r"<id>(.*?)</id>",e).group(1); d=re.search(r"<published>(.*?)</published>",e).group(1)[:10]
  s=" ".join(re.search(r"<summary>(.*?)</summary>",e,re.S).group(1).split())
  print("-"," ".join(t),"|",i,"|",d); print("  ",s[:900])'
 sleep 4
done
