// read-only: for stream 2 #7, the board pages behind census F9 "same board twice" (no child words)
const { q } = await import("/home/user/taxila-int/server/db.js");
const rows = (r) => r.rows ?? r;
await q("begin read only");
for (const pre of ["3437b744", "310b8c82"]) {
  const L = rows(await q(`select id::text, started_at from lesson where id::text like $1`, [`${pre}%`]))[0];
  const kinds = rows(await q(`select kind, count(*)::int n from trace_event where sid=$1 group by kind order by kind`, [L.id]));
  const first = rows(await q(`select kind, data from trace_event where sid=$1 order by t limit 3`, [L.id]));
  console.log(pre, L.started_at.toISOString(), kinds.filter((k) => /board|studio|tray|stage|page|build|start|version/i.test(k.kind)).map((k) => `${k.kind}:${k.n}`).join(" "));
  console.log("  first:", first.map((f) => `${f.kind} ${JSON.stringify(f.data ?? {}).slice(0, 160)}`).join(" | "));
}
await q("rollback"); process.exit(0);
