// READ-ONLY: for each env name on taxila-web's live template, how many of the given hashes (comma list on stdin-free argv
// --hashes) it contains. Prints counts only, never a value.
const { arm, loadEnv, SUB_PATH } = await import("/home/user/Taxila/infra/azure.mjs");
loadEnv?.();
const a = process.argv.slice(2), i = a.indexOf("--hashes"), hashes = (a[i + 1] || "").split(",").filter(Boolean), names = a.filter((x, k) => k !== i && k !== i + 1);
const app = await arm("GET", `${SUB_PATH()}/resourceGroups/${process.env.AZURE_RESOURCE_GROUP}/providers/Microsoft.App/containerApps/taxila-web?api-version=2024-03-01`);
const env = new Map((app.properties.template.containers[0].env || []).map((e) => [e.name, e.value ?? ""]));
console.log(`latest ${app.properties.latestRevisionName}`);
for (const n of names) { const parts = String(env.get(n) ?? "").split(",").map((s) => s.trim()); console.log(`${n}: holds ${hashes.filter((h) => parts.includes(h)).length}/${hashes.length} of the given hashes (${parts.filter(Boolean).length} entries)`); }
