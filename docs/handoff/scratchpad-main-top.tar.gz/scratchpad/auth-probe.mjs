import http from "http"; import fs from "fs";
for (const line of fs.readFileSync("/home/user/Taxila/.env.local", "utf8").split("\n")) { const m = line.match(/^([A-Z0-9_]+)=(.*)$/); if (m && !process.env[m[1]]) process.env[m[1]] = m[2].replace(/^"(.*)"$/, "$1"); }
const { handle } = await import("/home/user/Taxila/server/index.js");
const srv = http.createServer(handle); await new Promise((r) => srv.listen(0, "127.0.0.1", r));
const b = `http://127.0.0.1:${srv.address().port}`;
const post = async (p, body, cookie) => { const r = await fetch(b + p, { method: "POST", headers: { "content-type": "application/json", ...(cookie ? { cookie } : {}) }, body: JSON.stringify(body) }); return r.status; };
const L = "00000000-0000-0000-0000-000000000000";
console.log("tts no cookie", await post("/api/voice/tts-stream", { lessonId: L, seq: 1 }));
console.log("tts bogus cookie", await post("/api/voice/tts-stream", { lessonId: L, seq: 1 }, "tx_session=bogus"));
console.log("turn missing lesson", await post("/api/lesson/turn", { lessonId: L, childText: "x" }, "tx_session=bogus"));
const big = await fetch(b + "/api/voice/transcribe", { method: "POST", headers: { "content-type": "application/json" }, body: "x".repeat(3_100_000) }).then((r) => r.status).catch((e) => e.message);
console.log("oversized body", big);
srv.close(); process.exit(0);
