import fs from "fs";
import { decide, initState } from "/home/user/Taxila/prototypes/reset/conversation-v2/policy.mjs";
const R = JSON.parse(fs.readFileSync("/home/user/Taxila/evals/conversation-v2/results/2026-10-04-run1/understand-bakeoff/results.json", "utf8"));
const g = new Map(R.results.grok.map((r) => [r.id, r])), s = new Map(R.results.sol6.map((r) => [r.id, r]));
const mv = (n) => n ? decide(initState(), { ...n, langTo: n.langTo ? "hindi" : "" }).move : "ERR";
let agree = 0, agreeOk = 0, dis = 0, disSolOk = 0, disGrokOk = 0;
for (const [id, a] of g) {
  const b = s.get(id); if (!b) continue;
  if (mv(a.note) === mv(b.note)) { agree++; if (b.action) agreeOk++; } else { dis++; if (b.action) disSolOk++; if (a.action) disGrokOk++; }
}
console.log({ agree, agreeOk, dis, disSolOk, disGrokOk, n: agree + dis });
