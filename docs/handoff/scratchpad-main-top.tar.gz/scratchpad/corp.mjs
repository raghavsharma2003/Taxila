import { INLESSON_NEGATIVES as N, LEAVE_POSITIVES as P } from "/home/user/Taxila/evals/relational-os/inlesson-negatives.mjs";
import { signalsOf } from "/home/user/Taxila/server/relational/signals.js";
import { scanSafety, wantsToStop } from "/home/user/Taxila/server/director/safety.js";
const BAD = new Set(["goodbye","end_request","goodbye_distress","contact_ask","secret_ask","romance","warmth_offer","permanence_ask","night_ask","loneliness","harm"]);
console.log("n=", N.length, "by lang", ["en","hl","hi"].map(l=>N.filter(x=>x.lang===l).length));
let bad=0; for (const x of N) { const ks = signalsOf(x.text).filter(s=>BAD.has(s.kind)).map(s=>s.kind+(s.thirdParty?"*":"")); const st=wantsToStop(x.text); const sf=scanSafety(x.text).distress;
 if (ks.length||st||sf) { bad++; console.log("FALSE", JSON.stringify(x.text), ks, st?"STOP":"", sf?"DISTRESS":""); } }
console.log("false", bad);
for (const [k, list] of Object.entries(P)) for (const t of list) { const s = signalsOf(t); const ok = k==="third_party" ? s.some(x=>x.thirdParty) : k==="contact_self" ? s.some(x=>x.kind==="contact_ask") : s.some(x=>x.kind===k); if (!ok) console.log("MISS", k, t, s.map(x=>x.kind)); }
