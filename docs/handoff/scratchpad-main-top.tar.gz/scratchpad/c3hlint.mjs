import fs from "fs";
import { normalizeKit } from "/home/user/Taxila/server/content/kits.js";
const k=JSON.parse(fs.readFileSync("/home/user/Taxila/data/kits/c3-hindi.json","utf8"));
let tot={itemsDropped:0,diagnosticsDropped:0,hintsReplaced:0};
for(const t of k.topics){ const n=normalizeKit(t,{topicId:t.topicId,verified:true});
  if(!n){console.log("NULL",t.topicId);continue;}
  for(const key in tot) tot[key]+=n.lint[key];
  if(n.lint.hintsReplaced||n.lint.itemsDropped||n.lint.diagnosticsDropped){ console.log(t.topicId,JSON.stringify(n.lint));
    for(const it of n.items){ const raw=t.items.find(r=>r.id===it.id); it.hints.forEach((h,i)=>{ if(h!==raw.hints[i]) console.log("  replaced",it.id,i,JSON.stringify(raw.hints[i])); }); }
    const kept=new Set(n.items.map(i=>i.id)); for(const r of t.items) if(!kept.has(r.id)) console.log("  dropped",r.id);
  }}
console.log(tot);
