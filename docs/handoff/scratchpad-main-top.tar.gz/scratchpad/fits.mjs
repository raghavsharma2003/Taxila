import { readdirSync, readFileSync } from "fs";
import { checkFits } from "/home/user/Taxila/server/compiler/compile.js";
import { promptFor } from "/home/user/Taxila/server/director/items.js";
import { toSpoken } from "/home/user/Taxila/server/voice/spoken.js";
import { estimateTokens } from "/home/user/Taxila/server/learner/brief.js";
const old = await import(process.argv[2] + "/server/compiler/compile.js");
let n = 0, bad = [];
for (const f of readdirSync("/home/user/Taxila/data/kits").filter((x) => x.endsWith(".json"))) {
  const k = JSON.parse(readFileSync("/home/user/Taxila/data/kits/" + f, "utf8"));
  for (const t of k.topics ?? []) for (const it of t.items ?? []) {
    n++;
    if (old.checkFits(it) && !checkFits(it)) {
      const w = promptFor(it, "hindi"), sp = toSpoken(w, { mode: "hindi" });
      bad.push([it.id, estimateTokens(w), estimateTokens(sp), sp.slice(0, 140)]);
    }
  }
}
console.log(n, bad.length); for (const b of bad) console.log(b.join(" | "));
