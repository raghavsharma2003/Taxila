import * as C from "/home/user/Taxila/server/compiler/compile.js";
import * as SH from "/home/user/Taxila/server/director/shapes.js";
import { estimateTokens } from "/home/user/Taxila/server/learner/brief.js";
import { readFileSync } from "fs";
const d = JSON.parse(readFileSync("/home/user/Taxila/data/kits/c3-maths.json", "utf8"));
const item = d.topics[0].items[0];
const longHint = "x".repeat(45 * 3.5);
const branches = { cond: "it matches the key", right: { kind: "probe", text: SH.pose({ item, prefix: SH.CONFIRM.correct, verify: true }), ask: item.prompt_hi, content: [] },
  wrong: { kind: "hint", text: SH.hint({ level: 3, rungShape: longHint, askedForAnswer: true }), content: [] } };
for (const correction of [[], ["ai_denial", "ability", "personal_data", "exclusivity"]]) {
  for (const v of [{ lane: "text", move: { kind: "practice" }, lessonState: { hintLevel: 0, correction } }, { lane: "text", move: { kind: "hint" }, lessonState: { hintLevel: 3, correction } }, { lane: "voice", move: { kind: "hint" }, lessonState: { hintLevel: 3, correction }, branches }]) {
    const t = C.__lastParts({ ...v, item, ageBand: "6-9", language: "hinglish", protegeName: "Bittu" }).map((p) => p.text).join("\n");
    console.log(v.lane, correction.length, estimateTokens(t));
    if (v.lane === "voice" && correction.length) console.log(t);
  }
}
