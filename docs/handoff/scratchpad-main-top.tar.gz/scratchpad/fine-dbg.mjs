const { q } = await import("/home/user/taxila-int/server/db.js");
const a = await q(`select count(*)::int n, min(t) mn, max(t) mx from trace_event where kind = 'safety.scan'`);
console.log("safety.scan rows", a[0]);
const b = await q(`select data from trace_event where kind = 'safety.scan' and (data->>'safeguardMove') = 'true' order by t desc limit 3`);
console.log("safeguard scans", b.length, JSON.stringify(b.map((x) => x.data)));
const c = await q(`select sid, turn, data from trace_event where kind = 'srv.req' order by t desc limit 2`);
console.log("srv.req sample", JSON.stringify(c.map((x) => ({ turn: x.turn, keys: Object.keys(x.data), path: x.data.path, body: Object.keys(x.data.body ?? {}) }))));
process.exit(0);
