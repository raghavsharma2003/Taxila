const est = s => Math.ceil(s.length/3.5);
const worst = [
"CHILD Tara · class 4 · B2 · she calls you didi · you call her Tara · sessions together 14",
"LANG matrix hi · English insertion mid · subject terms in English · reply in the child's mix",
"READ support R1 · read every on-screen prompt aloud",
"TODAY topic Comparing fractions · plan foundation 30% then school 70%",
"SKILLS solid: halves and quarters; equivalent fractions (refresh due)",
"SKILLS learning: comparing unlike fractions (entry worked step); fraction of a collection",
"SKILLS new today: ordering three fractions",
"PREREQ gap: none open",
"WATCH seen 2x, verify before naming: bigger denominator means bigger fraction",
"WATCH seen 1x: adds numerators and denominators",
"REVIEW warm-up, no warning: place value to 1000; multiplication by 10; halves",
"NEED school now Fractions ch 5 · window unit test next week · scope ch 4-5",
"GOAL child picked: finish 3 apne-aap rounds today",
"INTEREST cricket; drawing (validated contexts only)",
"SUPPORT on comparing fractions: on-call, silent until asked · solo rounds 3 · wait 6 s",
"ACCOMMODATION longer wait · tap answers allowed",
"SESSION cap 25 min · stop on exit intent",
];
const s = worst.join("\n");
console.log("rows", worst.length, "chars", s.length, "est tokens", est(s));
// pL0 example: P=0.7 g=0.2 s=0.1
const P=0.7,g=0.2,sl=0.1; console.log("pL0", ((P-g)/(1-g-sl)).toFixed(3));
console.log("log12", Math.log(12).toFixed(3), "3 C0 LR8 sum", (3*Math.log(8)).toFixed(3));
// with budget: 3 C0 at LR 8 prior 0.39 capped at odds x12
const o0=0.39/0.61, capped=o0*12, full=o0*512; console.log("capped pL", (capped/(1+capped)).toFixed(3), "uncapped", (full/(1+full)).toFixed(4));
