import numpy as np
rng=np.random.default_rng(1)
def ddm(v,a,ter,n,s=0.1,dt=0.001):
    rts=[];cor=[]
    for _ in range(n):
        x=a/2;t=0
        while 0<x<a:
            x+=v*dt+s*np.sqrt(dt)*rng.standard_normal();t+=dt
        rts.append(t+ter);cor.append(x>=a)
    return np.array(rts),np.array(cor)
def ez(pc,vrt,mrt,s=0.1,n=None):
    if pc==1: pc=1-1/(2*n)
    L=np.log(pc/(1-pc)); x=L*(L*pc*pc-L*pc+pc-.5)/vrt
    v=np.sign(pc-.5)*s*x**.25; a=s*s*L/v; y=-v*a/s/s
    mdt=(a/(2*v))*(1-np.exp(y))/(1+np.exp(y)); return v,a,mrt-mdt
# child-like params
v,a,ter=0.20,0.14,0.45
rt,c=ddm(v,a,ter,20000)
print("true v a ter",v,a,ter," acc",c.mean()," RTsd",rt[c].std())
for label,jit,mean in [("clean",0,0),("touch jitter sd30ms +80ms",0.03,0.08),("audio jitter sd100ms +200ms",0.10,0.20)]:
    r=rt+mean+rng.normal(0,jit,len(rt)) if jit else rt
    print(label,[round(z,3) for z in ez(c.mean(),r[c].var(),r[c].mean(),n=len(c))])
# 5% fast guesses (200-400ms, 50% correct) contamination
k=int(.05*len(rt)); r2=rt.copy(); c2=c.copy()
r2[:k]=rng.uniform(.2,.4,k); c2[:k]=rng.random(k)<.5
print("5% fast guesses",[round(z,3) for z in ez(c2.mean(),r2[c2].var(),r2[c2].mean(),n=len(c2))])
# 3% lapses (slow 2-5s)
r3=rt.copy(); r3[:int(.03*len(rt))]=rng.uniform(2,5,int(.03*len(rt)))
print("3% slow lapses",[round(z,3) for z in ez(c.mean(),r3[c].var(),r3[c].mean(),n=len(c))])
# per-block sampling noise: 30 trials
vs=[]
for b in range(400):
    idx=rng.choice(len(rt),30,replace=False)
    try: vs.append(ez(c[idx].mean(),rt[idx][c[idx]].var(),rt[idx][c[idx]].mean(),n=30)[0])
    except: pass
vs=np.array(vs); print("30-trial block v: mean %.3f sd %.3f cv %.2f"%(vs.mean(),vs.std(),vs.std()/vs.mean()))
