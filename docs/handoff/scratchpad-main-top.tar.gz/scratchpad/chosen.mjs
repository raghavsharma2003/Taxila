import { chromium } from "/home/user/Taxila/node_modules/playwright/index.mjs";
const browser = await chromium.launch({ executablePath: "/opt/pw-browsers/chromium", args: ["--use-angle=swiftshader", "--enable-unsafe-swiftshader"] });
for (const [w, h] of [[360, 640], [1280, 800]]) {
  const page = await browser.newPage({ viewport: { width: w, height: h } });
  await page.goto("http://localhost:5199/dev/avatar?view=picker&class=8&lang=english&face=B");
  await page.waitForTimeout(1200);
  // keyboard path: 2 selects the second tile, Enter chooses (radiogroup keys, tutor-selection-ux §9)
  await page.focus("[role=radio]");
  await page.keyboard.press("2");
  await page.waitForTimeout(600);
  const sel = await page.getAttribute("[aria-checked=true]", "data-tutor");
  await page.keyboard.press("Enter");
  await page.waitForTimeout(2200);
  await page.screenshot({ path: `/tmp/claude-0/-home-user/ecee9fc1-62f9-5f67-a47d-69ca79d9981a/scratchpad/shots/m0-picker-${w}x${h}-chosen.png` });
  console.log(w, "selected by key:", sel, "chosen:", await page.getAttribute("[data-chosen]", "data-chosen"));
  await page.close();
}
await browser.close();
