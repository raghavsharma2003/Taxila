p='/home/user/Taxila/evals/voicesig/train/extract.mjs'
s=open(p).read()
a="""/** Run the product front-end over 16 kHz samples. Returns per-frame rows. */
export function frontEnd(x, { t0 = 0, gain = 1 } = {}) {
  const fc = new FrameCore();
  const lm = new LogMel(2, 4, 1);
  const gi = new GruInput();
  const rows = [];
  const mels = [];
  let mi = 0;
  for (let i = 0; i + 320 <= x.length; i += 320) {
    const t = t0 + (i / 16000) * 1000;"""
assert a in s
s=s.replace(a,"""/**
 * Run the product front-end over 16 kHz samples. Returns per-frame rows. `regions` ([[startS, endS], ...], sorted) limits
 * analysis to those spans of ONE continuous session (state carries across, the clock jumps: FrameAnalyzer re-anchors on a
 * jump exactly as it does after a dropped chunk). Used to skip long stretches where the channel owner is silent.
 */
export function frontEnd(x, { t0 = 0, gain = 1, regions = null } = {}) {
  const fc = new FrameCore();
  const lm = new LogMel(2, 4, 1);
  const gi = new GruInput();
  const rows = [];
  const mels = [];
  let mi = 0;
  const spans = regions ? regions.map(([a, b]) => [Math.floor(a * 50) * 320, Math.min(x.length, Math.ceil(b * 50) * 320)]) : [[0, x.length]];
  for (const [s0, s1] of spans) for (let i = s0; i + 320 <= s1; i += 320) {
    const t = t0 + (i / 16000) * 1000;""")
a="""  const [inp, out] = process.argv.slice(2);
  const t = performance.now();
  const x = readWav16(inp);
  const rows = frontEnd(x);"""
assert a in s
s=s.replace(a,"""  const [inp, out, regionsPath] = process.argv.slice(2);
  const t = performance.now();
  const x = readWav16(inp);
  const regions = regionsPath ? JSON.parse(readFileSync(regionsPath, "utf8")) : null;
  const rows = frontEnd(x, { regions });""")
s=s.replace("""//   node evals/voicesig/train/extract.mjs <in.wav> <out-prefix>""","""//   node evals/voicesig/train/extract.mjs <in.wav> <out-prefix> [regions.json]""")
s=s.replace("""audioS: x.length / 16000, cpuMs""","""audioS: x.length / 16000, analysedS: rows.length / 50, cpuMs""")
open(p,'w').write(s)

p='/home/user/Taxila/evals/voicesig/train/ami_prep.py'
s=open(p).read()
a="""    try:
        urllib.request.urlretrieve(url, wav)
        r = subprocess.run(["node", os.path.join(ROOT, "evals/voicesig/train/extract.mjs"), wav, stem], capture_output=True, text=True, timeout=3600)"""
assert a in s
s=s.replace(a,"""    lab = words(manual, meeting, sp["agent"])
    # Analyse only where the channel owner talks (+-PAD s, gaps < MERGE s bridged): ~3x less CPU on a shared box.
    reg = []
    for s, e, _, _ in lab:
        a, b = max(0.0, s - PAD), e + PAD
        if reg and a - reg[-1][1] < MERGE:
            reg[-1][1] = max(reg[-1][1], b)
        else:
            reg.append([a, b])
    rpath = stem + ".regions.json"
    json.dump(reg, open(rpath, "w"))
    try:
        urllib.request.urlretrieve(url, wav)
        r = subprocess.run(["node", os.path.join(ROOT, "evals/voicesig/train/extract.mjs"), wav, stem, rpath], capture_output=True, text=True, timeout=7200)""")
a="""        if os.path.exists(wav):
            os.remove(wav)
    lab = words(manual, meeting, sp["agent"])
"""
assert a in s
s=s.replace(a,"""        if os.path.exists(wav):
            os.remove(wav)
""")
s=s.replace("""IND = {"Hindi", "Telugu", "Tamil", "Malayalam", "Konkani"}""","""IND = {"Hindi", "Telugu", "Tamil", "Malayalam", "Konkani"}
PAD, MERGE = 2.0, 4.0""")
s=s.replace('ap.add_argument("--train", type=int, default=20)','ap.add_argument("--train", type=int, default=15)')
open(p,'w').write(s)
print("ok")
