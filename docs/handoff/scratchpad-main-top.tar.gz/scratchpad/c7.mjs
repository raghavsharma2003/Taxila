import { readFileSync } from "fs";
const {paramsFromKit}=await import("/home/user/Taxila/server/studio/plan.js");const {ARCHETYPES,validateParams}=await import("/home/user/Taxila/server/studio/archetypes/index.js");
const k=JSON.parse(readFileSync("/home/user/Taxila/data/kits/c7-maths.json"));
for (const id of ["c7-maths-ch03-t01","c7-maths-ch03-t02","c7-maths-ch12-t01"]){const t=k.topics.find(x=>x.topicId===id);for(const a of ["shade_fraction","number_line_jump"]){const p=paramsFromKit(a,t);console.log(id,a,JSON.stringify(p),p?validateParams(ARCHETYPES.get(a),p):"")}}
