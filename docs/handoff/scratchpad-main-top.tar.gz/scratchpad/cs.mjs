import { readText } from "/home/user/Taxila/server/signals/linguistic.js";
const item={id:"i",skillId:"s",form:"number",kitTerms:["fraction","aadha"],keyNum:5};
for (const t of ["mujhe nahi pata, aap bata do","pata nahi ek minute","मुझे नहीं पता","मुझे याद नहीं आ रहा","शायद 5","shayad paanch","pata nahi yaar","idk lol","mujhe lagta hai 5","5 hai na?","umm 5","nahi pata didi","main bhool gayi, phir se batao","ek baar phir batao","dheere bolo na","thoda slow please","bas karo, thak gaya","break chahiye"]){
 const L=readText({childText:t,item,teacherLast3:[]});
 console.log(t.padEnd(32),JSON.stringify({idk:L.idk?.v,hedge:L.hedge,meta:L.metaRequest,help:L.helpAsk,lang:L.langMode,lead:L.fillerLead?.v}));}
