import { initLessonState } from "/home/user/taxila-int/server/director/state.js";
import { classify, targetFor } from "/home/user/taxila-int/server/director/classify.js";
import { findItem } from "/home/user/taxila-int/server/director/items.js";
import { kit, CTX } from "/home/user/taxila-int/tests/fixtures/kit.mjs";
const K = kit();
process.env.AZURE_OPENAI_ENDPOINT = "https://example.test/openai/v1"; process.env.AZURE_OPENAI_API_KEY = "test-key";
const calls = [];
globalThis.fetch = async (u, init) => { const b = JSON.parse(init.body); calls.push(b.response_format?.json_schema?.name); return new Response(JSON.stringify({ choices: [{ message: { content: JSON.stringify({ match: "no_attempt", confidence: 0.9, off_topic: false, distress: true, asks_for_answer: false, wants_to_stop: false }) }, finish_reason: "stop" }], usage: {} }), { status: 200 }); };
for (const id of ["i1", "i3"]) for (const text of ["meri billi ne aaj mera haath khrocha", "teen chauthai"]) {
  calls.length = 0;
  const s = { ...initLessonState({ topicId: K.topicId, kit: K, ctx: CTX, seed: 1, now: 0 }), phase: "practice", activeItemId: id };
  const r = await classify({ target: targetFor(s, K, findItem(s, K, id)), childText: text, typed: true, classLevel: 4 });
  console.log(id, text, r.source, r.flags.distress, r.flags.distressKind, calls);
}
