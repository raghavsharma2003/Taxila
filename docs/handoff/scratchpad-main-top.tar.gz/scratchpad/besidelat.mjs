// 14.3.2 latency: the label call (classify(), the code on int today, DEPLOY_CLASSIFY as set) and a words-only distress read on
// deployment X started at the same instant; the turn waits for both, so the cost is max(0, beside - label). Sequential lines
// (one pair at a time) so the two calls of a pair share the endpoint's load. usage: node testenvrun.mjs node besidelat.mjs <corpus> <X> [n=30]
import { readFileSync } from "node:fs";
const { classify, targetFor } = await import("/home/user/taxila-int/server/director/classify.js");
const { kitFor } = await import("/home/user/taxila-int/server/brain/rows.js");
const { chat } = await import("/home/user/taxila-int/server/azure.js");
const { filterSafe, scrubPii } = await import("/home/user/taxila-int/server/director/safety.js");
const [corpus, X, nArg] = process.argv.slice(2);
const N = Number(nArg ?? 30);
const lines = JSON.parse(readFileSync(corpus, "utf8")).filter((x) => !x.safetyCard && !x.safeTurn && x.text.length > 12).slice(0, 4000);
let seed = 7; const rnd = () => { seed = (seed * 16807) % 2147483647; return seed / 2147483647; };
const pick = Array.from({ length: N }, () => lines[Math.floor(rnd() * lines.length)]);
const kit = await kitFor("c6-maths-ch06-t01", {});
const item = kit.items.find((i) => i.kind !== "teachback" && i.answer);
const target = targetFor({ phase: "teach", hintLevel: 0 }, kit, item);
const brief = "A reply from an Indian school child (class 6) in a lesson, in Hindi, English or Hinglish; the transcript may be misheard. distress: true ONLY for signs the child is unsafe, hurt, abused, frightened of a person, a place or what is happening to them, very sad, or may harm themself — never for ordinary frustration or worry about the lesson itself (scared of numbers, a question, a test or getting it wrong: the teacher reassures).";
const schema = { type: "object", additionalProperties: false, required: ["distress"], properties: { distress: { type: "boolean" } } };
const L = [], B = [], ADD = [];
for (const x of pick) {
  const t0 = performance.now();
  const lp = classify({ target, childText: x.text, asrConfidence: 0.95, typed: true, heard: "Rectangle ke chaaron sides jodo: 50, 30, 50, 30. Total kitna?", classLevel: 6, trace: [] }).then(() => performance.now() - t0, () => null);
  const bp = chat(X, [{ role: "system", content: brief }, { role: "user", content: filterSafe(scrubPii(x.text).text) }], { schema, schemaName: "distress_beside", effort: "none", maxTokens: 40, timeoutMs: 3000, retries: 0 })
    .then(() => performance.now() - t0, () => null);
  const [l, b] = await Promise.all([lp, bp]);
  if (l == null || b == null) continue;
  L.push(l); B.push(b); ADD.push(Math.max(0, b - l));
}
const q = (a, p) => { const s = [...a].sort((m, n) => m - n); return Math.round(s[Math.min(s.length - 1, Math.floor(p * s.length))]); };
console.log(`${X} beside vs label (${process.env.DEPLOY_CLASSIFY ?? "default"}) n=${L.length}: label p50/p90 ${q(L, 0.5)}/${q(L, 0.9)} ms · beside p50/p90 ${q(B, 0.5)}/${q(B, 0.9)} ms · added p50/p90/max ${q(ADD, 0.5)}/${q(ADD, 0.9)}/${Math.round(Math.max(...ADD))} ms · turns slowed ${ADD.filter((a) => a > 0).length}/${ADD.length}`);
process.exit(0);
