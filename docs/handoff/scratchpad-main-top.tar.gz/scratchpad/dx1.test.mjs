import { test } from "node:test";
import assert from "node:assert/strict";
import { DuplexLive } from "/home/user/Taxila/src/duplex/live.ts";
import { OVERLAP } from "/home/user/Taxila/src/duplex/config.ts";
const LOUD = Math.pow(10, -24 / 20), QUIET = Math.pow(10, -60 / 20), ECHO = Math.pow(10, -52 / 20);
function clock(){let now=1_000_000;const timers=[];let seq=0;return{now:()=>now,setInterval:(fn,ms)=>{const h=++seq;timers.push({h,at:now+ms,fn,every:ms});return h;},clearInterval:(h)=>{const i=timers.findIndex(x=>x.h===h);if(i>=0)timers.splice(i,1);},run(to){for(;;){timers.sort((a,b)=>a.at-b.at);const x=timers[0];if(!x||x.at>to)break;now=x.at;if(x.every)x.at+=x.every;else timers.shift();x.fn();}now=to;}};}
function fakePort(){const log=[];return{log,gain:1,paused:false,stopped:0,commits:[],duck(l){this.gain=l;log.push(["duck",l]);},pause(){this.paused=true;log.push(["pause"]);return true;},resume(){this.paused=false;log.push(["resume"]);},stop(){this.stopped++;log.push(["stop"]);},commit(t){this.commits.push(t);log.push(["commit",t.text,JSON.stringify(t.duplex?.safetyPending)]);},sttCommit(){log.push(["sttCommit"]);},dropReply(id){log.push(["drop",id]);},fallback(r){log.push(["fallback",r]);},state(){}};}
function rig({ui={beat:"explain"}}={}){const c=clock();const port=fakePort();const live=new DuplexLive({lessonId:"L1",port,now:c.now,setInterval:c.setInterval,clearInterval:c.clearInterval});const pending=[];let item=0;let herOn=false;
const frame=(loud,f0=260)=>{const t=c.now();while(pending.length&&pending[0][0]<=t)live.stt(pending.shift()[1]);const rms=loud?LOUD:herOn?ECHO:QUIET;live.frame(t,rms,loud?f0:null,herOn?-22:null);};
const r={c,port,live,quiet(ms){const end=c.now()+ms;while(c.now()<end){frame(false);c.run(c.now()+20);}},
say(text,ms,{deltaLag=600,finalLag=500,final=text,f0=260}={}){const id=`item_${++item}`;const start=c.now();pending.push([start+10,{type:"input_audio_buffer.speech_started",item_id:id,audio_start_ms:start-1_000_000}]);const end=start+ms;while(c.now()<end){frame(true,f0);c.run(c.now()+20);}const toks=text.split(/\s+/);toks.forEach((w,i)=>pending.push([start+((i+1)*ms)/toks.length+deltaLag,{type:"conversation.item.input_audio_transcription.delta",item_id:id,delta:(i?" ":"")+w}]));pending.push([end+finalLag,{type:"conversation.item.input_audio_transcription.completed",item_id:id,transcript:final}]);pending.sort((a,b)=>a[0]-b[0]);return id;},
her(text){live.setUi(ui);herOn=true;live.herStart(text);},herEnd(){herOn=false;live.herEnd();}};
live.start();r.quiet(800);return r;}
const LINE="तो देखो, जब हम pizza को चार बराबर हिस्सों में काटते हैं, तो हर हिस्सा एक चौथाई होता है, और दो हिस्से मिलकर आधा बनाते हैं।";
test("A distress over her line: she stops, and the commit carries safetyPending", () => {
  const r=rig(); r.her(LINE); r.quiet(1500); r.say("मुझे मर जाना है", 1400); r.quiet(4000);
  console.log(JSON.stringify(r.port.log));
  assert.ok(r.port.paused||r.port.stopped>0, "she stopped");
  const c=r.port.commits.at(-1); assert.ok(c, "a commit"); assert.ok(c.duplex.safetyPending, "safetyPending");
});
test("B distress partial revised clean in the final: safetyPending still rides the commit", () => {
  const r=rig(); r.her(LINE); r.quiet(1200); r.herEnd(); r.quiet(600);
  r.say("मुझे मर जाना है", 1400, { final: "मुझे मटर खाना है" }); r.quiet(4000);
  console.log(JSON.stringify(r.port.log));
  const c=r.port.commits.at(-1); assert.ok(c); assert.ok(c.duplex.safetyPending, "sticky");
});
test("C distress said in a LOW-pitched voice over her (an older child / a hoarse voice): still stops her", () => {
  const r=rig(); r.her(LINE); r.quiet(400);
  r.herEnd(); r.quiet(300); r.say("बारह", 500); r.quiet(2500); // learn the child's f0 at 260
  r.her(LINE); r.quiet(1500); r.say("मुझे मर जाना है", 1400, { f0: 150 }); r.quiet(4000);
  console.log(JSON.stringify(r.port.log));
  assert.ok(r.port.paused||r.port.stopped>0, "she stopped for a distress line");
  assert.ok(r.port.commits.some((c)=>c.duplex.safetyPending), "safetyPending reached a commit");
});
test("D distress SCREAMED (f0 above the tone guard) over her: still stops her", () => {
  const r=rig(); r.her(LINE); r.quiet(1500); r.say("मुझे मर जाना है", 1400, { f0: 600 }); r.quiet(4000);
  console.log(JSON.stringify(r.port.log));
  assert.ok(r.port.paused||r.port.stopped>0, "she stopped for a distress line");
  assert.ok(r.port.commits.some((c)=>c.duplex.safetyPending), "safetyPending reached a commit");
});
for (const f0 of [260, 480, 530, 545, 600, 700]) test(`E f0=${f0}: distress over her → a committed safeguard turn within 10 s`, () => {
  const r=rig(); r.her(LINE); r.quiet(1500); r.say("मुझे मर जाना है", 1400, { f0 }); r.quiet(10000);
  console.log(f0, JSON.stringify(r.port.log));
  assert.ok(r.port.commits.some((c)=>c.duplex.safetyPending), "safetyPending reached a commit");
});
for (const f0 of [260, 530, 545, 600]) test(`F f0=${f0}: latency`, () => {
  const r=rig(); r.her(LINE); r.quiet(1500); r.say("मुझे मर जाना है", 1400, { f0 }); const end=r.c.now();
  const origCommit=r.port.commit.bind(r.port); const at=[];
  r.port.commit=(t)=>{at.push(r.c.now()-end); origCommit(t);};
  const stopAt=[]; const os=r.port.stop.bind(r.port), op=r.port.pause.bind(r.port);
  r.port.stop=()=>{stopAt.push(r.c.now()-end); os();}; r.port.pause=()=>{stopAt.push(r.c.now()-end); return op();};
  r.quiet(10000);
  console.log("LAT", f0, "commit after end(ms):", JSON.stringify(at), "stop/pause after end:", JSON.stringify(stopAt));
});
test("G safeguard line: continuer over it hushes the helpline digits and they are not re-said", () => {
  const r=rig(); r.her(LINE); r.quiet(1500); r.say("मुझे मर जाना है", 1400); r.quiet(3000);
  const n0=r.port.log.length;
  r.her("आपने मुझे बताकर बिल्कुल सही किया। Childline 1098 पर कभी भी free call कर सकते हैं। मन की परेशानी के लिए Tele-MANAS 14416 है।");
  r.quiet(2500); r.say("हम्म", 900); r.quiet(4000);
  console.log("G", JSON.stringify(r.port.log.slice(n0)));
});
for (const variant of ["none","hmm300","hmm900","speech"]) test(`H safeguard line, overlap=${variant}`, () => {
  const r=rig(); r.her(LINE); r.quiet(1500); r.say("मुझे मर जाना है", 1400); r.quiet(3000);
  const n0=r.port.log.length; const t0=r.c.now();
  const at=[]; const os=r.port.stop.bind(r.port); r.port.stop=()=>{at.push(r.c.now()-t0); os();};
  r.her("आपने मुझे बताकर बिल्कुल सही किया। Childline 1098 पर कभी भी free call कर सकते हैं। मन की परेशानी के लिए Tele-MANAS 14416 है।");
  r.quiet(2500);
  if (variant==="hmm300") r.say("हम्म", 300); if (variant==="hmm900") r.say("हम्म", 900); if (variant==="speech") r.say("हाँ ठीक है दीदी", 1200);
  r.quiet(20000);
  console.log("H", variant, JSON.stringify(r.port.log.slice(n0)), "stopAt", JSON.stringify(at));
});
