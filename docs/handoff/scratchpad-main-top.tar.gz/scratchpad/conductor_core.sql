create or replace function gen_ulid() returns text language sql volatile as $$ select replace(gen_random_uuid()::text,'-','') $$;
create table workspace (child_id uuid primary key references child(id) on delete cascade,
  state text not null default 'active' check (state in ('provisional','active','dormant','paused','erasing')),
  legal_mode text not null default 'M1', academic_year text not null default '2026-27', last_active_at timestamptz);
create table child_seq (child_id uuid primary key references child(id) on delete cascade,
  last bigint not null default 0, pending_since timestamptz);
create index child_seq_dirty on child_seq (pending_since) where pending_since is not null;
create table student_event (
  child_id uuid not null references child(id) on delete cascade, seq bigint not null,
  id text not null, type text not null, source text not null, idem_key text not null,
  occurred_at timestamptz not null, received_at timestamptz not null default now(),
  causation_id text, correlation_id text not null, traceparent text, body jsonb not null,
  primary key (child_id, seq), unique (child_id, idem_key));
create or replace function ingest_event(p_child uuid, p_id text, p_type text, p_source text, p_idem text,
  p_occurred timestamptz, p_corr text, p_cause text, p_body jsonb, p_trace text default null)
returns bigint language plpgsql as $$
declare s bigint;
begin
  if exists (select 1 from student_event where child_id = p_child and idem_key = p_idem) then return null; end if;
  insert into child_seq (child_id) values (p_child) on conflict do nothing;
  update child_seq set last = last + 1, pending_since = coalesce(pending_since, now())
   where child_id = p_child returning last into s;
  insert into student_event (child_id, seq, id, type, source, idem_key, occurred_at, correlation_id, causation_id, body, traceparent)
  values (p_child, s, p_id, p_type, p_source, p_idem, p_occurred, p_corr, p_cause, p_body, p_trace)
  on conflict (child_id, idem_key) do nothing;
  return s;
end $$;
create table job (
  id bigint generated always as identity primary key,
  kind text not null, child_id uuid references child(id) on delete cascade, idem_key text not null,
  input jsonb not null, lane text not null check (lane in ('fast','slow','sandbox')),
  priority smallint not null default 2,
  status text not null default 'queued' check (status in ('queued','running','retry','done','failed','cancelled','dead')),
  run_after timestamptz not null default now(), not_before_lesson_end boolean not null default false,
  deadline_at timestamptz, cancel_requested boolean not null default false,
  budget_micro_usd bigint not null, spent_micro_usd bigint not null default 0,
  attempts int not null default 0, max_attempts int not null default 5,
  lease_sec int not null default 60, lease_until timestamptz, worker text,
  result_ref text, last_error text, correlation_id text not null, causation_id text, traceparent text,
  created_at timestamptz not null default now(), finished_at timestamptz,
  unique (kind, idem_key));
create index job_ready on job (lane, priority, run_after) where status in ('queued','retry');
create index job_expired on job (lane, lease_until) where status = 'running';
create index job_child on job (child_id);
create or replace function complete_job(p_job bigint, p_attempt int, p_ok boolean, p_result text,
                                        p_error text, p_final boolean) returns boolean language plpgsql as $$
declare j job%rowtype; v_status text;
begin
  select * into j from job where id = p_job and attempts = p_attempt and status = 'running' for update;
  if not found then return false; end if;
  if j.child_id is not null and exists (select 1 from workspace w where w.child_id = j.child_id and w.state = 'erasing')
    then update job set status = 'cancelled', finished_at = now() where id = p_job; return false; end if;
  v_status := case when j.cancel_requested then 'cancelled' when p_ok then 'done'
                   when p_final or j.attempts >= j.max_attempts then 'dead' else 'retry' end;
  update job set status = v_status, result_ref = p_result, last_error = p_error, lease_until = null,
         finished_at = case when v_status in ('done','dead','cancelled') then now() end,
         run_after = case when v_status = 'retry'
                          then now() + make_interval(secs => least(power(2, attempts), 300) * (0.8 + random() * 0.4)) end
   where id = p_job;
  if j.child_id is not null and v_status in ('done','dead') then
    perform ingest_event(j.child_id, gen_ulid(), case when v_status = 'done' then 'job.done' else 'job.failed' end, 'agent',
      'job:' || j.id || ':' || v_status, now(), j.correlation_id, 'job:' || j.id,
      jsonb_build_object('jobId', j.id::text, 'kind', j.kind, 'resultRef', p_result, 'error', p_error, 'final', v_status = 'dead'));
  end if;
  return true;
end $$;
create table wakeup (child_id uuid not null references child(id) on delete cascade, dedupe text not null,
  due_at timestamptz not null, reason text not null, fired_at timestamptz, primary key (child_id, dedupe));
create index wakeup_due on wakeup (due_at) where fired_at is null;
create or replace function fire_wakeups(p_limit int) returns table (child_id uuid, seq bigint) language sql as $$
  with d as (select w.child_id, w.dedupe, w.reason from wakeup w where w.fired_at is null and w.due_at <= now()
              order by w.due_at for update skip locked limit p_limit),
       f as (update wakeup w set fired_at = now() from d
              where w.child_id = d.child_id and w.dedupe = d.dedupe returning w.child_id, w.dedupe, w.reason)
  select f.child_id, ingest_event(f.child_id, gen_ulid(), 'clock.wakeup', 'clock', 'wake:' || f.dedupe, now(),
                                  'wake:' || f.dedupe, null, jsonb_build_object('reason', f.reason, 'wakeupId', f.dedupe))
    from f;
$$;
create table conductor_state (
  child_id uuid primary key references child(id) on delete cascade,
  state_v int not null, version bigint not null default 0, cursor_seq bigint not null default 0,
  mode text not null default 'free' check (mode in ('free','in_lesson','paused','safety_hold')),
  learning_day date, plan_day date, plan_version int, state jsonb not null,
  lease_token uuid, lease_until timestamptz, updated_at timestamptz not null default now());
create table conductor_usage (
  child_id uuid not null references child(id) on delete cascade, learning_day date not null,
  cap_min int not null, used_min real not null default 0, reserved_min real not null default 0,
  hw_used_min real not null default 0, voice_sec jsonb not null default '{}', primary key (child_id, learning_day));
create table rate_bucket (deployment text primary key, capacity int not null, tokens real not null,
  refill_per_sec real not null, refilled_at timestamptz not null default now());
create table notification (
  id bigint generated always as identity primary key,
  guardian_id uuid not null references guardian(id) on delete cascade,
  child_id uuid references child(id) on delete cascade,
  cls text not null, intent jsonb not null, dedupe text not null,
  not_before timestamptz not null, not_after timestamptz not null,
  status text not null default 'pending' check (status in ('pending','sending','sent','delivered','failed','expired','cancelled','blocked')),
  block_reason text, channel text, provider_id text, attempts int not null default 0,
  sent_at timestamptz, delivered_at timestamptz, opened_at timestamptz, correlation_id text not null,
  unique (guardian_id, dedupe));
create table notify_slot (
  guardian_id uuid not null references guardian(id) on delete cascade,
  child_id uuid not null references child(id) on delete cascade,
  scope text not null, slot smallint not null, notification_id bigint not null references notification(id) on delete cascade,
  primary key (guardian_id, child_id, scope, slot));
