import { readFileSync } from "fs";
import { normalizeKit } from "/home/user/Taxila/server/content/kits.js";
const [id, pe, ph] = process.argv.slice(2);
const d = JSON.parse(readFileSync("/home/user/Taxila/data/kits/c8-english.json", "utf8"));
const t = d.topics.find(t => id.startsWith(t.topicId));
const it = t.items.find(i => i.id === id);
if (pe) it.prompt_en = pe; if (ph) it.prompt_hi = ph;
const k = normalizeKit(t, { topicId: t.topicId, verified: true });
console.log(id, k.items.some(i => i.id === id) ? "FITS" : "DROPPED", it.prompt_en.length, it.prompt_hi.length);
