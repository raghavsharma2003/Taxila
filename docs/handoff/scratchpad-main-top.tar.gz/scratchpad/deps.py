import subprocess,re,sys,os
R="origin/claude/vyakti-cloning-platform-aq05n4"
def show(p):
    r=subprocess.run(["git","show",f"{R}:{p}"],capture_output=True,text=True,cwd="/home/user/html-portfolio");return r.stdout if r.returncode==0 else None
for p in open(sys.argv[1]).read().split():
    if p.endswith('/'): continue
    if not re.search(r'\.(js|mjs|ts|tsx)$',p): continue
    s=show(p)
    if s is None: continue
    specs=set(re.findall(r'(?:from|import)\s*\(?\s*[\'"](\.[^\'"]+)[\'"]',s))
    npm=set(re.findall(r'(?:from|import)\s+[\'"]([^.\'"][^\'"]*)[\'"]',s))
    npm={n for n in npm if not n.startswith('node:')}
    loc=[]
    for sp in specs:
        full=os.path.normpath(os.path.join(os.path.dirname(p),sp))
        loc.append(os.path.basename(full))
    print(f"{p}: local={len(loc)} {sorted(loc)[:14]} npm={sorted(npm)}")
