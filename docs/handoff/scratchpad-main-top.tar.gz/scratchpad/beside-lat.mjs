// Read-only TEST, 7 days: the words-only distress read's latency by deployment (model.call rows whose prompt is the
// distress brief), and how many came back after 1.2 s / 3 s or timed out.
process.env.DATABASE_URL = process.env.TEST_DATABASE_URL;
const { q } = await import("/home/user/taxila-1441/server/db.js");
const rows = (r) => r.rows ?? r;
await q("begin read only");
const ev = rows(await q(`select data->>'deployment' d, (data->>'ms')::int ms, data->>'status' st from trace_event where kind='model.call'
  and t > now() - interval '7 days' and data->>'promptId' like 'A reply from an Indian school child%'`));
const by = {};
for (const e of ev) { const b = (by[e.d] ??= { n: 0, over1200: 0, over3000: 0, timeout: 0, ms: [] }); b.n++; if (e.st === "timeout") b.timeout++; else { b.ms.push(e.ms); if (e.ms > 1200) b.over1200++; if (e.ms > 3000) b.over3000++; } }
for (const [d, b] of Object.entries(by)) { b.ms.sort((x, y) => x - y); const p = (k) => b.ms[Math.floor(k * (b.ms.length - 1))]; console.log(`${d}: n=${b.n} timeout=${b.timeout} >1.2s=${b.over1200} >3s=${b.over3000} p50=${p(0.5)} p90=${p(0.9)} p99=${p(0.99)}`); }
await q("rollback"); process.exit(0);
