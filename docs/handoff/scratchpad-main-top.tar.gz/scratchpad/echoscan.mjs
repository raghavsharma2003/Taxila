import { listStreams, loadStream, runStream } from "/home/user/Taxila/evals/duplex/taxilafdb/world.mjs";
import { armSpec } from "/home/user/Taxila/evals/duplex/taxilafdb/arms.mjs";
const norm=s=>s.replace(/[?।.,!]/g,"");
const ids = listStreams().filter((_, i) => i % 9 === 0);
let n=0, leak=0, ex=[];
for (const id of ids) { const d = loadStream(id); if (d.meta.split!=="test"||!d.sc.child) continue;
  for (const lane of ["FAST","D4"]) {
  const r = await runStream(d, { ...armSpec("stage-a"), lane });
  const her = new Set(d.gold.herWords.map(w=>norm(w.w))); const ch = new Set(d.gold.childWords.map(w=>norm(w.w)));
  for (const c of r.speaks) { if (c.reason==="safeguard"||!c.text) continue; n++; const t0=norm(c.text.split(/\s+/)[0]); if (her.has(t0)&&!ch.has(t0)) { leak++; if (ex.length<8) ex.push(lane+" "+id+" | "+c.text); } }
}}
console.log({n, leak, rate:(leak/n).toFixed(3)}); console.log(ex.join("\n"));
