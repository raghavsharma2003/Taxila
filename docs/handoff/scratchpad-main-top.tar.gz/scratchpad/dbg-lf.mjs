import { chromium } from "/home/user/Taxila/node_modules/playwright/index.mjs";
import { serve } from "/home/user/Taxila/prototypes/reset/studio/tools/serve.mjs";
const { server, port } = await serve(0);
const browser = await chromium.launch();
const page = await browser.newPage({ viewport: { width: 1280, height: 800 } });
await page.goto(`http://127.0.0.1:${port}/studio/01-landfall/?seed=7`);
await page.waitForFunction(() => document.documentElement.dataset.ready === "1");
const box = await page.locator("#stage").boundingBox();
const px = (x) => box.x + (x / 1000) * box.width;
await page.mouse.move(px(230), 700); await page.mouse.down();
const t0 = Date.now();
let lastPlan = null;
while (Date.now() - t0 < 16000) {
  const a = Date.now();
  const s = await page.evaluate(() => window.__studio.seam());
  const b = Date.now();
  const pods = s.pods.filter((p) => p.phase === "fall").sort((x, y) => x.eta - y.eta);
  if (pods.length && pods[0].id !== lastPlan) { lastPlan = pods[0].id; console.log(`${(a - t0)}ms eval=${b - a}ms new pod ${pods[0].label} trueX=${pods[0].trueX.toFixed(0)} eta=${pods[0].eta.toFixed(2)} dock=${s.dockX.toFixed(0)} state=${s.state}`);
    const t1 = Date.now(); await page.mouse.move(px(pods[0].trueX), 700, { steps: 10 }); console.log(`  moved in ${Date.now() - t1}ms`); }
  await new Promise((r) => setTimeout(r, 40));
}
const log = await page.evaluate(() => window.__studioLog.filter((m) => m.name === "land").map((m) => [m.data.item, m.data.caught, m.data.errUnits]));
console.log(JSON.stringify(log));
await browser.close(); server.close();
