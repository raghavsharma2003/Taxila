exec(open('awsenv.py').read())
import json
res={}
for r,ids in [('ap-south-1',['amazon.nova-2-lite-v1:0','amazon.nova-pro-v1:0','moonshotai.kimi-k3','openai.gpt-6-luna','openai.gpt-6.1-sol','xai.grok-4.7','anthropic.claude-sonnet-5-5','anthropic.claude-haiku-4-5-20251001-v1:0','openai.gpt-oss-safeguard-120b','mistral.voxtral-small-24b-2507','deepseek.v3.2','cohere.embed-v4:0','qwen.qwen3-vl-235b-a22b','zai.glm-5','minimax.minimax-m2.5','mistral.mistral-large-3-675b-instruct','google.gemma-3-27b-it']),
             ('us-east-1',['amazon.nova-2-sonic-v1:0','amazon.nova-2-multimodal-embeddings-v1:0','stability.stable-image-inpaint-v1:0','cohere.rerank-v3-5:0'])]:
    b=boto3.client('bedrock',region_name=r)
    for i in ids:
        try:
            x=b.get_foundation_model_availability(modelId=i); x.pop('ResponseMetadata',None)
        except Exception as e: x={'err':str(e)[:160]}
        res[r+'/'+i]=x; print(r,i,json.dumps(x)[:300])
json.dump(res,open('bedrock-availability.json','w'))
