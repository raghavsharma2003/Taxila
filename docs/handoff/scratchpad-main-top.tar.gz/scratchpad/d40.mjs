// TEST trace, read-only: QA's "Main already bol diya na" turns in the last 6 hours: scan kind/sources, move, shape.
const { q } = await import("/home/user/taxila-int/server/db.js");
const reqs = await q(`select sid, turn from trace_event where kind = 'srv.req' and t > now() - interval '6 hours' and data->'body'->>'childText' ilike '%already bol diya%'`);
for (const r of reqs) {
  const ev = await q(`select turn, kind, data from trace_event where sid = $1 and turn between $2 - 1 and $2 and kind in ('srv.req','safety.scan','director.turn') order by t`, [r.sid, r.turn]);
  console.log("== lesson", String(r.sid).slice(0, 8));
  for (const e of ev) {
    const d = e.data ?? {};
    if (e.kind === "srv.req" && d.body?.childText != null) console.log(`#${e.turn} child: ${String(d.body.childText).slice(0, 100)}`);
    if (e.kind === "safety.scan") console.log(`#${e.turn} scan kind=${d.kind} sources=${JSON.stringify(d.sources)} distress=${d.distress}`);
    if (e.kind === "director.turn") console.log(`#${e.turn} move=${d.move} shape=${String(d.shape ?? "").slice(0, 50)} reasons=${(d.reasons ?? []).filter((x) => /cls|note|safe|release/.test(x)).join(",")}`);
  }
}
process.exit(0);
