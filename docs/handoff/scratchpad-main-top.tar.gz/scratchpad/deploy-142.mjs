// 14.2 deploy: deploy-azure with the CHAT overflow lane (southindia twins). The endpoint host is not secret; the key goes
// in as a Container App secret via --secret NAME=LOCALVAR (never printed). Extra args pass through (e.g. --dry-run).
// usage (from /home/user/Taxila): node --env-file=.env.local deploy-142.mjs [--dry-run]
import { spawnSync } from "node:child_process";
const ep = process.env.AZURE_OPENAI_ENDPOINT_SIN;
if (!ep || !process.env.AZURE_OPENAI_API_KEY_SIN) { console.error("deploy-142: AZURE_OPENAI_ENDPOINT_SIN / _KEY_SIN missing"); process.exit(2); }
const twins = "taxila-fast,taxila-brain,grok-4-1-fast-non-reasoning,DeepSeek-V4-Pro,taxila-gpt6,taxila-gpt6-luna,gpt-5.6-terra";
const args = ["--env-file=.env.local", "scripts/deploy-azure.mjs", "--set", `AZURE_OPENAI_ENDPOINT_OVERFLOW=${ep}`, "--secret", "AZURE_OPENAI_API_KEY_OVERFLOW=AZURE_OPENAI_API_KEY_SIN",
  "--set", `TAXILA_OVERFLOW_DEPLOYMENTS=${twins}`, ...process.argv.slice(2)];
const r = spawnSync(process.execPath, args, { stdio: "inherit", env: process.env });
process.exit(r.status ?? 1);
