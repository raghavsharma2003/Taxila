import { q } from "/home/user/Taxila/server/db.js";
const r = await q("select count(*)::int n, min(created_at) first, max(created_at) last from guardian where email like '%@taxila.test'");
console.log(JSON.stringify(r[0]));
const r2 = await q("select email, created_at from guardian where email like '%@taxila.test' order by created_at desc limit 20");
console.log(JSON.stringify(r2));
