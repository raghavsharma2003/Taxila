import { readFileSync } from "fs";
for (const line of readFileSync("/home/user/Taxila/.env.local", "utf8").split("\n")) { const m = line.match(/^([A-Z0-9_]+)=(.*)$/); if (m && !process.env[m[1]]) process.env[m[1]] = m[2].replace(/^"(.*)"$/, "$1"); }
const { AZURE_SP_CLIENT_ID, AZURE_SP_SECRET, AZURE_TENANT_ID, AZURE_SUBSCRIPTION_ID: SUB, AZURE_RESOURCE_GROUP: RGN } = process.env;
const tok = (await (await fetch(`https://login.microsoftonline.com/${AZURE_TENANT_ID}/oauth2/v2.0/token`, { method: "POST", body: new URLSearchParams({ client_id: AZURE_SP_CLIENT_ID, client_secret: AZURE_SP_SECRET, grant_type: "client_credentials", scope: "https://management.azure.com/.default" }) })).json()).access_token;
const get = async (p) => { const u = p.startsWith("http") ? p : `https://management.azure.com/subscriptions/${SUB}${p.replace("{RG}", `/resourceGroups/${RGN}`)}`; const r = await fetch(u, { headers: { authorization: `Bearer ${tok}` } }); return { status: r.status, j: await r.json().catch(() => ({})) }; };
const redact = (o) => JSON.parse(JSON.stringify(o, (k, v) => (/secret|password|key|value/i.test(k) && typeof v === "string" && v.length > 20 ? "<r>" : v)));
const what = process.argv[2];
const r = await get(what);
console.log(r.status, JSON.stringify(redact(r.j), null, 1).slice(0, Number(process.argv[3] || 6000)));
