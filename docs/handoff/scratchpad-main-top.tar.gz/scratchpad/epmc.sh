for q in "$@"; do
curl -s -G "https://www.ebi.ac.uk/europepmc/webservices/rest/search" --data-urlencode "query=$q" --data-urlencode format=json --data-urlencode resultType=core --data-urlencode pageSize=2 | python3 -c "
import sys,json
d=json.load(sys.stdin)
for x in d['resultList']['result']:
  print('##',x.get('title'),'|',x.get('pubYear'),'|',x.get('doi'));print(x.get('abstractText','(no abstract)')[:1800]);print()
"
done
