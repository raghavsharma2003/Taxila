import { DuplexLive } from "/home/user/taxila-int/src/duplex/live.ts";
for (const gate of [false, true]) {
  let clock = 0, tick = null; const acts = [];
  const port = { duck: (l) => acts.push([clock, "duck", l]), pause: () => { acts.push([clock, "pause"]); return true; }, resume: () => {}, stop: () => acts.push([clock, "stop"]), commit: (t) => acts.push([clock, "commit", t.text]), sttCommit: () => {}, dropReply: () => acts.push([clock, "drop"]), fallback: () => {}, state: () => {} };
  const live = new DuplexLive({ lessonId: "t", port, now: () => clock, setInterval: (fn) => { tick = fn; return 1; }, clearInterval: () => {}, band: "B2", halfDuplex: true });
  const run = (u, f) => { for (; clock < u; clock += 20) { const x = f(clock); live.frame(clock, x.rms, x.f0, x.her); if (clock % 100 === 80) tick?.(); } };
  const q = () => ({ rms: 0.001, f0: null, her: null }); const echo = () => ({ rms: 0.1, f0: 210, her: -20 });
  live.start(); live.setUi({ answerForm: "number", beat: "check" }); live.herStart("सात गुणा आठ कितना होता है?"); run(2500, q); live.herEnd();
  const ans = (t) => (t >= 3200 && t < 3800 ? { rms: 0.3, f0: 290, her: null } : q());
  run(3500, ans); live.stt({ type: "input_audio_buffer.speech_started", item_id: "c1", audio_start_ms: 3200 }); run(4100, ans);
  live.stt({ type: "conversation.item.input_audio_transcription.completed", item_id: "c1", transcript: "छप्पन" });
  let t0 = null; for (let u = 4200; u < 9000 && t0 === null; u += 100) { run(u, ans); if (acts.some((a) => a[1] === "commit")) t0 = clock; }
  if (gate) live.ackStart(); run(t0 + 700, echo); if (gate) live.ackEnd(); run(t0 + 6000, q);
  console.log("gate", gate, JSON.stringify(acts));
}
for (const half of [false, true]) {
  let clock = 0, tick = null; const acts = [];
  const port = { duck: () => {}, pause: () => true, resume: () => {}, stop: () => {}, commit: (t) => acts.push([clock, t.text]), sttCommit: () => {}, dropReply: () => {}, fallback: () => {}, state: () => {} };
  const live = new DuplexLive({ lessonId: "t", port, now: () => clock, setInterval: (fn) => { tick = fn; return 1; }, clearInterval: () => {}, band: "B2", halfDuplex: half });
  const run = (u, f) => { for (; clock < u; clock += 20) { const x = f(clock); live.frame(clock, x.rms, x.f0, x.her); if (clock % 100 === 80) tick?.(); } };
  const q = () => ({ rms: 0.001, f0: null, her: null });
  live.start(); live.setUi({ beat: "explain" }); live.herStart("गुणा का मतलब है बार बार जोड़ना।"); run(2500, q); live.herEnd();
  run(15000, (t) => (t >= 3400 && t < 3800 ? { rms: 0.3, f0: 180, her: null } : q()));
  console.log("cough half", half, JSON.stringify(acts));
}
