// E2E (TEXT mode): create family -> child -> start lesson -> 3 typed turns -> screenshots 360x640 + 1280x800.
import { chromium } from "/home/user/Taxila/node_modules/playwright/index.mjs";
const BASE = process.env.BASE || "http://localhost:5181";
const SHOTS = process.env.SHOTS;
const CLASS = Number(process.env.CLASS || 4);
const TAG = process.env.TAG || `c${CLASS}`;
const browser = await chromium.launch({ executablePath: process.env.CHROMIUM, args: ["--autoplay-policy=no-user-gesture-required"] });
const ctx = await browser.newContext({ viewport: { width: 360, height: 640 }, deviceScaleFactor: 2 });
const page = await ctx.newPage();
const logs = [];
page.on("console", (m) => { if (m.type() === "error" || m.type() === "warning") logs.push(`[${m.type()}] ${m.text()}`); });
page.on("response", (r) => { if (r.status() >= 400) logs.push(`[http ${r.status()}] ${r.url().replace(/childId=[^&]+/, "childId=…")}`); });
page.on("pageerror", (e) => logs.push(`[pageerror] ${e.message}`));
const api = page.request;
const ok = async (r) => { if (!r.ok()) throw new Error(`${r.url()} ${r.status()} ${await r.text()}`); return r.json(); };
await ok(await api.post(`${BASE}/api/auth/signup`, { data: { email: `e2e+${Date.now().toString(36)}@taxila.test`, password: crypto.randomUUID(), name: "Test Parent", isGuardianAdult: true } }));
const { child } = await ok(await api.post(`${BASE}/api/children`, { data: { firstName: "Aarav", classLevel: CLASS, languagePref: "hinglish", interests: ["cricket"] } }));
await ok(await api.post(`${BASE}/api/consent`, { data: { childId: child.id, grants: { core_tutoring: true, learning_profile: true, memory: true, transcripts_retention: true } } }));
console.log("child", child.id, "class", CLASS);
const H = `${BASE}/src/child/dev/harness.html#/c/${child.id}`;

// home
await page.goto(H);
await page.getByTestId("home").waitFor();
await page.waitForTimeout(600);
await page.screenshot({ path: `${SHOTS}/${TAG}-home-360.png` });
// lesson (text mode)
await page.goto(`${H}/lesson/new?mode=text`);
await page.getByTestId("start").click();
const lesson = page.getByTestId("lesson");
await page.waitForFunction(() => document.querySelector('[data-testid="lesson"]')?.getAttribute("data-status") !== "starting", null, { timeout: 60000 });
const waitTurn = async (label) => {
  const t0 = Date.now();
  await page.waitForFunction(() => {
    const s = document.querySelector('[data-testid="lesson"]')?.getAttribute("data-status");
    return s === "your_turn" || s === "ended";
  }, null, { timeout: 90000 });
  console.log(label, "->", await lesson.getAttribute("data-status"), `${Date.now() - t0}ms`, "geometry", await lesson.getAttribute("data-geometry"), "phase", await lesson.getAttribute("data-phase"));
};
await waitTurn("opening");
await page.screenshot({ path: `${SHOTS}/${TAG}-lesson-open-360.png` });
const answers = ["haan, chalo shuru karte hain", "mujhe lagta hai teen chauthai", "kyunki chaar mein se teen hisse liye"];
for (let i = 0; i < 3; i++) {
  const status = await lesson.getAttribute("data-status");
  if (status === "ended") break;
  const chips = page.getByTestId("choices").locator("button");
  if (i === 1 && (await chips.count()) > 0) {
    console.log("tapping chip", await chips.first().innerText());
    await chips.first().click();
  } else {
    await page.getByTestId("child-input").fill(answers[i]);
    await page.getByTestId("send").click();
  }
  await page.waitForTimeout(300);
  await waitTurn(`turn ${i + 1}`);
  await page.screenshot({ path: `${SHOTS}/${TAG}-lesson-turn${i + 1}-360.png` });
}
const caption = await page.locator(".tx-caption").first().innerText().catch(() => "");
console.log("caption:", caption.slice(0, 120));
console.log("spoken:", (await page.getByTestId("spoken").innerText()).slice(0, 160));
console.log("ring count:", await page.locator(".tx-ring").count());
await page.setViewportSize({ width: 1280, height: 800 });
await page.waitForTimeout(800);
console.log("1280 family", await lesson.getAttribute("data-family"));
await page.screenshot({ path: `${SHOTS}/${TAG}-lesson-1280.png` });
console.log("ring count 1280:", await page.locator(".tx-ring").count());
// end
await page.setViewportSize({ width: 360, height: 640 });
await page.getByTestId("pause").click();
await page.screenshot({ path: `${SHOTS}/${TAG}-pause-360.png` });
await page.getByTestId("pause-stop").click();
await page.getByTestId("finish").waitFor({ timeout: 60000 });
await page.screenshot({ path: `${SHOTS}/${TAG}-end-360.png` });
await page.getByTestId("finish").click();
await page.getByTestId("home").waitFor();
console.log("home after finish:", await page.getByTestId("home").getAttribute("data-home"), "rings:", await page.locator(".tx-ring").count());
await page.screenshot({ path: `${SHOTS}/${TAG}-home-done-360.png` });
console.log("console:", logs.slice(0, 15).join("\n"));
await browser.close();
