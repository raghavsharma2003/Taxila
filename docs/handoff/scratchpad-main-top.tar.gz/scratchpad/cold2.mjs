import { performance } from "node:perf_hooks";
const { fuzzyScan } = await import("/home/user/Taxila/server/safety/fuzzy.js");
const { lexiconScan } = await import("/home/user/Taxila/server/safety/lexicon.js");
const T = (f, l) => { const a = performance.now(); f(l); return (performance.now() - a).toFixed(2); };
const order = process.argv[2] === "lex" ? [["lex", lexiconScan], ["fuz", fuzzyScan]] : [["fuz", fuzzyScan], ["lex", lexiconScan]];
for (const [n, f] of order) console.log(n, ["7", "aap mummy se achhi ho", "haha", "main buddhu hoon", "my dog died yesterday"].map((l) => T(f, l)).join(" "));
