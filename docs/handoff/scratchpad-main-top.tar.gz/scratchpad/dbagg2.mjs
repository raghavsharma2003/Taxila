import { readFileSync } from "fs";
for (const l of readFileSync("/home/user/Taxila/.env.local","utf8").split("\n")) { const m=/^([A-Z0-9_]+)=(.*)$/.exec(l.trim()); if (m && !process.env[m[1]]) process.env[m[1]]=m[2].replace(/^["']|["']$/g,""); }
const { q } = await import("/home/user/Taxila/server/db.js");
const run = async (label, sql) => { try { console.log(label, JSON.stringify(await q(sql))); } catch (e) { console.log(label, "ERR", e.message); } };
await run("db", "select current_database() db, inet_server_addr() addr");
await run("kt cols", "select column_name from information_schema.columns where table_name='kt_evidence'");
await run("kt by cls", "select cls, grader, shape_id, count(*) n, max(occurred_at) last from kt_evidence group by 1,2,3 order by 4 desc");
await run("lessons", "select count(*) n, max(started_at) last, count(*) filter (where started_at > now() - interval '1 day') d1 from lesson");
await run("evidence legacy", "select probe, outcome, count(*) n from evidence group by 1,2 order by 3 desc limit 20");
process.exit(0);
