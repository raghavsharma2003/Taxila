process.argv.push("--base", "https://taxila.dev");
const { hindiShare, enShare, RX } = await import("/home/user/Taxila/tests/prod/_owner.mjs");
const isHindi = (t) => hindiShare(t) >= 0.35 && enShare(t) < 0.15;
const isEnglish = (t) => enShare(t) >= 0.25 && hindiShare(t) < 0.2;
for (const t of ["Meher, naram hara tana aasani se mudta hai; kathor lakdi-jaisa tana seedha rehta hai.", "Meher, gudhal ka stem woody hai aur neeche se branches nikalti hain, isliye yeh shrub hai. Tree nahi—kyunki single thick trunk nahi.",
  "Sure, Ishaan. A ray has one endpoint and extends endlessly in one direction.", "Ishaan, ray OB starts at O and passes through B. Now, which other ray starts at O and passes through A?",
  "Ishaan, observation becomes a testable question: “Does more water make a plant grow faster?” Now make a similar question about football practice.",
  "Ishaan, prediction matlab pehle se andaaza: “Warm place mein curd jaldi set hoga.” Aap is prediction ka reason ek line mein likhenge?",
  "Meher, notice this: a soft green stem bends easily, while a hard woody stem stays firm. Is a rose plant soft or woody?"]) console.log(isHindi(t), isEnglish(t), hindiShare(t).toFixed(2), enShare(t).toFixed(2), t.slice(0, 60));
for (const t of ["Aarav, text-picture dekhiye:\n\n0 ┃——┃——┃——┃——┃ 1\n\nAb 0", "Ishaan, diagram sochiye: Torch ●────────→ roshni.", "Kabir, board par 3/5 × 2/3 likhiye.", "Zoya, aise draw kijiye: cloud", "yahan animation dikha nahi sakta", "1/2 + 1/4 = 3/4 - that is right"]) console.log(RX.asciiArt.test(t), RX.childDraws.test(t), RX.cantDraw.test(t), t.slice(0, 50).replace(/\n/g, " "));
