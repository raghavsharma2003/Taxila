import { neon } from "@neondatabase/serverless";
const sql = neon(process.env.CONDUCTOR_TEST_DATABASE_URL);
await sql.query("drop table if exists child_test_window");
await sql.query("alter table child_controls add column if not exists test_window jsonb");
console.log(await sql.query("select column_name from information_schema.columns where table_name='child_controls' order by 1"));
