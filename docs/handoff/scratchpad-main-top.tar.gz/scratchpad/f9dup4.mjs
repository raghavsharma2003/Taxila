const { q } = await import("/home/user/taxila-int/server/db.js");
const rows = (r) => r.rows ?? r;
await q("begin read only");
for (const pre of ["3437b744", "310b8c82"]) {
  const L = rows(await q(`select id::text from lesson where id::text like $1`, [`${pre}%`]))[0].id;
  console.log(`== ${pre}`);
  const ev = rows(await q(`select turn, kind, data from trace_event where sid=$1 and kind in ('studio.slot.revealed','board.page','director.turn') and turn is not null order by t`, [L]));
  const pages = {};
  for (const e of ev) { const d = e.data ?? {};
    if (e.kind === "board.page") { pages[e.turn] = `page seq=${d.seq} mode=${d.mode} beat=${d.beat?.type ?? d.beat ?? ""} ops=${Array.isArray(d.ops) ? d.ops.length : d.ops} clears=${d.clears ?? ""} intent=${String(d.intentId ?? "").slice(0, 8)}`; } }
  for (const e of ev) { const d = e.data ?? {};
    if (e.kind === "studio.slot.revealed") console.log(`  t${e.turn} revealed why=${d.why} state=${d.state} fallback=${JSON.stringify(d.fallback)} archetype=${d.archetype ?? ""} intent=${String(d.intentId ?? "").slice(0, 8)} slot=${String(d.slotId ?? "").slice(0, 10)} art=${typeof d.artifact === "object" ? Object.keys(d.artifact ?? {}).join("/") : String(d.artifact).slice(0, 30)} | ${pages[e.turn] ?? "NO new board.page this turn"}`);
    if (e.kind === "director.turn" && Object.keys(pages).length) {} }
}
await q("rollback"); process.exit(0);
