// read-only, production: latency of model.call rows on real lesson sids, aggregated (no ids, no content)
const { q } = await import("/home/user/taxila-int/server/db.js");
const rows = (r) => r.rows ?? r;
await q("begin read only");
const keys = rows(await q(`select distinct jsonb_object_keys(data) k from trace_event where kind = 'model.call' and t > now() - interval '7 days' limit 40`));
console.log("keys:", keys.map((x) => x.k).join(" "));
const r = rows(await q(`
  with m as (select e.data from trace_event e where e.kind = 'model.call' and e.t > now() - interval '7 days'
             and exists (select 1 from lesson l where l.id::text = e.sid))
  select coalesce(data->>'deployment', data->>'model') dep, coalesce(data->>'schema', data->>'schemaName', data->>'purpose', data->>'what', '?') what,
         count(*) n, percentile_cont(0.5) within group (order by (data->>'ms')::float) p50,
         percentile_cont(0.9) within group (order by (data->>'ms')::float) p90, percentile_cont(0.95) within group (order by (data->>'ms')::float) p95
  from m where data ? 'ms' group by 1, 2 having count(*) >= 5 order by n desc limit 25`));
console.table(rows(r).map((x) => ({ ...x, p50: Math.round(x.p50), p90: Math.round(x.p90), p95: Math.round(x.p95) })));
await q("rollback"); process.exit(0);
