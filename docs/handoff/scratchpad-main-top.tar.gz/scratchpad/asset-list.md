### B00: Style keys: the three anchors every later image is matched against, plus the phone crop of the world anchor (4)

- bg/home-young-wide | 2560x1440 webp | ref: - | A sunlit Indian home courtyard in calm morning light. Limewash walls in warm off-white with soft cream light from the upper left. A neem tree at the right edge with its leaf shadows on the wall. An open wooden veranda doorway at the LEFT, EMPTY and calm inside (the teacher is placed there by the app). White rice-flour kolam dots on the floor near the edges only. Two terracotta pots with leafy plants and a magenta bougainvillea spray. A charpai with teal cotton-tape weave at the far edge. A band of pale day sky (#A9D8E8) at the top. Painted garden beds along the lower right wall edge (bare soil, the app makes them tappable on desktop).
- bg/home-young-phone | 1440x2560 webp | ref: bg/home-young-wide | the same scene as bg/home-young-wide, recomposed tall
- avatars/red-panda | 512x512 png alpha | ref: - | a red panda sitting, rust-red fur (deep rust, not orange), ringed tail curled round; disc tint teal
- picto/home | 256x256 png alpha | ref: avatars/red-panda | a small clay house with a sloped tiled roof

### B01: Young world backgrounds + stage-young + garden panorama (12)

- bg/home-young-rest-wide | 2560x1440 webp | ref: bg/home-young-wide | The SAME courtyard as bg/home-young (same walls, tree, doorway, pots, charpai, same camera) in late-afternoon cream light with longer soft shadows. An open book with blank pages resting on the charpai. The doorway is still empty. Calm, slightly quieter than the morning version.
- bg/home-young-rest-phone | 1440x2560 webp | ref: bg/home-young-wide, bg/home-young-rest-wide | the same scene as bg/home-young-rest-wide, recomposed tall
- bg/home-older-wide | 2560x1440 webp | ref: bg/home-young-wide | A flat Indian rooftop at dusk, editorial and muted. A black plastic water tank on a low brick stand at one edge, a simple painted iron rail, a telescope on a tripod pointing at the sky, a string of UNLIT bulbs on a wire, city lights far below as tiny cool-white and soft-rose points (never orange street lights). Deep indigo sky (#26304A to #0F1A33) with a faint rose-violet glow at the horizon (never orange or gold). Lots of negative space.
- bg/home-older-phone | 1440x2560 webp | ref: bg/home-young-wide, bg/home-older-wide | the same scene as bg/home-older-wide, recomposed tall
- bg/home-older-rest-wide | 2560x1440 webp | ref: bg/home-older-wide | The SAME rooftop as bg/home-older (same tank, rail, telescope, camera) later at night: deeper navy sky (#0F1A33), the telescope pointing straight up, no lit signs below, a few soft city lights. No stars painted (the app owns stars).
- bg/home-older-rest-phone | 1440x2560 webp | ref: bg/home-older-wide, bg/home-older-rest-wide | the same scene as bg/home-older-rest-wide, recomposed tall
- bg/who-wide | 2560x1440 webp | ref: bg/home-young-wide | The same home's courtyard gate seen from outside: an open weathered wooden gate in greyed walnut, a short stone path, the sunlit courtyard visible beyond (same limewash walls and neem tree as bg/home-young), a calm arch over the gate. The lower two-thirds are calm and low-detail for avatar tiles.
- bg/who-phone | 1440x2560 webp | ref: bg/home-young-wide, bg/who-wide | the same scene as bg/who-wide, recomposed tall
- bg/practice-wide | 2560x1440 webp | ref: bg/home-young-wide | A quiet courtyard corner of the same home: a big BLANK black slate on a simple wooden easel at one edge, a woven floor mat, a closed steel tiffin, soft cream light. The centre is calm and empty.
- bg/practice-phone | 1440x2560 webp | ref: bg/home-young-wide, bg/practice-wide | the same scene as bg/practice-wide, recomposed tall
- bg/stage-young | 1600x1600 webp | ref: bg/home-young-wide | A softly out-of-focus veranda at dusk seen behind a head-and-shoulders position: deep dusk blue (#26304A) overall, the edge of a large BLANK green chalkboard (#1F3B30) at one side, a warm soft pool of CREAM light centred at x 50%, y 38%. The centre is plain and smooth (her face goes there). No person.
- bg/garden-panorama | 4800x1200 webp tile wrap | ref: bg/home-young-wide | A long kitchen-garden strip along the courtyard wall of the same home in morning light: a row of low brick-edged beds of BARE dark soil (the app places plants on them), a garden tap with a steel bucket, a neem tree at one end, limewash wall behind. No plants in the beds. The LEFT and RIGHT edges must join seamlessly (it scrolls).

### B02: Older and neutral backgrounds, stage-older, sky, onboarding edge, landing hero, parent header (9)

- bg/ask-wide | 2560x1440 webp | ref: bg/home-older-wide | A study desk on the same rooftop at dusk: an open textbook with BLANK pages, a pencil, a steel tumbler, the rail and indigo sky behind, muted and editorial. The centre third is calm for the text field.
- bg/ask-phone | 1440x2560 webp | ref: bg/home-older-wide, bg/ask-wide | the same scene as bg/ask-wide, recomposed tall
- bg/notebook-shelf-wide | 2560x1440 webp | ref: bg/home-young-wide | A wooden wall shelf in desaturated greyed-walnut wood holding a few CLOSED blank cloth-bound notebooks (teal, rose, leaf, stone covers, no labels) and one small potted plant, soft cream light from the upper left, limewash wall. The centre is calm for the page stack.
- bg/notebook-shelf-phone | 1440x2560 webp | ref: bg/home-young-wide, bg/notebook-shelf-wide | the same scene as bg/notebook-shelf-wide, recomposed tall
- bg/stage-older | 1600x1600 webp | ref: bg/stage-young | A softly out-of-focus study wall in evening light: a bookshelf with BLANK spines, a window with neem leaves, the same dusk blue (#26304A) and the same cream light pool at x 50%, y 38% as bg/stage-young. The centre is plain and smooth. No person.
- bg/sky-panel | 2400x1600 webp | ref: bg/home-older-wide | A calm deep-navy night sky (#0F1A33) with faint painted clouds near the bottom and a far city skyline silhouette with NO lit signs. NO stars, no moon, no planets: the sky is empty for the app's stars.
- bg/onboarding-edge | 1200x2400 webp skin | ref: bg/home-young-wide | A quiet vertical edge strip: a parent's hand resting near a face-down phone on a kitchen table, a steel cup of chai, very low contrast, everything on the RIGHT edge; the left two-thirds are near-empty warm paper (#F6F3EC) tone.
- bg/landing-hero | 2400x1400 webp | ref: bg/home-older-wide | A warm study desk at dusk, editorial: a child's BLANK notebook and a pencil at the lower left, a steel tumbler, a window with dusk indigo sky, soft cream light from the upper left. An EMPTY calm space centre-right where two portraits are composited. No person.
- bg/parent-header | 2400x600 webp | ref: bg/home-young-wide | A quiet limewash wall with a single leafy plant in a terracotta pot at the right edge and soft cream light from the upper left; very low detail, most of the band is plain wall.

### B03: Young pictograms (incl. picture-PIN set) (50)

- picto/pause | 256x256 png alpha | ref: picto/home | a resting open palm enclosed inside a soft circle
- picto/mic | 256x256 png alpha | ref: picto/home | a round microphone with a wooden handle
- picto/ear | 256x256 png alpha | ref: picto/home | a listening ear
- picto/hear-again | 256x256 png alpha | ref: picto/home | an ear with a curved arrow around it
- picto/slower | 256x256 png alpha | ref: picto/home | a tortoise walking
- picto/your-turn | 256x256 png alpha | ref: picto/home | an open hand, palm up, offering
- picto/tap | 256x256 png alpha | ref: picto/home | a finger tapping, pointing UP
- picto/eraser | 256x256 png alpha | ref: picto/home | a pencil eraser
- picto/pencil | 256x256 png alpha | ref: picto/home | a pencil
- picto/captions | 256x256 png alpha | ref: picto/home | speech lines inside a speech bubble, NO letters
- picto/watch | 256x256 png alpha | ref: picto/home | an eye
- picto/hint | 256x256 png alpha | ref: picto/home | a lightbulb of cool white glass, NOT yellow, not lit yellow
- picto/choices | 256x256 png alpha | ref: picto/home | three blank cards fanned
- picto/show-me-how | 256x256 png alpha | ref: picto/home | a hand holding a chalk stick
- picto/yes | 256x256 png alpha | ref: picto/home | a tick made of a twig
- picto/no | 256x256 png alpha | ref: picto/home | two crossed twigs, natural wood colour, never red
- picto/garden | 256x256 png alpha | ref: picto/home | a watering can
- picto/practice | 256x256 png alpha | ref: picto/home | a slate
- picto/notebook | 256x256 png alpha | ref: picto/home | a closed notebook
- picto/help | 256x256 png alpha | ref: picto/home | a child and a grown-up side by side, simple shapes
- picto/call | 256x256 png alpha | ref: picto/home | a phone handset and a grown-up silhouette
- picto/sound-on | 256x256 png alpha | ref: picto/home | a speaker with sound lines
- picto/sound-off | 256x256 png alpha | ref: picto/home | a speaker with a soft line through it
- picto/ai-teacher | 256x256 png alpha | ref: picto/home | a small rounded laptop with a warm cream glow, no face
- picto/who-sees | 256x256 png alpha | ref: picto/home | an eye beside a grown-up silhouette
- picto/list | 256x256 png alpha | ref: picto/home | three stacked blank strips
- picto/arrow-left | 256x256 png alpha | ref: picto/home | a soft arrow pointing left
- picto/arrow-right | 256x256 png alpha | ref: picto/home | a soft arrow pointing right
- picto/water-glass | 256x256 png alpha | ref: picto/home | a steel glass of water
- picto/stretch | 256x256 png alpha | ref: picto/home | a pair of arms stretching up
- picto/finish | 256x256 png alpha | ref: picto/home | a closed notebook with a tick-shaped ribbon
- picto/calmer | 256x256 png alpha | ref: picto/home | a single feather floating, still
- picto/switch-learner | 256x256 png alpha | ref: picto/home | two round picture discs with a curved arrow between them
- picto/more-pictures | 256x256 png alpha | ref: picto/home | three round picture discs fanned
- picto/send | 256x256 png alpha | ref: picto/home | a paper plane
- picto/subject-maths | 256x256 png alpha | ref: picto/home | a compass from a geometry box
- picto/subject-english | 256x256 png alpha | ref: picto/home | a closed cloth-bound book
- picto/subject-hindi | 256x256 png alpha | ref: picto/home | a small blank slate with a chalk stick, no script
- picto/subject-evs | 256x256 png alpha | ref: picto/home | a potted sprout
- picto/subject-science | 256x256 png alpha | ref: picto/home | a magnifying glass
- picto/subject-social-science | 256x256 png alpha | ref: picto/home | a small globe with no borders
- picto/pin-kite | 256x256 png alpha | ref: picto/home | a diamond kite
- picto/pin-boat | 256x256 png alpha | ref: picto/home | a paper boat
- picto/pin-umbrella | 256x256 png alpha | ref: picto/home | an open umbrella
- picto/pin-cup | 256x256 png alpha | ref: picto/home | a steel cup
- picto/pin-fish | 256x256 png alpha | ref: picto/home | a small fish
- picto/pin-leaf | 256x256 png alpha | ref: picto/home | a leaf
- picto/pin-ball | 256x256 png alpha | ref: picto/home | a ball
- picto/pin-bus | 256x256 png alpha | ref: picto/home | a small bus
- picto/pin-flower | 256x256 png alpha | ref: picto/home | a five-petal flower

### B04: Child avatars (23)

- avatars/tiger-cub | 512x512 png alpha | ref: avatars/red-panda | a tiger cub lying with paws forward, fur painted deep rust-terracotta (never bright orange or gold), dark stripes; disc tint rose
- avatars/elephant-calf | 512x512 png alpha | ref: avatars/red-panda | an elephant calf with its trunk curled up, soft grey; disc tint leaf
- avatars/river-dolphin | 512x512 png alpha | ref: avatars/red-panda | a Ganges river dolphin arcing out of water, grey-pink, long slim beak; disc tint sky
- avatars/hornbill | 512x512 png alpha | ref: avatars/red-panda | an Indian grey hornbill on a branch, soft greys, dark grey casque (no yellow casque); disc tint terracotta
- avatars/peacock | 512x512 png alpha | ref: avatars/red-panda | a peacock in profile with its tail folded, teal and blue body, tail shown as a closed sweep (no fan of eyes); disc tint stone
- avatars/turtle | 512x512 png alpha | ref: avatars/red-panda | a small turtle with a leaf-green shell walking; disc tint teal
- avatars/butterfly | 512x512 png alpha | ref: avatars/red-panda | a blue Mormon butterfly, wings open, deep blue and black; disc tint rose
- avatars/squirrel | 512x512 png alpha | ref: avatars/red-panda | an Indian palm squirrel holding a nut, grey-brown with three pale back stripes; disc tint leaf
- avatars/camel | 512x512 png alpha | ref: avatars/red-panda | a young camel sitting, pale greyish-fawn coat (low saturation, never golden sand); disc tint sky
- avatars/rhino | 512x512 png alpha | ref: avatars/red-panda | a one-horned rhino calf, slate grey, gentle; disc tint terracotta
- avatars/snow-leopard | 512x512 png alpha | ref: avatars/red-panda | a snow leopard cub with a thick tail, pale grey with soft rosettes; disc tint stone
- avatars/kite | 512x512 png alpha | ref: avatars/red-panda | a diamond paper kite with a tail, teal and rose, string trailing (no yellow); disc tint teal
- avatars/rocket | 512x512 png alpha | ref: avatars/red-panda | a small rounded rocket with a teal body, cream nose and a soft white puff below; disc tint rose
- avatars/football | 512x512 png alpha | ref: avatars/red-panda | a classic football on grass, white and ink-blue panels, no logo; disc tint leaf
- avatars/cricket-bat | 512x512 png alpha | ref: avatars/red-panda | a cricket bat in pale low-saturation willow with a rose grip and a red ball, no logo, no stickers; disc tint sky
- avatars/mango | 512x512 png alpha | ref: avatars/red-panda | a raw green mango (kairi) with two leaves and a soft rose blush (not ripe yellow); disc tint terracotta
- avatars/sunflower | 512x512 png alpha | ref: avatars/red-panda | a white-petalled sunflower variety with a dark centre (cream-white petals, never yellow); disc tint stone
- avatars/mountain | 512x512 png alpha | ref: avatars/red-panda | a snowy mountain peak with a pine at its foot; disc tint teal
- avatars/sailboat | 512x512 png alpha | ref: avatars/red-panda | a small sailboat with a white sail on calm water; disc tint rose
- avatars/auto-rickshaw | 512x512 png alpha | ref: avatars/red-panda | an Indian auto-rickshaw seen three-quarter, leaf-green body and cream roof, no number plate, no text; disc tint leaf
- avatars/bicycle | 512x512 png alpha | ref: avatars/red-panda | a simple bicycle with a front basket, ink-blue frame; disc tint sky
- avatars/telescope | 512x512 png alpha | ref: avatars/red-panda | a small telescope on a tripod, ink-blue tube, steel fittings (no brass); disc tint terracotta
- avatars/paintbrush | 512x512 png alpha | ref: avatars/red-panda | a paintbrush with a teal handle and a wet rose tip, a small dab of paint; disc tint stone

### B05: Interest tiles and home-task objects (22)

- interests/cricket | 512x512 png alpha | ref: avatars/red-panda | a cricket bat in pale willow, a red ball and three stumps on a patch of grass, no logos
- interests/football | 512x512 png alpha | ref: avatars/red-panda | a football resting on grass beside a small cone
- interests/space | 512x512 png alpha | ref: avatars/red-panda | a ringed planet in teal and rose with a small cream rocket passing it
- interests/animals | 512x512 png alpha | ref: avatars/red-panda | a friendly dog and a cat sitting together
- interests/drawing | 512x512 png alpha | ref: avatars/red-panda | a few crayons (teal, rose, leaf, sky, no yellow) beside a BLANK sketchbook
- interests/music | 512x512 png alpha | ref: avatars/red-panda | a small harmonium in dark wood and a small hand drum
- interests/dance | 512x512 png alpha | ref: avatars/red-panda | a pair of SILVER ankle bells (ghungroo) and a twirling rose scarf in mid-air, no person
- interests/cooking | 512x512 png alpha | ref: avatars/red-panda | a rolling pin and a small steel bowl of flour on a board
- interests/trains | 512x512 png alpha | ref: avatars/red-panda | a blue passenger train crossing a small arched bridge
- interests/stories | 512x512 png alpha | ref: avatars/red-panda | an open book with BLANK pages and a small desk lamp glowing cream-white
- interests/building | 512x512 png alpha | ref: avatars/red-panda | a small tower of wooden blocks painted teal, rose, leaf and stone
- interests/nature | 512x512 png alpha | ref: avatars/red-panda | a green leaf, a red ladybird and a smooth grey pebble
- home/roti | 384x384 png alpha | ref: avatars/red-panda | a single pale wheat roti with a few light-brown spots (low saturation, never golden)
- home/steel-plate | 384x384 png alpha | ref: avatars/red-panda | an empty round steel plate
- home/paper-strip | 384x384 png alpha | ref: avatars/red-panda | a long strip of plain cream paper, slightly curled
- home/bowl-of-grapes | 384x384 png alpha | ref: avatars/red-panda | a small steel bowl of green grapes
- home/matchbox-closed | 384x384 png alpha | ref: avatars/red-panda | a closed plain ink-blue matchbox with NO printing
- home/measuring-cup | 384x384 png alpha | ref: avatars/red-panda | a clear measuring cup with NO markings
- home/water-bottle | 384x384 png alpha | ref: avatars/red-panda | a steel water bottle
- home/rope | 384x384 png alpha | ref: avatars/red-panda | a coiled grey-blue cotton rope (not golden jute)
- home/ladoos-on-plate | 384x384 png alpha | ref: avatars/red-panda | a few pale coconut ladoos on a small steel plate (no yellow or orange sweets)
- home/chocolate-bar-plain-wrapper | 384x384 png alpha | ref: avatars/red-panda | a chocolate bar in a plain dusty-rose wrapper with NO printing

### B06: Subject spots and topic motifs, part 1 (35)

- subjects/maths | 768x768 png alpha | ref: avatars/red-panda | an open steel geometry box with a compass, a clear protractor WITHOUT any markings, and a red-and-black striped pencil (no brand)
- subjects/science | 768x768 png alpha | ref: avatars/red-panda | a glass jar with a sprouting bean, a magnifying glass and a red horseshoe magnet
- subjects/english | 768x768 png alpha | ref: avatars/red-panda | two cloth-bound books (teal and rose covers, no titles) and a fountain pen; blank pages
- subjects/hindi | 768x768 png alpha | ref: avatars/red-panda | a small black slate with a BLANK surface, a white chalk stick and a small steel bell (no script anywhere)
- subjects/evs | 768x768 png alpha | ref: avatars/red-panda | a potted mint plant, a tin watering can and a small house sparrow on the pot rim
- subjects/social-science | 768x768 png alpha | ref: avatars/red-panda | a globe with soft abstract continents in leaf green on sky-blue seas with NO borders and no recognisable country shapes, an old steel compass and a terracotta clay pot
- topics/hide-and-seek | 512x512 png alpha | ref: avatars/red-panda | a curious kitten peeking out from behind a woven basket
- topics/long-and-round | 512x512 png alpha | ref: avatars/red-panda | a long bamboo stick lying beside a rolling ball and a round steel plate standing on its edge
- topics/mango-basket | 512x512 png alpha | ref: avatars/red-panda | a shallow woven basket heaped with raw green mangoes with a rosy blush, too many to count at a glance
- topics/stick-bundles | 512x512 png alpha | ref: avatars/red-panda | bundles of thin sticks tied with teal string beside a small loose pile of sticks; amounts are not countable at a glance
- topics/two-bowls | 512x512 png alpha | ref: avatars/red-panda | two small steel bowls of green peas with a few peas mid-way between them, as if being moved
- topics/vegetable-basket | 512x512 png alpha | ref: avatars/red-panda | a basket of fresh vegetables: a brinjal, a tomato, okra, a cauliflower and a radish
- topics/hand-span | 512x512 png alpha | ref: avatars/red-panda | a child's hand spread flat beside a ribbon laid along a floor tile, and a pair of small footprints
- topics/bead-pattern | 512x512 png alpha | ref: avatars/red-panda | a string of wooden beads in a repeating teal, rose and leaf sequence, loosely coiled
- topics/daily-clock | 512x512 png alpha | ref: avatars/red-panda | a round wall clock with NO numerals and no tick marks, two simple hands, a small cream sun and a small crescent moon on either side
- topics/equal-plates | 512x512 png alpha | ref: avatars/red-panda | a row of identical small steel plates, each holding the same small heap of peanuts
- topics/vegetable-cart | 512x512 png alpha | ref: avatars/red-panda | a wooden vegetable cart with baskets under a cloth awning; no price tags, no money, no signs
- topics/toy-sorting | 512x512 png alpha | ref: avatars/red-panda | toys sorted into three cloth baskets: balls in one, blocks in another, soft toys in the third
- topics/beach-shells | 512x512 png alpha | ref: avatars/red-panda | a beach with scattered shells, a small bucket and gentle waves
- topics/solid-shapes | 512x512 png alpha | ref: avatars/red-panda | a ball, a box, a steel tin and a clay cone arranged together
- topics/shadow-shapes | 512x512 png alpha | ref: avatars/red-panda | a wooden block and a steel tin casting long soft shadows that make clean flat shapes
- topics/paper-shapes | 512x512 png alpha | ref: avatars/red-panda | a scatter of cut coloured-paper shapes: a circle, a triangle, a square and a long strip
- topics/stick-lines | 512x512 png alpha | ref: avatars/red-panda | sticks standing, lying and leaning against a wall, a string stretched between two pegs
- topics/paper-bunting | 512x512 png alpha | ref: avatars/red-panda | a string of triangular paper bunting in teal, rose and leaf with a few paper flowers (not tied to any festival)
- topics/balance-jug | 512x512 png alpha | ref: avatars/red-panda | a simple two-pan balance with a steel jug and a cup beside it
- topics/three-seasons | 512x512 png alpha | ref: avatars/red-panda | an umbrella, a woollen cap and a hand fan together
- topics/fair-wheel | 512x512 png alpha | ref: avatars/red-panda | a small wooden giant wheel and a striped stall awning at a fair, no signs
- topics/pebble-groups | 512x512 png alpha | ref: avatars/red-panda | smooth pebbles placed in neat small groups on a cloth
- topics/frog-stones | 512x512 png alpha | ref: avatars/red-panda | a small green frog mid-jump between flat stepping stones in a line across a pond
- topics/roti-share | 512x512 png alpha | ref: avatars/red-panda | a whole pale roti on a steel plate with a small butter knife beside it (the roti is not cut)
- topics/butterfly-symmetry | 512x512 png alpha | ref: avatars/red-panda | a blue butterfly with wings fully open, perfectly mirrored left and right
- topics/transport-toys | 512x512 png alpha | ref: avatars/red-panda | a toy bus, a toy train engine and a toy boat
- topics/animal-figures | 512x512 png alpha | ref: avatars/red-panda | small carved wooden figurines of an elephant, a tiger and a leopard
- topics/clean-lane | 512x512 png alpha | ref: avatars/red-panda | a tidy lane corner with a grass broom, a lidded dustbin and a potted plant
- topics/chappals-door | 512x512 png alpha | ref: avatars/red-panda | many pairs of chappals of different sizes placed neatly by a doorstep

### B07: Topic motifs, part 2 (29)

- topics/plant-roots | 512x512 png alpha | ref: avatars/red-panda | a young plant lifted from soil showing its roots, a small trowel beside it
- topics/tree-home | 512x512 png alpha | ref: avatars/red-panda | a tree trunk with a squirrel on it, a bird's nest on a branch and an ant trail at the roots
- topics/matka-water | 512x512 png alpha | ref: avatars/red-panda | a terracotta matka with a steel tumbler and a ladle, a few water drops
- topics/thali-food | 512x512 png alpha | ref: avatars/red-panda | a steel thali with small bowls of dal, rice and vegetables and a roti
- topics/healthy-habits | 512x512 png alpha | ref: avatars/red-panda | a toothbrush in a steel cup, a bar of soap and a skipping rope
- topics/materials | 512x512 png alpha | ref: avatars/red-panda | a glass tumbler, a wooden spoon, a steel spoon and a folded cotton cloth side by side
- topics/potter-wheel | 512x512 png alpha | ref: avatars/red-panda | a clay pot on a potter's wheel with wet clay
- topics/reuse-bag | 512x512 png alpha | ref: avatars/red-panda | a cloth shopping bag, a glass jar reused as a pencil holder, and a small compost pot
- topics/lane-shop | 512x512 png alpha | ref: avatars/red-panda | a small neighbourhood lane with a corner shop shutter half open, a red post box with no writing and a parked bicycle
- topics/float-sink | 512x512 png alpha | ref: avatars/red-panda | a tub of water with a paper boat floating and a stone resting at the bottom
- topics/land-forms | 512x512 png alpha | ref: avatars/red-panda | a small diorama: a snowy mountain, pale stone-pink sand dunes, and a strip of coast with a coconut palm
- topics/sun-moon | 512x512 png alpha | ref: avatars/red-panda | a cream-white sun and a crescent moon side by side above a rooftop rail
- topics/open-book | 512x512 png alpha | ref: avatars/red-panda | an open book with BLANK pages and a bookmark ribbon
- topics/singing-bird | 512x512 png alpha | ref: avatars/red-panda | a small bird singing on a branch, beak open
- topics/two-kites | 512x512 png alpha | ref: avatars/red-panda | two kites flying side by side, their strings close together
- topics/rain-clouds | 512x512 png alpha | ref: avatars/red-panda | soft rain clouds over a small pond with rain rings
- topics/envelope-letter | 512x512 png alpha | ref: avatars/red-panda | a closed paper envelope with NO writing and no stamp, tied with string
- topics/garden-snail | 512x512 png alpha | ref: avatars/red-panda | a snail on a broad leaf in a garden
- topics/jungle-friends | 512x512 png alpha | ref: avatars/red-panda | a monkey on a branch, a crow on a fence post and a deer at the edge
- topics/street-games | 512x512 png alpha | ref: avatars/red-panda | a stack of flat lagori stones with a soft ball and a coiled tug rope
- topics/rocket-moon | 512x512 png alpha | ref: avatars/red-panda | a small rocket flying toward a large pale moon
- topics/sweets-plate | 512x512 png alpha | ref: avatars/red-panda | a steel plate of pale sweets: white coconut barfi and rose-pink peda (no yellow or orange sweets)
- topics/grandparents-shawl | 512x512 png alpha | ref: avatars/red-panda | a pair of reading glasses resting on a folded wool shawl beside a walking stick
- topics/paint-palette | 512x512 png alpha | ref: avatars/red-panda | a paint palette with teal, rose, leaf, sky and stone paint and a brush
- topics/bicycle | 512x512 png alpha | ref: avatars/red-panda | a child's bicycle leaning on its stand
- topics/big-tree | 512x512 png alpha | ref: avatars/red-panda | a big neem tree with a wide shady canopy
- topics/farm-field | 512x512 png alpha | ref: avatars/red-panda | a green field with young crop rows, a small hand plough resting at the edge, no person
- topics/swing | 512x512 png alpha | ref: avatars/red-panda | a wooden swing hanging from a tree branch on two ropes
- topics/braille-hand | 512x512 png alpha | ref: avatars/red-panda | fingertips reading raised dots on a blank cream page

### B08: Empty, system and trouble states (16)

- states/notebook-empty | 1024x768 png alpha | ref: avatars/red-panda, bg/home-young-wide | a closed cloth notebook with a ribbon bookmark, waiting on a desk
- states/garden-empty | 1024x768 png alpha | ref: avatars/red-panda, bg/home-young-wide | one bed of bare soil, a BLANK seed packet and a small trowel
- states/sky-empty | 1024x768 png alpha | ref: avatars/red-panda, bg/home-young-wide | a child's telescope on a windowsill pointing at a dark empty sky, no stars
- states/no-internet | 1024x768 png alpha | ref: avatars/red-panda, bg/home-young-wide | a paper boat resting on a still pond with a few ripples
- states/mic-off | 1024x768 png alpha | ref: avatars/red-panda, bg/home-young-wide | a microphone lying on a soft cushion, quiet
- states/sound-off | 1024x768 png alpha | ref: avatars/red-panda, bg/home-young-wide | a small speaker with a paper flower in front of it
- states/done-for-today | 1024x768 png alpha | ref: avatars/red-panda, bg/home-young-wide | a closed school bag by a door in evening light, small shoes placed neatly
- states/rest-until-tomorrow | 1024x768 png alpha | ref: avatars/red-panda, bg/home-young-wide | a desk lamp switched off, a window with a crescent moon (no face on the moon)
- states/something-wrong | 1024x768 png alpha | ref: avatars/red-panda, bg/home-young-wide | a tangled ball of teal wool with a cat's paw reaching in, gentle and funny
- states/lessons-empty-parent | 1024x768 png alpha skin | ref: avatars/red-panda, bg/home-young-wide | an adult's hand placing a fresh closed notebook on a child's desk
- states/ai-teacher-card | 1024x768 png alpha | ref: avatars/red-panda, bg/home-young-wide | a friendly rounded laptop on a desk with a soft cream glow and a small potted plant; the screen is BLANK and warm; no face on the screen
- states/talk-to-grown-up | 1024x768 png alpha skin | ref: avatars/red-panda, bg/home-young-wide | a child and a grown-up sitting side by side on a step, seen from behind, the grown-up's arm around the child, the child wearing a small behind-the-ear hearing aid; calm, safe, warm
- states/permission-mic | 1024x768 png alpha | ref: avatars/red-panda, bg/home-young-wide | an abstract settings toggle switch on a blank panel, switching on, beside a small microphone shape
- states/volume-keys | 1024x768 png alpha skin | ref: avatars/red-panda, bg/home-young-wide | a hand holding a phone, thumb on the side volume button, the screen blank
- states/404 | 1024x768 png alpha | ref: avatars/red-panda, bg/home-young-wide | an empty winding garden path between terracotta pots, inviting, nobody on it
- states/help-calm | 1024x768 png alpha | ref: avatars/red-panda, bg/home-young-wide | a soft, plain warm room corner with a lamp switched on (cream-white light), almost abstract

### B09: Garden, sky seal, protégés (25)

- garden/rose-bush-seed | 512x768 png alpha | ref: avatars/red-panda | a soil mound with a BLANK seed packet on a stick
- garden/rose-bush-sprout | 512x768 png alpha | ref: garden/rose-bush-seed | a soil mound with two small leaves
- garden/rose-bush-bloom | 512x768 png alpha | ref: garden/rose-bush-seed | a small rose bush with dusty-rose flowers
- garden/rose-bush-fruit | 512x768 png alpha | ref: garden/rose-bush-seed | a full rose bush with many open roses and a few rose hips
- garden/tomato-seed | 512x768 png alpha | ref: garden/rose-bush-seed | a soil mound with a BLANK seed packet on a stick
- garden/tomato-sprout | 512x768 png alpha | ref: garden/rose-bush-seed | a soil mound with two small leaves
- garden/tomato-bloom | 512x768 png alpha | ref: garden/rose-bush-seed | a young tomato plant in flower with pale cream blossoms (never yellow)
- garden/tomato-fruit | 512x768 png alpha | ref: garden/rose-bush-seed | a tomato plant with ripe red tomatoes
- garden/guava-tree-seed | 512x768 png alpha | ref: garden/rose-bush-seed | a soil mound with a BLANK seed packet on a stick
- garden/guava-tree-sprout | 512x768 png alpha | ref: garden/rose-bush-seed | a soil mound with two small leaves
- garden/guava-tree-bloom | 512x768 png alpha | ref: garden/rose-bush-seed | a small guava sapling with white flowers
- garden/guava-tree-fruit | 512x768 png alpha | ref: garden/rose-bush-seed | a small guava tree with pale green guavas
- garden/sunbird | 256x256 png alpha | ref: garden/rose-bush-seed | A small purple sunbird perched, looking curious, side view, feet at the bottom edge so it can sit on a plant. Transparent background.
- garden/chapter-seal | 768x768 png alpha | ref: garden/rose-bush-seed | A small woven garden gate of weathered grey-green bamboo with a dark iron bell hanging from its top bar (no brass, no gold), a few leaves twined on it. Transparent background.
- garden/watering-can | 512x512 png alpha | ref: garden/rose-bush-seed | A dented grey tin watering can with a rose spout. Transparent background.
- sky/chapter-seal | 768x768 png alpha | ref: bg/sky-panel | A softly glowing crest made of cool white and pale blue light and dust, like a gentle halo ring with a faint inner weave; no star points, no letters, never gold. Transparent background (the glow fades to full transparency).
- protege/sprout-sprite | 512x512 png alpha | ref: avatars/red-panda | a small leaf creature with a sprout on its head, calm and attentive, simple dot eyes and a small smile
- protege/sprout-sprite-puzzled | 512x512 png alpha | ref: protege/sprout-sprite | a small leaf creature with a sprout on its head, head tilted, one small question-shaped curl of air above it (no question mark glyph), curious, never sad
- protege/sprout-sprite-happy | 512x512 png alpha | ref: protege/sprout-sprite | a small leaf creature with a sprout on its head, delighted, eyes crescent-shaped, arms or paws up
- protege/cloud-pup | 512x512 png alpha | ref: avatars/red-panda | a small soft cloud with four little paws, calm and attentive, simple dot eyes and a small smile
- protege/cloud-pup-puzzled | 512x512 png alpha | ref: protege/cloud-pup | a small soft cloud with four little paws, head tilted, one small question-shaped curl of air above it (no question mark glyph), curious, never sad
- protege/cloud-pup-happy | 512x512 png alpha | ref: protege/cloud-pup | a small soft cloud with four little paws, delighted, eyes crescent-shaped, arms or paws up
- protege/pebble-friend | 512x512 png alpha | ref: avatars/red-panda | a round smooth grey stone creature, calm and attentive, simple dot eyes and a small smile
- protege/pebble-friend-puzzled | 512x512 png alpha | ref: protege/pebble-friend | a round smooth grey stone creature, head tilted, one small question-shaped curl of air above it (no question mark glyph), curious, never sad
- protege/pebble-friend-happy | 512x512 png alpha | ref: protege/pebble-friend | a round smooth grey stone creature, delighted, eyes crescent-shaped, arms or paws up

### B10: Landing, promises, onboarding tiles, brand mark, icons, splash (17)

- onboarding/handover-now | 768x768 png alpha skin | ref: states/talk-to-grown-up | An adult hand passing a phone (blank screen) into a child's two cupped hands, seen close, warm and calm. Transparent background.
- onboarding/handover-later | 768x768 png alpha | ref: onboarding/handover-now | A phone (blank screen) resting face-up on a folded cloth beside a steel cup, quiet, nobody there. Transparent background.
- landing/listening | 1600x1200 webp skin | ref: bg/landing-hero | a 10-year-old Indian child using a wheelchair, at a desk with a phone propped up, listening and smiling (the wheelchair is simply part of the scene, not the subject), a notebook open with BLANK pages, cream-white evening lamp light; the phone screen is blank
- landing/parent-reading | 1600x1200 webp skin | ref: bg/landing-hero | an Indian parent at a kitchen table reading a phone with a calm, pleased expression, a steel cup of chai beside them; the screen is blank light
- landing/notebook | 1600x1200 webp skin | ref: bg/landing-hero | a child's hands drawing in a notebook, soft abstract marks only (no letters, digits or shapes that read as writing)
- landing/og-share | 1200x630 png | ref: bg/landing-hero | The landing-hero desk scene (same desk, notebook, tumbler, dusk window) cropped wide to 1200x630, the calm space kept centre-right. No text, no logo.
- promises/ai-honest | 768x768 png alpha | ref: states/ai-teacher-card | a small rounded laptop with a gentle cream glow beside a child's open hand
- promises/you-see | 768x768 png alpha | ref: states/ai-teacher-card | a grown-up's hand and a child's hand resting together on the same open notebook with blank pages, warm and open, seen from above (sharing, never watching from outside)
- promises/no-ads | 768x768 png alpha | ref: states/ai-teacher-card | a quiet phone face down on a cushion beside a teacup
- promises/delete | 768x768 png alpha | ref: states/ai-teacher-card | a sheet of paper folding into a small paper bird that flies away
- brand/mark | 1024x1024 png alpha | ref: - | the Taxila mark: a stylised open book seen from the front whose centre spine rises into a fountain-pen nib, warm paper cream (#F6F3EC) shapes on deep ink blue (#24346E), simple, geometric-but-hand-painted edges, no letters, no lamp, no yellow, as a rounded-square ink-blue tile with the cream book-and-nib inside, centred, the tile filling 88% of the frame. Transparent outside the tile.
- brand/app-icon | 1024x1024 png | ref: brand/mark | the Taxila mark: a stylised open book seen from the front whose centre spine rises into a fountain-pen nib, warm paper cream (#F6F3EC) shapes on deep ink blue (#24346E), simple, geometric-but-hand-painted edges, no letters, no lamp, no yellow, full-bleed ink-blue square (the OS applies the mask), the cream book-and-nib centred inside the central 66% safe zone. Opaque.
- brand/adaptive-foreground | 1024x1024 png alpha | ref: brand/app-icon | ONLY the cream book-and-nib shape from brand/app-icon, centred inside the central 66% (676 px) safe circle, everything else fully transparent.
- brand/adaptive-background | 1024x1024 png script | ref: brand/app-icon | A flat deep ink blue (#24346E) square with a very faint paper grain. Opaque. May be made by script (no image model needed).
- brand/monochrome | 1024x1024 png alpha script | ref: brand/adaptive-foreground | The book-and-nib silhouette from brand/adaptive-foreground as a single flat white (#FFFFFF) shape on full transparency, same placement. Made by script from the foreground's alpha.
- brand/splash-light | 2732x2732 png script | ref: brand/mark | Flat #F6F3EC canvas with brand/mark composited dead centre at 640x640 px. Nothing else. Made by script (no image model needed).
- brand/splash-dark | 2732x2732 png script | ref: brand/mark | Flat #121418 canvas with brand/mark composited dead centre at 640x640 px. Nothing else. Made by script (no image model needed).

### B11-B13: Teacher references, one pass per character: asha = B11, arjun = B12, uma = B13 (153 lines after expansion: 51 per character × 3; the accessory sheets below make it 156). Expand {c} to the character id.

- teacher-ref/{c}/turnaround/front | 1024x1024 webp | ref: - | Head and shoulders, front view, neutral relaxed face, mouth closed, looking straight at the camera. THIS IS THE IDENTITY ANCHOR: every later image of this character is generated with this image as the reference.
- teacher-ref/{c}/turnaround/three-quarter-left | 1024x1024 webp | ref: teacher-ref/{c}/turnaround/front | Same character, same lighting, head and shoulders turned 45 degrees to the character's right, neutral face.
- teacher-ref/{c}/turnaround/profile-left | 1024x1024 webp | ref: teacher-ref/{c}/turnaround/front | Same character, full profile facing left, neutral face.
- teacher-ref/{c}/turnaround/back | 1024x1024 webp | ref: teacher-ref/{c}/turnaround/front | Same character from directly behind: hair and garment detail.
- teacher-ref/{c}/emotions/warm-smile | 1024x1024 webp | ref: teacher-ref/{c}/turnaround/front | Head and shoulders, front three-quarter, soft genuine smile, eyes crinkling (Duchenne: cheek raise and lower-lid raise). Same identity, outfit and lighting as the front turnaround.
- teacher-ref/{c}/emotions/encouraging | 1024x1024 webp | ref: teacher-ref/{c}/turnaround/front | Head and shoulders, front three-quarter, small smile, brows gently raised, slight forward lean. Same identity, outfit and lighting as the front turnaround.
- teacher-ref/{c}/emotions/curious | 1024x1024 webp | ref: teacher-ref/{c}/turnaround/front | Head and shoulders, front three-quarter, brows raised, head tilted, interested. Same identity, outfit and lighting as the front turnaround.
- teacher-ref/{c}/emotions/thinking | 1024x1024 webp | ref: teacher-ref/{c}/turnaround/front | Head and shoulders, front three-quarter, looking slightly up and to the side, lips lightly pressed, calm (the THINKING floor state). Same identity, outfit and lighting as the front turnaround.
- teacher-ref/{c}/emotions/listening | 1024x1024 webp | ref: teacher-ref/{c}/turnaround/front | Head and shoulders, front three-quarter, soft attentive face, head tilted a little (about 4 degrees), faint smile (the LISTENING floor state). Same identity, outfit and lighting as the front turnaround.
- teacher-ref/{c}/emotions/gentle-concern | 1024x1024 webp | ref: teacher-ref/{c}/turnaround/front | Head and shoulders, front three-quarter, inner brows slightly raised, kind, NOT sad (used for content difficulty only). Same identity, outfit and lighting as the front turnaround.
- teacher-ref/{c}/emotions/delighted | 1024x1024 webp | ref: teacher-ref/{c}/turnaround/front | Head and shoulders, front three-quarter, big open smile, eyes crinkled, joyful. Same identity, outfit and lighting as the front turnaround.
- teacher-ref/{c}/emotions/playful | 1024x1024 webp | ref: teacher-ref/{c}/turnaround/front | Head and shoulders, front three-quarter, a teacher sharing a gentle joke with a class: a small lopsided smile, one eyebrow lifted a little, head tilted; warm and kind, never a smirk, a wink, a coy or a flirtatious look. Same identity, outfit and lighting as the front turnaround.
- teacher-ref/{c}/emotions/surprised | 1024x1024 webp | ref: teacher-ref/{c}/turnaround/front | Head and shoulders, front three-quarter, eyebrows high, eyes wide, mouth slightly open, happy surprise, not fear. Same identity, outfit and lighting as the front turnaround.
- teacher-ref/{c}/emotions/speaking | 1024x1024 webp | ref: teacher-ref/{c}/turnaround/front | Head and shoulders, front three-quarter, mid-sentence on an open vowel, brows animated, engaged, looking at the camera (the SPEAKING floor state). Same identity, outfit and lighting as the front turnaround.
- teacher-ref/{c}/emotions/your-turn | 1024x1024 webp | ref: teacher-ref/{c}/turnaround/front | Head and shoulders, front three-quarter, leaning in slightly toward the camera, head pitched down about 3 degrees, direct gaze, brows lightly held up, expectant and patient, never impatient (the YOUR TURN floor state). Same identity, outfit and lighting as the front turnaround.
- teacher-ref/{c}/emotions/got-it-nod | 1024x1024 webp | ref: teacher-ref/{c}/turnaround/front | Head and shoulders, front three-quarter, a small 'got it' nod caught mid-motion, chin slightly down, soft closed mouth, neutral-warm (the HEARD receipt; identical for every answer). Same identity, outfit and lighting as the front turnaround.
- teacher-ref/{c}/emotions/calm-help | 1024x1024 webp | ref: teacher-ref/{c}/turnaround/front | Head and shoulders, front three-quarter, calm, steady direct gaze, smile 0, relaxed brows, kind and serious (the safety Help sheet face). Same identity, outfit and lighting as the front turnaround.
- teacher-ref/{c}/visemes/sil | 1024x1024 webp | ref: teacher-ref/{c}/turnaround/front | Close-up of the LOWER FACE only (nose tip to chin), front view, mid-speech mouth shape: closed, relaxed. Same skin, lips and lighting.
- teacher-ref/{c}/visemes/PP | 1024x1024 webp | ref: teacher-ref/{c}/turnaround/front | Close-up of the LOWER FACE only (nose tip to chin), front view, mid-speech mouth shape: lips pressed together. Same skin, lips and lighting.
- teacher-ref/{c}/visemes/FF | 1024x1024 webp | ref: teacher-ref/{c}/turnaround/front | Close-up of the LOWER FACE only (nose tip to chin), front view, mid-speech mouth shape: lower lip tucked under the upper teeth. Same skin, lips and lighting.
- teacher-ref/{c}/visemes/TH | 1024x1024 webp | ref: teacher-ref/{c}/turnaround/front | Close-up of the LOWER FACE only (nose tip to chin), front view, mid-speech mouth shape: tongue tip just behind the upper teeth. Same skin, lips and lighting.
- teacher-ref/{c}/visemes/DD | 1024x1024 webp | ref: teacher-ref/{c}/turnaround/front | Close-up of the LOWER FACE only (nose tip to chin), front view, mid-speech mouth shape: teeth slightly apart, tongue tip up. Same skin, lips and lighting.
- teacher-ref/{c}/visemes/kk | 1024x1024 webp | ref: teacher-ref/{c}/turnaround/front | Close-up of the LOWER FACE only (nose tip to chin), front view, mid-speech mouth shape: open, tongue back. Same skin, lips and lighting.
- teacher-ref/{c}/visemes/CH | 1024x1024 webp | ref: teacher-ref/{c}/turnaround/front | Close-up of the LOWER FACE only (nose tip to chin), front view, mid-speech mouth shape: lips slightly rounded forward, teeth close. Same skin, lips and lighting.
- teacher-ref/{c}/visemes/SS | 1024x1024 webp | ref: teacher-ref/{c}/turnaround/front | Close-up of the LOWER FACE only (nose tip to chin), front view, mid-speech mouth shape: teeth nearly together, lips spread. Same skin, lips and lighting.
- teacher-ref/{c}/visemes/nn | 1024x1024 webp | ref: teacher-ref/{c}/turnaround/front | Close-up of the LOWER FACE only (nose tip to chin), front view, mid-speech mouth shape: slightly open, tongue up. Same skin, lips and lighting.
- teacher-ref/{c}/visemes/RR | 1024x1024 webp | ref: teacher-ref/{c}/turnaround/front | Close-up of the LOWER FACE only (nose tip to chin), front view, mid-speech mouth shape: slightly rounded. Same skin, lips and lighting.
- teacher-ref/{c}/visemes/aa | 1024x1024 webp | ref: teacher-ref/{c}/turnaround/front | Close-up of the LOWER FACE only (nose tip to chin), front view, mid-speech mouth shape: wide open 'aa'. Same skin, lips and lighting.
- teacher-ref/{c}/visemes/E | 1024x1024 webp | ref: teacher-ref/{c}/turnaround/front | Close-up of the LOWER FACE only (nose tip to chin), front view, mid-speech mouth shape: mid open, spread. Same skin, lips and lighting.
- teacher-ref/{c}/visemes/I | 1024x1024 webp | ref: teacher-ref/{c}/turnaround/front | Close-up of the LOWER FACE only (nose tip to chin), front view, mid-speech mouth shape: spread, smile-like 'ee'. Same skin, lips and lighting.
- teacher-ref/{c}/visemes/O | 1024x1024 webp | ref: teacher-ref/{c}/turnaround/front | Close-up of the LOWER FACE only (nose tip to chin), front view, mid-speech mouth shape: rounded open 'oh'. Same skin, lips and lighting.
- teacher-ref/{c}/visemes/U | 1024x1024 webp | ref: teacher-ref/{c}/turnaround/front | Close-up of the LOWER FACE only (nose tip to chin), front view, mid-speech mouth shape: small rounded 'oo'. Same skin, lips and lighting.
- teacher-ref/{c}/visemes/tongue-tip-up | 1024x1024 webp | ref: teacher-ref/{c}/turnaround/front | Close-up of the LOWER FACE only (nose tip to chin), front view, mid-speech mouth shape: Hindi dental: mouth slightly open, tongue tip pressed against the back of the upper teeth (as in 'ta' of 'taaraa'). Same skin, lips and lighting.
- teacher-ref/{c}/visemes/tongue-curl | 1024x1024 webp | ref: teacher-ref/{c}/turnaround/front | Close-up of the LOWER FACE only (nose tip to chin), front view, mid-speech mouth shape: Hindi retroflex: mouth slightly open, tongue tip curled back toward the roof of the mouth. Same skin, lips and lighting.
- teacher-ref/{c}/visemes/tongue-wide | 1024x1024 webp | ref: teacher-ref/{c}/turnaround/front | Close-up of the LOWER FACE only (nose tip to chin), front view, mid-speech mouth shape: Hindi open 'aa' with the jaw open and the tongue lying wide and flat. Same skin, lips and lighting.
- teacher-ref/{c}/detail/eye-closeup | 1024x1024 webp | ref: teacher-ref/{c}/turnaround/front | Extreme close-up of one eye: lashes, lid crease, iris texture with depth, the wet line, a catch-light from the upper left. Same character.
- teacher-ref/{c}/detail/iris-flat | 1024x1024 webp | ref: teacher-ref/{c}/turnaround/front | A perfectly front-on, flat, evenly lit iris and pupil disc filling the frame, no lids, no reflections, for painting the iris texture. Same character.
- teacher-ref/{c}/detail/skin-cheek | 1024x1024 webp | ref: teacher-ref/{c}/turnaround/front | Close-up of cheek and nose skin under soft light: natural texture, faint pores, no blemishes painted on, no make-up. Same character.
- teacher-ref/{c}/detail/lips-teeth | 1024x1024 webp | ref: teacher-ref/{c}/turnaround/front | Close-up of a natural open smile showing the upper teeth and lips. Same character.
- teacher-ref/{c}/detail/hair | 1024x1024 webp | ref: teacher-ref/{c}/turnaround/front | Close-up of the hairstyle: strand clumps, flyaways, how the hair catches the key light. Same character.
- teacher-ref/{c}/detail/fabric | 1024x1024 webp wrap | ref: teacher-ref/{c}/turnaround/front | Flat seamless swatch of the outfit's main fabric, evenly lit, tileable, no print text or logos. Same character.
- teacher-ref/{c}/detail/wrinkle-smile | 1024x1024 webp | ref: teacher-ref/{c}/turnaround/front | Close-up of the eye corner and cheek in a big smile: crow's feet and the cheek fold, for the compress wrinkle map. Same character.
- teacher-ref/{c}/detail/wrinkle-concern | 1024x1024 webp | ref: teacher-ref/{c}/turnaround/front | Close-up of the brow and glabella in gentle concern: the fine inner-brow knot, for the compress wrinkle map. Same character.
- teacher-ref/{c}/poses/wave | 1024x1024 webp | ref: teacher-ref/{c}/turnaround/front | waist-up, a single friendly wave with the right hand at shoulder height, warm smile. Same identity, outfit and lighting.
- teacher-ref/{c}/poses/reading | 1024x1024 webp | ref: teacher-ref/{c}/turnaround/front | waist-up, sitting, reading a closed-cover book held low (no text visible), relaxed. Same identity, outfit and lighting.
- teacher-ref/{c}/poses/watering-can | 1024x1024 webp | ref: teacher-ref/{c}/turnaround/front | waist-up, holding a tin watering can, looking down at it kindly. Same identity, outfit and lighting.
- teacher-ref/{c}/poses/telescope | 1024x1024 webp | ref: teacher-ref/{c}/turnaround/front | waist-up, beside a small telescope on a tripod, one hand on it, looking up. Same identity, outfit and lighting.
- teacher-ref/{c}/poses/one-moment | 1024x1024 webp | ref: teacher-ref/{c}/turnaround/front | waist-up, a small 'one moment' hand gesture (index finger raised softly beside the face), thinking face. Same identity, outfit and lighting.
- teacher-ref/{c}/poses/point-to-tray | 1024x1024 webp | ref: teacher-ref/{c}/turnaround/front | head and shoulders, gaze down and to the viewer's right toward an off-frame tray, one hand pointing lightly that way. Same identity, outfit and lighting.
- teacher-ref/{c}/stage/classroom-wide | 1536x1024 webp | ref: teacher-ref/{c}/turnaround/front | The character head-and-shoulders, centred, in a soft-focus warm Indian classroom (blank green board, window light, plants), no writing on the board.
- teacher-ref/{c}/stage/on-stage | 1024x1024 webp | ref: teacher-ref/{c}/turnaround/front, bg/stage-{stage} | The character head-and-shoulders, centred, in front of the dusk stage ground (bg/stage-{stage}: dusk blue #26304A, cream light pool behind the head). This is the colour script for the SH light probe of that stage.

### B11-B13: the one accessory sheet per character (3; each goes in its character's batch)

- teacher-ref/asha/detail/ear-stud | 1024x1024 webp | ref: teacher-ref/asha/turnaround/front | Extreme close-up of her ear with the small stud earring and the flyaway strands of the ponytail near it. Same character.
- teacher-ref/arjun/detail/glasses | 1024x1024 webp | ref: teacher-ref/arjun/turnaround/front | His round thin-rim glasses alone, front view and folded side view on a neutral surface, dark metal rim, clear lenses, no logo. Same character.
- teacher-ref/uma/detail/pallu-drape | 1024x1024 webp | ref: teacher-ref/uma/turnaround/front | The saree pallu drape over the left shoulder and the thin contrasting border, close, showing the weave and how the edge falls. Same character.

### B13 (after uma): cast lineup (1)

- teacher-ref/cast/lineup | 1536x1024 webp | ref: teacher-ref/asha/turnaround/front, teacher-ref/arjun/turnaround/front, teacher-ref/uma/turnaround/front | Asha, Arjun and Uma standing waist-up side by side, front view, neutral warm expressions, same studio background and lighting, each matching their own front turnaround exactly.
