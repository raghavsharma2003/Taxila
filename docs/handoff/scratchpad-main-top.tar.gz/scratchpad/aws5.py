exec(open('awsenv.py').read())
import json
for r in ['us-east-1','ap-south-1']:
    try:
        x=boto3.client('bedrock-runtime',region_name=r).converse(modelId='amazon.nova-micro-v1:0' if r=='us-east-1' else 'apac.amazon.nova-micro-v1:0',messages=[{'role':'user','content':[{'text':'hi'}]}],inferenceConfig={'maxTokens':5})
        print(r,'OK',x['output'])
    except Exception as e: print(r,'ERR',str(e)[:200])
p=boto3.client('polly',region_name='ap-south-1')
vs=[]
for lang in ['hi-IN','en-IN']:
    v=p.describe_voices(LanguageCode=lang,IncludeAdditionalLanguageCodes=True)['Voices']
    for x in v: vs.append(x); print('polly',lang,x['Id'],x['Gender'],x['SupportedEngines'],x.get('AdditionalLanguageCodes'))
json.dump(vs,open('polly-voices.json','w'))
try:
    o=p.synthesize_speech(Text='Achha, toh batao, teen chauthai bada hai ya do tihai? Socho zara.',VoiceId='Kajal',Engine='generative',LanguageCode='hi-IN',OutputFormat='mp3')
    open('polly-kajal-gen.mp3','wb').write(o['AudioStream'].read()); print('polly synth OK generative')
except Exception as e: print('polly synth ERR',str(e)[:200])
t=boto3.client('transcribe',region_name='ap-south-1')
try: print('transcribe list', t.list_transcription_jobs(MaxResults=1)['ResponseMetadata']['HTTPStatusCode'])
except Exception as e: print('transcribe ERR',str(e)[:200])
