const { getKit } = await import("/home/user/Taxila/server/content/index.js");
const { initLessonState, step } = await import("/home/user/Taxila/server/director/state.js");
const NE = { outcome: "no_evidence", flags: {}, source: "test", confidence: 1 };
for (const id of ["c5-maths-ch02-t01","c6-maths-ch07-t01","c4-maths-ch05-t01","c7-maths-ch08-t01"]) {
  const kit = await getKit(id, { generate: false }); const cl=+id[1];
  const ctx = { protege: { name: "Golu", what: "x" }, teacherName: "Asha", teacherId: "asha", sessionId: `b-${id}`, lang: "hinglish", classLevel: cl, ageBand: cl <= 4 ? "6-9" : "10-15", firstName: "A", interests: [] };
  let r = step(initLessonState({ topicId: id, kit, ctx, seed: 7, now: 0 }), { event: "start", kit, now: 0 });
  const seq = [];
  for (let i = 0; i < 9; i++) { r = step(r.state, { event: "turn", kit, cls: NE, now: (i + 1) * 20000 }); const m = r.state.module; seq.push(`${r.move.kind}:${m ? m.engine + (m.itemId ? "[bound]" : "") : "-"}`); }
  console.log(id, seq.join(" "));
}
