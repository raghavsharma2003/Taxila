// 14.3 deploy (from /home/user/taxila-int, int/r5-rel143): deploy-azure with
//  - the 14.2 CHAT overflow lane, re-stated unchanged (southindia twins; key as a Container App secret, never printed);
//  - the continuer for the owner cohort (dc-r143-continuer-owner-cohort): TAXILA_ACK_CONTINUER_FOR as a Container App
//    secret holding taxila-web's current owner cohort (TAXILA_DUPLEX_LIVE_FOR, plain env or secret). The value is never
//    printed, logged or written to disk; only its entry count is shown.
// usage: NODE_USE_ENV_PROXY=1 node --env-file=/home/user/Taxila/.env.local deploy-143.mjs [--dry-run]
import { spawnSync } from "node:child_process";
const { arm, SUB_PATH } = await import("/home/user/taxila-int/infra/azure.mjs");
const ep = process.env.AZURE_OPENAI_ENDPOINT_SIN;
if (!ep || !process.env.AZURE_OPENAI_API_KEY_SIN) { console.error("deploy-143: AZURE_OPENAI_ENDPOINT_SIN / _KEY_SIN missing"); process.exit(2); }
const base = `${SUB_PATH()}/resourceGroups/${process.env.AZURE_RESOURCE_GROUP}/providers/Microsoft.App/containerApps/taxila-web`;
const a = await arm("GET", `${base}?api-version=2024-03-01`);
const e = (a.properties.template.containers[0].env || []).find((x) => x.name === "TAXILA_DUPLEX_LIVE_FOR");
let value = e?.value ?? null;
if (!value && e?.secretRef) {
  const sec = (await arm("POST", `${base}/listSecrets?api-version=2024-03-01`)).value || [];
  value = sec.find((s) => s.name === e.secretRef)?.value ?? null;
}
if (!value || !value.trim()) { console.error("deploy-143: no owner cohort on taxila-web (TAXILA_DUPLEX_LIVE_FOR empty): refusing"); process.exit(2); }
console.log(`deploy-143: owner cohort read (${value.split(",").filter((x) => x.trim()).length} entries; value not shown)`);
const twins = "taxila-fast,taxila-brain,grok-4-1-fast-non-reasoning,DeepSeek-V4-Pro,taxila-gpt6,taxila-gpt6-luna,gpt-5.6-terra";
const args = ["scripts/deploy-azure.mjs",
  "--set", `AZURE_OPENAI_ENDPOINT_OVERFLOW=${ep}`, "--secret", "AZURE_OPENAI_API_KEY_OVERFLOW=AZURE_OPENAI_API_KEY_SIN",
  "--set", `TAXILA_OVERFLOW_DEPLOYMENTS=${twins}`,
  "--secret", "TAXILA_ACK_CONTINUER_FOR=OWNER_COHORT",
  ...process.argv.slice(2)];
const r = spawnSync(process.execPath, args, { stdio: "inherit", cwd: "/home/user/taxila-int", env: { ...process.env, OWNER_COHORT: value } });
process.exit(r.status ?? 1);
