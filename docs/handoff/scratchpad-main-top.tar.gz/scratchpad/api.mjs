// Same as scripts/dev-api.mjs but on :8795 (other workstreams may hold :8790).
import http from "http";
import { readFileSync } from "fs";
const ROOT = "/home/user/Taxila/";
for (const line of readFileSync(ROOT + ".env.local", "utf8").split("\n")) {
  const m = line.match(/^([A-Z0-9_]+)=(.*)$/);
  if (m && !process.env[m[1]]) process.env[m[1]] = m[2].replace(/^"(.*)"$/, "$1");
}
const { handle } = await import(ROOT + "server/index.js");
http.createServer(handle).listen(8795, () => console.log("api on :8795"));
