// Deploy wrapper: copies the OWNER COHORT value (taxila-web's current TAXILA_DUPLEX_LIVE_FOR, plain env or secret) into the
// child's environment as OWNER_COHORT, so deploy-azure's --secret NAME=OWNER_COHORT can store it as a Container App secret.
// The value is never printed, logged or written to disk. usage: node deploy-with-cohort.mjs <deploy-azure args...>
// (run from the Taxila checkout with --env-file=.env.local)
import { spawnSync } from "node:child_process";
const { arm, loadEnv, SUB_PATH } = await import("/home/user/Taxila/infra/azure.mjs");
loadEnv?.();
const base = `${SUB_PATH()}/resourceGroups/${process.env.AZURE_RESOURCE_GROUP}/providers/Microsoft.App/containerApps/taxila-web`;
const a = await arm("GET", `${base}?api-version=2024-03-01`);
const e = (a.properties.template.containers[0].env || []).find((x) => x.name === "TAXILA_DUPLEX_LIVE_FOR");
let value = e?.value ?? null;
if (!value && e?.secretRef) {
  const sec = (await arm("POST", `${base}/listSecrets?api-version=2024-03-01`)).value || [];
  value = sec.find((s) => s.name === e.secretRef)?.value ?? null;
}
if (!value || !value.trim()) { console.error("deploy-with-cohort: no owner cohort on taxila-web (TAXILA_DUPLEX_LIVE_FOR empty): refusing"); process.exit(2); }
console.log(`deploy-with-cohort: owner cohort read (${value.split(",").filter(Boolean).length} entries; value not shown)`);
const r = spawnSync(process.execPath, ["--env-file=.env.local", "scripts/deploy-azure.mjs", ...process.argv.slice(2)], { stdio: "inherit", env: { ...process.env, OWNER_COHORT: value } });
process.exit(r.status ?? 1);
