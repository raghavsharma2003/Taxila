import json,collections
m=json.load(open('maths-engine-map.json')); s=json.load(open('science-engine-map.json'))
T={}  # id -> (class, subj, primary, anyset)
for tid,v in m['topics'].items():
    c=int(tid.split('-')[0][1:]); T[tid]=(c,'maths',v['primary'],{v['primary'],*v['secondary']})
for t in s['topics']:
    p = t['engine'].split('@')[0] if t['format']=='engine' else 'G:'+t['generic']
    T[t['id']]=(t['class'],'sci',p,{p})
cnt=collections.Counter(v[2] for v in T.values())
N=len(T); print('total',N)
cost={'number-grid':1,'place-value':3,'fractions':3,'multiply-divide':3,'geoboard':3,'data-graphs':3,'patterns':3,'measure':3,'shape-lab':3,'algebra-tiles':3,'geo-construct':3,'solids':3,'algebra-moves':3,
 'float-sink':1.5,'magnets':2,'ecosystem':2,'sound':2,'indicator-lab':2,'measure-lab':2,'heat-flow':2,'particles':3,'circuits':3,'optics':3,'plant-lab':3,'body-systems':3,'sky':3,'mixtures-lab':3,'water-cycle':3,'motion-lab':5}
eng=[k for k in cnt if not k.startswith('G:')]
# pure greedy on primary
chosen=[];cov=0
for i in range(14):
    best=max((e for e in eng if e not in chosen), key=lambda e: cnt[e])
    chosen.append(best); cov+=cnt[best]; print(i+1,best,cnt[best],cost.get(best,2),'cum',cov, f'{cov/N:.1%}')

def report(name,S,generic=()):
    byc=collections.defaultdict(lambda:[0,0]); tot=0; anyc=0
    for tid,(c,sub,p,a) in T.items():
        k=(c,sub); byc[k][1]+=1
        if p in S or p in generic: byc[k][0]+=1; tot+=1
        if (p in S or p in generic) or (a & set(S)): anyc+=1
    print(f'\n{name}: primary {tot}/{N} = {tot/N:.1%}; primary-or-secondary {anyc}/{N} = {anyc/N:.1%}; cost {sum(cost.get(e,2) for e in S)}')
    for sub in ['maths','sci']:
        row=[f'C{c}:{byc[(c,sub)][0]}/{byc[(c,sub)][1]}' for c in range(1,10) if byc[(c,sub)][1]]
        mt=sum(byc[(c,sub)][0] for c in range(1,10)); mn=sum(byc[(c,sub)][1] for c in range(1,10))
        print(' ',sub,f'{mt}/{mn}={mt/mn:.0%}',' '.join(row))
A=['place-value','multiply-divide','number-line','data-graphs','motion-lab','patterns','geo-construct','measure','fractions','geoboard','sky','collections']
B=['number-line','collections','place-value','fractions','multiply-divide','data-graphs','patterns','geoboard','measure','motion-lab','sky','water-cycle']
C=['number-line','collections','place-value','fractions','multiply-divide','data-graphs','patterns','geoboard','tape-diagram','motion-lab','sky','water-cycle']
D=['number-line','collections','place-value','fractions','multiply-divide','data-graphs','patterns','geoboard','measure','motion-lab','sky','circuits']
G=['G:sorter','G:sequence','G:label-diagram','G:story','G:time-lapse','G:classification-key','G:habitat-match']
for n,S in [('A greedy',A),('B',B),('C',C),('D',D)]: report(n,S)
report('B + generic T2a layer',B,G)
print({k:v for k,v in cnt.items() if k.startswith('G:')})

print('\n=== FINAL')
merge={'measure-lab':'measure','heat-flow':'particles','number-grid':'patterns','symmetry':'shape-lab','chance':'data-graphs','algebra-moves':'symbol-lab','rule-lab':'symbol-lab'}
T2={tid:(c,sub,merge.get(p,p),{merge.get(x,x) for x in a}) for tid,(c,sub,p,a) in T.items()}
T.clear(); T.update(T2)
cnt=collections.Counter(v[2] for v in T.values())
V1=['number-line','collections','place-value','fractions','multiply-divide','data-graphs','patterns','geoboard','measure','motion-lab','sky','water-cycle']
GEN=['G:sorter','G:sequence','G:time-lapse','G:label-diagram','G:microscope','G:classification-key','G:habitat-match','G:pattern','G:thali-builder','G:spot-the-hazard','G:formula-builder']
report('V1 T1 only',V1); report('V1 + T2a/diagram layer',V1,GEN)
for e in V1: print(e,cnt[e])
print('v1.1 candidates', {e:cnt[e] for e in ['balance','tape-diagram','shape-lab','geo-construct','circuits','ecosystem','indicator-lab','mixtures-lab','optics','particles','clock-calendar','money','coord-grid','angles']})
rest=collections.Counter(v[2] for v in T.values() if v[2] not in V1 and v[2] not in GEN)
print('fallback topics',sum(rest.values()), rest.most_common(40))
