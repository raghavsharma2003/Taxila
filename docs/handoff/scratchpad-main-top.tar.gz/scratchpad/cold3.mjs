import { performance } from "node:perf_hooks";
const { __lexicon } = await import("/home/user/Taxila/server/safety/lexicon.js");
const s = "aap mumi se achi ho";
const out = [];
for (const sh of __lexicon.SHAPES) { const a = performance.now(); sh.re.exec(s); out.push([performance.now() - a, sh.id, sh.re.source.length]); }
out.sort((a, b) => b[0] - a[0]);
console.log("total", out.reduce((a, b) => a + b[0], 0).toFixed(1)); console.log(out.slice(0, 8).map((x) => `${x[0].toFixed(1)} ${x[1]} ${x[2]}`).join("\n"));
