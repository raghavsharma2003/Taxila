// start one taxila-conductor-canary execution and wait for its status (read-only apart from the start)
const { arm, loadEnv, SUB_PATH } = await import("/home/user/Taxila/infra/azure.mjs");
loadEnv?.();
const RG = process.env.AZURE_RESOURCE_GROUP;
const JOB = `${SUB_PATH()}/resourceGroups/${RG}/providers/Microsoft.App/jobs/taxila-conductor-canary`;
const API = "api-version=2024-03-01";
const job = await arm("GET", `${JOB}?${API}`);
console.log("job image:", job.properties.template.containers[0].image.split("/").pop());
const started = await arm("POST", `${JOB}/start?${API}`, {});
const name = started?.name || started?.id?.split("/").pop();
console.log("started:", name);
for (let i = 0; i < 40; i++) {
  await new Promise((r) => setTimeout(r, 15000));
  const ex = await arm("GET", `${JOB}/executions/${name}?${API}`, undefined, { allow404: true });
  const st = ex?.properties?.status;
  if (st && !["Running", "Processing"].includes(st)) { console.log("status:", st); process.exit(st === "Succeeded" ? 0 : 1); }
}
console.log("status: still running after 10 min"); process.exit(2);
