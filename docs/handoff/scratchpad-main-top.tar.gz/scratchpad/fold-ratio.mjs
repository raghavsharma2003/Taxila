import { fold, newLedger } from "/home/user/taxila-int/server/learner/kt/ledger.js";
import { makeLog } from "/home/user/taxila-int/server/learner/kt/gen.js";
const L0 = () => newLedger({ childId: "11111111-1111-4111-8111-111111111111", classLevel: 5 });
const events = makeLog(41, { sessions: 6, perSession: [40, 40] }).map(({ seq, ...e }, i) => ({ ...e, id: `x${i}` }));
let L = L0();
for (let i = 0; i < 20; i++) L = fold(L, events.map((e) => ({ ...e, id: `${e.id}-${i}`, sessionId: `${e.sessionId}-${i}` })));
const one = { ...events[0], id: "probe-one", sessionId: L.session.sessionId };
const N = 50;
const best = (fn) => { let b = Infinity; for (let r = 0; r < 3; r++) { const t0 = performance.now(); fn(); b = Math.min(b, (performance.now() - t0) / N); } return b; };
const out = [];
for (let k = 0; k < 12; k++) {
  const ms = best(() => { for (let i = 0; i < N; i++) fold(L, [{ ...one, id: `probe-${i}` }]); });
  const c = best(() => { for (let i = 0; i < N; i++) structuredClone(L); });
  out.push(`${ms.toFixed(2)}/${c.toFixed(2)}=${(ms / c).toFixed(2)}`);
}
console.log(out.join("  "));
