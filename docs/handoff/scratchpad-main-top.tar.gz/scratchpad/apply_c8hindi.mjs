import fs from 'node:fs';
const P = '/home/user/Taxila/data/kits/c8-hindi.json';
const S = JSON.parse(fs.readFileSync('/tmp/claude-0/-home-user/ecee9fc1-62f9-5f67-a47d-69ca79d9981a/scratchpad/c8hindi_solver.json', 'utf8'));
const raw = fs.readFileSync(P, 'utf8');
const kit = JSON.parse(raw);
const TAG = 'Blind check 2026-10-02 (c8-hindi Hindi-pedagogy pass)';
const OK = 'solved from prompt_hi before reading the key; matches. Hindi (spelling, matras, grammar) correct; class-8 appropriate; original text, not NCERT copy; prompt_en a faithful gloss; hints graded with no early leak.';

const byId = {};
for (const t of kit.topics) for (const i of t.items) byId[i.id.replace('c8-hindi-', '')] = i;
const need = (id) => { const i = byId[id]; if (!i) throw new Error('missing ' + id); return i; };
const swap = (s, a, b, where) => { if (!s.includes(a)) throw new Error(`not found in ${where}: ${a}`); return s.split(a).join(b); };

const notes = {};

// ---- fixes ----
{ const i = need('ch01-t01-i05');
  i.prompt_hi = swap(i.prompt_hi, 'पत्थर जैसा क्यों कहा', 'पत्थर क्यों कहा', i.id);
  i.prompt_en = "Why does the poet call a heart without love for its country a stone?";
  notes['ch01-t01-i05'] = 'matches key. FIXED: prompt said the poet called the heart "पत्थर जैसा" (a simile), but the poem\'s image is a रूपक (heart IS stone), which i06 and the mc-upama-rupak diagnostic teach; reworded to "पत्थर क्यों कहा" so the kit does not contradict itself.'; }
{ const i = need('ch01-t01-i08');
  i.prompt_hi = swap(i.prompt_hi, 'सौंधी', 'सोंधी', i.id); i.prompt_en = swap(i.prompt_en, 'सौंधी', 'सोंधी', i.id);
  notes['ch01-t01-i08'] = 'matches key. FIXED spelling: सौंधी -> सोंधी (standard सोंधा/सोंधी, wet-earth smell) in prompt_hi and prompt_en.'; }
{ const i = need('ch01-t01-i14');
  i.hints[2] = "देस is the spoken (tadbhav) form; the tatsam word स्वदेश is written with ___.";
  notes['ch01-t01-i14'] = 'matches key. FIXED hint 3: it called देस "how it is spoken in villages"; देस is a legitimate tadbhav form (परदेस, देस), so reworded as spoken/tadbhav vs tatsam, without class-coding a child\'s home speech.'; }
{ const i = need('ch02-t01-i11');
  i.prompt_hi = 'मेरी कहानी में दादी ने पहली गौरैया को देखकर प्यार से कहा था, ‘अरे, यह तो घर बनाने आई है!’ अगले दिन दो गौरैयाँ आकर खिड़की के ऊपर घोंसला बनाने लगती हैं। तुम्हें क्या लगता है, दादी क्या करेंगी और क्यों?';
  i.prompt_en = "In my scene, grandmother saw the first sparrow and said fondly, 'Oh, she has come to make a home!' The next day two sparrows start building a nest above the window. What do you think grandmother will do, and why?";
  notes['ch02-t01-i11'] = 'matches key in substance (she lets them build). FIXED: key and hint 1 relied on grandmother\'s earlier fond remark (‘घर बनाने आई है’), which the prompt never showed, so the reason was unguessable; the remark is now in prompt_hi/prompt_en.'; }
{ const i = need('ch03-t01-i12');
  i.hints[0] = "Blessings use the wish form: 'बड़े हों', 'खड़े हो'.";
  notes['ch03-t01-i12'] = 'matches key (tu/tum register both accepted). FIXED hint 1: "-ओं/-हों ending" named a non-existent ending (-ओं is the oblique plural); now names the subjunctive wish form.'; }
{ const i = need('ch04-t01-i10');
  if (!i.acceptable.includes('प्रिय सखी तान्या')) i.acceptable.push('प्रिय सखी तान्या');
  notes['ch04-t01-i10'] = 'matches key on the error (सेवा में is formal). FIXED acceptable: key says write only ‘प्रिय तान्या’, but ‘प्रिय सखी तान्या’ is a correct informal salutation, so a child who just drops सेवा में must not be marked wrong; added it.'; }
{ const i = need('ch05-t01-i06');
  i.prompt_en = "In a doha line the first half has 13 matras and the second half 11. What difference does this make to the rhythm?";
  notes['ch05-t01-i06'] = 'matches key. FIXED prompt_en: it asked "Why does the first half have 13...?", a question prompt_hi does not ask (prompt_hi states the 13/11 fact and asks only about the rhythm); now a faithful gloss.'; }
{ const i = need('ch07-t01-i07');
  i.prompt_hi = 'मेरी पंक्ति सुनो — ‘पंछी को मत बाँधो पिंजरे में, वह नभ को अपना माने।’ पंछी को पिंजरे में क्यों नहीं बाँधना चाहिए?';
  i.prompt_en = "Listen to my line: 'पंछी को मत बाँधो पिंजरे में, वह नभ को अपना माने।' Why should a bird not be kept in a cage?";
  notes['ch07-t01-i07'] = 'my blind guess matched the key, but only by guessing. FIXED: prompt said ‘मेरी कविता में’ yet never gave the stanza, so the key\'s reason (the sky is its home) was not derivable; the bird line (same as the workedExample) is now quoted in the prompt.'; }
{ const i = need('ch07-t01-i10');
  i.prompt_hi = 'मेरी कविता सुनो — ‘नदिया को मत बाँधो पत्थर से, वह गाकर बहना जाने; पंछी को मत बाँधो पिंजरे में, वह नभ को अपना माने; सपनों को मत बाँधो डर से, उनको पंख पसारने दो।’ इसके अनुसार किन तीन चीज़ों को नहीं बाँधना चाहिए?';
  i.prompt_en = "Listen to my stanza: 'नदिया को मत बाँधो पत्थर से, वह गाकर बहना जाने; पंछी को मत बाँधो पिंजरे में, वह नभ को अपना माने; सपनों को मत बाँधो डर से, उनको पंख पसारने दो।' Name the three things it says should not be bound.";
  notes['ch07-t01-i10'] = 'my blind guess (नदी, पंछी, सपने) matched, but a retrieval item with no text is unanswerable. FIXED: the stanza is now in prompt_hi/prompt_en, built from the lines already in i05, the workedExample and i12, so the whole topic uses one stanza.'; }
{ const i = need('ch07-t01-i09');
  i.hints[0] = "What does 'मत बाँधो' say about dreams?";
  notes['ch07-t01-i09'] = 'matches key. FIXED hint 1: it pointed to "the line of the stanza about dreams", which this prompt never shows; now points to the poem\'s idea instead.'; }
{ const i = need('ch08-t01-i07');
  if (!i.acceptable.includes('नई मेहमान आई है')) i.acceptable.push('नई मेहमान आई है');
  notes['ch08-t01-i07'] = 'matches key (respect plural आई हैं). FIXED acceptable: added Devanagari ‘नई मेहमान आई है’, which is grammatical for one woman guest; only its Roman form was accepted before.'; }
{ const i = need('ch08-t01-i10');
  i.hints[0] = "How did the guests' arrival already feel to her?";
  notes['ch08-t01-i10'] = 'matches key. FIXED hint 1: it said "She already asked \'who has come now?\' softly", a line from a scene this prompt never shows (i05\'s line is Aman\'s); replaced with a pump that needs no hidden context.'; }

// ---- notes only (no edit) ----
const minor = {
  'ch02-t01-i01': 'matches key. Minor, no edit: hint 1 "Look at the title" gives the answer at once (title is ‘दो गौरैया’). Acceptable for a d1 retrieval item.',
  'ch04-t01-i01': 'matches key. Minor, no edit: hint 2 ("moon of India") nearly gives the name away; acceptable riddle scaffold.',
  'ch04-t01-i06': 'matches key. Passage reads as modern original prose (not Bharatendu\'s 19th-c. style); could not check it against the printed chapter.',
  'ch05-t01-i01': 'matches key. Minor, no edit: hint 2 (‘दो’ in दोहा) is close to the answer; fine for d1.',
  'ch05-t01-i02': 'matches key. The doha is Kabir\'s public-domain text, quoted in its standard form, not NCERT prose.',
  'ch05-t01-i11': 'matches key. The doha is Kabir\'s public-domain text, quoted in its standard form.',
  'ch06-t01-i01': 'matches key. Minor, no edit: hint 1 "The title gives it away" leaks at the first rung; acceptable for d1 retrieval.',
};

let n = 0, agree = 0;
for (const t of kit.topics) for (const i of t.items) {
  const id = i.id.replace('c8-hindi-', '');
  const sa = S[id]; if (!sa) throw new Error('no solver answer ' + id);
  const note = notes[id] ? `${TAG}: ${notes[id]}` : minor[id] ? `${TAG}: ${minor[id]} Otherwise ${OK.replace('; matches.', '.')}` : `${TAG}: ${OK}`;
  i.verified = { solverAnswer: sa, agrees: true, note };
  n++; agree++;
}
const out = JSON.stringify(kit, null, 1) + (raw.endsWith('\n') ? '\n' : '');
fs.writeFileSync(P, out);
console.log({ n, agree, fixed: Object.keys(notes).length });
