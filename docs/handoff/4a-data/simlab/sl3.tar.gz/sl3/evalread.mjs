import fs from "fs";
import { evidenceRead } from "/home/user/Taxila/server/agent/read.js";
import { earnedRead } from "/home/user/Taxila/server/agent/agent.js";
const D = process.argv[2] + "/records/";
const L = { not: 0, partly: 1, understood: 2 };
const rows = [];
for (const f of fs.readdirSync(D).filter((f) => f.includes("agent_gpt6"))) {
  const r = JSON.parse(fs.readFileSync(D + f));
  const le = r.lane2?.agent?.learner ?? {};
  for (const [k, truth] of Object.entries(r.state ?? {})) {
    const v = le[k]; const g = v?.graded ?? [];
    // truth-by-design graded list: the decided outcomes in order for this skill
    const dg = r.turns.filter((t) => t.decided && t.decided.skillId === k).map((t) => ({ kind: t.decided.kind, g: t.decided.outcome === "right" ? "correct" : "wrong" }));
    rows.push({ truth, stored: v?.read ?? null, g, dg });
  }
}
const score = (name, fn) => { let n = 0, agree = 0, over = 0, under = 0, none = 0;
  for (const r of rows) { const read = fn(r); if (!read || read === "unknown") { none++; continue; } n++; if (read === r.truth) agree++; else if (L[read] > L[r.truth]) over++; else under++; }
  console.log(name.padEnd(28), `read ${n}/${rows.length} agree ${agree} (${(100 * agree / n).toFixed(0)}%) over ${over} (${(100 * over / n).toFixed(0)}%) under ${under}`); };
console.log("skills", rows.length, "with graded", rows.filter((r) => r.g.length).length, "truth", JSON.stringify(rows.reduce((a, r) => (a[r.truth] = (a[r.truth] ?? 0) + 1, a), {})));
score("stored", (r) => r.stored);
score("earned(understood claim)", (r) => (r.g.length ? earnedRead("understood", r.g) : null));
for (const bar of [0.5, 0.6, 0.7, 0.8, 0.85, 0.9]) score(`evidence bar ${bar}`, (r) => evidenceRead(r.g, { bar }));
for (const bar of [0.6, 0.7, 0.8]) score(`evidence(decided) bar ${bar}`, (r) => evidenceRead(r.dg, { bar }));
score("stored else evidence .7", (r) => r.stored ?? evidenceRead(r.g, { bar: 0.7 }));
score("earned on graded, else stored", (r) => (r.g.length ? earnedRead("understood", r.g) : r.stored));
for (const bar of [0.7, 0.8]) score(`evidence ${bar} on graded, else stored`, (r) => (r.g.length ? evidenceRead(r.g, { bar }) : r.stored));
score("earned(stored claim) on graded", (r) => (r.g.length ? earnedRead(r.stored ?? "understood", r.g) : r.stored));
