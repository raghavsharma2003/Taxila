// offline: regenerate the agent arm's end summary with the read-aware writer, re-judge old vs new (judge 1)
import { readFileSync, writeFileSync, existsSync } from "fs";
import { MODELS } from "./lib.mjs";
import { judgeLesson, understandingScore } from "./judge.mjs";
const { endMessages, END_SCHEMA, checkOf } = await import("../../server/routes/lesson.js");
const { chat, DEPLOY } = await import("../../server/azure.js");
const { earnedRead } = await import("../../server/agent/agent.js");
const REREAD = process.env.REREAD === "1";
const run = process.argv[2], arm = process.argv[3] || "agent_gpt6", out = process.argv[4];
const dir = new URL(`./results/${run}/`, import.meta.url).pathname;
const P = Object.fromEntries(JSON.parse(readFileSync(new URL("./personas.json", import.meta.url))).map((p) => [p.id, p]));
const scores = JSON.parse(readFileSync(dir + "scores.json"));
const lessons = scores.lessons.filter((l) => l.arm === arm);
const res = existsSync(out) ? JSON.parse(readFileSync(out)) : {};
const teacher = { name: "Asha", pronouns: { subject: "she", object: "her" } };
async function one(l) {
  if (res[l.persona]?.newU && res[l.persona]?.oldU) return;
  const rec = JSON.parse(readFileSync(`${dir}records/${l.persona}--${arm}--text.json`));
  const p = P[l.persona]; if (!rec.end?.facts) return;
  const byTitle = Object.fromEntries(p.skills.map((s) => [s.title, s.id]));
  const learner0 = rec.lane2?.agent?.learner ?? {};
  const learner = REREAD ? Object.fromEntries(Object.entries(learner0).map(([k, v]) => [k, v.read === "understood" ? { ...v, read: earnedRead("understood", v.graded ?? []) } : v])) : learner0;
  const facts = { ...rec.end.facts, skills: rec.end.facts.skills.map((s) => { const c = checkOf(learner[byTitle[s.skill]]); return c ? { ...s, check: c } : s; }) };
  const childTurns = rec.turns.filter((t) => t.child?.say).map((t) => ({ text: String(t.child.say) }));
  const { json } = await chat(DEPLOY.fast, endMessages({ child: { first_name: p.name, class_level: p.classLevel }, teacher, facts, childTurns }), { schema: END_SCHEMA, schemaName: "lesson_end", effort: "low", maxTokens: 2000, timeoutMs: 40_000 });
  const recNew = { ...rec, end: { ...rec.end, summary: json.summary, parentNote: json.parentNote } };
  const [jo, jn] = await Promise.all([judgeLesson(rec, p), judgeLesson(recNew, p)]);
  res[l.persona] = { checks: facts.skills.map((s) => s.check ?? null), oldSummary: rec.end.summary + "\n" + rec.end.parentNote, newSummary: json.summary + "\n" + json.parentNote,
    oldU: understandingScore(rec, p, jo), newU: understandingScore(recNew, p, jn), gateU: l.understanding, reread: Object.fromEntries(Object.entries(learner).map(([k, v]) => [k, v.read])) };
  writeFileSync(out, JSON.stringify(res, null, 1));
  process.stderr.write(".");
}
const q = [...lessons]; await Promise.all(Array.from({ length: 6 }, async () => { while (q.length) { const l = q.shift(); try { await one(l); } catch (e) { process.stderr.write(`\n${l.persona}: ${e.message}\n`); } } }));
const sum = (k, f) => Object.values(res).reduce((a, r) => a + (r[k]?.[f] ?? 0), 0);
for (const k of ["gateU", "oldU", "newU"]) console.log(k, { n: Object.values(res).filter((r) => r[k]).length, probed: sum(k, "probed"), agree: sum(k, "agree"), overclaim: sum(k, "overclaim") });
